﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using DigiOPS.TechFoundation.MultiTenancy;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
namespace PowerShellTest
{
    class MainProgram
    {

        public static void Main(string[] args)
        {
            LoggingFactory objlog = new LoggingFactory();
            LogInfo objloginfo = new LogInfo();
            MultiTenant objmultitnt = new MultiTenant();
            MultiTenantOutput objmou = new MultiTenantOutput();
            MultiTenancyInfo objminfo = new MultiTenancyInfo();
            objminfo.PSScriptPath = @"D:\188598\PS\Test.ps1";
            objminfo.ServerName = ("CTSC00806852101");
            objminfo.DataBaseName = ("DB_TEST_Thur");
            objminfo.UserName = "sa";
            objminfo.Password = "password-1";
            objminfo.SQLScriptPath = (@"D:\188598\PS\MultiTenantScript.sql");
            objloginfo.Message = ("before calling component");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            objmou = objmultitnt.GenerateDataBase(objminfo);
            objloginfo.Message = ("after calling component-main prog");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            string op = objmou.Output;
            objloginfo.Message = ("MultiTenancy - GenerateDataBase - Called.");
           objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            Console.WriteLine(op);
            Console.ReadLine();
            

            //string scriptText = "D:\\Powershellscript.ps1";
            //// create Powershell runspace
            //Runspace runspace = RunspaceFactory.CreateRunspace();

            //// open it
            //runspace.Open();
            //// create a pipeline and feed it the script text
            //Pipeline pipeline = runspace.CreatePipeline();
            //pipeline.Commands.AddScript(scriptText);          
            //pipeline.Commands.Add("Out-String");

            //// execute the script
            //Collection<PSObject> results = pipeline.Invoke();

            //// close the runspace
            //runspace.Close();

            //// convert the script result into a single string
            //StringBuilder stringBuilder = new StringBuilder();
            //foreach (PSObject obj in results)
            //{
            //    stringBuilder.AppendLine(obj.ToString());
            //}

        }
       

    }
}
