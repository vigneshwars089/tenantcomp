﻿    var rolesArray = '@ViewBag.Roles';
rolesArray = rolesArray.split(',');

var activitiesArray =;
activitiesArray = activitiesArray.split(',');

var workingHrsPerMonthArray = '150,160,170,180,200';
workingHrsPerMonthArray = workingHrsPerMonthArray.split(',');

var efficiencyPercentageArray = '5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100';
efficiencyPercentageArray = efficiencyPercentageArray.split(',');

function SetRoles(ddlRoleId)
{
    //alert(ddlRoleId);
    var ddlRole = document.getElementById(ddlRoleId);
    //alert(ddlRole);
    for (counter = 0; counter < rolesArray.length; counter++)
    {
        var option = document.createElement("option");
        option.text = rolesArray[counter];
        option.value = rolesArray[counter];
        ddlRole.options.add(option);
    }
}

function SetActivities(ddlActivityId)
{
    var ddlActivity = document.getElementById(ddlActivityId);
    for (counter = 0; counter < activitiesArray.length; counter++)
    {
        var option = document.createElement("option");
        option.text = activitiesArray[counter];
        option.value = activitiesArray[counter];
        ddlActivity.options.add(option);
    }
}

function SetWorkingHoursPerMonth(ddlWorkingHrsPerMonthId)
{
    var ddlWorkingHrsPerMonth = document.getElementById(ddlWorkingHrsPerMonthId);
    for (counter = 0; counter < workingHrsPerMonthArray.length; counter++)
    {
        var option = document.createElement("option");
        option.text = workingHrsPerMonthArray[counter] + ' Hours';
        option.value = workingHrsPerMonthArray[counter];
        ddlWorkingHrsPerMonth.options.add(option);
    }
}

function SetEfficiencyPercentage(ddlEfficiencyPercentageId)
{
    var ddlEfficiencyPercentage = document.getElementById(ddlEfficiencyPercentageId);
    for (counter = 0; counter < efficiencyPercentageArray.length; counter++)
    {
        var option = document.createElement("option");
        option.text = efficiencyPercentageArray[counter] + '%';
        option.value = efficiencyPercentageArray[counter];
        ddlEfficiencyPercentage.options.add(option);
    }
}

function AddNewRow()
{
    var oneTable = document.getElementById('tblMain');
    var newRowIndex = oneTable.rows.length - 1;
    //alert(newRowIndex);
    var oneRow = oneTable.insertRow(oneTable.rows.length);
    var oneCell = oneRow.insertCell(0);
    var elementId = 'ddlRole_' + newRowIndex.toString().trim();
    oneCell.innerHTML = '<select id="' + elementId + '"></select>';
    //alert(elementId);
    SetRoles(elementId);
    oneCell = oneRow.insertCell(1);
    elementId = 'ddlWorkingHoursPerMonth_' + newRowIndex.toString().trim();
    oneCell.innerHTML = '<select id="' + elementId + '"  onchange="javascript: Recalculate(this);" ></select>';
    SetWorkingHoursPerMonth(elementId);
    oneCell = oneRow.insertCell(2);
    elementId = 'ddlActivities_' + newRowIndex.toString().trim();
    oneCell.innerHTML = '<select id="' + elementId + '"></select>';
    SetActivities(elementId);
    oneCell = oneRow.insertCell(3);
    elementId = 'txtTimeSpentHrsPerMonth_' + newRowIndex.toString().trim();
    oneCell.innerHTML = '<input type="text" id="' + elementId + '" size="10" onchange="javascript: Recalculate(this);" />';
    oneCell = oneRow.insertCell(4);
    elementId = 'ddlEfficiencyPercentage_' + newRowIndex.toString().trim();
    oneCell.innerHTML = '<select id="' + elementId + '"  onchange="javascript: Recalculate(this);" ></select>';
    SetEfficiencyPercentage(elementId);
    oneCell = oneRow.insertCell(5);
    elementId = 'txtNumberOfAuditors_' + newRowIndex.toString().trim();
    oneCell.innerHTML = '<input type="text" id="' + elementId + '" size="10" onchange="javascript: Recalculate(this);" />';
    oneCell = oneRow.insertCell(6);
    elementId = 'txtTotalHrsSaved_' + newRowIndex.toString().trim();
    oneCell.innerHTML = '<input type="text" id="' + elementId + '" size="10" onfocus="this.blur();" />';
    oneCell = oneRow.insertCell(7);
    elementId = 'txtOverallEfficiency_' + newRowIndex.toString().trim();
    oneCell.innerHTML = '<input type="text" id="' + elementId + '" size="10" onfocus="this.blur();" />';
    oneCell = oneRow.insertCell(8);
    elementId = 'txtFTESaved_' + newRowIndex.toString().trim();
    oneCell.innerHTML = '<input type="text" id="' + elementId + '" size="10" onfocus="this.blur();" />';
    oneCell = oneRow.insertCell(9);
    elementId = 'btnDelete_' + newRowIndex.toString().trim();
    oneCell.innerHTML = '<input type="button" id="' + elementId + '" value="Delete" onclick="javascript: DeleteRow(this);" />';
}

function DeleteRow(thisObject)
{
    var runningID = thisObject.id.toString().split('_')[1];
    var oneTable = document.getElementById('tblMain');
    var rowsCount = oneTable.rows.length;
    for (counter = 1; counter < rowsCount; counter++)
    {
        var oneCell = oneTable.rows[counter].cells[0];
        var innerHTML = oneCell.innerHTML;
        var startPosition = innerHTML.indexOf('ddlRole');
        var endPosition = innerHTML.indexOf('">');
        var id = innerHTML.substr(startPosition, endPosition - startPosition).split('_')[1];
        if (id == runningID)
        {
            oneTable.deleteRow(counter);
            break;
        }
    }
    CalculateTheGrandTotals();
}

function Recalculate(thisObject)
{
    var runningID = thisObject.id.toString().split('_')[1];
    //alert(runningID);
    var workingHoursPerMonth = document.getElementById('ddlWorkingHoursPerMonth_' + runningID).value;
    var timeSpent = document.getElementById('txtTimeSpentHrsPerMonth_' + runningID).value;
    if (timeSpent == '')
    {
        timeSpent = 0;
    }
    var efficiencyUsage = document.getElementById('ddlEfficiencyPercentage_' + runningID).value;
    var numberOfAuditors = document.getElementById('txtNumberOfAuditors_' + runningID).value;
    if (numberOfAuditors == '')
    {
        numberOfAuditors = 0;
    }
    var totalHoursSaved = parseFloat(numberOfAuditors) * parseFloat(efficiencyUsage) * parseFloat(timeSpent) / 100.00;
    document.getElementById('txtTotalHrsSaved_' + runningID).value = totalHoursSaved;

    var overallEfficiency = parseFloat(efficiencyUsage) * parseFloat(timeSpent) / 100.00;
    document.getElementById('txtOverallEfficiency_' + runningID).value = overallEfficiency;

    var fteSaved = parseFloat(totalHoursSaved) / parseFloat(workingHoursPerMonth);
    document.getElementById('txtFTESaved_' + runningID).value = fteSaved;

    CalculateTheGrandTotals();
}

function CalculateTheGrandTotals()
{
    var oneTable = document.getElementById('tblMain');
    var rowsCount = oneTable.rows.length - 1;
    var fteSavedTotal = 0.0;
    var totalHoursSavedTotal = 0.0;
    var overallEfficiencyTotal = 0.0;
    for (counter = 0; counter < rowsCount; counter++)
    {
        var oneCell = oneTable.rows[counter+1].cells[0];
        var innerHTML = oneCell.innerHTML;
        var startPosition = innerHTML.indexOf('ddlRole');
        var endPosition = innerHTML.indexOf('">');
        var id = innerHTML.substr(startPosition, endPosition - startPosition).split('_')[1];

        //alert(counter);
        var oneFTESaved = document.getElementById('txtFTESaved_' + id).value;
        if (oneFTESaved != '') {
            fteSavedTotal = fteSavedTotal + parseFloat(oneFTESaved);
        }
        var oneTotalHoursSaved = document.getElementById('txtTotalHrsSaved_' + id).value;
        if (oneTotalHoursSaved != '') {
            totalHoursSavedTotal = totalHoursSavedTotal + parseFloat(oneTotalHoursSaved);
        }
        var oneOverallEfficiency = document.getElementById('txtOverallEfficiency_' + id).value;
        if (oneOverallEfficiency != '') {
            overallEfficiencyTotal = overallEfficiencyTotal + parseFloat(oneOverallEfficiency);
        }
    }
    document.getElementById('lblTotalFTESaved').innerHTML = RoundToThree(fteSavedTotal.toString());
    document.getElementById('lblTotalHoursSaved').innerHTML = RoundToThree(totalHoursSavedTotal.toString());
    document.getElementById('lblOverallEfficiency').innerHTML = RoundToThree(overallEfficiencyTotal.toString());
}

function RoundToThree(bigValue)
{
    if (bigValue.indexOf('.') >= 0)
    {
        var afterDecimal = bigValue.substr(bigValue.indexOf('.') + 1);
        if (afterDecimal.length > 3)
        {
            afterDecimal = afterDecimal.substr(0, 3);
        }
        bigValue = bigValue.substr(0, bigValue.indexOf('.') + 1) + afterDecimal;
    }
    return bigValue;
}

SetRoles('ddlRole_0');
SetWorkingHoursPerMonth('ddlWorkingHoursPerMonth_0');
SetActivities('ddlActivities_0');
SetEfficiencyPercentage('ddlEfficiencyPercentage_0');
