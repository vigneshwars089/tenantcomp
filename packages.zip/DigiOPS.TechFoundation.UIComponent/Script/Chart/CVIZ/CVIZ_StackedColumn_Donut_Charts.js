function DrawCVIZStackedColumnChart()
{
    var stackedColumnOptions =
    {
        id: '1',
        container: container,
        bindings: bindings,
        axisRange: axisRange,
        base : base,
        colors: groupColors,

        margin: margin,
        scaling: scaling,
        scaleFormat: scaleFormat,
        ticks: ticks,
        columnGloss: columnGloss,
        tickerAngle: tickerAngle,
        padding: padding,
        labels: labels,
        legend: legend,
        tooltip: toolTip,
        utility:{print:print, download:download}
    };
    jQuery(window).ready(function ()
    {
        var graph = cviz.widget.StackedColumn.Runner(stackedColumnOptions).graph();
        graph.render(stackedColumnData);

    });
}

function DrawCVIZDonutChart()
{
    var doughnutOptions = {
        container: container,
        bindings: bindings,
        colors: colors,
        gloss: gloss,
        margin: margin,
        radius: radius,
        legend: legend,
        tooltip: tooltip,
        utility: {
            print: print,
            download: download
        }
    };

    jQuery(window).ready(function ()
    {
        var graph = cviz.widget.DoughnutChart.Runner(doughnutOptions).graph();
        graph.render(doughnutData);
    });
}