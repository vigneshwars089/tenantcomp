    array = [];
    function Remove(event)
    {
        array.push(event.currentTarget.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.attributes.id.value);
        var el = document.querySelector("#" + event.currentTarget.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.attributes.id.value);
        angular.element(el).addClass('remove')
        if (document.getElementById('ForShowAllButton').innerHTML == '') {
            CreateButton();
        }
        document.getElementById('ForShowAllButton').style.visibility = 'visible';
    }

    var a = [];
    function Resize(event, i)
    {
        var optionsIndex = event.currentTarget.attributes.id.value;
        optionsIndex = optionsIndex.substr(6, optionsIndex.length - 6);
        var divId = 'div' + optionsIndex.toString();
        var divOuterId = 'divOuter' + optionsIndex.toString();

        var shrinkOrExpand = 0;

        if (document.getElementById(event.currentTarget.attributes.id.value).className == "glyphicon glyphicon-resize-small")
        {
            a[i] = 1;
        }

        if (a[i] == 0)
        {
            a[i] = 1;
            shrinkOrExpand = 1;
            document.getElementById(event.currentTarget.attributes.id.value).className = "glyphicon glyphicon-resize-small";
            document.getElementById(divOuterId).style.width="96.5%";
        }
        else
        {
            a[i] = 0;
            shrinkOrExpand = 0;
            document.getElementById(event.currentTarget.attributes.id.value).className = "glyphicon glyphicon-resize-full";
            var thisLayout = document.getElementById('hidLayout').value;
            if (thisLayout == '2')
            {
                document.getElementById(divOuterId).style.width = "47.7%";
            }
            if (thisLayout == '3')
            {
                document.getElementById(divOuterId).style.width = "31.5%";
            }
            if (thisLayout == '4')
            {
                document.getElementById(divOuterId).style.width = "23.5%";
            }
        }
        ResizeChart(optionsIndex, shrinkOrExpand);
    }


    function ShowAll()
    {
        var a = document.querySelectorAll(".draggable2");
        for (var k = 0; k < a.length; k++)
        {
            angular.element(a[k]).removeClass('remove');

        }
        document.getElementById('ForShowAllButton').style.visibility = 'hidden';
    }

    function OneGraph(event)
    {
      var myEl = angular.element(document.querySelectorAll('.draggable2'));
      for(i=0;i<myEl.length;i++)
      {
          myEl.css('width', '98%');
      }
      var allElements = document.getElementsByTagName("span");
      for (elementIndex = 0; elementIndex < allElements.length; elementIndex++)
      {
          if (allElements[elementIndex].id.substr(0, 6) == 'resize')
          {
              allElements[elementIndex].className = '';
          }
      }
      document.getElementById('hidLayout').value = '1';
      DrawLayoutOneGraph();
    }

    function TwoGraph()
    {
       var myEl = angular.element(document.querySelectorAll('.draggable2'));
       for(i=0;i<myEl.length;i++)
       {
         myEl.css('width','47.7%');
       }
       var allElements = document.getElementsByTagName("span");
       for (elementIndex = 0; elementIndex < allElements.length; elementIndex++)
       {
           if (allElements[elementIndex].id.substr(0, 6) == 'resize')
           {
               allElements[elementIndex].className = "glyphicon glyphicon-resize-full";
           }
       }
       document.getElementById('hidLayout').value = '2';
       DrawLayoutTwoGraph();
    }

    function ThreeGraph()
    {
      var myEl = angular.element(document.querySelectorAll('.draggable2'));
      for(i=0;i<myEl.length;i++)
      {
        myEl.css('width','31.5%');
      }
      var allElements = document.getElementsByTagName("span");
      for (elementIndex = 0; elementIndex < allElements.length; elementIndex++)
      {
          if (allElements[elementIndex].id.substr(0, 6) == 'resize')
          {
              allElements[elementIndex].className = "glyphicon glyphicon-resize-full";
          }
      }
      document.getElementById('hidLayout').value = '3';
      DrawLayoutThreeGraph();
    }


    function FourGraph()
    {
      var myEl = angular.element(document.querySelectorAll('.draggable2'));
      for(i=0;i<myEl.length;i++)
      {
        myEl.css('width','23.5%');
      }
      var allElements = document.getElementsByTagName("span");
      for (elementIndex = 0; elementIndex < allElements.length; elementIndex++)
      {
          if (allElements[elementIndex].id.substr(0, 6) == 'resize')
          {
              allElements[elementIndex].className = "glyphicon glyphicon-resize-full";
          }
      }
      document.getElementById('hidLayout').value = '4';
      DrawLayoutFourGraph();
    }


    var j = -1;
    function AddDiv(inEntireRow,width,height)
    {
        j++;
        var divId = 'div' + j.toString();
        var resizeId = 'resize' + j.toString();
        var divOuterId = 'divOuter' + j.toString();

        var innerHTML =       '<div class="draggable2" class="ui-widget-content" flex="50" id="' + divOuterId + '">';
        innerHTML=innerHTML + '<div layout="row" flex id="divhead">';
        innerHTML = innerHTML + '<table width="100%;" border="0">';
        innerHTML = innerHTML + '<tr><td align="right" width="75%">';
        innerHTML=innerHTML + '<span flex="5" class="glyphicon glyphicon-resize-full"  id="'+resizeId+'" onclick="javascript:Resize(event, ' + j + ')">';
        innerHTML = innerHTML + '</span>';
        innerHTML = innerHTML + '</td><td align="middle" width="15%">';
        innerHTML=innerHTML + '<span flex="5" class="glyphicon glyphicon-remove-circle" id="close" onclick="javascript:Remove(event)">';
        innerHTML = innerHTML + '</span>';
        innerHTML = innerHTML + '</td><td width="10%"></td></tr>';
        innerHTML = innerHTML + '<tr><td colspan="2">';
        innerHTML = innerHTML + '<div style="width:100%;position:relative;left:0px;" id="' + divId + '">';
        innerHTML = innerHTML + '</div>';
        innerHTML = innerHTML + '</td></tr></table>';
        innerHTML=innerHTML + '</div>';
        innerHTML=innerHTML + '</div>';

        var firstDiv = document.getElementById('FirstDiv');
        firstDiv.innerHTML = firstDiv.innerHTML + innerHTML;

        var divOuterId = 'divOuter' + j.toString();
        if (inEntireRow == 1)
        {
            document.getElementById(divOuterId).style.width = "98%";
            document.getElementById(resizeId).className = "glyphicon glyphicon-resize-small";
        }
        else 
        {
            document.getElementById(divOuterId).style.width = width +'%';
        }
        document.getElementById(divOuterId).style.height = height + 'px';
        a.push(0);

        return divId;
    }


    function CreateButton()
    {
        var btn = document.createElement("BUTTON");
        btn.className = 'ShowAll';
      var target = document.createTextNode("Show All");
      document.getElementById('ForShowAllButton').appendChild(btn);
      btn.appendChild(target);
      btn.onclick=ShowAll;
    }

    function ShowLayout()
    {
        var innerHTML=  '<button class="dropdown"data-toggle="dropdown">Layout';
        innerHTML=innerHTML + '<ul class="dropdown-menu">';
        innerHTML=innerHTML + '<li><a href="#" onclick="javascript:OneGraph(event)">1 X 1</a></li>';
        innerHTML=innerHTML + '<li><a href="#" onclick="javascript:TwoGraph(event)">1 X 2</a></li>';
        innerHTML=innerHTML + '<li><a href="#" onclick="javascript:ThreeGraph(event)">1 X 3</a></li>';
        innerHTML=innerHTML + '<li><a href="#" onclick="javascript:FourGraph(event)">1 X 4</a></li>';
        innerHTML=innerHTML + '</ul>';
        innerHTML=innerHTML + '</button>';

        var secDiv = document.getElementById('tdForLayout');
        secDiv.innerHTML = innerHTML + secDiv.innerHTML;

        $('button.dropdown').hover(function() {
          $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
        }, function() {
          $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
        });

    }


  $(function()
  {
    $('.dynamic').sortable();
    $( '.dynamic').disableSelection();
  })
