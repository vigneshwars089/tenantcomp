﻿using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Security.Authentication;

namespace DigiOPS.TechFoundation.Security
{
    public class ADUserSecurity : BaseUserSecurity
    {
        /// <summary>
        /// AD Method to Authenticate user
        /// </summary>
        /// <param name="objUserContextInfo">User Credentials</param>
        /// <returns>bool</returns>
        public override bool Authenticate(UserContextInfo objUserContextInfo)
        {
            LogInfo objLogInfo = new LogInfo();
            ILoggingFactory objLogging = new LoggingFactory();
            objUserContextInfo.ErrorMessage = new System.Text.StringBuilder();
            objUserContextInfo.ErrorMessage.Clear() ;
           
            string userPrincipalName = objUserContextInfo.Domain.Trim() + @"\" + objUserContextInfo.UserID.Trim();
            try
            {               
                if(ValidateUserContext(objUserContextInfo).ResultStatus)
                   {
                       using (var context = new PrincipalContext(ContextType.Domain, objUserContextInfo.Domain.Trim() ))
                    {
                        using (var domainContext = new PrincipalContext(ContextType.Domain, objUserContextInfo.Domain.Trim()))
                        {
                            using (var foundUser = UserPrincipal.FindByIdentity(domainContext, IdentityType.SamAccountName,  objUserContextInfo.UserID.Trim()))
                            {
                                if (foundUser != null)
                                {
                                    if ((context.ValidateCredentials(userPrincipalName, objUserContextInfo.Password.Trim())) == true)
                                    {
                                        return objUserContextInfo.ResultStatus = true;                                    }
                                    else
                                    {
                                        objLogInfo.Message = "Incorrect password";
                                        objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
                                        objUserContextInfo.ErrorMessage.Append("Incorrect password");
                                        return objUserContextInfo.ResultStatus = false;
                                    }
                                }
                                else
                                {
                                    objLogInfo.Message = "User " + objUserContextInfo.UserID.Trim() + " is not found in domain " + objUserContextInfo.Domain.Trim();
                                    objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
                                    objUserContextInfo.ErrorMessage.Append( "User " + objUserContextInfo.UserID.Trim() + " is not found in domain " + objUserContextInfo.Domain.Trim());
                                    return objUserContextInfo.ResultStatus = false;
                                }
                            }
                        }
                    }
                }
                else
                    return objUserContextInfo.ResultStatus = false;
            }
            catch (ArgumentNullException e)
            {
                objLogInfo.Message = e.Message;
                objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
                objLogging.GetLoggingHandler("Log4net").LogException(e);
                objUserContextInfo.ErrorMessage.Append( e.Message);
                return objUserContextInfo.ResultStatus = false;
            }
            catch (Exception ex)
            {
                objLogInfo.Message =ex.Message;
                objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
                objLogging.GetLoggingHandler("Log4net").LogException(ex);
               objUserContextInfo.ErrorMessage.Append(ex.Message);
               return objUserContextInfo.ResultStatus = false;
            }
            return false;
        }
        public override bool Authorize(UserRoleInfo objUserRoleInfo)
        {
            //to your logic here
            return false;
        }
    }
}
