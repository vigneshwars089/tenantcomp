﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    public interface ISecurityFactory
    {
        IUserSecurity GetUserSecurityHandler(string appId);
        ICrypt GetCryptHandler(string appId);
        IProductLicenseKey GetLicenseKeyHandler();
       // ISystemSecurity GetSystemSecurityHandler(string appId);
    }

}
