﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    public class AccountLockInfo : BaseInfo
    {
        public string LoginID { set; get; }
         public bool Lock { set; get; }
         public  string Token { set; get; }
         public   int Size { set; get; }
         public  string TokenKey { set; get; }
         public DateTime TokenExpirationTime { set; get; }
         public double TokenExpiration { set; get; }
         public string cipherpassword { set; get; }
       
       
    }
}
