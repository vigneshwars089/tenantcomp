﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Security
{
    public class UserContextInfo : BaseInfo
    {
        public string UserID { set; get; }
        public string Password { set; get; }
        public string Domain { set; get; }
    }
}
