﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
        public class LicenseInfo : BaseInfo
      {
          public string ToolPurchased { set; get; }
          public string DateOfPurchase { set; get; }
          public string Version { set; get; }
          public string InstanceID { set; get; }
          public string EncryptedProductKey { set; get; }
          public int MaxNoOfUser { set; get; }
          public int UserCount { set; get; }
      }

    
}
