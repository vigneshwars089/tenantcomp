﻿using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    public class AESCrypt : BaseCrypt
    {
        /// <summary>
        /// Contains AES Encryption and Decryption methods
        /// </summary>
        /// <param name="objCryptInfo">string</param>
        /// <returns>string</returns>
       public  override string Encrypt(CryptInfo objCryptInfo)
        {
            return Encode(objCryptInfo.ValueToCrypt, objCryptInfo.CryptKey);
             
        }
       public override string Decrypt(CryptInfo objCryptInfo)
        {
            return Decode(objCryptInfo.ValueToCrypt, objCryptInfo.CryptKey);
           
        }
       /// <summary>
       /// Method to Encode the Key value pair
       /// </summary>
       /// <param name="value">string</param>
       /// <param name="key">string</param>
       /// <returns>string</returns>
       private string Encode(string value, string EncryptionKey)
       {
           byte[] inputByteArray;
           LogInfo objLogInfo = new LogInfo();
           ILoggingFactory objLogging = new LoggingFactory();

           try
           {
               using (Aes aesCrypt = Aes.Create())
               {
                   inputByteArray = Encoding.UTF8.GetBytes(value);

                   Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                   aesCrypt.Key = pdb.GetBytes(32);
                   aesCrypt.IV = pdb.GetBytes(16);

                   using (MemoryStream ms = new MemoryStream())
                   {
                       using (CryptoStream cs = new CryptoStream(ms, aesCrypt.CreateEncryptor(), CryptoStreamMode.Write))
                       {
                           cs.Write(inputByteArray, 0, inputByteArray.Length);
                           cs.FlushFinalBlock();
                       }
                       value = Convert.ToBase64String(ms.ToArray());
                   }
               }

           }
           catch (FormatException ex)
           {
               objLogInfo.Message = "Invalid TamperProofString" + ex.Message;
               objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
               objLogging.GetLoggingHandler("Log4net").LogException(ex);
               throw;// ArgumentException("Invalid TamperProofString" + ex.Message);
           }
           catch (ArgumentException ex)
           {
               objLogInfo.Message = "Invalid TamperProofString" + ex.Message;
               objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
               objLogging.GetLoggingHandler("Log4net").LogException(ex);
               throw;
           }
           catch (NotSupportedException ex)
           {
               objLogInfo.Message = "Invalid TamperProofString" + ex.Message;
               objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
               objLogging.GetLoggingHandler("Log4net").LogException(ex);
               throw; 
           }
           catch (CryptographicException ex)
           {
               objLogInfo.Message = "Invalid TamperProofString" + ex.Message;
               objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
               objLogging.GetLoggingHandler("Log4net").LogException(ex);
               throw; 
           }
           //catch (QuartException ex)
           //{
           //    throw new ArgumentException("Invalid TamperProofString" + ex.Message);
           //}
           finally
           {
               objLogInfo.Message = "Value was Encrypted Successfully"+System.DateTime.Now;
               objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
               inputByteArray = null;
           }
           return value;
       }
       /// <summary>
       /// Method to Decode the Key value pair
       /// </summary>
       /// <param name="value">string</param>
       /// <param name="key">string</param>
       /// <returns>string</returns>
       private static string Decode(string value, string EncryptionKey)
       {
           byte[] inputByteArray;
           LogInfo objLogInfo = new LogInfo();
           ILoggingFactory objLogging = new LoggingFactory();

           try
           {
               using (Aes aesCrypt = Aes.Create())
               {
                   inputByteArray = Convert.FromBase64String(value);
                   Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                   aesCrypt.Key = pdb.GetBytes(32);
                   aesCrypt.IV = pdb.GetBytes(16);

                   using (MemoryStream ms = new MemoryStream())
                   {
                       using (CryptoStream cs = new CryptoStream(ms, aesCrypt.CreateDecryptor(), CryptoStreamMode.Write))
                       {
                           cs.Write(inputByteArray, 0, inputByteArray.Length);
                           cs.FlushFinalBlock();
                       }
                       value = Encoding.UTF8.GetString(ms.ToArray());
                   }
               }

           }
           catch (FormatException ex)
           {
               objLogInfo.Message = "Invalid TamperProofString" + ex.Message;
               objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
               objLogging.GetLoggingHandler("Log4net").LogException(ex);
               throw;// new ArgumentException("Invalid TamperProofString" + ex.Message);
           }
           catch (ArgumentException ex)
           {
               objLogInfo.Message = "Invalid TamperProofString" + ex.Message;
               objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
               objLogging.GetLoggingHandler("Log4net").LogException(ex);
               throw;// new ArgumentException("Invalid TamperProofString" + ex.Message);
           }
           catch (NotSupportedException ex)
           {
               objLogInfo.Message = "Invalid TamperProofString" + ex.Message;
               objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
               objLogging.GetLoggingHandler("Log4net").LogException(ex);
               throw;// new ArgumentException("Invalid TamperProofString" + ex.Message);
           }
           catch (CryptographicException ex)
           {
               objLogInfo.Message = "Invalid TamperProofString" + ex.Message;
               objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
               objLogging.GetLoggingHandler("Log4net").LogException(ex);
               throw;// new ArgumentException("Invalid TamperProofString" + ex.Message);
           }
           //catch (QuartException ex)
           //{
           //    throw new ArgumentException("Invalid TamperProofString" + ex.Message);
           //}
           finally
           {
               objLogInfo.Message = "Value was Decrypted Successfully" + System.DateTime.Now;
               objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
               inputByteArray = null;
           }
           return value;
       }
    }
}
