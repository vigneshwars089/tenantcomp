﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{    
   public  abstract class BaseCrypt : ICrypt
{

       public virtual string Encrypt(CryptInfo objCryptInfo)
	{
 		return null;
	}
       public virtual string Decrypt(CryptInfo objCryptInfo)
	{
		return null;
	}
}
}
