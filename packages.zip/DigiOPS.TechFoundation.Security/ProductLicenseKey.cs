﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    public class ProductLicenseKey : BaseProductLicenseKey
    {
        string cryptKey = "ProductKeyInformation";
        /// <summary>
        /// Generating Product Key
        /// </summary>
        /// <param name="objUserContextInfo">LicenseInfo</param>
        /// <returns>string</returns>
        public override LicenseInfo GenerateProductKey(LicenseInfo productKeyInfo)
        {
            try
            {
                productKeyInfo.ErrorMessage = new StringBuilder();
                string productKey = productKeyInfo.ToolPurchased + "|" + productKeyInfo.DateOfPurchase + "|" + productKeyInfo.Version + "|" + productKeyInfo.InstanceID + "|" + productKeyInfo.UserCount + "|" + productKeyInfo.MaxNoOfUser;
                // ResponseInfo responseInfo = ValidateProductKeyInfo(productKeyInfo);
                if (ValidateProductKeyInfo(productKeyInfo).ResultStatus)
                {
                    CryptInfo cryptInfo = new CryptInfo();
                    cryptInfo.CryptKey = cryptKey;
                    cryptInfo.ValueToCrypt = productKey;
                    var securityFactory = new SecurityFactory();
                    productKeyInfo.EncryptedProductKey = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);

                    return productKeyInfo;
                }
                else
                {
                    productKeyInfo.ErrorMessage.Append("Encryption failed");
                     productKeyInfo.EncryptedProductKey = string.Empty;
                    return productKeyInfo;
                }
            }
            catch (Exception ex)
            {
                productKeyInfo.ErrorMessage.Append(ex.Message);
                 productKeyInfo.EncryptedProductKey = string.Empty;
                return productKeyInfo;
            }
        }

        private LicenseInfo DecryptProductKey(string encryptedProductKey)
        {
            LicenseInfo productKeyInfo = new LicenseInfo();
            try
            {

                productKeyInfo.ErrorMessage = new StringBuilder();
                if (string.IsNullOrEmpty(encryptedProductKey))
                {
                    productKeyInfo.ErrorMessage.Append("Encrypted product key not found!...");
                    productKeyInfo.ResultStatus = false;
                    return productKeyInfo;
                }
                CryptInfo cryptInfo = new CryptInfo();
                cryptInfo.CryptKey = cryptKey;
                cryptInfo.ValueToCrypt = encryptedProductKey;
                var securityFactory = new SecurityFactory();
                string productKey = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);

                var productKeyInformation = productKey.Split('|');
                productKeyInfo.ToolPurchased = productKeyInformation[0];
                productKeyInfo.DateOfPurchase = productKeyInformation[1];
                productKeyInfo.Version = productKeyInformation[2];
                productKeyInfo.InstanceID = productKeyInformation[3];
                productKeyInfo.UserCount = Convert.ToInt16(productKeyInformation[4]);
                productKeyInfo.MaxNoOfUser = Convert.ToInt16(productKeyInformation[5]);
                productKeyInfo.ResultStatus = true;
                return productKeyInfo;

            }
            catch (Exception ex)
            {
                productKeyInfo.ErrorMessage.Append(ex.Message);
                productKeyInfo.ResultStatus = false;
                return productKeyInfo;


            }
        }
        public override LicenseInfo ValidateProductLicenseKey(string encryptedProductKey)
        {
            LicenseInfo productKeyInfo = new LicenseInfo();

            productKeyInfo = DecryptProductKey(encryptedProductKey);
            DateTime PurchasedDate = Convert.ToDateTime(productKeyInfo.DateOfPurchase).Date;
            if (PurchasedDate.AddYears(1) < System.DateTime.Now)
            {
                productKeyInfo.ErrorMessage.Append("Expired Product License Key");
                productKeyInfo.ResultStatus = false;
                return productKeyInfo;
            }
            else if (PurchasedDate.AddYears(1).AddDays(-7) < System.DateTime.Now)
            {
                productKeyInfo.ErrorMessage.Append("Product License Key will expire in a week");
                productKeyInfo.ResultStatus = false;
                return productKeyInfo;
            }
            if (productKeyInfo.UserCount > productKeyInfo.MaxNoOfUser)
            {
                productKeyInfo.ErrorMessage.Append("User Count exceeds the maximum value");
                productKeyInfo.ResultStatus = false;
                return productKeyInfo;
            }
            else
            {
                productKeyInfo.ErrorMessage.Append("Product License Key is valid");
                productKeyInfo.ResultStatus = true;
            }
            return productKeyInfo;

        }



    }
}
