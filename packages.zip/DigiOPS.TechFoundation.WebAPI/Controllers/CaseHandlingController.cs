﻿
using DigiOPS.TechFoundation.DataTransfer;
using DigiOPS.TechFoundation.RuleEngine;
using DigiOPS.TechFoundation.WebAPI.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Helpers;
using System.Web.Http;

namespace DigiOPS.TechFoundation.WebAPI.Controllers
{
    public class CaseHandlingController : ApiController
    {
        CaseHandling objCaseHandling = new CaseHandling();
        CaseCreationInfo objCaseCreationInfo = new CaseCreationInfo();
        CaseHandlingEntities db = new CaseHandlingEntities();
        static HttpClient client = new HttpClient();
        GenericJSONSerializer objjson = new GenericJSONSerializer();

       
        public bool JSONValidation(string jsonString) 
        {
            return false;
        }            
      

         //[Serializable]
         [HttpPost]
        public string Insert(string jsonString)//(Person obj )
        {
            string result = string.Empty;
            try
            {
                CaseHandleModel objCaseHandlingmodel = new CaseHandleModel();
                //foreach(string jso in jsonString)
                objCaseHandlingmodel = objjson.JsonDeserialize<CaseHandleModel>(jsonString);
                
                ElementDatas objElementdatas = new ElementDatas();   
                ElementData objElementdata = new ElementData();
                string output = string.Empty;
               
                objElementdata.ElementId = objCaseHandlingmodel.CasesList[0].ID;
                objElementdata.ElementValue = objCaseHandlingmodel.CasesList[0].Value;
                objElementdata.IsList = objCaseHandlingmodel.CasesList[0].IsList;
                if (objElementdata.IsList)
                    objElementdata.ElementItemValue = objCaseHandlingmodel.CasesList[0].MultipleValues;
                else
                    objElementdata.ElementItemValue = null;
                
                objElementdatas.Items.Add(objElementdata);

                output = objCaseHandling.Create(objElementdatas);
                result = objjson.JsonSerializer<string>(output);                
                //db.SaveChanges();
            }
            catch (Exception) { }
            return result;
        }

         [HttpGet]
         public IEnumerable<CaseHandleModel> Retrieve(string jsonid)
         {
            // CaseHandleModel objCaseHandlingmodel = new CaseHandleModel();
             objCaseCreationInfo = objjson.JsonDeserialize<CaseCreationInfo>(jsonid);
             objCaseHandling.RetrieveTransactions(objCaseCreationInfo);
              

             return db.Objcasehandling.ToList();
            
         }

      //   [Serializable]
         [HttpPost]
         public void Update(string jsonString)
         {
            
         }


        [HttpDelete]
        public void DeleteTransaction(int id)
        {
            objCaseCreationInfo.RecordId = id;
            objCaseHandling.Delete(objCaseCreationInfo);

        }

        


    }
}
