﻿using DigiOPS.TechFoundation.RuleEngine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace DigiOPS.TechFoundation.WebAPI.Controllers
{
    public class RuleEngController : ApiController
    {
        [HttpGet]
        public IEnumerable<string> GetRole()
        {
            EfficiencyCalculator objefficiency = new EfficiencyCalculator();
            List<string> objlis = new List<string>();
            objlis = objefficiency.ListRoles();
            return objlis;
        }
        [HttpGet]
        public IEnumerable<string> GetActivity()
        {
            EfficiencyCalculator objefficiency = new EfficiencyCalculator();
            List<string> objlis = new List<string>();
            objlis = objefficiency.ListAcitvities();

            return objlis;
        }

    }
}
