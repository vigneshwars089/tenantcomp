﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Calibration;
//using DigiOPS.TechFoundation.
//using DigiOPS.TechFoundation.Calibration.Interface;
using DigiOPS.TechFoundation.MetricManagement;
//using DigiOPS.TechFoundation.CalibrationAudit;

namespace DigiOPS.WebAPI.Controllers
{
    public class CalibrationAuditController : ApiController
    {
        [HttpGet]
        public ScoringOutput CalibrationValidation(CalibrationScoreInfo objCalScoreInfo)
        {
            try
            {
                CalibrationScoreInfo ad = new CalibrationScoreInfo();
                List<CalibrationDetailsEntity> lstIn = new List<CalibrationDetailsEntity>();
                CalibrationDetailsEntity ade = new CalibrationDetailsEntity();
                lstIn.Add(ade);
                ad.IntAuditedList = lstIn;
                List<CalibrationDetailsEntity> lstEx = new List<CalibrationDetailsEntity>();
                CalibrationDetailsEntity adEx = new CalibrationDetailsEntity();
               lstEx.Add(adEx);
                ad.ExtAuditedList = lstEx;
               List<CalibrationDetailsEntity> lstComb = new List<CalibrationDetailsEntity>();
                CalibrationDetailsEntity adComb = new CalibrationDetailsEntity();
                lstComb.Add(adComb);
                ad.CombinedAccuracyList = lstComb;
                ScoringOutput output = new ScoringOutput();
                CalibrationScoreInfo csi = new CalibrationScoreInfo();
               ICalibrationFactory cal = new CalibrationFactory();
                ICalibrationAlgorithm CalAg = cal.GetCalibratorHandler(ad);
                output = CalAg.CalibrationValidation(ad);
                return output;
               

              }
            catch (ArgumentException ex)
            {
                return null;
            }
            catch (Exception ex)
            {
                return null;
            }
            
        }
    }
}
