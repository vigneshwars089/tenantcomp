﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using DigiOPS.TechFoundation.DataTransfer;
using DigiOPS.TechFoundation.Entities;





namespace DigiOPS.WebAPI.Controllers
{
    public class EmailCaseCreationController : ApiController
    {
        
    
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :xxxx.cs
        // Namespace : DigiOps.WebAPI
        // Class Name(s) :EmailCaseCreationController
        // Author : Tejaswini
        // Creation Date : 18-Apr-2017
        // Purpose : WebAPI for EmailCaseCreationController
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name         Method Name               Description
        // ----------   --------    -------------------------- --------------------------------------------------
        //18-Apr-2017    Tejaswini         Validation       Added for Reading Mails for Quart/EMT/TrackWork 
        //////////////////////////////////////////////////////////////////////////////////////////////////////


        [HttpGet]
        public string CaseCreation(EMailInfo eInfo)
        {
            string output = string.Empty;
            try
            {
                //EMailInfo eInfo = new EMailInfo();
                //eInfo.eMailType = "outlook";
                //eInfo.CreationType = "EMT";
                List<EmailInput> elist = new List<EmailInput>();
                EmailInput input = new EmailInput();
                //input.intmailfolderid = "2";
                //input.strpath = @"https://mail.cognizant.com/ews/Exchange.asmx";
                //input.strname = "Inbox";
                //input.EMailId = "Megha.Patil@cognizant.com";
                //input.LoginEMailId = "391099";
                //input.TimeZone = "India Standard Time";
                //input.ClientExVersion = "Exchange2010_SP1";
                //input.password = "meghjeen-2";
                elist.Add(input);
                // elist.Add(input1);
                eInfo.EmailInputList = elist;
                IEmailReadingFactory bft = new EmailReadingFactory();
                ElementDatas EData = new ElementDatas();
              
                ICaseCreationFactory ccft = new CaseCreationFactory();
           
                if (eInfo.CreationType == "Quart")
                {
                    EData.CreationType = eInfo.CreationType;
                
                    
                    eInfo.result = ccft.CaseCreationHandler(eInfo.eMailType).CCHandler(eInfo).CreateCases(EData);
                }               
                else if ((eInfo.CreationType == "EMT") || (eInfo.CreationType == "TRACKWORK"))
                {

                    //IEmailReadingFactory bft = new EmailReadingFactory();            
                    eInfo = bft.eMailReadingHandler(eInfo.eMailType).MailReading(eInfo);
                    eInfo.result = ccft.CaseCreationHandler(eInfo.eMailType).CCHandler(eInfo).CreateCases(eInfo);
                }
               // eInfo = bft.eMailReadingHandler(eInfo).MailReading(eInfo);
                eInfo.result = eInfo.ErrorMessage.ToString();
            }
            catch (ArgumentException ex)
            {
                return null;
            }
            catch (Exception ex)
            {
                return null;

            }
            return eInfo.result;

        }
        }
    }

 