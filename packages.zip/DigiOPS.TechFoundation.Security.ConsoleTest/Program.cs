﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Newtonsoft.Json;
using DigiOPS.TechFoundation.Security;
using DigiOPS.TechFoundation.DataTransfer;
using System.Data;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.UserManagement;
using DigiOPS.TechFoundation.Audit;
using System.Configuration;
using System.Net.Mail;
using System.Web;
using System.IO;
                                                      

namespace DigiOPS.TechFoundation.Security.ConsoleTest
{
 /// <summary>
 /// 
 /// </summary>
    public class Program
    {
        public static void Main(string[] args)
        {
             AuditCheckItemsInfo objdo = new AuditCheckItemsInfo();
                RootCauseEntity objsdentity = new RootCauseEntity();
              AuditCheckItemsInfo  lstdet = new AuditCheckItemsInfo();
              AuditFactory Auditfactory = new AuditFactory();

                objdo.AppID ="Quart";
               // objdo.TenantID = 1;
                objdo.TenantName = "demo";

              
                    //  objdo.SortColumn = "Checkpointlist.[szDisplayName]";

                    objdo.SubProcessId = 19;
                    objdo.CategoryId = -1;
                    objdo.HeadId = -1;
                    objdo.RatingGroupId = 0;
                    objdo.CheckItemGroupId = 0;
                    objdo.CriticalityType = "";
                    // lstdet = objBAL.GetEntityList(objdo).Cast<DigiOPS.TechFoundation.Entities.TransDropDown>().ToList();
                    lstdet = Auditfactory.GetAuditTypeHandler("Manual", "Checkitems").GetCTQItems(objdo);

            //UserInfo objuser = new UserInfo();
            //UserMgmtInfo objusermgmtinfo = new UserMgmtInfo();
            //BaseCustomUserManagement objBaseCustom = new BaseCustomUserManagement();
            //objuser.ModifiedBy ="1416";
            //objuser.CreatedBy = "1416";
            //objuser.TenantName = "demo";
            ////objuser.TenantID = 1;
            //objuser.AppID = "Quart";
            //objuser.CreationType = "UserGroupMapping";
            //objuser.UserList = "1416";
            //objuser.ProgramID = 5;
            //objuser.UserGroupID = 115;
            //objuser.IsActive = true;
            //string sortOrder = null;
            //string sortColumn = null;
            //int? startRowIndex = null;
            //objuser.IsUserSearch = true;
            //objuser.UsersSearchText = "572748";
            //objuser.eventAction = Constants.ACTION_Insert;
            //objusermgmtinfo = objBaseCustom.CreateUser(objuser);
            //string result = objusermgmtinfo.Message;
           // /*
          //   * MultiTenancy
            //MultiTenant objMultiTenancy = new MultiTenant();
            //MultiTenantOutput objmtoup = new MultiTenantOutput();
            //MultiTenancyInfo objinfo = new MultiTenancyInfo();
           
            //objinfo.AppID = "1";
            //objmtoup = objMultiTenancy.GetConnectionString(objinfo);
            //objinfo.DataBaseName = obji.DataBaseName;// "DB1";
            //objinfo.UserName = obji.UserName;// "User1";
            //objinfo.Password = obji.Password;// "pwd";
                        // objmtoup = objMultiTenancy.SaveTenantDBDetails(objinfo);

            //objinfo.ServerName = "serv";
            //objinfo.DataBaseName = "abc";
            //objinfo.UserName = "user";
            //objinfo.Password = "PWD";

            //objinfo.InstanceName ="gg";// "INST1";
            //objinfo.TenantName = "TENT1";
            //objinfo.TenantUserID = 5728;
            //objinfo.URL = "WWW.ABC";
            //objinfo.SameURL = true;
            //objinfo.LicenseKey = "ABC";
            //objinfo.EffectiveFrom = System.DateTime.Now;
            //objinfo.EffectiveTo = System.DateTime.Now;
            //objinfo.Vertical = 8;
            //objinfo.AccountId = 1;

            //objmtoup = objMultiTenancy.SaveTenantDetails(objinfo);
          //  */

           // Quart Case Handling
           /* 
            ICaseCreationFactory ccft = new CaseCreationFactory();
            EMailInfo eInfo = new EMailInfo();
            eInfo.CreationType = "Quart";
          
            CaseHandling objch = new CaseHandling();
            List<ElementDatas> listeld = new List<ElementDatas>();
            ElementDatas eds = new ElementDatas();
            ElementData ed = new ElementData();
            eds.Items = new List<ElementData>();
            eds.CreationType = eInfo.CreationType;
            
            //ed.ElementId = "txtProcessedDateandTime";
            //ed.ElementItemValue = null;
            //ed.ElementValue = Convert.ToString(System.DateTime.Now);
           
            ed = new ElementData();
            ed.ElementId = "360";
            ed.ElementItemValue = null;
            ed.ElementValue = "gt";
            ed.IsList = false;
           
            ed.IsList = true;
          
            eds.Items.Add(ed);
            eds.USERID = "1730";
            eds.ReceivedDate = Convert.ToString(System.DateTime.Now);
            eds.Processeddate = Convert.ToString(System.DateTime.Now);
            eds.subprocessid = 124;
            eds.Comments = "TESTMODIFY";
            listeld.Add(eds);
             eds = new ElementDatas();
           ed = new ElementData();
            eds.Items = new List<ElementData>();
            eds.CreationType = eInfo.CreationType;

            //ed.ElementId = "txtProcessedDateandTime";
            //ed.ElementItemValue = null;
            //ed.ElementValue = Convert.ToString(System.DateTime.Now);

            ed = new ElementData();
            ed.ElementId = "300";
            ed.ElementItemValue = null;
            ed.ElementValue = "gt";
            ed.IsList = false;

            ed.IsList = true;

            eds.Items.Add(ed);
            eds.USERID = "1730";
            eds.ReceivedDate = Convert.ToString(System.DateTime.Now);
            eds.Processeddate = Convert.ToString(System.DateTime.Now);
            eds.subprocessid = 124;
            eds.Comments = "TESTMODIFY1";
            listeld.Add(eds);
            //eds.Items.Add(ed);
            eInfo.result = ccft.CaseCreationHandler(eInfo.CreationType).CCHandler(eInfo).CreateCases(listeld);
         // string op= objch.CreateCases(eds);
          
           CaseCreationInfo objccinfo = new CaseCreationInfo();
           List<TransactionListView> objlistvm = new List<TransactionListView>();
          //objccinfo.RecordId = 52;
           objccinfo.SUBPROCESSID = "124";
           objccinfo.USERID = "1730";
           objlistvm = objch.RetrieveTransactions(objccinfo);

           objccinfo.USERID = "1730";
           objccinfo.UpdateTransactionRecordId = "2";
           //string opp = objch.Update(objccinfo);
           eInfo.result = ccft.CaseCreationHandler(eInfo.CreationType).CCHandler(eInfo).Update(objccinfo);
           objccinfo.RecordId = 18;
           eInfo.result = ccft.CaseCreationHandler(eInfo.CreationType).CCHandler(eInfo).Delete(objccinfo);
         //  string re = objch.Delete(objccinfo);
           Console.WriteLine();
            
            */
           /*
            * support ticket
           SupportTicket objSupportTicket = new SupportTicket();
           SupportTicketViewModel objsupport = new SupportTicketViewModel();
           SupportTicketEntity objspte = new SupportTicketEntity();
           object filenam="C:\\Users\\Public\\Pictures\\Sample Pictures\\Chrysanthemum.jpg";
           HttpPostedFileBase hpf = filenam as HttpPostedFileBase;
           objSupportTicket.SaveTicket(objspte, hpf);
           objsupport = objSupportTicket.GetSupportTicketById(1, "354132","2");
         //  objsupport = objSupportTicket.GetSupportTicketByList("2");
           //SupportTicketTrailModel objsttm = new SupportTicketTrailModel();
           //objsttm = objSupportTicket.GetSupportTicketTrailByList(1);
           //string op = objSupportTicket.UpdateSupportTicketById("8", "123", "strType", "low", "1", "20.0", "gud", "19"); //verified



           /*Mail Testing

           CollaborationFactory objcoll = new CollaborationFactory();

           EMailInfo objInfo = new EMailInfo();
          
           ToAddressInfo objtoadrr = new ToAddressInfo();
           objtoadrr.ToAddress = "Sujitha.Subbiah@cognizant.com";
           objInfo.IsBodyPlainText = false;
          objInfo.Sender = "Sujitha.Subbiah@cognizant.com";
           objInfo.ToAddressList =new List<ToAddressInfo>();
           objInfo.ToAddressList.Add(objtoadrr);
           objInfo.IsBodyWithEmbededObjects = false;
           objInfo.szMailBody = "Hi";

           CCAddressInfo objccadrr = new CCAddressInfo();
           objInfo.CCAddressList = new List<CCAddressInfo>();
           objccadrr.CCAddress= "Sujitha.Subbiah@cognizant.com";
           objInfo.CCAddressList.Add(objccadrr);

           objInfo.szSentCC = "Sujitha.Subbiah@cognizant.com";
           objInfo.Recipient = "Sujitha.Subbiah@cognizant.com";

           MailMessage mailMessage = new MailMessage();
           mailMessage.From = System.Configuration.ConfigurationManager.AppSettings["MailName"];

           objInfo.szMailName = System.Configuration.ConfigurationManager.AppSettings["MailName"].ToString();
           objInfo.szPort = System.Configuration.ConfigurationManager.AppSettings["Port"].ToString();
           objInfo.szHost = System.Configuration.ConfigurationManager.AppSettings["Host"].ToString();
         
           objcoll.GetCollaborationHandler("EMail").send(objInfo);

                    
            */


           /*  Logging testing
            * LogInfo objLogInfo = new LogInfo();
             objLogInfo.ErrorMessage = new StringBuilder();
             objLogInfo.Message = "this is nandhini123445";
             objLogInfo.ErrorMessage.Append(objLogInfo.Message);
            // LoggingFactory logfac = new LoggingFactory();
          //   var logdata = logfac.GetLoggingHandler("Log4net");
          //   logdata.LogInfo(new1);
             ILoggingFactory objLogging = new LoggingFactory();
             objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
            // logdata.LogException();

           /*
            * Scoring Testing
             ScoringAlgorithmInfo objScoringAlgorithmInfo = new ScoringAlgorithmInfo();
             ScoringAlgorithmFactory objscofact = new ScoringAlgorithmFactory();

             ScoringInfo ad = new ScoringInfo();
             ad._strAuditlogic = "DPO";
             ad._strScoringLogic = "HEADING BASED";
             ad._IsCriticalApp = "False";

             List<DetailsEntity> lstComb = new List<DetailsEntity>();
             DetailsEntity adComb = new DetailsEntity();

             adComb.DOGroupID = 603;
             adComb.ParentDOId = 457;
             adComb.CriticalityType = "Critical";
             adComb.DefectNA = false;
             adComb.CalculatedGroupWeightage = 0;
             adComb.GivenWeightage =19;
             adComb.GroupWeightage = 110;
             adComb.MaxWeightage = -12;
             lstComb.Add(adComb);

             ad.AuditedList = lstComb;
             double score = 0.0;
             ScoringOutput objScoringOutput = new ScoringOutput();
             objScoringOutput = objscofact.GetScoringHandler(ad).Validation(ad);
              if (objScoringOutput.ResultStatus != false)
                     score = objScoringOutput.QualityScore;
                 else
                 {
                     string nr = objScoringOutput.ErrorMessage.ToString();

                     var productKeyInformation = objScoringOutput.ErrorMessage.ToString().Split('!');

                     string n1 = productKeyInformation[0];
                 }

             */
            //  double fieldscore = objScoringOutput.FieldQualityScore;

            //string nr = objScoringOutput.ErrorMessage.ToString();

            //var productKeyInformation = objScoringOutput.ErrorMessage.ToString().Split('!');

            //string n1 = productKeyInformation[0];
            //string n2 = productKeyInformation[1];
            //string n3 = productKeyInformation[2];
            Console.WriteLine();
            Console.ReadLine();
        }          
            
    }
}
