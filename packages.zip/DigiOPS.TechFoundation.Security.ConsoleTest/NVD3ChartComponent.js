﻿
        var height = 450;
var width = 500;
var countryName;
var subProcessName;
var mailBoxName;
var UID;
var roleID;
var lftSelection;
var SelectionText;
//var data1 = "";
var myColors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf"];


$(document).ready(function () {
    countryName = parent.countryName;
    //alert(countryName);           
    subProcessName = parent.subProcessName;
    mailBoxName = parent.mailBoxName;          
    DrawDonut();
    DrawStackedbarchart();
                    
});
        
function DrawDonut() {
           
    if (countryName == undefined || countryName == null) {
        countryName = '';
    }
    if (subProcessName == undefined || subProcessName == null) {
        subProcessName = '';
    }
    if (mailBoxName == undefined || mailBoxName == null) {
        mailBoxName = '';
    }
    roleID = parent.roleID;
    if (roleID == 4) {
        UID = parent.UID;
    }
    else {
        UID = 0;
    }
    //debugger;
    //alert(JSON.stringify('{countryName: "' + countryName + '",subprocessname: "' + subProcessName + '",mailBoxName: "' + mailBoxName + '" }'));
    var dataparam = {};
    dataparam['countryName'] = countryName;//'Australia';
    dataparam['subprocessName'] = subProcessName;//'Order to Cash';
    dataparam['mailboxName'] = mailBoxName; 
    dataparam['UID'] = UID;
    dataparam['roleID'] = roleID;
    //alert("countryName : " + $.session('countryName'));
    $.ajax({
        type: "POST",
        url: "../../EMTSrv.asmx/GetDonutChartData",
        data: JSON.stringify(dataparam),
        contentType: "application/json; charset=utf-8",
        dataType: 'json',
        success: function (result) {
            var r_data = result.d[0].chartdtls;
            nv.addGraph(function () {
                var donutChart = nv.models.pieChart()
                      .x(function (d) { return d.Name })
                      .y(function (d) { return d.Count })
                       //.legendPosition("right")
                      .showLabels(true)
                      //.labelThreshold(.01)
                      .labelType(function (d, i) { return d.data.Count; })
                      //.labelType("value")
                      .padAngle(0)
                      .cornerRadius(0)
                      .color(["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf"])
                      .donut(true)
                      .labelsOutside(false)
                      .donutRatio(0.5)
                      .width(430)
                      .height(480)
                      .showLegend(true)
                     .title("Work Items")
                      .id('test1');
                       
                donutChart.tooltip.contentGenerator(function (d) {
                    var html = "<B>" + d.data.Name + ":" + d.data.Count + "</B>";                        
                    return html;
                })
                       
                d3.select("#piechart svg")
                  .datum(r_data)
                  .transition().duration(600)
                  .call(donutChart);
                donutChart.pie.dispatch.on("elementClick", function (e) {                          
                    var Statusid = e.data.Name;
                            
                    if (subProcessName!="")
                    {
                        window.location = "../../Common/content/Inbox.aspx?Statuid=" + encodeURIComponent(Statusid);

                        sessionStorage.Statusid = Statusid;
                    }
                });
                        

                       
                $('#test1').css({ "font-family": "Segoe UI", "font-size": "14px" });//, "width": "500px" });

                $('.nv-pie-title').css({ "font-size": "24px" });//, "width": "500px" });

                        
                return donutChart;

            });
        },
        error: function (result) {

        }
    });
}
              
var chart2;
function DrawStackedbarchart() {

    var long_short_data = [
{
    key: 'Series1',
    values: [
        {
            "Name": "Group A",
            "Count": 1.8746444827653
        },
        {
            "Name": "Group B",
            "Count": 8.0961543492239
        },
        {
            "Name": "Group C",
            "Count": 0.57072943117674
        },
        {
            "Name": "Group D",
            "Count": 2.4174010336624
        },
        {
            "Name": "Group E",
            "Count": 0.72009071426284
        },
        {
            "Name": "Group F",
            "Count": 2.77154485523777
        },
        {
            "Name": "Group G",
            "Count": 9.90152097798131
        },
        {
            "Name": "Group H",
            "Count": 14.91445417330854
        },
        {
            "Name": "Group I",
            "Count": 3.055746319141851
        }
    ]
},
{
    key: 'Series2',
    values: [
        {
            "Name": "Group A",
            "Count": 25.307646510375
        },
        {
            "Name": "Group B",
            "Count": 16.756779544553
        },
        {
            "Name": "Group C",
            "Count": 18.451534877007
        },
        {
            "Name": "Group D",
            "Count": 8.6142352811805
        },
        {
            "Name": "Group E",
            "Count": 7.8082472075876
        },
        {
            "Name": "Group F",
            "Count": 5.259101026956
        },
        {
            "Name": "Group G",
            "Count": 7.0947953487127
        },
        {
            "Name": "Group H",
            "Count": 8
        },
        {
            "Name": "Group I",
            "Count": 21
        }
    ]
},
{
    key: 'Series3',
    values: [
        {
            "Name": "Group A",
            "Count": 14.307646510375
        },
        {
            "Name": "Group B",
            "Count": 16.756779544553
        },
        {
            "Name": "Group C",
            "Count": 18.451534877007
        },
        {
            "Name": "Group D",
            "Count": 8.6142352811805
        },
        {
            "Name": "Group E",
            "Count": 7.8082472075876
        },
        {
            "Name": "Group F",
            "Count": 15.259101026956
        },
        {
            "Name": "Group G",
            "Count": 0.30947953487127
        },
        {
            "Name": "Group H",
            "Count": 0
        },
        {
            "Name": "Group I",
            "Count": 0
        }
    ]
}
    ];



    if (countryName == undefined || countryName == null) {
        countryName = '';
    }
    if (subProcessName == undefined || subProcessName == null) {
        subProcessName = '';
    }
    if (mailBoxName == undefined || mailBoxName == null) {
        mailBoxName = '';
    }
    if (UID == undefined || UID == null) {
        UID = '';
    }
    if (roleID == undefined || roleID == null) {
        roleID = '';
    }
    roleID = parent.roleID;
    if (roleID == 4) {
        UID = parent.UID;
    }
    else {
        UID = 0;
    }
    //debugger;
    //alert(JSON.stringify('{countryName: "' + countryName + '",subprocessname: "' + subProcessName + '",mailBoxName: "' + mailBoxName + '" }'));
    var dataparam = {};
    dataparam['countryName'] = countryName;//'Australia';
    dataparam['subprocessName'] = subProcessName;//'Order to Cash';
    dataparam['mailboxName'] = mailBoxName;  
    dataparam['UID'] = UID;
    dataparam['roleID'] = roleID;

    $.ajax({
        type: "POST",
        url: "../../EMTSrv.asmx/GetStackedbarChartData",
        data: JSON.stringify(dataparam),
        contentType: "application/json; charset=utf-8",
        dataType: 'json',
        success: function (result) {

            // result = long_short_data;
                   
            var chart;
            nv.addGraph(function () {
                chart = nv.models.multiBarHorizontalChart()
                    .x(function (d) { return d.Name })
                    .y(function (d) { return parseInt(d.Count) })
                    //.yErr(function(d) { return [-Math.abs(d.value * Math.random() * 0.3), Math.abs(d.value * Math.random() * 0.3)] })
               //     .barColor(d3.scale.category20().range())
                    .color(["#1f77b4", "#2ca02c", "#d62728", "#bcbd22", "#e377c2", "#6D8E41", "#4E652E", "#2F3C1B", "#9dcb5d", "#17becf", "#1f77b4", "#2f59dd", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b", "#7f7f7f"])
                    //.duration(250)
                    .margin({ left: 125 })
                    .showControls(true)
                    .stacked(true);

                chart.yAxis.tickFormat(d3.format(',d'));//.2f'));

                //chart.yAxis.axisLabel('Y Axis');`
                //chart.xAxis.axisLabel('X Axis').axisLabelDistance(20);

                d3.select('#stackedGraphchart svg')
                    .datum(result.d)
                    //.datum(result)
                    .call(chart);

                nv.utils.windowResize(chart.update);

                chart.dispatch.on('stateChange', function (e) { nv.log('New State:', JSON.stringify(e)); });
                chart.state.dispatch.on('change', function (state) {
                    nv.log('state', JSON.stringify(state));
                });
                return chart;
            });
        },
        error: function (result) {

        }
    });
    $('#test2').css({ "height": "540px", "width": "430px" });
}

