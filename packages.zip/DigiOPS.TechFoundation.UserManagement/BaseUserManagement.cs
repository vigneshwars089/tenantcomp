﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.UserManagement
{
  public  class BaseUserManagement :IUserManagement
    {


        public virtual UserMgmtInfo AddOrUpdateUserMgmt(AddUsers user)
        {
            throw new NotImplementedException();
        }

        public virtual UserMgmtInfo DeleteUserMgmt(AddUsers user)
        {
            throw new NotImplementedException();
        }

        public virtual UserMgmtInfo AddOrUpdateGroupUser(GroupUsers groupUser)
        {
            throw new NotImplementedException();
        }

        public virtual UserMgmtInfo AddOrUpdateUserGroupUserMapping(GroupUserMapping groupUserMapping)
        {
            throw new NotImplementedException();
        }

        public virtual UserMgmtInfo AddUserRoleMapping(UserRoleMapping objUserRoleMapping)
        {
            throw new NotImplementedException();
        }

        public virtual UserMgmtInfo DeleteUserRoleMapping(UserRoleMapping objUserRoleMapping)
        {
            throw new NotImplementedException();
        }

        public virtual UserMgmtInfo AddRolePermissionMapping(RolePermissionMapping rolePermissionMapping)
        {
            throw new NotImplementedException();
        }
    }
}
