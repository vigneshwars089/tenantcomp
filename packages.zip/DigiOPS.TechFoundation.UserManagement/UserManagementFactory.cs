﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.UserManagement
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :GetUserManagementHandler.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Interface Name(s) :GetUserManagementHandler
    // Author : P Sadhesh Kumar.
    // Creation Date : 6/12/2017
    // Purpose : This Interface will be used to create the object of sampling Type class depending on the user input.
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //12-Jun-2017    sadhesh             GetUserManagementHandler                
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class UserManagementFactory : IUserManagementFactory
    {

        public struct S_UserManagement
        {

            public const string User = "User";
            public const string UserGroup = "UserGroup";
            public const string UserGroupMapping = "UserGroupMapping";
            public const string UserRoleMapping = "UserRoleMapping";
            public const string UserRolePermissionMapping = "UserRolePermissionMapping";

        }

        public IUserManagement GetUserManagementHandler(string Type)
        {
            IUserManagement objSampling = null;

            switch (Type)
            {
                case S_UserManagement.User:
                    objSampling = new UserCreation();

                    break;
                case S_UserManagement.UserGroup:
                    objSampling = new UserGroupCreation();
                    break;
                case S_UserManagement.UserGroupMapping:
                    objSampling = new UserGroupMapping();
                    break;

                case S_UserManagement.UserRoleMapping:
                    objSampling = new UserRoleMapping();
                    break;
                case S_UserManagement.UserRolePermissionMapping:
                    objSampling = new UserRolePermissionMapping();
                    break;
              
            }

            return objSampling;
        }




    }

}
