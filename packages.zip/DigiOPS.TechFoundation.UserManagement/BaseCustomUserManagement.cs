﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
namespace DigiOPS.TechFoundation.UserManagement
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :BaseCustomUserManagement.cs
    // Namespace : DigiOps.TechFoundation.DataTransfer
    // Class Name(s) :BaseCustomUserManagement
    // Author : Sadhesh
    // Creation Date : 6/14/2017
    // Purpose : insert the user and user group details for EMT and quart
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //14-Jun-2017    Sadhesh     Create            Create user,usergroup, usergroup mapping, usergroup role mapping  
    //14-Jun-2017    Sadhesh     Read            Read user,usergroup content
    //14-Jun-2017    Sadhesh     Update            update user,usergroup, usergroup mapping, usergroup role mapping  
    //14-Jun-2017    Sadhesh     Delete            delete user, usergroup mapping

    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class BaseCustomUserManagement
    {

        public virtual UserMgmtInfo CreateUser(UserInfo BaseData)
        {
            UserMgmtInfo objinfo = new UserMgmtInfo();
            int result = 0;
            BaseData.ResultStatus = false;
            try
            {
                switch (BaseData.AppID)
                {
                    case S_AppID.EMT:
                        {
                            if (ValidatingUser(BaseData))
                            {
                                IUserRepository objUserRepository = new EMTUserRepository();

                                objinfo = objUserRepository.Create(BaseData);
                                if (result <= 0)
                                {
                                    BaseData.ErrorMessage.Append("Error");
                                    return objinfo;
                                }
                                else
                                {

                                    BaseData.ResultStatus = true;
                                    return objinfo;
                                }
                            }
                            break;
                        }
                    case S_AppID.AUDIT:
                        {
                            //if (ValidatingUser(BaseData))
                            //{
                            IUserRepository objUserRepository = new AuditUserRepository();

                            objinfo = objUserRepository.Create(BaseData);
                            //if (result <= 0)
                            //{
                            //    objinfo.ErrorMessage.Append("Error");
                            //    return objinfo;
                            //}
                            //else
                            //{

                                objinfo.ResultStatus = true;
                                return objinfo;
                            //}
                            //}

                        }
                    default: { break; }
                }
            }
            catch (Exception Ex)
            {
                objinfo.ResultStatus = false;
                return objinfo;
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //Response.Redirect("~/Errors/Error.aspx", false);

            }
            return objinfo;
        }

        public virtual UserMgmtInfo UpdateUser(UserInfo BaseData)
        {
            UserMgmtInfo objinfo = new UserMgmtInfo();
            int result = 0;
            BaseData.ResultStatus = false;
            try
            {
                switch (BaseData.AppID)
                {
                    case S_AppID.EMT:
                        {
                            if (ValidatingUser(BaseData))
                            {
                                IUserRepository objUserRepository = new EMTUserRepository();

                                objinfo = objUserRepository.Update(BaseData);
                                if (result <= 0)
                                {
                                    objinfo.ErrorMessage.Append("Error");
                                    return objinfo;
                                }
                                else
                                {
                                    objinfo.ResultStatus = true;
                                    return objinfo;
                                }
                            }
                            break;
                        }
                    case S_AppID.AUDIT:
                        {
                            //if (ValidatingUser(BaseData))
                            //{
                            IUserRepository objUserRepository = new AuditUserRepository();

                            objinfo = objUserRepository.Create(BaseData);
                            //if (result <= 0)
                            //{
                            //    objinfo.ErrorMessage.Append("Error");
                            //    return objinfo;
                            //}
                            //else
                            //{

                                objinfo.ResultStatus = true;
                                return objinfo;
                            //}
                            //}

                        }
                    default: { break; }
                }
            }
            catch (Exception Ex)
            {
                objinfo.ResultStatus = false;
                return objinfo;
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //Response.Redirect("~/Errors/Error.aspx", false);

            }
            return objinfo;
        }

        public virtual UserMgmtInfo DeleteUser(UserInfo BaseData)
        {
            UserMgmtInfo objinfo = new UserMgmtInfo();
            int result = 0;
            BaseData.ResultStatus = false;
            try
            {
                switch (BaseData.AppID)
                {
                   
                    case S_AppID.AUDIT:
                        {
                            //if (ValidatingUser(BaseData))
                            //{
                            IUserRepository objUserRepository = new AuditUserRepository();

                            objinfo = objUserRepository.Delete(BaseData);
                            //if (result <= 0)
                            //{
                            //    objinfo.ErrorMessage.Append("Error");
                            //    return objinfo;
                            //}
                            //else
                            //{

                                objinfo.ResultStatus = true;
                                return objinfo;
                            //}
                            //}

                        }
                    default: { break; }
                }
            }
            catch (Exception Ex)
            {
                objinfo.ResultStatus = false;
                return objinfo;
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //Response.Redirect("~/Errors/Error.aspx", false);

            }
            return objinfo;
        }

        public virtual UserMgmtInfo ReadUser(UserInfo BaseData)
        {
            UserMgmtInfo objinfo = new UserMgmtInfo();
            int result = 0;
            BaseData.ResultStatus = false;
            try
            {
                switch (BaseData.AppID)
                {
                    
                    case S_AppID.AUDIT:
                        {
                            //if (ValidatingUser(BaseData))
                            //{
                            IUserRepository objUserRepository = new AuditUserRepository();

                            objinfo = objUserRepository.Read(BaseData);
                            //if (result <= 0)
                            //{
                            //    objinfo.ErrorMessage.Append("Error");
                            //    return objinfo;
                            //}
                            //else
                            //{

                                objinfo.ResultStatus = true;
                                return objinfo;
                            //}
                            //}
                            
                        }
                    default: { break; }
                }
            }
            catch (Exception Ex)
            {
                objinfo.ResultStatus = false;
                return objinfo;
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //Response.Redirect("~/Errors/Error.aspx", false);

            }
            return objinfo;
        }

        public virtual int AssignUserRole(UserRoleInfo ObjRoleInfo)
        {
            int result = 0;
            ObjRoleInfo.ResultStatus = false;
            try
            {
                switch (ObjRoleInfo.AppID)
                {
                    case S_AppID.EMT:
                        {
                            IUserRepository objUserRepository = new EMTUserRepository();

                            result = objUserRepository.AssignRole(ObjRoleInfo);
                            if (result <= 0)
                            {
                                ObjRoleInfo.ErrorMessage.Append("Error");
                                return result;

                            }
                            else
                            {
                                ObjRoleInfo.ResultStatus = true;
                                return result;
                            }
                            break;

                        }
                    default: { break; }
                }
            }
            catch (Exception Ex)
            {
                ObjRoleInfo.ResultStatus = false;
                return result;
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //Response.Redirect("~/Errors/Error.aspx", false);

            }
            return result;
        }

        public int UpdateUserRole(UserRoleInfo objRoleInfo)
        {
            int result = 0;
            objRoleInfo.ResultStatus = false;
            try
            {
                switch (objRoleInfo.AppID)
                {
                    case S_AppID.EMT:
                        {
                            IUserRepository objUserRepository = new EMTUserRepository();

                            result = objUserRepository.UpdateUserRole(objRoleInfo);
                            if (result <= 0)
                            {
                                objRoleInfo.ErrorMessage.Append("Error");
                                return result;

                            }
                            else
                            {
                                objRoleInfo.ResultStatus = true;
                                return result;
                            }
                            break;

                        }
                    default: { break; }
                }
            }
            catch (Exception Ex)
            {
                objRoleInfo.ResultStatus = false;
                return result;
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //Response.Redirect("~/Errors/Error.aspx", false);

            }
            return result;
        }

        public int DeleteUserRole(UserRoleInfo objRoleInfo)
        {
            int result = 0;
            objRoleInfo.ResultStatus = false;
            try
            {
                switch (objRoleInfo.AppID)
                {
                    case S_AppID.EMT:
                        {
                            IUserRepository objUserRepository = new EMTUserRepository();

                            result = objUserRepository.DeleteUserRole(objRoleInfo);
                            if (result <= 0)
                            {
                                objRoleInfo.ErrorMessage.Append("Error");
                                return result;

                            }
                            else
                            {
                                objRoleInfo.ResultStatus = true;
                                return result;
                            }
                            break;

                        }

                    default: { break; }
                }
            }
            catch (Exception Ex)
            {
                objRoleInfo.ResultStatus = false;
                return result;
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.aspx.cs | btnSubmit_Click()");
                //Response.Redirect("~/Errors/Error.aspx", false);

            }
            return result;
        }

        private bool IsValidRoleToAccessThisPage(UserInfo UserData)
        {
            try
            {
                if ((UserData.RoleId == (int)Constant.UserRole.TeamLead) || (UserData.RoleId == (int)Constant.UserRole.Admin) || (UserData.RoleId == (int)Constant.UserRole.SuperAdmin))
                {
                    return true;
                }
                else
                {
                    //Response.Redirect(@"~\Errors\AccessDenied.aspx", false);
                    return false;
                }
            }
            catch (Exception Ex)
            {
                //ExceptionHelper.HandleException(Ex);
                //errorlog.HandleError(Ex, UserData.UserId, " | CreateUser.cs | IsValidRoleToAccessThisPage()");
                //Response.Redirect("~/Errors/Error.aspx", false);
                return false;
            }

        }

        public bool ValidatingUser(UserInfo BaseData)
        {
            if (string.IsNullOrEmpty(BaseData.UserID))
            {
                BaseData.ErrorMessage.Append("UserID is null");
            }
            else if (string.IsNullOrEmpty(BaseData.FirstName))
            {
                BaseData.ErrorMessage.Append("FirstName is null");
            }
            else if (string.IsNullOrEmpty(BaseData.LastName))
            {
                BaseData.ErrorMessage.Append("LastName is null");
            }
            else if (string.IsNullOrEmpty(BaseData.EmailID))
            {
                BaseData.ErrorMessage.Append("EmailID is null");
            }
            else if (string.IsNullOrEmpty(BaseData.TimeZone))
            {
                BaseData.ErrorMessage.Append("TimeZone is null");
            }
            else if (string.IsNullOrEmpty(BaseData.EncryptPassword))
            {
                BaseData.ErrorMessage.Append("EncryptPassword is null");
            }
            else if (string.IsNullOrEmpty(BaseData.EncryptConfirmPassword))
            {
                BaseData.ErrorMessage.Append("EncryptConfirmPassword is null");
            }
            else if (BaseData.EncryptPassword != BaseData.EncryptConfirmPassword)
            {
                BaseData.ErrorMessage.Append("Password's do not match");
                return false;
            }
            else
            {
                return true;
            }

            return false;
        }
    }
}
