﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;

namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :SamplingFactory.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :SamplingFactory
    // Author : P Sadhesh Kumar.
    // Creation Date : 4/17/2017
    // Purpose : This class will be used to create the object of sampling Type class depending on the user input.
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class SamplingFactory : ISamplingFactory
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :SamplingFactory.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Interface Name(s) :GetSamplingHandler
        // Author : P Sadhesh Kumar.
        // Creation Date : 4/17/2017
        // Purpose : This Interface will be used to create the object of sampling Type class depending on the user input.
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public ISampling GetSamplingHandler(string Type)
        {
            ISampling objSampling = null;

            switch (Type)
            {
                case Constants.RANDOM:
                    objSampling = new SimpleRandomSampling();

                    break;
                case Constants.STRATIFIED:
                    objSampling = new StratifiedSampling();
                    break;
                case Constants.STATISTICAL:
                    objSampling = new StatisticalSampling();
                    break;

                case Constants.FIELD:
                    objSampling = new FieldSampling();
                    break;
                case Constants.TEAM:
                    objSampling = new TeamSampling();
                    break;
                case Constants.VOLUME:
                    objSampling = new VolumeSampling();
                    break;
                case Constants.PROPENSITYSCORE:
                    objSampling = new PropensityScoreSampling();
                    break;
            }

            return objSampling;
        }

        public TransactionListDetails GetSampingDetails(string Actor, string Duration, string Type, TransactionListDetails objTransListDetails)
        {

            LoggingFactory objlog = new LoggingFactory();
            LogInfo objloginfo = new LogInfo();
            TransactionListDetails objListDet = new TransactionListDetails();
            TransactionListResponse objListRes = new TransactionListResponse();
            List<TransactionLists> objListTran = new List<TransactionLists>();

            BaseSampling objbase = new BaseSampling();
            objListDet = objbase.SamplingValidation(Actor, Duration, Type, objTransListDetails);

            if (objListDet.ResultStatus)
            {
                SamplingDataFilterFactory objSamplingDataFilterFactory = new SamplingDataFilterFactory();

                //Calling the Filter Handler
                objListRes = objSamplingDataFilterFactory.GetFilterHandler(Actor, Duration, Type).GetDataTobeSampled(Actor, Duration, Type, objTransListDetails);

                SamplingFactory objsampling = new SamplingFactory();
                //Calling the Sampling Handler and passing the response list received from Filter Handler
                objListRes = objsampling.GetSamplingHandler(Type).GetSampledSet(objListRes, Actor, Duration);

                //if (objTransListDetails.TobeStoredDB == true)
                //{

                //    string rtnVal = string.Empty;
                //    SamplingDataAccess SamplingDA = new SamplingDataAccess();
                //    rtnVal = SamplingDA.InsertSampledTrans(objListRes.TransactionLists);
                //    objListDet.TransactionLists = objListRes.TransactionLists;
                //    objTransListDetails.ErrorMessage.Append(rtnVal.ToString());
                //}
                //else
                //{
                //Returning the Response Transaction List 
                objListDet.TransactionLists = objListRes.TransactionLists;
                //}


            }
            if (objListDet.ResultStatus == false || objListDet.ErrorMessage.ToString() != "")
            {
                objListDet.TransactionLists = objListTran;
            }
            return objListDet;
        }

        public TransactionListDetails GetSampingDetails(MultiStageSamplingInfo objmultistageinfo, TransactionListDetails objTransListDetails)
        {
            List<SamplingInfo> objinfo = (from c in objmultistageinfo.Multistageinfo
                                          orderby c.Level ascending
                                          select new SamplingInfo()
                                          {
                                              Level = c.Level,
                                              Actor = c.Actor,
                                              Duration = c.Duration,
                                              Type = c.Type
                                          }

                                         ).ToList();

            TransactionListDetails objListDet = new TransactionListDetails();
            TransactionListResponse objListRes = new TransactionListResponse();
            List<TransactionLists> objListTran = new List<TransactionLists>();

            BaseSampling objbase = new BaseSampling();

            TransactionListDetails objoutput = new TransactionListDetails();
            objListDet = objTransListDetails;

            foreach (SamplingInfo obj in objinfo)
            {

                objListDet = objbase.SamplingValidation(obj.Actor, obj.Duration, obj.Type, objListDet);
                if (objListDet.ResultStatus)
                {
                    SamplingDataFilterFactory objSamplingDataFilterFactory = new SamplingDataFilterFactory();

                    //Calling the Filter Handler
                    objListRes = objSamplingDataFilterFactory.GetFilterHandler(obj.Actor, obj.Duration, obj.Type).GetDataTobeSampled(obj.Actor, obj.Duration, obj.Type, objListDet);

                    SamplingFactory objsampling = new SamplingFactory();
                    //Calling the Sampling Handler and passing the response list received from Filter Handler
                    objListRes = objsampling.GetSamplingHandler(obj.Type).GetSampledSet(objListRes, obj.Actor, obj.Duration);

                    //if (objTransListDetails.TobeStoredDB == true)
                    //{

                    //    string rtnVal = string.Empty;
                    //    SamplingDataAccess SamplingDA = new SamplingDataAccess();
                    //    rtnVal = SamplingDA.InsertSampledTrans(objListRes.TransactionLists);
                    //    objListDet.TransactionLists = objListRes.TransactionLists;
                    //    objTransListDetails.ErrorMessage.Append(rtnVal.ToString());
                    //}
                    //else
                    //{
                    //Returning the Response Transaction List 
                    objListDet.TransactionLists = objListRes.TransactionLists;
                    //}


                }
            }

            return objTransListDetails;
        }



    }
}
