﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{
    public interface IBaseSamplingStage
    {
        TransactionListDetails GetSampingDetails(string Actor, string Duration, string Type, TransactionListDetails objTransListDetails);

        TransactionListDetails GetSampingDetails(MultiStageSamplingInfo objmultistageinfo, TransactionListDetails objTransListDetails);
    }
}
