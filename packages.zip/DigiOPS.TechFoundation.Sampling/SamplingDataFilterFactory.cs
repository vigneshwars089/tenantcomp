﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :SamplingDataFilterFactory.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :SamplingDataFilterFactory
    // Author : P Sadhesh Kumar.
    // Creation Date : 4/18/2017
    // Purpose : This class will be used to create the Filtered objects depending on the user Actor(SubProcess,Processor), Duration(Daily, Monthly), Type(Filed,Team,Random..etc.)
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class SamplingDataFilterFactory: IDataToBeSampledFactory
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :SamplingDataFilterFactory.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Interface Name(s) :GetFilterHandler
        // Author : P Sadhesh Kumar.
        // Creation Date : 4/18/2017
        // Purpose : This Interface will be used to create the Filtered objects depending on the user Actor(SubProcess,Processor), Duration(Daily, Monthly), Type(Filed,Team,Random..etc.)
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public IDataToBeSampled GetFilterHandler(string Actor, string Duration, string Type)
        {
            IDataToBeSampled objSampling = null;

            switch (Actor)
            {
                case Constants.PROCESSOR:
                    switch (Duration)
                    {
                        case Constants.DAILY:
                            objSampling = new DataToBeFilteredByProcessorDaily();
                            break;
                        case Constants.Monthly:
                            objSampling = new DataToBeFilteredByProcessorMonthly();
                            break;

                    }
                    break;
                case Constants.SUBPROCESS:
                    switch (Duration)
                    {
                        case Constants.DAILY:
                            objSampling = new DataToBeFilteredBySubProcessDaily();
                            break;
                        case Constants.Monthly:
                            objSampling = new DataToBeFilteredBySubProcessMonthly();
                            break;

                    }
                    break;

            }

            if (Type == Constants.STRATIFIED)
            {
                objSampling = new DataToBeFilteredByCondition();
            }
            if (Type == Constants.FIELD)
            {
                objSampling = new DataToBeFilteredByField();
            }
            if (Type == Constants.STATISTICAL)
            {
                objSampling = new DataToBeFilteredByFormula();
            }
            if (Type == Constants.TEAM)
            {
                objSampling = new DataToBeFilteredByTeam();
            }
            if (Type == Constants.VOLUME)
            {
                objSampling = new DataToBeFilteredByVolume();
            }
            if (Type == Constants.PROPENSITYSCORE)
            {
                objSampling = new DataToBeFilteredByThresholdValue();
            }
            return objSampling;
        }

    }
}
