﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :MultiStageSampling.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :MultiStageSampling
    // Author : P Sadhesh Kumar.
    // Creation Date : 5/4/2017
    // Purpose : This class will be used to select the Multi Stage sampling.
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class MultiStageSampling : BaseSamplingStage
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :MultiStageSampling.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Class Name(s) :GetSampingDetails
        // Author : P Sadhesh Kumar.
        // Creation Date : 5/4/2017
        // Purpose : This Class will be used to Get the Sampling Details for MultiStage Sampling.
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        
        public override TransactionListDetails GetSampingDetails(MultiStageSamplingInfo objmultistageinfo, TransactionListDetails objTransListDetails)
        {
            List<SamplingInfo> objinfo = (from c in objmultistageinfo.Multistageinfo
                                          orderby c.Level ascending
                                          select new SamplingInfo()
                                          {
                                              Level = c.Level,
                                              Actor = c.Actor,
                                              Duration = c.Duration,
                                              Type = c.Type
                                          }

                                         ).ToList();

            TransactionListDetails objListDet = new TransactionListDetails();
            TransactionListResponse objListRes = new TransactionListResponse();
            List<TransactionLists> objListTran = new List<TransactionLists>();

            BaseSampling objbase = new BaseSampling();

            TransactionListDetails objoutput = new TransactionListDetails();
            objListDet = objTransListDetails;

            foreach (SamplingInfo obj in objinfo)
            {

                objListDet = objbase.SamplingValidation(obj.Actor, obj.Duration, obj.Type, objListDet);
                if (objListDet.ResultStatus)
                {
                    SamplingDataFilterFactory objSamplingDataFilterFactory = new SamplingDataFilterFactory();

                    //Calling the Filter Handler
                    objListRes = objSamplingDataFilterFactory.GetFilterHandler(obj.Actor, obj.Duration, obj.Type).GetDataTobeSampled(obj.Actor, obj.Duration, obj.Type, objListDet);

                    SamplingFactory objsampling = new SamplingFactory();
                    //Calling the Sampling Handler and passing the response list received from Filter Handler
                    objListRes = objsampling.GetSamplingHandler(obj.Type).GetSampledSet(objListRes, obj.Actor,obj.Duration);

                    //if (objTransListDetails.TobeStoredDB == true)
                    //{

                    //    string rtnVal = string.Empty;
                    //    SamplingDataAccess SamplingDA = new SamplingDataAccess();
                    //    rtnVal = SamplingDA.InsertSampledTrans(objListRes.TransactionLists);
                    //    objListDet.TransactionLists = objListRes.TransactionLists;
                    //    objTransListDetails.ErrorMessage.Append(rtnVal.ToString());
                    //}
                    //else
                    //{
                        //Returning the Response Transaction List 
                        objListDet.TransactionLists = objListRes.TransactionLists;
                    //}


                }
            }

            return objTransListDetails;
        }





    }
}
