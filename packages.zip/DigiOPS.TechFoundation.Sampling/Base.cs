﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{
    public class BaseSample : ISampling
    {
        public virtual TransactionListDetails GetSampledSet(TransactionListDetails DatatobeSampled)
        {
            //Getting the SamplingPercentage
            double SampPercentage = 100;

            //Getting the Transaction Total count
           // List<object> Transaction = 100;

            double Percentage = (DatatobeSampled.Total * SampPercentage) / 100;
            TransactionListDetails obj = new TransactionListDetails();
            //switch (objTranDet.SamplingLevel)
            //{
            //    case Constants.SUBPROCESS:
            //        objSamplingType = new RandomSubProcessSampling();

            //        break;
            //    case Constants.PROCESSOR:
            //        objSamplingType = new RandomProcessorSampling();

            //        break;

            //    default:
            //        objSamplingType = new RandomSubProcessSampling();
            //        break;
            //}
            return obj;
        }
        //public virtual object GetDataToBeSampled(List<object> AssociateList)
        //{
        //    return null;
        //}
        //public virtual object GetFieldsToBeSampled(List<object> Field)
        //{
        //    return null;
        //}

        
    }
}
