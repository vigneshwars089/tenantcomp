﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :SamplingStageFactory.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :SamplingStageFactory
    // Author : P Sadhesh Kumar.
    // Creation Date : 5/4/2017
    // Purpose : This class will be used to select the single Stage or Multi Stage sampling.
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class SamplingStageFactory : ISamplingStageFactory
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :SamplingStageFactory.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Class Name(s) :GetSamplingStageHandler
        // Author : Venkata Lakshmi CH.
        // Creation Date : 5/4/2017
        // Purpose : This Class will be used to select the single Stage or Multi Stage sampling.
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public IBaseSamplingStage GetSamplingStageHandler(string Type)
        {

            switch (Type)
            {
                case "SingleStage":
                    return new SingleStage();

                case "MultiStage":
                    return new MultiStageSampling();

                default:
                    return new BaseSamplingStage();
            }

        }
    }
}
