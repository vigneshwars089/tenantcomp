﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :VolumeSampling.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :VolumeSampling
    // Author : Venkata Lakshmi CH.
    // Creation Date : 5/4/2017
    // Purpose : This class will be used to perform Sampling for Volume.
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class VolumeSampling : BaseSampling
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :VolumeSampling.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Method Name(s) :GetSampledSet
        // Author : Venkata Lakshmi CH.
        // Creation Date : 5/4/2017
        // Purpose : This method will be used to perform Sampling for Volume.
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public override TransactionListResponse GetSampledSet(TransactionListResponse objTransactionListDetails, string Actor, string Duration)
        {


            List<TransactionLists> objTransactionLists = objTransactionListDetails.TransactionLists;
            List<TransactionsPendingLists> objTransactionAllocatedLists = objTransactionListDetails.TransactionPendingLists;
            List<TransactionLists> objGetFinalTransactionLists = new List<TransactionLists>();


            var ran = new Random();


            /*Getting the transactions from Subprocess based on the TobeSampled */
            objGetFinalTransactionLists = (from c in objTransactionLists
                                           select c).OrderBy(x => ran.Next()). Take((int)objTransactionAllocatedLists
                                           .Select(b => b.TobeSampled).DefaultIfEmpty(0).Single()).Cast<TransactionLists>()
                                 
                                           .ToList();




            objTransactionListDetails.TransactionLists = objGetFinalTransactionLists;
            return objTransactionListDetails;
        }


    }
}
