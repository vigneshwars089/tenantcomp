﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :TeamSampling.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :TeamSampling
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/28/2017
    // Purpose : This class will be used to perform Sampling for Team.
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class TeamSampling : BaseSampling
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :TeamSampling.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Method Name(s) :GetSampledSet
        // Author : Venkata Lakshmi CH.
        // Creation Date : 4/28/2017
        // Purpose : This method will be used to perform Sampling for Team.
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public override TransactionListResponse GetSampledSet(TransactionListResponse objTransactionListDetails, string Actor, string Duration)
        {


            List<TransactionLists> objTransactionLists = objTransactionListDetails.TransactionLists;
            int startrowindex = 1;
            int maxrow = 10;

            try
            {
                startrowindex = objTransactionListDetails.TransactionLists.ElementAtOrDefault(0).StartrowIndex;
                maxrow = objTransactionListDetails.TransactionLists.ElementAtOrDefault(0).MaximumRows;
            }
            catch (Exception ex)
            {

            }
            List<TransactionsPendingLists> objTransactionAllocatedLists = objTransactionListDetails.TransactionPendingLists;

            List<TransactionLists> objGetFinalTransactionLists = new List<TransactionLists>();
            int Allocated = objTransactionAllocatedLists.FirstOrDefault().Allocated;

            double SampPercentage = objTransactionAllocatedLists.FirstOrDefault().Percentage;

            int Total = (from p in objTransactionListDetails.TransactionLists

                         select p
                          ).Count();


            /* Calculating the Percentage*/
            double Percentage = Math.Ceiling((Total * SampPercentage) / 100);

            /* Calculating the pending transactions*/
            int pending = Convert.ToInt16(Percentage);
            pending = ((pending <= Allocated) ? 0 : pending - Allocated);

            /*Grouping the Priority */
            var objGrpPriority = from c in objTransactionLists
                                 group c by new { c.Priority } into Procgrp
                                 select new
                                 {
                                     Priority = Procgrp.Key.Priority,
                                     NoofTransaction = Procgrp.Count()


                                 };
            int TotalPriorityCount = objGrpPriority.Count();
            int PriorityCount = 1;


            List<Priority> objpriority = new List<Priority>();

            for (int j = 1; j <= pending; j++)
            {
                if (PriorityCount <= TotalPriorityCount)
                {
                    var alreadyexist = objpriority.Where(x => x.Key == PriorityCount).Count();
                    int PriorityTranCount = objGrpPriority.Where(x => int.Parse(x.Priority) == PriorityCount).FirstOrDefault().NoofTransaction;

                    if (alreadyexist != 0)
                    {
                        int Remcnt = objpriority.Where(x => x.Key == PriorityCount).SingleOrDefault().Value;
                        if (Remcnt < PriorityTranCount)
                        {
                            var objvalue = objpriority.Where(x => x.Key == PriorityCount);
                            objvalue.FirstOrDefault().Value = (int.Parse(objvalue.FirstOrDefault().Value.ToString()) + 1);
                        }
                        else
                        {
                            j--;
                        }
                    }
                    else
                    {
                        if (objpriority == null)
                        {
                            objpriority = new List<Priority>();
                        }
                        Priority obj = new Priority();
                        obj.Key = PriorityCount;
                        obj.Value = 1;
                        objpriority.Add(obj);
                    }
                    PriorityCount++;
                }
                else
                {

                    j--;
                    PriorityCount = 1;
                }


            }
            var ran = new Random();
            /*Getting the transactions from each Priority based on the TobeSampled */
            objGetFinalTransactionLists = objTransactionLists.GroupBy(a => new { a.Priority })
                                     .OrderBy(x => ran.Next())
                                     .SelectMany(g => g.Take((int)objpriority.Where(b => (b.Key == (int.Parse( g.Key.Priority))))
                                         .Select(b => b.Value).DefaultIfEmpty(0).Single())).ToList();
            
            int skip=(startrowindex-1)*maxrow;
            objTransactionListDetails.TransactionLists = objGetFinalTransactionLists.Skip(skip).Take(maxrow).ToList();
            if (objGetFinalTransactionLists.Count() > 0)
            {
                objTransactionListDetails.TransactionLists.ElementAtOrDefault(0).TotalRecordrows = objGetFinalTransactionLists.Count;
            }
            return objTransactionListDetails;
        }

        public class Priority
        {

            public int Key { get; set; }
            public int Value { get; set; }
        }

    }
}
