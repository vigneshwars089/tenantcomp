﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :FieldSampling.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :FieldSampling
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/26/2017
    // Purpose : This class will be used to perform Sampling for Field.
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class FieldSampling:BaseSampling
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :FieldSampling.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Method Name(s) :GetSampledSet
        // Author : Venkata Lakshmi CH.
        // Creation Date : 4/26/2017
        // Purpose : This method will be used to perform Sampling for Field.
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////

        public override TransactionListResponse GetSampledSet(TransactionListResponse objTransactionListDetails, string Actor, string Duration)
        {


            List<TransactionLists> objTransactionLists = objTransactionListDetails.TransactionLists;
            List<TransactionsPendingLists> objTransactionAllocatedLists = objTransactionListDetails.TransactionPendingLists;
            List<TransactionLists> objGetFinalTransactionLists = new List<TransactionLists>();

            if (Actor == Constants.PROCESSOR)
            {

                if (Duration == Constants.DAILY)
                {

                    /*Getting the transactions from each processors based on the TobeSampled */
                    objGetFinalTransactionLists = objTransactionLists.GroupBy(a => new { a.ProcessedBy, a.ProcessedDate })

                                             .SelectMany(g => g.Take((int)objTransactionAllocatedLists.Where(b => (b.ProcessedBy == g.Key.ProcessedBy) && (b.ProcessedDate == g.Key.ProcessedDate))

                                                 .Select(b => b.TobeSampled).DefaultIfEmpty(0).Single())).ToList();
                }
                else if (Duration == Constants.Monthly)
                {
                    /*Getting the transactions from each processors based on the TobeSampled */
                    objGetFinalTransactionLists = objTransactionLists.GroupBy(a => new { a.ProcessedBy })

                                             .SelectMany(g => g.Take((int)objTransactionAllocatedLists.Where(b => (b.ProcessedBy == g.Key.ProcessedBy))

                                                 .Select(b => b.TobeSampled).DefaultIfEmpty(0).Single())).ToList();
                }

            }
            else if (Actor == Constants.SUBPROCESS)
            {


                if (Duration == Constants.DAILY)
                {
                    /*Getting the transactions from each processors based on the TobeSampled */
                    objGetFinalTransactionLists = objTransactionLists.GroupBy(a => new { a.ProcessedDate })

                                             .SelectMany(g => g.Take((int)objTransactionAllocatedLists.Where(b => (b.ProcessedDate == g.Key.ProcessedDate))

                                                 .Select(b => b.TobeSampled).DefaultIfEmpty(0).Single())).ToList();
                }
                else if (Duration == Constants.Monthly)
                {
                    /*Getting the transactions from Subprocess based on the TobeSampled */
                    objGetFinalTransactionLists = (from c in objTransactionLists
                                                   select c).Take((int)objTransactionAllocatedLists

                                                   .Select(b => b.TobeSampled).DefaultIfEmpty(0).Single()).Cast<TransactionLists>().ToList();
                }


            }

            objTransactionListDetails.TransactionLists = objGetFinalTransactionLists;
            return objTransactionListDetails;
        }

    }
}
