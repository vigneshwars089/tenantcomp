﻿using DigiOPS.TechFoundation.Sampling;
using System;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;

namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :BaseSampling.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :BaseSampling
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/6/2017
    // Purpose : This class will be having one virtual method GetSampledSet and one concreat method is SamplingValidation which 
    // will validate the TransactionLiseDetais Object and parameters which are passed to the sampling component.
    //
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
    //////////////////////////////////////////////////////////////////////////////////////////////////////


    public class BaseSampling : ISampling
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :BaseSampling.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Class Name(s) :TransactionListResponse
        // Author : P. Sadhesh Kumar.
        // Creation Date : 4/6/2017
        // Purpose : This method will be implemented in all the sampling classes.
        //
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name         Method Name               Description
        // ----------   --------    -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public virtual TransactionListResponse GetSampledSet(TransactionListResponse ObjDatatobeSampled, string Actor, string Duration)
        {
            throw new NotImplementedException();
        }

        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :BaseSampling.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Class Name(s) :TransactionListResponse
        // Author : P. Sadhesh Kumar.
        // Creation Date : 4/26/2017
        // Purpose : This method will be used validate the TransactionLiseDetais Object and parameters which are passed to the sampling component.
        //
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name         Method Name               Description
        // ----------   --------    -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        public TransactionListDetails SamplingValidation(string Actor, string Duration, string Type, TransactionListDetails objTranListDet)
        {
            LoggingFactory objlog = new LoggingFactory();
            LogInfo objloginfo = new LogInfo();
            objTranListDet.ResultStatus = false;
            objTranListDet.ErrorMessage = new StringBuilder();

            int flag = 0;
            try
            {
                if (objTranListDet.TransactionLists.Count == 0 || (objTranListDet.TransactionLists) == null)
                {
                    objTranListDet.ErrorMessage.Append("There are no transactions to perform sampling");
                    objTranListDet.ResultStatus = false;
                }
                else
                {
                    if ((Actor == Constants.SUBPROCESS || Actor == Constants.PROCESSOR) && (Duration == Constants.DAILY || Duration == Constants.Monthly) && (Type == Constants.RANDOM || Type == Constants.STATISTICAL || Type == Constants.STRATIFIED || Type == Constants.FIELD || Type == Constants.TEAM || Type == Constants.VOLUME || Type == Constants.PROPENSITYSCORE))
                    {
                        if (Actor == Constants.PROCESSOR)
                        {
                            foreach (TransactionLists item in objTranListDet.TransactionLists)
                            {


                                if (item.ProcessedBy <= 0)
                                {
                                    flag = 1;
                                }
                                else if (item.RecordID <= 0)
                                {
                                    flag = 2;
                                }

                                if (Type == Constants.STRATIFIED)
                                {
                                    if (string.IsNullOrEmpty(item.DataValue))
                                    {
                                        flag = 3;
                                    }


                                }

                                if (Type == Constants.FIELD)
                                {
                                    if (string.IsNullOrEmpty(item.DataValue))
                                    {
                                        flag = 3;
                                    }

                                }


                            }
                            foreach (TransactionsAllocatedLists item in objTranListDet.TransactionAllocatedLists)
                            {


                                if (item.ProcessedBy <= 0)
                                {
                                    flag = 4;
                                }
                                else if (item.Percentage < 0)
                                {
                                    flag = 5;
                                }
                                else if (item.Sampled < 0)
                                {
                                    flag = 6;
                                }
                                
                            }

                        }
                        else if (Actor == Constants.SUBPROCESS)
                        {
                            foreach (TransactionLists item in objTranListDet.TransactionLists)
                            {

                                if (item.RecordID <= 0)
                                {
                                    flag = 2;
                                }
                            }
                            foreach (TransactionsAllocatedLists item in objTranListDet.TransactionAllocatedLists)
                            {


                                if (item.Percentage < 0)
                                {
                                    flag = 5;
                                }
                                else if (item.Sampled < 0)
                                {
                                    flag = 6;
                                }

                            }
                        }

                        if (Type == Constants.STRATIFIED)
                        {
                            if (objTranListDet.MinValue <= 0 || objTranListDet.MaxValue <= 0)
                            {
                                flag = 7;
                            }

                        }
                        if (Type == Constants.FIELD)
                        {
                            if (objTranListDet.FieldValue.Count == 0)
                            {
                                flag = 8;
                            }


                        }
                        if (Type == Constants.STATISTICAL)
                        {
                            if (string.IsNullOrEmpty(objTranListDet.FormulaToSample))
                            {
                                flag = 11;
                            }
                            if (Actor == Constants.PROCESSOR)
                            {
                                flag = 13;
                            }

                            try
                            {
                                StringToFormula objStringToFormula = new StringToFormula();
                                double Percentage = Math.Round(objStringToFormula.Eval(objTranListDet.FormulaToSample));
                            }
                            catch (Exception ex)
                            {
                                flag = 14;
                            }

                            //if (Duration == Constants.DAILY)
                            //{
                            //    flag = 14;
                            //}

                        }
                        if (Type == Constants.VOLUME && Actor == Constants.PROCESSOR)
                        {

                            flag = 12;


                        }
                        if (Type == Constants.PROPENSITYSCORE)
                        {
                            if (objTranListDet.ThresholdValue == 0)
                            {
                                flag = 15;
                            }
                            if (Actor == Constants.PROCESSOR)
                            {
                                flag = 16;
                            }


                        }
                        if (flag == 1)
                        {
                            objTranListDet.ErrorMessage.Append("ProcessedBy is not provided in the Transaction Lists");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 2)
                        {
                            objTranListDet.ErrorMessage.Append("Record ID is not provided in the Transaction Lists");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 3)
                        {
                            objTranListDet.ErrorMessage.Append("Data Value is Needed in the Transaction Lists, if Type is Stratified/Field");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 4)
                        {
                            objTranListDet.ErrorMessage.Append("ProcessedBy is not provided in the Transaction Allocated Lists");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 5)
                        {
                            objTranListDet.ErrorMessage.Append("Percentage is not provided in the Transaction Allocated Lists");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 6)
                        {
                            objTranListDet.ErrorMessage.Append("Allocated is not provided in the Transaction Allocated Lists");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 7)
                        {
                            objTranListDet.ErrorMessage.Append("Min and Max Value is Needed, if Type is Stratified");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 8)
                        {
                            objTranListDet.ErrorMessage.Append("Field Value is Needed, if Type is Field");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 9)
                        {
                            objTranListDet.ErrorMessage.Append("Data Value should be in 'Completed' or 'Pending', if Type is Field");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 10)
                        {
                            objTranListDet.ErrorMessage.Append("Data Value should be in integer Value, if Type is Stratified");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 11)
                        {
                            objTranListDet.ErrorMessage.Append("Formula is Needed, if Type is Statistical");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 12)
                        {
                            objTranListDet.ErrorMessage.Append("Volume Sampling Applicable at Subprocess level only");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 13)
                        {
                            objTranListDet.ErrorMessage.Append("Statistical Sampling Applicable at Subprocess level only");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 14)
                        {
                            objTranListDet.ErrorMessage.Append("Invalid Formula");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 15)
                        {
                            objTranListDet.ErrorMessage.Append("ThresholdValue is Needed, if Type is PropensityScore");
                            objTranListDet.ResultStatus = false;
                        }
                        else if (flag == 16)
                        {
                            objTranListDet.ErrorMessage.Append("PropensityScore Sampling Applicable at Subprocess level only");
                            objTranListDet.ResultStatus = false;
                        }
                        else
                        {
                            objTranListDet.ResultStatus = true;
                            
                        }

                    }
                    else
                    {
                        objTranListDet.ErrorMessage.Append("Input's are not in the standard format");
                        objTranListDet.ResultStatus = false;
                    }
                }
            }
            catch (NullReferenceException ex)
            {

                objTranListDet.ErrorMessage.Append("Transaction List Or Transaction Allocated List object is null");
                // throw;// n

            }

            return objTranListDet;
        }



        
    }
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :BaseSampling.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :StringToFormula
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/26/2017
    // Purpose : This class will be used calculate sampling percentage from the given formula for statistical sampling.
    //
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class StringToFormula
    {
        private string[] _operators = { "-", "+", "/", "*", "^" };
        private Func<double, double, double>[] _operations = {
        (a1, a2) => a1 - a2,
        (a1, a2) => a1 + a2,
        (a1, a2) => a1 / a2,
        (a1, a2) => a1 * a2,
        (a1, a2) => Math.Pow(a1, a2)
            };

        public double Eval(string expression)
        {
            List<string> tokens = getTokens(expression);
            Stack<double> operandStack = new Stack<double>();
            Stack<string> operatorStack = new Stack<string>();
            int tokenIndex = 0;

            while (tokenIndex < tokens.Count)
            {
                string token = tokens[tokenIndex];
                if (token == "(")
                {
                    string subExpr = getSubExpression(tokens, ref tokenIndex);
                    operandStack.Push(Eval(subExpr));
                    continue;
                }
                if (token == ")")
                {
                    throw new ArgumentException("Mis-matched parentheses in expression");
                }
                //If this is an operator  
                if (Array.IndexOf(_operators, token) >= 0)
                {
                    while (operatorStack.Count > 0 && Array.IndexOf(_operators, token) < Array.IndexOf(_operators, operatorStack.Peek()))
                    {
                        string op = operatorStack.Pop();
                        double arg2 = operandStack.Pop();
                        double arg1 = operandStack.Pop();
                        operandStack.Push(_operations[Array.IndexOf(_operators, op)](arg1, arg2));
                    }
                    operatorStack.Push(token);
                }
                else
                {
                    operandStack.Push(double.Parse(token));
                }
                tokenIndex += 1;
            }

            while (operatorStack.Count > 0)
            {
                string op = operatorStack.Pop();
                double arg2 = operandStack.Pop();
                double arg1 = operandStack.Pop();
                operandStack.Push(_operations[Array.IndexOf(_operators, op)](arg1, arg2));
            }
            return operandStack.Pop();
        }
        private string getSubExpression(List<string> tokens, ref int index)
        {
            StringBuilder subExpr = new StringBuilder();
            int parenlevels = 1;
            index += 1;
            while (index < tokens.Count && parenlevels > 0)
            {
                string token = tokens[index];
                if (tokens[index] == "(")
                {
                    parenlevels += 1;
                }

                if (tokens[index] == ")")
                {
                    parenlevels -= 1;
                }

                if (parenlevels > 0)
                {
                    subExpr.Append(token);
                }

                index += 1;
            }

            if ((parenlevels > 0))
            {
                throw new ArgumentException("Mis-matched parentheses in expression");
            }
            return subExpr.ToString();
        }

        private List<string> getTokens(string expression)
        {
            string operators = "()^*/+-";
            List<string> tokens = new List<string>();
            StringBuilder sb = new StringBuilder();

            foreach (char c in expression.Replace(" ", string.Empty))
            {
                if (operators.IndexOf(c) >= 0)
                {
                    if ((sb.Length > 0))
                    {
                        tokens.Add(sb.ToString());
                        sb.Length = 0;
                    }
                    tokens.Add(c.ToString());
                }
                else
                {
                    sb.Append(c);
                }
            }

            if ((sb.Length > 0))
            {
                tokens.Add(sb.ToString());
            }
            return tokens;
        }
    }
}
