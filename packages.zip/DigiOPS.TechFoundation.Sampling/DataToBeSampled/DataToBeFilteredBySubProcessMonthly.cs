﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :DataToBeFilteredBySubProcessMonthly.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :DataToBeFilteredBySubProcessMonthly
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/17/2017
    // Purpose : This class will be used to perform Sampling for SubProcess and Monthly Wise
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public class DataToBeFilteredBySubProcessMonthly : BaseDataTobeSampled
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :DataToBeFilteredBySubProcessMonthly.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Method Name(s) :GetDataTobeSampled
        // Author : Venkata Lakshmi CH.
        // Creation Date : 4/17/2017
        // Purpose : This method will be used to perform Sampling for SubProcess and Monthly Wise
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////

        public override TransactionListResponse GetDataTobeSampled(string Actor, string Duration, string Type, TransactionListDetails objTransactionListDetails)
        {

            TransactionListResponse objResponse = new TransactionListResponse();

            //Getting the SamplingPercentage
            List<TransactionsAllocatedLists> objTransactionAllocatedLists = objTransactionListDetails.TransactionAllocatedLists;


            //Passing for Response
            List<TransactionsPendingLists> objTransactionsPendingLists = new List<TransactionsPendingLists>();

            double SampPercentage = objTransactionAllocatedLists.FirstOrDefault().Percentage;
            int Allocated = 0;

            /* GEt Total Transactions for the given Month*/
            int AllocatedTotal = (from p in objTransactionListDetails.TransactionLists

                         select p
                           ).Count();

            /* GEt Total Transactions for the given Month*/
            int Total = objTransactionAllocatedLists.FirstOrDefault().Total;
            /* Calculating the Percentage*/
            double Percentage = Math.Ceiling((Total * SampPercentage) / 100);

            Allocated = Total - AllocatedTotal;

            /* Calculating the pending transactions*/
            int pending = Convert.ToInt16(Percentage);
            pending = ((pending <= Allocated) ? 0 : pending - Allocated);


            TransactionsPendingLists objPendinglist = new TransactionsPendingLists();
            objPendinglist.TobeSampled = pending;

            objTransactionsPendingLists.Add(objPendinglist);
            // objTransactionListDetails.TransactionpenLists = objTransactionAllocatedLists;

            objResponse.TransactionPendingLists = objTransactionsPendingLists;
            objResponse.TransactionLists = objTransactionListDetails.TransactionLists.OrderBy(x => Guid.NewGuid()).ToList();
            return objResponse;


        }
    }
}
