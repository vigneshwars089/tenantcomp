﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :DataToBeFilteredByCondition.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :DataToBeFilteredByCondition
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/18/2017
    // Purpose : This class will be used to perform Sampling for Stratified.
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public class DataToBeFilteredByCondition : BaseDataTobeSampled
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :DataToBeFilteredByCondition.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Method Name(s) :GetDataTobeSampled
        // Author : Venkata Lakshmi CH.
        // Creation Date : 4/18/2017
        // Purpose : This method will be used to perform Sampling for Stratified.
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////

        public override TransactionListResponse GetDataTobeSampled(string Actor, string Duration,string Type, TransactionListDetails objTransactionListDetails)
        {
            TransactionListDetails objListDetails = new TransactionListDetails();
            TransactionListResponse objResponse = new TransactionListResponse();

            //Getting the SamplingPercentage
            List<TransactionsAllocatedLists> objTransactionAllocatedLists = objTransactionListDetails.TransactionAllocatedLists;

           
            //Passing for Response
            List<TransactionsPendingLists> objTransactionsPendingLists = new List<TransactionsPendingLists>();

            int Min = objTransactionListDetails.MinValue;
            int Max = objTransactionListDetails.MaxValue;

            List<TransactionLists> objTransactionLists = (from q in objTransactionListDetails.TransactionLists
                            where (int.Parse(q.DataValue) >= Min && int.Parse(q.DataValue) <= Max)
                            select q
                            ).ToList();
                
               
            objListDetails.TransactionLists = objTransactionLists.ToList();
            objListDetails.TransactionAllocatedLists = objTransactionAllocatedLists;
            IDataToBeSampled objSampling = null;
            switch (Actor)
            {
                case Constants.SUBPROCESS:

                    switch (Duration)
                    {
                        case Constants.DAILY:
                            objSampling = new DataToBeFilteredBySubProcessDaily();
                            objResponse = objSampling.GetDataTobeSampled(Actor, Duration, Type, objListDetails);

                            break;
                        case Constants.Monthly:
                            objSampling = new DataToBeFilteredBySubProcessMonthly();
                            objResponse = objSampling.GetDataTobeSampled(Actor, Duration, Type, objListDetails);
                            break;
                    }

                    break;
                case Constants.PROCESSOR:

                    switch (Duration)
                    {
                        case Constants.DAILY:
                            objSampling = new DataToBeFilteredByProcessorDaily();
                            objResponse = objSampling.GetDataTobeSampled(Actor, Duration, Type, objListDetails);
                            break;
                        case Constants.Monthly:
                            objSampling = new DataToBeFilteredByProcessorMonthly();
                            objResponse = objSampling.GetDataTobeSampled(Actor, Duration, Type, objListDetails);
                            break;
                    }

                    break;


            }
        

         
            return objResponse;


        }
   
    }
}
