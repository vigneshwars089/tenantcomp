﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :DataToBeFilteredByProcessorMonthly.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :DataToBeFilteredByProcessorMonthly
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/17/2017
    // Purpose : This class will be used to perform Sampling for Processor and Daily Wise
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class DataToBeFilteredByProcessorMonthly : BaseDataTobeSampled
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :DataToBeFilteredBySubProcessMonthly.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Method Name(s) :GetDataTobeSampled
        // Author : Venkata Lakshmi CH.
        // Creation Date : 4/17/2017
        // Purpose : This method will be used to perform Sampling for Processor and Monthly Wise
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////

        public override TransactionListResponse GetDataTobeSampled(string Actor, string Duration, string Type, TransactionListDetails objTransactionListDetails)
        {
            TransactionListResponse objResponse = new TransactionListResponse();
            //Passing for Response
            List<TransactionsPendingLists> objTransactionsPendingLists = new List<TransactionsPendingLists>();

            //Getting the Transaction List
            List<TransactionLists> objTransactionLists = objTransactionListDetails.TransactionLists.ToList();

            //Getting the Processor Transaction Details
            var ProcessorAllocatedLists = objTransactionListDetails.TransactionAllocatedLists;

            /*Grouping the Processors */
            var objGrpProcessor = from c in objTransactionLists
                                  group c by new { c.ProcessedBy } into Procgrp
                                  select new
                                  {
                                      ProcessedBy = Procgrp.Key.ProcessedBy,
                                      NoofTransaction = Procgrp.Count()


                                  };

            /*Finding the Pending Details for Each Processor */
            var GetPendinglist = (from c in objGrpProcessor
                                  join d in ProcessorAllocatedLists on new { c.ProcessedBy } equals new { d.ProcessedBy }

                                  select new
                                  {
                                      TotalRecords = d.Total,
                                      ProcessedBy = d.ProcessedBy,
                                      Allocated = (d.Total - c.NoofTransaction),
                                      Pending =(int) Math.Ceiling((c.NoofTransaction * d.Percentage) / 100)

                                  }).ToList();

            GetPendinglist = (from c in GetPendinglist
                              select new
                              {
                                  TotalRecords = c.TotalRecords,
                                  ProcessedBy = c.ProcessedBy,
                                  Allocated = c.Allocated,
                                  Pending = ((c.Pending <= c.Allocated) ? 0 : c.Pending - c.Allocated)

                              }).ToList();

            ///*Getting the transactions from each processors based on the pending */

            List<TransactionsPendingLists> TransactionsAllocatedPendingLists = (from b in GetPendinglist
                                                                                select new TransactionsPendingLists()
                                                                                {
                                                                                    ProcessedBy = b.ProcessedBy,
                                                                                    TobeSampled = b.Pending

                                                                                }).ToList();
            objResponse.TransactionPendingLists = TransactionsAllocatedPendingLists;
            objResponse.TransactionLists = objTransactionListDetails.TransactionLists.OrderBy(x => Guid.NewGuid()).ToList();

            return objResponse;
        }
    }
}
