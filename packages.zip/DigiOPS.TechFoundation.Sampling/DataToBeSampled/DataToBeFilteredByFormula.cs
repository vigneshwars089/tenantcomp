﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Sampling
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :DataToBeFilteredByFormula.cs
    // Namespace : DigiOps.TechFoundation.Sampling
    // Class Name(s) :DataToBeFilteredByFormula
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/26/2017
    // Purpose : This class will be used to perform Sampling for Statistical by using Formula
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    class DataToBeFilteredByFormula : BaseDataTobeSampled
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :DataToBeFilteredByFormula.cs
        // Namespace : DigiOps.TechFoundation.Sampling
        // Method Name(s) :GetDataTobeSampled
        // Author : Venkata Lakshmi CH.
        // Creation Date : 4/26/2017
        // Purpose : This method will be used to perform Sampling for Statistical by using Formula
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////

        public override TransactionListResponse GetDataTobeSampled(string Actor, string Duration, string Type, TransactionListDetails objTransactionListDetails)
        {
            TransactionListDetails objListDetails = objTransactionListDetails;
            TransactionListResponse objResponse = new TransactionListResponse();
            TransactionsAllocatedLists objTransactionAllocatedList = new TransactionsAllocatedLists();

            //Getting the SamplingPercentage
            List<TransactionsAllocatedLists> objTransactionAllocatedLists = objTransactionListDetails.TransactionAllocatedLists;


            //Passing for Response
            List<TransactionsPendingLists> objTransactionsPendingLists = new List<TransactionsPendingLists>();

            //formula 
            string formula = objTransactionListDetails.FormulaToSample;
            //string formula = "(N*(((5^2)*(4*6))+(((5^2)*4)*6)))"; //or get it from DB

            StringToFormula StringToFormula = new StringToFormula();
            double Percentage = Math.Round(StringToFormula.Eval(formula));

            // objTransactionAllocatedList.Percentage = Percentage;
            // objTransactionAllocatedLists.Add(objTransactionAllocatedList);
            //objTransactionAllocatedLists.FirstOrDefault().Percentage = Percentage;
            foreach (TransactionsAllocatedLists objAllocatelist in objTransactionAllocatedLists)
            {
                objAllocatelist.Percentage = Percentage;
            }
            //update the Transactionallocated List an pass the percentage no need to chk anything in objTransactionLists below line


            //Getting the Transaction List

            objListDetails.TransactionAllocatedLists = objTransactionAllocatedLists;
            IDataToBeSampled objSampling = null;
            switch (Actor)
            {
                case Constants.SUBPROCESS:

                    switch (Duration)
                    {
                        case Constants.DAILY:
                            objSampling = new DataToBeFilteredBySubProcessDaily();
                            objResponse = objSampling.GetDataTobeSampled(Actor, Duration, Type, objListDetails);

                            break;
                        case Constants.Monthly:
                            objSampling = new DataToBeFilteredBySubProcessMonthly();
                            objResponse = objSampling.GetDataTobeSampled(Actor, Duration, Type, objListDetails);
                            break;

                        default:
                            objSampling = new DataToBeFilteredBySubProcessMonthly();
                            objResponse = objSampling.GetDataTobeSampled(Actor, Duration, Type, objListDetails);
                            break;
                    }

                    break;
                //case Constants.PROCESSOR:

                //  switch (Duration)
                //  {
                //      case Constants.DAILY:
                //          objSampling = new DataToBeFilteredByProcessorDaily();
                //          objResponse = objSampling.GetDataTobeSampled(Actor, Duration, Type, objListDetails);
                //          break;
                //      case Constants.Monthly:
                //          objSampling = new DataToBeFilteredByProcessorMonthly();
                //          objResponse = objSampling.GetDataTobeSampled(Actor, Duration, Type, objListDetails);
                //          break;
                //  }

                //  break;


            }

            return objResponse;

        }

        public class StringToFormula
        {
            private string[] _operators = { "-", "+", "/", "*", "^" };
            private Func<double, double, double>[] _operations = {
        (a1, a2) => a1 - a2,
        (a1, a2) => a1 + a2,
        (a1, a2) => a1 / a2,
        (a1, a2) => a1 * a2,
        (a1, a2) => Math.Pow(a1, a2)
            };

            public double Eval(string expression)
            {
                List<string> tokens = getTokens(expression);
                Stack<double> operandStack = new Stack<double>();
                Stack<string> operatorStack = new Stack<string>();
                int tokenIndex = 0;

                while (tokenIndex < tokens.Count)
                {
                    string token = tokens[tokenIndex];
                    if (token == "(")
                    {
                        string subExpr = getSubExpression(tokens, ref tokenIndex);
                        operandStack.Push(Eval(subExpr));
                        continue;
                    }
                    if (token == ")")
                    {
                        throw new ArgumentException("Mis-matched parentheses in expression");
                    }
                    //If this is an operator  
                    if (Array.IndexOf(_operators, token) >= 0)
                    {
                        while (operatorStack.Count > 0 && Array.IndexOf(_operators, token) < Array.IndexOf(_operators, operatorStack.Peek()))
                        {
                            string op = operatorStack.Pop();
                            double arg2 = operandStack.Pop();
                            double arg1 = operandStack.Pop();
                            operandStack.Push(_operations[Array.IndexOf(_operators, op)](arg1, arg2));
                        }
                        operatorStack.Push(token);
                    }
                    else
                    {
                        operandStack.Push(double.Parse(token));
                    }
                    tokenIndex += 1;
                }

                while (operatorStack.Count > 0)
                {
                    string op = operatorStack.Pop();
                    double arg2 = operandStack.Pop();
                    double arg1 = operandStack.Pop();
                    operandStack.Push(_operations[Array.IndexOf(_operators, op)](arg1, arg2));
                }
                return operandStack.Pop();
            }
            private string getSubExpression(List<string> tokens, ref int index)
            {
                StringBuilder subExpr = new StringBuilder();
                int parenlevels = 1;
                index += 1;
                while (index < tokens.Count && parenlevels > 0)
                {
                    string token = tokens[index];
                    if (tokens[index] == "(")
                    {
                        parenlevels += 1;
                    }

                    if (tokens[index] == ")")
                    {
                        parenlevels -= 1;
                    }

                    if (parenlevels > 0)
                    {
                        subExpr.Append(token);
                    }

                    index += 1;
                }

                if ((parenlevels > 0))
                {
                    throw new ArgumentException("Mis-matched parentheses in expression");
                }
                return subExpr.ToString();
            }

            private List<string> getTokens(string expression)
            {
                string operators = "()^*/+-";
                List<string> tokens = new List<string>();
                StringBuilder sb = new StringBuilder();

                foreach (char c in expression.Replace(" ", string.Empty))
                {
                    if (operators.IndexOf(c) >= 0)
                    {
                        if ((sb.Length > 0))
                        {
                            tokens.Add(sb.ToString());
                            sb.Length = 0;
                        }
                        tokens.Add(c.ToString());
                    }
                    else
                    {
                        sb.Append(c);
                    }
                }

                if ((sb.Length > 0))
                {
                    tokens.Add(sb.ToString());
                }
                return tokens;
            }
        }

    }

}
