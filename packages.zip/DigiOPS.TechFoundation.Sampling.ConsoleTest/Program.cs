﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using DigiOPS.TechFoundation.Sampling;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.Entities;
using System.Data;
//using DigiOPS.TechFoundation.MetricManagement;
using DigiOPS.TechFoundation.DataTransfer;
using DigiOPS.TechFoundation.UserManagement;

using Microsoft.Exchange.WebServices.Data;
using DigiOPS.TechFoundation.MetricManagement;
using DigiOPS.TechFoundation.Audit;
namespace DigiOPS.TechFoundation.Sampling.ConsoleTest
{
    class Program
    {
        public struct SAMPLING_TECHNIQUES
        {
            public const string RANDOM = "Random";
            public const string STATISTICAL = "Statistical";
            public const string STRATIFIED = "Stratified";
            public const string FIELD = "Field";
            public const string TEAM = "TEAM";
            public const string VOLUME = "Volume";
        }

        public struct SAMPLING_LEVEL
        {
            public const string SUBPROCESS = "Process";
            public const string PROCESSOR = "User";

        }

        public struct SAMPLING_PERIOD
        {

            public const string DAILY = "Daily";
            public const string Monthly = "Monthly";


        }
        static void Main(string[] args)
        {
            AuditFactory Auditfactory = new AuditFactory();
            List<DigiOPS.TechFoundation.Entities.RatingEntity> lstRatingConfig = new List<DigiOPS.TechFoundation.Entities.RatingEntity>();
            DigiOPS.TechFoundation.Entities.RatingEntity RatingGrp = new DigiOPS.TechFoundation.Entities.RatingEntity();

            RatingGrp.TenantID = 1;
            RatingGrp.AppID = "Quart";

            RatingGrp.SubProcessId = 19;

            lstRatingConfig = Auditfactory.GetAuditTypeHandler("", "Rating").GetAuditRating(RatingGrp);
        }
        static void Main2(string[] args)
        {
            DataTransferFactory objdata = new DataTransferFactory();
            DataTransferInfo objDataInfo = new DataTransferInfo();
            DataTransferInfo objinfo = new DataTransferInfo();
            IDataTransfer iobj = objdata.GetFileDataTransferHandler("Excel");
            ExcelTemplate objtemplate = new ExcelTemplate();



            objtemplate.SubProcessId = System.Configuration.ConfigurationManager.AppSettings["SubProcessID"];// "19";
            objtemplate.CurrentUserID = System.Configuration.ConfigurationManager.AppSettings["CurrentUserID"]; //"1371";

            objtemplate.FileName = "Template.xls";
            objtemplate.FilePath = "D:\\288293\\Template_12.xls";
            objinfo = iobj.CreateCaseforSourceData(objtemplate);

        }

        static void Main6(string[] args)
        {

            BaseCustomUserManagement obj = new BaseCustomUserManagement();
            UserInfo objinfo = new UserInfo();
            objinfo.TenantID = 1;
            objinfo.AppID = "Quart";
            objinfo.ProgramID = 5;
            objinfo.SystemUserId = 0;
            objinfo.CreationType = "UserGroup";
            objinfo.UserGroupID = 8;
            objinfo.CtsUserId = "581339";
            objinfo.ClientUserId = "581339";
            objinfo.FirstName = "Adhiyaman";
            objinfo.EmailID = "Adhiyaman.M@cognizant.com";
            objinfo.IsActive = true;
            objinfo.eventAction = "Update";
            objinfo.CreatedBy = "330";
            objinfo.ModifiedBy = "330";
            objinfo.EffectiveFrom = Convert.ToDateTime("02/24/2017");
            objinfo.EffectiveTo = Convert.ToDateTime("12/31/2018");
            objinfo.UserGroupName = "HealthCare";
            UserMgmtInfo objres = new UserMgmtInfo();
            //objres = obj.ReadUser(objinfo);
            // objres = obj.CreateUser(objinfo);
            objres = obj.UpdateUser(objinfo);
            Console.WriteLine("Case Created Successfully...");
            Console.ReadLine();

        }
        static void Main3(string[] args)
        {

            //DigiOPS.TechFoundation.Entities.ElementDatas _ElementDatas = new DigiOPS.TechFoundation.Entities.ElementDatas();
            //List<DigiOPS.TechFoundation.Entities.ElementData> objlist = new List<DigiOPS.TechFoundation.Entities.ElementData>();

            //DigiOPS.TechFoundation.Entities.ElementData objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "hdnSearchPage";
            //objelementdata.ElementId = null;
            //objelementdata.ElementItemValue = null;
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "hdnEditMode";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "False";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "hdnResetMode";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "False";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "hdnSubprocessid";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "19";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "hdnRecordid";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "0";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "txtProcessedDateandTime";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "09/06/2017";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "txtReceivedDateTime";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "09/06/2017";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "73";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "09/06/2017";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "74";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "09/06/2017";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "22";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "1";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "52";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "1";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "403";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "1";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "420";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "1";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "421";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "1";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "422";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "1";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "423";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "1";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "424";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "1";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);


            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "425";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "1";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);


            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "426";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "1";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);


            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "427";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "1";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);


            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "428";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "1";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "1442";
            //objelementdata.ElementId = "Chennai";
            //objelementdata.ElementItemValue = "171";
            //objelementdata.IsList = true;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "txtComments";
            //objelementdata.ElementId = "";
            //objelementdata.ElementItemValue = "1";
            //objelementdata.IsList = false;
            //objlist.Add(objelementdata);

            //objelementdata = new DigiOPS.TechFoundation.Entities.ElementData();
            //objelementdata.ElementValue = "ddlReference";
            //objelementdata.ElementId = "Completed";
            //objelementdata.ElementItemValue = "15";
            //objelementdata.IsList = true;
            //objlist.Add(objelementdata);

            //_ElementDatas.Items = objlist;

            //_ElementDatas.USERID = Convert.ToString(1371);
            //DataTransferFactory objdata = new DataTransferFactory();
            //ICaseCreation iobj = objdata.CaseCreationHandler("");
            //DataTransferInfo objinfo = new DataTransferInfo();
            //string str = iobj.CreateCases(_ElementDatas);


            // SamplingFactory objSamplingFactory = new SamplingFactory();
            // TransactionListDetails tld = new TransactionListDetails();
            // List<TransactionLists> tldlst = new List<TransactionLists>();
            // List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            // List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            // TransactionsAllocatedLists talR = new TransactionsAllocatedLists();

            // tld.MinValue = 0;
            // tld.MaxValue = 0;

            // // tld.FormulaToSample = "1";

            // TransactionLists objlist = new TransactionLists();

            // objlist = new TransactionLists();
            // objlist.RecordID = 803;
            // objlist.ProcessedBy = 1;
            // objlist.ProcessedDate = Convert.ToDateTime("05/18/2017");
            // // objlist.Priority = "1";
            // //Required only, if stratified sampling
            // // objlist.DataValue = 50;
            // tldlst.Add(objlist);
            // objlist = new TransactionLists();
            // objlist.RecordID = 804;
            // objlist.ProcessedBy = 1;
            // objlist.ProcessedDate = Convert.ToDateTime("05/18/2017");
            // // objlist.Priority = "2";
            // //Required only, if stratified sampling
            // // objlist.DataValue = 50;
            // tldlst.Add(objlist);

            // objlist = new TransactionLists();
            // objlist.RecordID = 805;
            // objlist.ProcessedBy = 1;
            // objlist.ProcessedDate = Convert.ToDateTime("05/18/2017");
            // // objlist.Priority = "1";
            // //Required only, if stratified sampling
            // // objlist.DataValue = 50;
            // tldlst.Add(objlist);

            // objlist = new TransactionLists();
            // objlist.RecordID = 806;
            // objlist.ProcessedBy = 1;
            // objlist.ProcessedDate = Convert.ToDateTime("05/18/2017");
            // // objlist.Priority = "1";
            // //Required only, if stratified sampling
            // // objlist.DataValue = 50;
            // tldlst.Add(objlist);

            // objlist = new TransactionLists();
            // objlist.RecordID = 807;
            // objlist.ProcessedBy = 1;
            // objlist.ProcessedDate = Convert.ToDateTime("05/18/2017");
            // // objlist.Priority = "1";
            // //Required only, if stratified sampling
            // // objlist.DataValue = 50;
            // tldlst.Add(objlist);

            // objlist = new TransactionLists();
            // objlist.RecordID = 808;
            // objlist.ProcessedBy = 1;
            // objlist.ProcessedDate = Convert.ToDateTime("05/18/2017");
            // // objlist.Priority = "1";
            // //Required only, if stratified sampling
            // // objlist.DataValue = 50;
            // tldlst.Add(objlist);
            // //objlist = new TransactionLists();
            // //objlist.RecordID = 806;
            // //objlist.ProcessedBy = 288293;
            // //objlist.ProcessedDate = Convert.ToDateTime("05/06/2017");
            // //// objlist.Priority = "1";
            // ////Required only, if stratified sampling
            // //// objlist.DataValue = 50;
            // //tldlst.Add(objlist);

            // List<TransactionsAllocatedLists> objallocatedLists = new List<TransactionsAllocatedLists>();
            // TransactionsAllocatedLists obj1 = new TransactionsAllocatedLists();
            // obj1.ProcessedBy = 1;
            // obj1.ProcessedDate = Convert.ToDateTime("05/18/2017");
            // obj1.Total = 14;
            // obj1.Percentage = 109;
            // objallocatedLists.Add(obj1);

            // //obj1 = new TransactionsAllocatedLists();
            // //obj1.ProcessedBy = 2;
            // //obj1.Total = 3;
            // //obj1.Percentage = 50;
            // //obj1.ProcessedDate = Convert.ToDateTime("05/06/2017");
            // //objallocatedLists.Add(obj1);


            // tld.TransactionLists = tldlst;
            // tld.TransactionAllocatedLists = objallocatedLists;

            //// SamplingStageFactory objSamplingStageFactory = new SamplingStageFactory();
            //// objSamplingFactory.
            //// tld = objBase.GetSampingDetails(SAMPLING_LEVEL.SUBPROCESS, SAMPLING_PERIOD.DAILY, SAMPLING_TECHNIQUES.RANDOM, tld);


            // tld = objSamplingFactory.GetSampingDetails(SAMPLING_LEVEL.PROCESSOR, SAMPLING_PERIOD.DAILY, SAMPLING_TECHNIQUES.RANDOM, tld);
            // tldlst = tld.TransactionLists;


            // tldlst.ForEach(i => Console.Write(i.ProcessedBy + ", " + i.ProcessedDate + ", " + i.RecordID + ", " + i.DataValue + "\n"));

            // Console.ReadLine();


            /**METRIC MANAGEMENT**/
            //  ScoringInfo ad = new ScoringInfo();
            //  ad._strAuditlogic = "DEDUCTIVEWDPO";
            //  ad._strScoringLogic = "Checkpoint BASED";
            //  ad._IsCriticalApp = "False";

            //  List<DetailsEntity> lstComb = new List<DetailsEntity>();
            //  DetailsEntity adComb = new DetailsEntity();

            //  adComb.DOGroupID = 2172;
            //  adComb.ParentDOId = 2172;

            //  adComb.CriticalityType = "Critical";
            //  adComb.GivenWeightage = 1;
            // // adComb.GroupWeightage = 5;
            //  adComb.MaxWeightage = 1;
            //  lstComb.Add(adComb);

            //  DetailsEntity adComb1 = new DetailsEntity();

            //  adComb1.DOGroupID = 2173;
            //  adComb1.ParentDOId = 2173;

            //  adComb1.CriticalityType = "Fatal";
            //  adComb1.GivenWeightage = 1;
            ////  adComb1.GroupWeightage = 5;
            //  adComb1.MaxWeightage = 1;
            //  lstComb.Add(adComb1);

            //  ad.AuditedList = lstComb;

            //  ScoringOutput so = new ScoringOutput();
            //  IScoringAlgorithmFactory isaf = new ScoringAlgorithmFactory();
            //  so = isaf.GetScoringHandler(ad).CalculateQualityScore(ad);

            //  Console.WriteLine("Quality Score= " + so.QualityScore + "\n" + "Message: " + so.ErrorMessage);
            //  Console.ReadLine();

            ///**Multi scoring METRIC MANAGEMENT**/
            //List<ScoringInfo> objlist = new List<ScoringInfo>();
            ScoringInfo ad = new ScoringInfo();
            ad._strAuditlogic = "DPU";
            ad._strScoringLogic = "Heading BASED";
            ad._IsCriticalApp = "False";

            //List<DetailsEntity> lstComb = new List<DetailsEntity>();
            //DetailsEntity adComb = new DetailsEntity();

            //adComb.DOGroupID = 2172;
            //adComb.ParentDOId = 2172;

            //adComb.CriticalityType = "Critical";
            //adComb.GivenWeightage = 0;
            //adComb.GroupWeightage = 50;
            //adComb.MaxWeightage = 1;
            //lstComb.Add(adComb);

            //DetailsEntity adComb1 = new DetailsEntity();

            //adComb1.DOGroupID = 2173;
            //adComb1.ParentDOId = 2173;

            //adComb1.CriticalityType = "Critical";
            //adComb1.GivenWeightage = 1;
            //adComb1.GroupWeightage = 50;
            //adComb1.MaxWeightage = 1;
            //lstComb.Add(adComb1);

            //ad.AuditedList = lstComb;

            //objlist.Add(ad);

            //ad = new ScoringInfo();
            //ad._strAuditlogic = "DPO";
            //ad._strScoringLogic = "Checkpoint BASED";
            //ad._IsCriticalApp = "False";

            //lstComb = new List<DetailsEntity>();
            //adComb = new DetailsEntity();

            //adComb.DOGroupID = 2172;
            //adComb.ParentDOId = 2172;

            //adComb.CriticalityType = "Critical";
            //adComb.GivenWeightage = 0;
            //adComb.GroupWeightage = 50;
            //adComb.MaxWeightage = 1;
            //lstComb.Add(adComb);

            //adComb = new DetailsEntity();

            //adComb.DOGroupID = 2172;
            //adComb.ParentDOId = 2172;

            //adComb.CriticalityType = "Critical";
            //adComb.GivenWeightage = 1;
            //adComb.GroupWeightage = 50;
            //adComb.MaxWeightage = 1;
            //lstComb.Add(adComb);

            //ad.AuditedList = lstComb;

            //objlist.Add(ad);

            // ScoringOutput so = new ScoringOutput();
            // IScoringAlgorithmFactory isaf = new ScoringAlgorithmFactory();

            //ScoringInfo scorinfoinput = new ScoringInfo();
            //scorinfoinput._strAuditlogic = "COMBINED";
            //scorinfoinput._strScoringLogic = "Checkpoint BASED";


            // so = isaf.GetScoringHandler(ad).CalculateQualityScore(ad);

            //  Console.WriteLine("Quality Score= " + so.QualityScore + "\n" + "Message: " + so.ErrorMessage);

            //Quart bulkupload
            DataTransferFactory objdata = new DataTransferFactory();

            //Mail Creation
            IMailDataTransfer iobjoutlook = objdata.GetMailDataTransferHandler("OUTLOOK");
            //DataTransferInfo objinfo = new DataTransferInfo();
            EMailInfo eInfo = new EMailInfo();
            eInfo.eMailType = "outlook"; /// Mail Type OUTLOOK/GMAIL/ OUTBOX365

            List<EmailInput> elist = new List<EmailInput>();



            EmailInput input = new EmailInput();
            input.ServiceExchangeUrl = @"https://mail.cognizant.com/ews/Exchange.asmx";
            //  Folder readmailFolder = GetFolderFromName(service, "Read", RootFolderId); 
            input.SourceFolder = WellKnownFolderName.Inbox;/// source folder to read the mails
            input.EMailId = "emtdemo@cognizant.com";/// Email Id 
            input.LoginEMailId = "Cemtdemo";/// Login Id
            input.TimeZone = "India Standard Time";/// standard time zone
            input.ClientExVersion = "Exchange2010_SP1";
            input.Password = "E111111#";/// password
            input.DestinationIgnoreFolder = "Important"; /// Destination ignore folder to move the mails
            input.Domain = "cts"; ///Domain name


            IgnoreList IgnoreList = new IgnoreList(); /// Ignore List to move the mails directly to destination ignore folder
            IgnoreList.Item = ("out of office autoreply");

            IgnoreList IgnoreList1 = new IgnoreList();
            IgnoreList1.Item = ("message recall failure:");


            List<IgnoreList> IgnLst = new List<IgnoreList>();
            IgnLst.Add(IgnoreList);
            IgnLst.Add(IgnoreList1);
            input.IgnoreList = IgnLst;

            elist.Add(input);
            eInfo.EmailInputList = elist;

            DataTransferInfo objDataInfo = new DataTransferInfo();
            EmailResponceInfo ERinfo = new EmailResponceInfo();

            objDataInfo = iobjoutlook.ReadAttachementfromSource(eInfo);


            DataTransferInfo objinfo = new DataTransferInfo();
            IDataTransfer iobj = objdata.GetFileDataTransferHandler("Excel");
            ExcelTemplate objtemplate = new ExcelTemplate();



            objtemplate.SubProcessId = System.Configuration.ConfigurationManager.AppSettings["SubProcessID"];// "19";
            objtemplate.CurrentUserID = System.Configuration.ConfigurationManager.AppSettings["CurrentUserID"]; //"1371";
            foreach (CaseCreationInput obj in objDataInfo.EmailResponseInfo.CaseCreationInputList)
            {
                objtemplate.FileName = obj.FileAttachmentName;
                objtemplate.FileContent = obj.MailFileAttachmentContentBytes;
                objinfo = iobj.CreateCaseforSourceData(objtemplate);
            }

            Console.WriteLine("Case Created Successfully...");
            Console.ReadLine();

        }


    }
}
