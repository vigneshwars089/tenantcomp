﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Sampling;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.Entities;
using System.Data;



namespace DigiOPS.TechFoundation.Sampling.ConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {

            SamplingFactory objSamplingFactory = new SamplingFactory();
            TransactionListDetails tld = new TransactionListDetails();
            List<TransactionLists> tldlst = new List<TransactionLists>();
            List<TransactionListDetails> tldList1 = new List<TransactionListDetails>();
            List<TransactionsAllocatedLists> tal = new List<TransactionsAllocatedLists>();
            TransactionsAllocatedLists talR = new TransactionsAllocatedLists();
            //tld.Allocated = 0;
            //tld.Total = 8;
            talR.Allocated = 0;
            talR.Percentage = 10.0;
            talR.ProcessedBy = 288220;
            tal.Add(talR);

            //talR = new TransactionsAllocatedLists();
            ////tld.Allocated = 0;
            ////tld.Total = 8;
            //talR.Allocated = 0;
            //talR.Percentage = 50.0;
            //talR.ProcessedBy = 188598;
            //tal.Add(talR);

            //List<TransactionLists> tldlst = new List<TransactionLists>();
            TransactionLists objlist = new TransactionLists();
            objlist = new TransactionLists();
            objlist.RecordID = 800;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "14";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;

            //Required only, if team sampling
            // objlist.DataValue = 51;
            objlist.Priority = "1";
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 801;
            objlist.DataValue = "20";
            objlist.ProcessedBy = 188598;
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            objlist.Priority = "2";
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 802;
            objlist.ProcessedBy = 188598;
            objlist.DataValue = "50";
            //Required only, if stratified sampling
            // objlist.DataValue = 51;
            objlist.Priority = "1";
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 803;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "60";
            objlist.Priority = "1";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);
            objlist = new TransactionLists();
            objlist.RecordID = 804;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "70";
            objlist.Priority = "2";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            objlist = new TransactionLists();
            objlist.RecordID = 805;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "10";
            objlist.Priority = "1";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);


            objlist = new TransactionLists();
            objlist.RecordID = 806;
            objlist.ProcessedBy = 288220;
            objlist.DataValue = "30";
            objlist.Priority = "1";
            //Required only, if stratified sampling
            // objlist.DataValue = 50;
            tldlst.Add(objlist);

            tld.TransactionLists = tldlst;
            tld.TransactionAllocatedLists = tal;
            tld.MinValue = 20;
            tld.MaxValue = 60;
           // tld.IsStoreInDB = true;

            tld = objSamplingFactory.GetSampingDetails("Processor", "Monthly", "TEAM", tld);
            tldlst = tld.TransactionLists;
            ////---Audit Logic
            //AuditSamplingFactory objAuditSampling = new AuditSamplingFactory();
            //string res;
            //TransactionListDetails tld = new TransactionListDetails();
            //tld.SamplingTechnique = "Random";
            //tld.SamplingLevel = "Processor";
            //tld.SamplingPeriod = "Daily";
            //tld.ProcessedFromDate = DateTime.Today.AddDays(-1);
            //tld.ProcessingToDate = DateTime.Today;
            //tld.Percentage = 50.0;
            //tld.Allocated = 2;objTransListDetailsobjTransListDetails
            //tld.Total = 8;


            ////If stratified
            //tld.MinValue = 0;
            //tld.MaxValue = 200;


            //List<TransactionLists> tldlst = new List<TransactionLists>();
            //TransactionLists objlist = new TransactionLists();
            //objlist.RecordID = 26;
            //objlist.ProcessedBy = 188598;
            //objlist.ProcessedDate = DateTime.Today;
            ////Required only, if stratified sampling
            //objlist.DataValue = 50;
            //tldlst.Add(objlist);

            //objlist = new TransactionLists();
            //objlist.RecordID = 27;
            //objlist.ProcessedBy = 188598;
            //objlist.ProcessedDate = DateTime.Today;
            ////Required only, if stratified sampling
            //objlist.DataValue = 51;
            //tldlst.Add(objlist);

            //objlist = new TransactionLists();
            //objlist.RecordID = 28;
            //objlist.ProcessedBy = 188598;
            //objlist.ProcessedDate = DateTime.Today;
            //tldlst.Add(objlist);

            //objlist = new TransactionLists();
            //objlist.RecordID = 29;
            //objlist.ProcessedBy = 188598;
            //objlist.ProcessedDate = DateTime.Today;
            //tldlst.Add(objlist);

            //objlist = new TransactionLists();
            //objlist.RecordID = 30;
            //objlist.ProcessedBy = 288220;
            //objlist.ProcessedDate = DateTime.Today;
            //tldlst.Add(objlist);

            //objlist = new TransactionLists();
            //objlist.RecordID = 31;
            //objlist.ProcessedBy = 288220;
            //objlist.ProcessedDate = DateTime.Today;
            //tldlst.Add(objlist);

            //objlist = new TransactionLists();
            //objlist.RecordID = 32;
            //objlist.ProcessedBy = 288220;
            //objlist.ProcessedDate = DateTime.Today;
            //tldlst.Add(objlist);

            //objlist = new TransactionLists();
            //objlist.RecordID = 33;
            //objlist.ProcessedBy = 288220;
            //objlist.ProcessedDate = DateTime.Today;
            //tldlst.Add(objlist);

            //objlist = new TransactionLists();
            //objlist.RecordID = 34;
            //objlist.ProcessedBy = 288220;
            //objlist.ProcessedDate = DateTime.Today;
            //tldlst.Add(objlist);

            //tld.TransactionLists = tldlst;

            // List<TransactionsAllocatedLists> objallocatedLists = new List<TransactionsAllocatedLists>();
            // TransactionsAllocatedLists obj1 = new TransactionsAllocatedLists();
            // obj1.ProcessedBy = 288220;
            // obj1.Allocated = 1;
            //// obj1.ProcessedDate = DateTime.Today;
            // objallocatedLists.Add(obj1);

            //obj1 = new TransactionsAllocatedLists();
            //obj1.ProcessedBy = 188598;
            //obj1.Allocated = 0;
            //obj1.ProcessedDate = DateTime.Today;
            //objallocatedLists.Add(obj1);


            //tld.TransactionAllocatedLists = objallocatedLists;

            //TransactionListDetails objAudit = new TransactionListDetails();
            //objAudit = objAuditSampling.AuditSamplingHandler("processor","daily","").SamplingLogic(tld);
            //tld = objAudit;

            //List<TransactionListDetails> BEL = new List<TransactionListDetails>();
            //List<TransactionLists> TL = new List<TransactionLists>();
            //TL = tld.TransactionLists;

            //TL.ForEach(i => Console.Write(i.RecordID + "\n"));



            ////set Sampling 

            //SamplingEntity SESet = new SamplingEntity();
            //SESet.AuditTypeId = Convert.ToInt32("2");
            //SESet.SubProcessId = Convert.ToInt32("75");
            //SESet.SystemUserId = Convert.ToInt32("0");
            //SESet.SamplingPct = "19.0";
            //SESet.SamplingType = "Sub-process";
            //SESet.CreatedBy = Convert.ToInt32("206");
            //string res1 = string.Empty;
            //res1 = objAuditSampling.SetSamplingPercentage(SESet);
            //Console.WriteLine(res1 + "\n");
            //Console.WriteLine("-----" + res1 + "-----\n\n");


            //// --- Get samlpling
            //SamplingEntity SE = new SamplingEntity();

            //SE.SubProcessId = Convert.ToInt32("75");
            //SE.samplingMethod = "Associate";//Associate, Sub-Process
            //SE.SortOrder = "DESC";
            //SE.SortColumn = "iSamplingId";
            //SE.StartRowIndex = 1;
            //SE.levelID = 2;
            //SE.MaximumRows = 20;
            //List<SamplingEntity> BEL = new List<SamplingEntity>();

            //BEL = objAuditSampling.GetSamplingPctDetails(SE);

            //BEL.ForEach(i => Console.Write(i.szAssociate + ", "  + i.dSamplingPct + "\n"));



            tldlst.ForEach(i => Console.Write(i.ProcessedBy + ", " + i.RecordID + ", " + i.DataValue + "\n"));




            Console.ReadLine();
        }
    }
}
