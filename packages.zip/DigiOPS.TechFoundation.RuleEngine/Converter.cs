﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.RuleEngine
{
    public class Converter
    {
        public string TimeConverter(String TimeZone)
        {
            TimeZoneInfo cst = TimeZoneInfo.FindSystemTimeZoneById(TimeZone);
            TimeSpan offset = cst.GetUtcOffset(DateTime.Now);
            //if((offset < TimeSpan.Zero) ? "-" : "")
            string OffSet = ((offset < TimeSpan.Zero) ? "-" : "+") + offset.ToString(@"hh\:mm");
           
            return OffSet;
        }
    }
}
