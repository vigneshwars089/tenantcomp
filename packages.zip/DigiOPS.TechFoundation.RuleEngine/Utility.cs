﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.RuleEngine
{
    class Utility
    {
        //public void IsLogEnabled(string LogMessage, bool IsEnabled)
        //{
        //    LogInfo objLogInfo = new LogInfo();
        //    ILoggingFactory objLogging = new LoggingFactory();
        //    if (IsEnabled)
        //    {
        //        objLogInfo.Message = LogMessage;
        //        objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
        //    }
        //}
    }
}
