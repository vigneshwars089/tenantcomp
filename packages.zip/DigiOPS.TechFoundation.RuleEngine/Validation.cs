﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Security;
using System.Text.RegularExpressions;
namespace DigiOPS.TechFoundation.RuleEngine
{
    public class Validation
    {
        public ResponseInfo RequiredFieldValidation(object data)
            {
                ISecurityFactory objIUS = new SecurityFactory();
                ResponseInfo objResponseInfo = new ResponseInfo();
                foreach (PropertyInfo objpropertyInfo in data.GetType().GetProperties())
                {
                    switch (Type.GetTypeCode(objpropertyInfo.PropertyType))
                    {
                        //switch (objpropertyInfo.PropertyType){
                        case TypeCode.String:
                            {
                                String value = (String)objpropertyInfo.GetValue(data, null);

                                if (String.IsNullOrEmpty(value))
                                {
                                    objResponseInfo.ErrorMessage.Append("Not of type String");
                                    
                                } break;
                            }
                        case TypeCode.Int32:
                            {
                                int value = (int)objpropertyInfo.GetValue(data, null);

                                if (value <= 0)
                                {
                                   
                                    objResponseInfo.ErrorMessage.Append("Not of type int");
                                }
                                break;
                            }
                        case TypeCode.Boolean:
                            {
                                Boolean value = (Boolean)objpropertyInfo.GetValue(data, null);

                                if (value)
                                {
                                    objIUS.GetUserSecurityHandler("AD").IsLogEnabled("RequiredFieldValidation|Not of type bool", true);
                                    objResponseInfo.ErrorMessage.Append("Not of type bool");
                                }
                                break;
                            }
                        case TypeCode.Byte:
                            {
                                Byte value = (Byte)objpropertyInfo.GetValue(data, null);

                                if (value <= 0)
                                {
                                    objIUS.GetUserSecurityHandler("AD").IsLogEnabled("RequiredFieldValidation|Not of type long", true);
                                    objResponseInfo.ErrorMessage.Append("Not of type long");
                                } break;
                            }

                        case TypeCode.Decimal:
                            {
                                Decimal value = (Decimal)objpropertyInfo.GetValue(data, null);

                                if (value <= 0)
                                {
                                    objIUS.GetUserSecurityHandler("AD").IsLogEnabled("RequiredFieldValidation|Not of type short", true);
                                    objResponseInfo.ErrorMessage.Append("Not of type short");
                                } break;
                            }

                        case TypeCode.Double:
                            {
                                double value = (double)objpropertyInfo.GetValue(data, null);

                                if (value <= 0)
                                {
                                    objIUS.GetUserSecurityHandler("AD").IsLogEnabled("RequiredFieldValidation|Not of type double", true);
                                    objResponseInfo.ErrorMessage.Append("Not of type double");
                                } break;
                            }

                        case TypeCode.DateTime:
                            {
                                DateTime value = (DateTime)objpropertyInfo.GetValue(data, null);

                                if (string.IsNullOrEmpty(value.ToString()))
                                {
                                    objIUS.GetUserSecurityHandler("AD").IsLogEnabled("RequiredFieldValidation|Not of type float", true);
                                    objResponseInfo.ErrorMessage.Append("Not of type float");
                                }
                                break;
                            }

                        case TypeCode.Char:
                            {
                                Char value = (Char)objpropertyInfo.GetValue(data, null);

                                if (value == ' ')
                                {
                                    objIUS.GetUserSecurityHandler("AD").IsLogEnabled("RequiredFieldValidation|Not of type char", true);
                                    objResponseInfo.ErrorMessage.Append("Not of type char");
                                }
                                break;
                            }

                        default: break;

                    }
                }
                return objResponseInfo;
        }

        public  bool PasswordComplexityValidation(string password)
        {
            Regex regex = new Regex(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,50}$");
            //Password must be 8-15 characters including 1 uppercase letter, 1 special character, alphanumeric characters
            Match match = regex.Match(password);
            return match.Success;

        }
    

    }
}

   