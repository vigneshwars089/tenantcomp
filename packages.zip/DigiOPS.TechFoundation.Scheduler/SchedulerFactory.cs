﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Scheduler
{
     class SchedulerFactory : ISchedulerFactory
    {
         public IBaseScheduler GetSchedulerHandler()
        {
            return null;
           // throw new NotImplementedException();
        }
    }
}
