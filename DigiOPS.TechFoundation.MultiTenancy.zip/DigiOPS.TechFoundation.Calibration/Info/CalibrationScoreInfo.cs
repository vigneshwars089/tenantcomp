﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace DigiOPS.TechFoundation.Calibration
{
    public class CalibrationScoreInfo 
    {
       public CalibrationScoreInfo() //Included by 391099 for calibration
            {
                IntAuditedList = new List<CalibrationDetailsEntity>();
                ExtAuditedList = new List<CalibrationDetailsEntity>();
                CombinedAccuracyList = new List<CalibrationDetailsEntity>();
              
            }

            public List<CalibrationDetailsEntity> IntAuditedList { get; set; }
            public List<CalibrationDetailsEntity> ExtAuditedList { get; set; }
            public List<CalibrationDetailsEntity> CombinedAccuracyList { get; set; }
           
            public string _strAuditlogic { get; set; }
            public string _strScoringLogic { get; set; } 
            public string _IsCriticalApp { get; set; }
            public string _calibrationType { get; set; }
    }

   public class CalibrationDetailsEntity : CalibrationScoreInfo
   {

       public int DOId { get; set; } // Category / Heading /CTQ id 
       public int SelectedRatingId { get; set; }   // selected interal/external rating Id
       public float GivenWeightage { get; set; } // Weitage provided on selecting the rating 1- yes 0 -No 
       //public Boolean DefectNA { get; set; }  // Should be considerd for score calculation 
       //  public float ActualWeightage { get; set; } // 
       public float MaxWeightage { get; set; } // Maximum configured for CTQ -1 yes
       public int DOGroupID { get; set; } // Grouping CTQ with Heading 
       public int ParentDOId { get; set; }       //If its is CTQ , Parent id - Heading Id ,if it Heading ParentId - Category Id    
       //   public int ErrorField { get; set; }           
       private string criticalityType = "";
       public string CriticalityType   // Critical , Non-Critical , Fatal 
       {
           get { return criticalityType; }
           set { criticalityType = value; }
       }
       // public Boolean IsCritical { get; set; }
       // public int iLine { get; set; }
       public float GroupWeightage { get; set; } // Group Based defined for more heading 
       //public float CalculatedGroupWeightage { get; set; } // Weigtage provided for groups 
       //   public int iPageCntDataAudit { get; set; }

       /*Added for combined accuracy list*/
       public int InternalRatingId { get; set; }
       public int ExternalRatingId { get; set; }
       public int CombinedRatingId { get; set; }

   }
}
