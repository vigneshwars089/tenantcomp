﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.CalibrationAudit
{
   public class CalibrationInfo
    {
       public CalibrationInfo()
        {
            _auditedData = new AuditDOEntity();
        }
      
        //Returning fields
        public double _QualityScore { get; set; }
        public double FieldQualityScore { get; set; }

        public AuditDOEntity _auditedData { get; set; }

        //AuditDOEntity _auditedData = new AuditDOEntity();


        public int _CriticalityChecked { get; set; }
        /*CheckPoint Based*/
        public int _totOpp { get; set; }
        public int _totAppOpp { get; set; }
        public int _totNotAppOpp { get; set; }
        public int _totAppDefects { get; set; }
        public int _totAppNoDefects { get; set; }

        public double _totOpp_W { get; set; }
        public double _totAppOpp_W { get; set; }
        public double _totNotAppOpp_W { get; set; }
        public double _totAppDefects_W { get; set; }
        public double _totAppNoDefects_W { get; set; }

        public double _totOppWithEmp_W { get; set; }
        public double _totAppOppWithEmp_W { get; set; }
        public double _totNotAppOppWithEmp_W { get; set; }
        public double _totAppDefectsWithEmp_W { get; set; }
        public double _totAppNoDefectsWithEmp_W { get; set; }

        /*Heading Based*/
        public int _totHeadings { get; set; }
        public int _totAppHeadings { get; set; }
        public int _totNotAppHeadings { get; set; }
        public int _totAppHeadingsDefects { get; set; }
        public int _totAppHeadingsNoDefects { get; set; }
        public int _totErrorField { get; set; }

        public double _totHeadings_W { get; set; }
        public double _totAppHeadings_W { get; set; }
        public double _totNotAppHeadings_W { get; set; }
        public double _totAppHeadingsDefects_W { get; set; }
        public double _totAppHeadingsNoDefects_W { get; set; }
        public double _totAppHeadingsWDPO_W { get; set; }
        public double _totHeadingsWDPO_W { get; set; }
        public double _ErrorFieldScore { get; set; }
        public double _ErrorFieldQualityScore { get; set; }

    }
}
