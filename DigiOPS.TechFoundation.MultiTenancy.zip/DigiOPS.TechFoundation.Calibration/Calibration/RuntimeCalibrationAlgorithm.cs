﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.MetricManagement;

namespace DigiOPS.TechFoundation.Calibration
{
   public class RuntimeCalibrationAlgorithm: BaseCalibrationAlgorithm
    {
       public override ScoringOutput GetCalibartionScore(ScoringInfo objAuditDataEntity)
       {
           ScoringAlgorithmInfo info = new ScoringAlgorithmInfo();

           ScoringOutput objScoringOutput = new ScoringOutput();

           IScoringAlgorithmFactory fs = new ScoringAlgorithmFactory();
           IScoringAlgorithm score = fs.GetScoringHandler(objAuditDataEntity._strScoringLogic, objAuditDataEntity._strAuditlogic);
            objScoringOutput = score.CalculateQualityScore(objAuditDataEntity);

           return objScoringOutput;
       }
    }
}
