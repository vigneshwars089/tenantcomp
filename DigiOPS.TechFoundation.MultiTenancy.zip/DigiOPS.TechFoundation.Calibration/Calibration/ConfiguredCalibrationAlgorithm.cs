﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.MetricManagement;

namespace DigiOPS.TechFoundation.Calibration
{
  public class ConfiguredCalibrationAlgorithm: BaseCalibrationAlgorithm
    {
      public override ScoringOutput GetCalibartionScore(ScoringInfo objAuditDataEntity)
      {
          ScoringAlgorithmInfo info = new ScoringAlgorithmInfo();

          ScoringOutput objScoringOutput = new ScoringOutput();

          List<DetailsEntity> CombinedAuditedList = (from c in objAuditDataEntity.AuditedList
                                                            join d in objAuditDataEntity.ExtAuditedList on c.DOId equals d.DOId
                                                     select new DetailsEntity
                                                            {
                                                               DOId=c.DOId,
                                                               ParentDOId=c.ParentDOId,
                                                               DOGroupID=c.DOGroupID,
                                                               InternalRatingId=c.SelectedRatingId,
                                                               ExternalRatingId=d.SelectedRatingId
                                                            }).ToList();

          List<DetailsEntity> FinalAuditedList = (from config in objAuditDataEntity.CombinedAccuracyList
                                                       join comb in CombinedAuditedList
                                                       on new { config.DOGroupID, config.InternalRatingId, config.ExternalRatingId }
                                                       equals new { comb.DOGroupID, comb.InternalRatingId, comb.ExternalRatingId }
                                                  select new DetailsEntity
                                                       {
                                                           DOId=comb.DOId,
                                                           ParentDOId=comb.ParentDOId,
                                                           DOGroupID=comb.DOGroupID,
                                                           InternalRatingId=comb.InternalRatingId,
                                                           ExternalRatingId=comb.ExternalRatingId,
                                                           CombinedRatingId=config.CombinedRatingId,
                                                           MaxWeightage=config.MaxWeightage,
                                                           GivenWeightage=config.GivenWeightage,
                                                           CalulatedWeightage=config.CalulatedWeightage,
                                                           DefectNA=config.DefectNA,
                                                           ActualWeightage=config.ActualWeightage,
                                                           CriticalityType=config.CriticalityType,
                                                           iLine=config.iLine,
                                                           GroupWeightage=config.GroupWeightage,
                                                           CalculatedGroupWeightage=config.CalculatedGroupWeightage

                                                       }
                                                       ).ToList();
          objAuditDataEntity.AuditedList = FinalAuditedList;

          IScoringAlgorithmFactory fs = new ScoringAlgorithmFactory();
          IScoringAlgorithm score = fs.GetScoringHandler(objAuditDataEntity._strScoringLogic, objAuditDataEntity._strAuditlogic);
           objScoringOutput = score.CalculateQualityScore(objAuditDataEntity);

          return objScoringOutput;
      }
    }
}
