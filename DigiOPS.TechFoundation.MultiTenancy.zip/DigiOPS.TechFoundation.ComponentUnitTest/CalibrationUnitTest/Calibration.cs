﻿using System;
using System.Text;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Calibration;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using System.Xml;
using System.Configuration;
using System.Collections;
using System.IO;

namespace DigiOPS.TechFoundation.ComponentUnitTest.CalibrationUnitTest
{
    /// <summary>
    /// Summary description for Calibration
    /// </summary>
    [TestClass]
    public class Calibration
    {
        //public Calibration()
        //{
            
        //}

        //private TestContext testContextInstance;

        ///// <summary>
        /////Gets or sets the test context which provides
        /////information about and functionality for the current test run.
        /////</summary>
        //public TestContext TestContext
        //{
        //    get
        //    {
        //        return testContextInstance;
        //    }
        //    set
        //    {
        //        testContextInstance = value;
        //    }
        //}

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void GetCalibratorsColl_PositiveTest()
        {
            MasterCalibratorEntity cal = new MasterCalibratorEntity();
            cal.SelectedSubProcessId = 43;
            cal.szCalibrators = "1354,324";
            cal.RecordIds = "111478";
            cal.SystemUserId = 936;
            MasterCalibratorAllocationDAO obj = new MasterCalibratorAllocationDAO();

            DataSet ds = new DataSet();
                ds=obj.GetCalibratorsColl(cal);
            int count = ds.Tables.Count;
            Assert.AreEqual(1, count);
        }

        // [TestMethod]
        //public void GetCalibratorscoll_NegativeTest()
        //{
        //    MasterCalibratorEntity cal = new MasterCalibratorEntity();
        //    cal.SelectedSubProcessId = 43;
        //    cal.szCalibrators = "1354,324";
        //    cal.RecordIds = "111478";
        //    cal.SystemUserId = 936;
        //    MasterCalibratorAllocationDAO obj = new MasterCalibratorAllocationDAO();

        //    DataSet ds = new DataSet();
        //    ds = obj.GetCalibratorsColl(cal);
        //    int count = ds.Tables.Count;
        //    Assert.AreEqual(3, count);
        //}

         [TestMethod]
        public void mapcalibrator_PositiveTest()
        {
            //string sb = string.Empty;
            //SearchElementConfigViewModel search = new SearchElementConfigViewModel();
            //BaseTransportEntity bte = new BaseTransportEntity();
            //XmlDocument doc = new XmlDocument();

            //doc.LoadXml("<root><SearchElementConfigViewModel  >  <Id>0</Id>  <CurrentUserID>936</CurrentUserID>  <CurrentUserRoleID>11</CurrentUserRoleID>  <_ProgramID>0</_ProgramID>  <_ProcessID>0</_ProcessID>  <_SubProcessID>43</_SubProcessID>  <eventAction>GetSearchList</eventAction>  <_ProcessedFromDate>02/01/2017</_ProcessedFromDate>  <_ProcessedToDate>02/15/2017</_ProcessedToDate>  <iSubCategoryId>0</iSubCategoryId>  <_StartRowIndex>1</_StartRowIndex>  <_MaximumRows>10</_MaximumRows>  <_SortOrder>DESC</_SortOrder>  <_SortColumn>iRecordID</_SortColumn>  <_TotalRows>0</_TotalRows>  <bIsEmpNeeded>false</bIsEmpNeeded>  <bIsLineNeeded>false</bIsLineNeeded>  <iSubcategory>0</iSubcategory>  <bIsLineApplicable>false</bIsLineApplicable>  <IsPeerCheckerReq>false</IsPeerCheckerReq>  <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>  <IsReadonDDL>false</IsReadonDDL>  <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>  <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>  <_ElementCount>0</_ElementCount>  <bIsExternalAudit>false</bIsExternalAudit>  <bIsExternalAuditAuto>false</bIsExternalAuditAuto>  <ReportID>0</ReportID>  <RatingDifferenceCount>0</RatingDifferenceCount>  <ProcessedFromDate>02/01/2017</ProcessedFromDate>  <ProcessedToDate>02/15/2017</ProcessedToDate>  <RecordId>0</RecordId>  <SearchTransactionList>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>156</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>157</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>158</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>159</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>160</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>161</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>162</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>163</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>164</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>165</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>166</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>167</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>168</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>    <SearchElementConfig>      <Id>0</Id>      <CurrentUserID>0</CurrentUserID>      <CurrentUserRoleID>0</CurrentUserRoleID>      <_ProgramID>0</_ProgramID>      <_ProcessID>0</_ProcessID>      <_SubProcessID>0</_SubProcessID>      <iSubCategoryId>0</iSubCategoryId>      <_StartRowIndex>0</_StartRowIndex>      <_MaximumRows>0</_MaximumRows>      <_TotalRows>0</_TotalRows>      <bIsEmpNeeded>false</bIsEmpNeeded>      <bIsLineNeeded>false</bIsLineNeeded>      <iSubcategory>0</iSubcategory>      <bIsLineApplicable>false</bIsLineApplicable>      <IsPeerCheckerReq>false</IsPeerCheckerReq>      <bIsSLAActivityApplicable>false</bIsSLAActivityApplicable>      <IsReadonDDL>false</IsReadonDDL>      <isBusiAutoAllocationSamplingRequired>false</isBusiAutoAllocationSamplingRequired>      <isExternalAutoAllocationSamplingRequired>false</isExternalAutoAllocationSamplingRequired>      <_ElementCount>0</_ElementCount>      <bIsExternalAudit>false</bIsExternalAudit>      <bIsExternalAuditAuto>false</bIsExternalAuditAuto>      <ReportID>0</ReportID>      <RatingDifferenceCount>0</RatingDifferenceCount>      <ElementId>169</ElementId>      <StartRowIndex>0</StartRowIndex>      <MaximumRows>0</MaximumRows>      <TotalRows>0</TotalRows>      <NoofLines>0</NoofLines>    </SearchElementConfig>  </SearchTransactionList>  <NoofLines>0</NoofLines></SearchElementConfigViewModel></root>");
            //StringWriter sw = new StringWriter();
            //XmlTextWriter tx = new XmlTextWriter(sw);
            //doc.WriteTo(tx);
            //sb = sw.ToString();

            //search._ProcessedFromDate = "02/01/2017";
            //search._ProcessedToDate = "02/15/2017";
            //search._ReceivedDate = "";

            //XmlDocument doc1 = new XmlDocument();

            //doc.LoadXml("<root>  <xmlArguments iRecordId='0' iSubProcessId='43' StartRowIndex='1' MaximumRows='10' SortOrder='DESC' SortColumn='Record ID' SearchedBy='936' /></root>");
            //StringWriter sw1 = new StringWriter();
            //XmlTextWriter tx1 = new XmlTextWriter(sw1);
            //doc.WriteTo(tx1);
            //string sb1 = sw1.ToString();
            //DataSet ds = new DataSet();
            //MasterCalibratorAllocationDAO obj = new MasterCalibratorAllocationDAO();
            //ds = obj.GetSearchTransactionList();
            //int count = ds.Tables.Count;
            //Assert.AreEqual(1, count);
        }
    }
}
