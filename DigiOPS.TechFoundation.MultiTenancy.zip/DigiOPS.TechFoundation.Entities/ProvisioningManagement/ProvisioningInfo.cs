﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    public class ProvisioningInfo : BaseInfo
    {
        public int InstanceID { get; set; }
        public string InstanceName { get; set; }
        public short ProgramId { get; set; }
        public short SelectedProgramId { get; set; }
        public string ProgramName { get; set; }
        public string TransCreateType { get; set; }
        public string transProcessAllocation { get; set; }
        public string transProcessing { get; set; }
        public bool IsPeerCheck { get; set; }
        public AuditSampling AuditSample { get; set; }
        public string AuditAllocation { get; set; }
        public AuditScoring auditScore { get; set; }
        public string Rework { get; set; }
        public string Rebuttal { get; set; }
        public string Callibration { get; set; }
        public string TimeTracking { get; set; }
        public string Databackup { get; set; }
    }
    [Serializable]
    public class AuditSampling : BaseInfo
    {
        public string SamplingTechnique { get; set; }
        public string SamplingLevel { get; set; }
        public string SamplingPeriod { get; set; }
        public string SamplingFreezing { get; set; }

    }
    [Serializable]
    public class AuditScoring : BaseInfo
    {
        public string HeadingBased { get; set; }
        public string CheckItemBased { get; set; }
        public string RoleBased { get; set; }
        public string GroupBased { get; set; }
        public string DualSampling { get; set; }

    }
}
