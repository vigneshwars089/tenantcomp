﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class TenantInfo : BaseInfo
    {
        public TenantInfo()
        {
            DatabaseDetails = new DatabaseInfo();
            TenantDetails = new List<TenantInstanceInfo>();
            HierarchyInfoList = new List<HierarchyInfo>();
            InstanceFeatureInfoList = new List<InstanceFeatureInfo>();
            ProgramFeatures = new TenantProgramFeaturesInfo();
            AuditFeatures = new AuditFeatureInfo();
            MailFeatures = new MailFeatureInfo();
            LookupInfo = new LookupInfo();
        }
        public DatabaseInfo DatabaseDetails { get; set; }
        public List<TenantInstanceInfo> TenantDetails { get; set; }
        public string OperationName { get; set; } //Insert/Update/Delete
        public string Output { get; set; }
        public List<HierarchyInfo> HierarchyInfoList { get; set; }
        public List<InstanceFeatureInfo> InstanceFeatureInfoList { get; set; }
        public TenantProgramFeaturesInfo ProgramFeatures { get; set; }
        public AuditFeatureInfo AuditFeatures { get; set; }
        public MailFeatureInfo MailFeatures { get; set; }
        public LookupInfo LookupInfo { get; set; }

    }

    public class DatabaseInfo
    {
        //For tblTenantDBDetails
        public string ServerName { get; set; }
        public string DataBaseName { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool IsLocked { get; set; }
        public bool IsActive { get; set; }
        //To excute ps scripts
        public string PSScriptPath { get; set; }
        public string SQLScriptPath { get; set; }
    }

    public class TenantInstanceInfo
    {
        //For tblQuartTenantmaster      

        public string InstanceName { get; set; }
        public int TenantUserID { get; set; }
        public string LicenseKey { get; set; }
        public bool SameURL { get; set; }
        public string URL { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }
        public int HierarchyId { get; set; }
        //public int AccountId { get; set; }
        public int Vertical { get; set; }
        public int AccountId { get; set; }
        public int TenantDBID { get; set; }
        //Added for EMT Config Changes
        //  public bool IsLocked { get; set; }
        public bool IsActive { get; set; }
    }
    public class InstanceFeatureInfo
    {
        public InstanceFeatureInfo()
        {
            AuditFeatureInfo = new AuditFeatureInfo();
            MailFeatureInfo = new MailFeatureInfo();
            ProcessingFeatureInfo = new ProcessingFeatureInfo();
        }
        public int ProgramId { get; set; }
        public AuditFeatureInfo AuditFeatureInfo { get; set; }
        public MailFeatureInfo MailFeatureInfo { get; set; }
        public ProcessingFeatureInfo ProcessingFeatureInfo { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedOn { get; set; }


    }
    public class AuditFeatureInfo
    {
        public AuditFeatureInfo()
        {
            ProgramFeatureSetUp = new ProgramFeatureSetUp();
            MenuInfo = new MenuInfo();
        }
        public int AuditFeatureId { get; set; }
        public ProgramFeatureSetUp ProgramFeatureSetUp { get; set; }
        public MenuInfo MenuInfo { get; set; }

    }
    public class MailFeatureInfo
    {
        public MailFeatureInfo()
        {
            MailFeatureEntity = new MailFeatureEntity();
            AddONsToBeConfiguredEntity = new AddONsToBeConfiguredEntity();
        }
        public string FeatureName { get; set; }
        public AddONsToBeConfiguredEntity AddONsToBeConfiguredEntity { get; set; }
        public MailFeatureEntity MailFeatureEntity { get; set; }

    }
    public class ProcessingFeatureInfo
    {
        public string FeatureName { get; set; }

    }

    public class HierarchyInfo
    {
        public int HierarchyID { get; set; }
        public int HierarchyLevel { get; set; }
        public string HierarchyLevelName { get; set; }
        public string HierarchyName { get; set; }
        public string HierarchyDesc { get; set; }
        public int ParentId { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string HierarchyPOC { get; set; }

    }

    public class TenantProgramFeaturesInfo
    {
        public int TenantProgramId { get; set; }
        public int TenantId { get; set; }
        public int ProgramId { get; set; }
        public int AuditFeatureId { get; set; }
        public int MailFeatureId { get; set; }
        public int ProcessingFeatureId { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedOn { get; set; }
    }

    public class MenuInfo
    {
        public string MenuName { get; set; }
        public string MenuDesc { get; set; }
        public string MenuControllerName { get; set; }
        public string MenuActionName { get; set; }
        public int SequenceNo { get; set; }
        public bool IsActive { get; set; }
        public int MenuId { get; set; }
        public int AccessTypeId { get; set; }
        public int ZoneId { get; set; }
        public string AccessType { get; set; }
        public string Category { get; set; }
        public string ZoneName { get; set; }
        public string ZoneDesc { get; set; }
        public string ZoneOffsetName { get; set; }
        public string ZoneOffsetDesc { get; set; }
        public string TenantName { get; set; }
        public string AppID { get; set; }

    }

    public class LookupInfo
    {
        public int LookupID { get; set; }
        public int LookupLevel { get; set; }
        public string LookupLevelName { get; set; }
        public string LookupName { get; set; }
        public string LookupDesc { get; set; }
        public string LookupValue { get; set; }
        public int ParentId { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }

    }

}
