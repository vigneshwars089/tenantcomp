﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// Search Element Config class
    /// </summary>
    [Serializable]
    public class SearchElementConfig : BaseTransportEntity
    {

        public int ElementId { get; set; }
        public string DisplayName { get; set; }
        public string ElementValue { get; set; }
        public string ElementTypeName { get; set; }
        public string DataTypeName { get; set; }
        public string DataTypes { get; set; }
        public string ElementLength { get; set; }
        public string CustomMessage { get; set; }
        public int StartRowIndex { get; set; }
        public int MaximumRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public int? TotalRows { get; set; }
        public int NoofLines { get; set; }
    }

    /// <summary>
    /// SearchElementConfigViewModel class
    /// </summary>
    [Serializable]
    public class SearchElementConfigViewModel : BaseTransportEntity
    {
        public string SubProcessId { get; set; }
        public string ProcessedDate { get; set; }
        public string ProcessedFromDate { get; set; }
        public string ProcessedToDate { get; set; }
        public string ReceivedDate { get; set; }
        public string ReferenceValue { get; set; }
        public string ReasonValue { get; set; }
        public string SelectedUser { get; set; }
        public string SelectedCurrentStatus { get; set; }
        public string SelectedPeerChecker { get; set; }
        public string SelectedSLAActivity { get; set; }
        public int RecordId { get; set; }

        /// <summary>
        /// SearchElementConfigViewModel constructor
        /// </summary>
        public SearchElementConfigViewModel()
        {
            SearchTransactionList = new List<SearchElementConfig>();
        }
        public List<SearchElementConfig> SearchTransactionList { get; set; }

        public int NoofLines { get; set; }

        //public class entityXMLSerialization
        //{
            /// <summary>
            /// Method convert string to XML format
            /// </summary>
            /// <returns>string</returns>
            public string ToXml()
            {
                StringWriter Output = new StringWriter(new StringBuilder());
                BaseTransportEntity bs = new BaseTransportEntity();
                string Ret = "";
                try
                {
                    
                   // XmlSerializer s = new XmlSerializer(this.GetType());   
                    XmlSerializer s = new XmlSerializer(typeof(BaseTransportEntity)); 
                   // s.Serialize(Output, this);
                    s.Serialize(Output, bs);
                    Ret = Output.ToString().Replace("xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"", "");
                    Ret = Ret.Replace("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"", "");
                    Ret = Ret.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", "").Trim();
                    Ret = Ret.Replace("<Value xsi:type=\"xsd:string\">", "<Value>").Trim();
                    Ret = Ret.Replace(Environment.NewLine, "");
                }
                catch (XmlException ex)
                {
                    throw ex;
                }
                catch (ArgumentNullException ex)
                {
                    throw ex;
                }
                catch (ArgumentException ex)
                {
                    throw ex;
                }
                catch (ApplicationException ex)
                {
                    throw ex;
                }
                return Ret;
            }
        }
    //}

    /// <summary>
    /// SearchReferenceReasonReq used to Check reference or reason is required
    /// for search transaction
    /// </summary>
    [Serializable]
    public class SearchReferenceReasonReq : BaseTransportEntity
    {
        public bool IsReferenceRequired { get; set; }
        public bool IsReasonRequired { get; set; }
    }
}
