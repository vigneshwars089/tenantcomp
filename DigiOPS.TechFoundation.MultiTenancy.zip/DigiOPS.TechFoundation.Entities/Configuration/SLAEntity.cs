﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// Added SLA entity for SLA changes
    /// </summary>
    [Serializable]
    public class SLAEntity : ProcessEntity
    {
        public int iSLALevelID { get; set; }

        [DisplayName("Service Level")]
        public string ServiceLevelName { get; set; }

        [DisplayName("Reference to Schedule 01")]
        public string ReferencetoSchedule01 { get; set; }

        [DisplayName("Service Level Criticality")]
        public string ServiceLevelCriticality { get; set; }

        [DisplayName("Service Level Criticality")]
        public int ServiceLevelCriticalityID { get; set; }

        [DisplayName("Quality Target")]
        public string QualityTarget { get; set; }

        [DisplayName("isActive")]
        public Boolean isActive { get; set; }
              
        [DisplayName("Created By")]
        public string CreatedBy { get; set; }
        [DisplayName("Created Date")]
        public DateTime CreatedDate { get; set; }

        [DisplayName("Last Modified By")]
        public string ModifiedBy { get; set; }

        [DisplayName("Last Modified Date")]
        public DateTime ModifiedDate { get; set; }

        public bool IsEditMode { get; set; }

        public string Action { get; set; }

        public string ServiceLevelDisplayName { get; set; }

        public string IsMappedtoSubprocess { get; set; }

        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
    }

    /// <summary>
    /// SLAViewModel
    /// </summary>
    [Serializable]
    public class SLAViewModel
    {

        public string CustomMessage { get; set; }
        public string ResultStatus { get; set; }
        /// <summary>
        /// TO ADD SLA Constructor
        /// </summary>
        public SLAViewModel()
        {
            ServiceLevelList = new List<SLAEntity>();
            ServiceLevel = new SLAEntity();
            DDLSLACriticality = new DropDownEntity();
        }

        public List<SLAEntity> ServiceLevelList { get; set; }
        public SLAEntity ServiceLevel { get; set; }
        public DropDownEntity DDLSLACriticality { get; set; }
        public SLAListViewModel ServiceLevelListDetails { get; set; }
    }

    /// <summary>
    /// SLAList View model
    /// </summary>
    [Serializable]
    public class SLAListViewModel
    {
        public string CustomMessage { get; set; }
        /// <summary>
        /// FOR SLA LIST Constructor
        /// </summary>
        public SLAListViewModel()
        {
            ServiceLevelList = new List<SLAEntity>();
            ServiceLevel = new SLAEntity();

        }
        public List<SLAEntity> ServiceLevelList { get; set; }
        public SLAEntity ServiceLevel { get; set; }
    }
}
