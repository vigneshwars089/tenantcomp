﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.Entities
{
   public class ManualHierarchyInfo:BaseInfo
    {
       public int ProgramId { get; set; }
       public int ProcessId { get; set; }
       public int SubProcessId { get; set; }
       public string ViewName { get; set; }
       public int? StartRowIndex { get; set; }
       public int? MaximumRows { get; set; }
       public int? TotalRows { get; set; }
       public string SortOrder { get; set; }
       public string SortColumn { get; set; }

    }
}
