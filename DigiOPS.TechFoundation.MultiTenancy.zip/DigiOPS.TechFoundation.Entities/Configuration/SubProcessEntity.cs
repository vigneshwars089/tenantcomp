﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;


namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// SubProcessEntity class
    /// </summary>
    [Serializable]
    public class SubProcessEntity : BaseInfo
    {
        public int SubProcessId { get; set; }
        public int ProcessId { get; set; }
        public int ProgramId { get; set; }
        public int UserGroupId { get; set; }
        public int SystemUserId { get; set; }
        public string SubProcessName { get; set; }
        public string ProcessName { get; set; }
        public string UserGroupName { get; set; }
        public string DisplayName { get; set; }
        public string ProgramName { get; set; }
        public Nullable<decimal> dSamplingPct { get; set; }

        public string CreatedByName { get; set; }
        public string ModifiedByName { get; set; }
        public int SelectedProcessId { get; set; }
        public int SelectedProgramId { get; set; }
        public int SelectedUserGroupId { get; set; }

        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public bool IsEditMode { get; set; }
        public string Action { get; set; }

        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public int? iSLALevelID { get; set; }  //Added for SLA Changes
        public string ServiceLevelName { get; set; }  //Added for SLA Changes
        public string eventAction { get; set; }
        public string ViewName { get; set; }

    }

    /// <summary>
    /// SubProcessEntityViewModel class
    /// </summary>
    [Serializable]
    public class SubProcessEntityViewModel
    {
        public string CustomMessage { get; set; }
  /// <summary>
  /// TO ADD SUBPROCESS ENTITY
  /// </summary>
        public SubProcessEntityViewModel()
        {
            SubProcessList = new List<SubProcessEntity>();
            SubProcess = new SubProcessEntity();
            DropDownLst = new DropDownEntity();
            SubProcessListDetails = new SubProcessListViewModel();
            
        }

        public List<SubProcessEntity> SubProcessList { get; set; }
        public List<UserGroupEntity> UserGroupList { get; set; }
        public SubProcessEntity SubProcess { get; set; }
        public DropDownEntity DropDownLst { get; set; }
        public SubProcessListViewModel SubProcessListDetails { get; set; }

    }
    public class Transddlsubprocess : SubProcessEntity
    {
        public Boolean IsSelected { get; set; }
        public Boolean IsNA { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
        public string Score { get; set; }
        public string ForeignKey { get; set; }
        public string criticality { get; set; }
        public string TempId { get; set; }
    }
    /// <summary>
    /// SubProcessEntityViewModel class
    /// </summary>
    [Serializable]
    public class SubProcessListViewModel
    {
        public string CustomMessage { get; set; }
        public string ResultStatus { get; set; }
        /// <summary>
        /// TO ADD SUBPROCESS LIST
        /// </summary>
        public SubProcessListViewModel()
        {
            SubProcessList = new List<SubProcessEntity>();
            SubProcessMaster = new SubProcessEntity();

        }
        public List<SubProcessEntity> SubProcessList { get; set; }
        public SubProcessEntity SubProcessMaster { get; set; }
    }
}
