﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    public class WorkflowConfigurationEntity:BaseInfo
    {
        public int WorkflowConfigID { get; set; } 

        public int SubProcessID { get; set; }
        public int TransactionTypeID { get; set; }
        public int iSubCategoryId { get; set; }

        public bool IsCoreTransactionStatusRequired { get; set; }
        public bool IsCoreTransactionStatusReasonRequired { get; set; }

        public bool IsInternalExternalAuditRequired { get; set; }
        public bool IsExternalAuditRequired { get; set; }


        public bool IsDirectBusinessAuditRequired { get; set; }

        public bool bIsExternalAudit { get; set; }
        public bool bIsExternalAuditAuto { get; set; }
        public bool isBusiAutoAllocationSamplingRequired { get; set; }

        public bool isExternalAutoAllocationSamplingRequired { get; set; }

        public int AuditConfigId { get; set; }  

        public string AuditingLogicType { get; set; }
        public string ScoringLogicType { get; set; }

        public bool IsEmpNeeded { get; set; }
        public bool bIsLineApplicable { get; set; }

        public int RootCauseLevel { get; set; }

        public string SamplingType { get; set; }
        public string ExternalSamplingType { get; set; }
        public string BusinessSamplingType { get; set; }


        // Common Properties for Workflow Configuration & Audit Configuration

        public bool IsEditAllowed { get; set; }

        public bool IsActive { get; set; }

        public string Action { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDate { get; set; }

        public string EntityName { get; set; }
        public bool EntitySavedStatus { get; set; }
        public string ErrorMessage { get; set; }
        //added by sathish
        public string ReworkRequiredFor { get; set; }
        public string ReworkupdateNeedFor { get; set; }
        public string ManualAllocationRequiredFor { get; set; }
        public bool IsSuperVisorAuditRequired { get; set; }
        public bool IsAutoSamplingRequired { get; set; }
        public bool IsTotalVolumeAuditRequired { get; set; }
        public bool IsCalibratorRequired { get; set; }
        public bool IsMCalibratorRequired { get; set; }
        public string szSamplingMethodInternal { get; set; }
        public string szSamplingMethodBusiness { get; set; }
        public int iCopysubdefectLevel { get; set; }

        public bool IsSamplingByVolume { get; set; }
        public bool IsCoverageScore { get; set; }
        public bool bIsAutoAudit { get; set; }
        public bool bIsAdditionalLanguageRequired { get; set; }
        public string szLangId { get; set; }
        public bool bIsNAWeightageRequired { get; set; }
    
 public string RootCauseLevelType { get; set; } 


    }
}
