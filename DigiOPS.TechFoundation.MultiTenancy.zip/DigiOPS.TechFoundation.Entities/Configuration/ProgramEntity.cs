﻿using System;
using System.Collections.Generic;



namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// ProgramEnity Class
    /// </summary>
    [Serializable]
    public class ProgramEntity : BaseInfo
    {
        public int programId { get; set; }
        public string programName { get; set; }
        public Boolean isActive { get; set; }
        public DateTime effectiveFrom { get; set; }
        public DateTime effectiveTo { get; set; }
        public string createdBy { get; set; }
        public DateTime createdDate { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDate { get; set; }
        public Boolean IsEditMode { get; set; }
        public int? _TotalRows { get; set; }
        public int TenantdbID { get; set; }

        public int selectedAccountId { get; set; }
        public string selectedAccountName { get; set; }
        public int selectedVerticalId { get; set; }
        public string selectedVerticalName { get; set; }        
        public int selectedZoneId { get; set; }
        public string selectedZoneName { get; set; }

        public string programRoleName { get; set; }
        public string RoleName { get; set; }
        public int RoleId { get; set; }
        public string programRoleMaplist { get; set; }

        public int selectedProgramId { get; set; }
        public int selectedRoleId { get; set; }

        public string eventAction { get; set; }
        public int CurrentUserID { get; set; }
    }    
   
    /// <summary>
    /// Program Entity view Model
    /// </summary>
    public class ProgramEntityViewModel
    {
       /// <summary>
       /// TO ADD  PROGRAM ENTITY
       /// </summary>
        public ProgramEntityViewModel()
        {
            ProgramList = new List<ProgramEntity>();
            Program = new ProgramEntity();
            DDLProgram = new DropDownEntity();
        }
        public List<ProgramEntity> ProgramList { get; set; }
        public ProgramEntity Program { get; set; }
        public DropDownEntity DDLProgram { get; set; }
        public string CustomErrorMessage { get; set; }
    }

    public class Transddlprogram : ProgramEntity
    {
        public Boolean IsSelected { get; set; }
        public Boolean IsNA { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
        public string Score { get; set; }
        public string ForeignKey { get; set; }
        public string criticality { get; set; }
        public string TempId { get; set; }
    }
    /// <summary>
    /// Program entity mapping view model 
    /// </summary>
    public class ProgramRoleMappingViewModel
    {
        /// <summary>
        /// TO ADD PROGRAM  ROLE MAPPING  constructor 
        /// </summary>
        public ProgramRoleMappingViewModel()
        {
            ProgramRoleMappingList = new List<ProgramEntity>();
            Program = new ProgramEntity();
            DDLProgram = new DropDownEntity();
            RoleList = new List<TransDropDown>();

        }
        public List<TransDropDown> RoleList { get; set; }
        public List<ProgramEntity> ProgramRoleMappingList { get; set; }
        public ProgramEntity Program { get; set; }
        public DropDownEntity DDLProgram { get; set; }
        public DropDownEntity DDLRole { get; set; }
        public string CustomErrorMessage { get; set; }
    }

    /// <summary>
    /// Program Role Map Element Data class
    /// </summary>
    public class ProgramRoleMapElementData
    {
        public string RoleId { get; set; }
       
        public string programRoleName { get; set; }
        public bool isActive { get; set; }
        public int programId { get; set; }
    }

    /// <summary>
    /// ProgramRoleMapElementDatas class
    /// </summary>
    public class ProgramRoleMapElementDatas
    {
       
        public List<ProgramRoleMapElementData> Items { get; set; }
    }

    /// <summary>
    ///  AccountEntity class
    /// </summary>
    [Serializable]
    public class AccountEntity : BaseTransportEntity
    {
        public int accountId { get; set; }
        public string accountName { get; set; }

        public int verticalId { get; set; }
    }

    /// <summary>
    /// VerticalEntity class
    /// </summary>
    [Serializable]
    public class VerticalEntity : BaseTransportEntity
    {
        public int verticalId { get; set; }
        public string verticalName { get; set; }
    }
    /// <summary>
    /// ZoneEntity class
    /// </summary>
    [Serializable]
    public class ZoneEntity : BaseTransportEntity
    {
        public int zoneId { get; set; }
        public string zoneName { get; set; }
        public string zoneOffsetName { get; set; }
        public string zoneOffsetDesc { get; set; }
    }
}
