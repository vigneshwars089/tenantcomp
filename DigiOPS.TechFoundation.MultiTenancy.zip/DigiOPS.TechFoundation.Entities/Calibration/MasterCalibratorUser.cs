﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;
using System.Web.UI.WebControls;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// MasterCalibratorUser class
    /// </summary>
    [Serializable]
    public class MasterCalibratorUser : BaseTransportEntity
    {
        public int SystemUserId { get; set; }
    }

    /// <summary>
    /// MasterCalibratorUserViewModel class
    /// </summary>
    [Serializable]
    public class MasterCalibratorUserViewModel
    {
        /// <summary>
        /// MasterCalibratorUserViewModel constructor
        /// </summary>
        public MasterCalibratorUserViewModel()
        {
            MasterCalibratorUserList = new List<MasterCalibratorUser>();
            CalibratorList = new List<CheckBoxList>();
        }
        public List<CheckBoxList> CalibratorList { get; set; }
        public List<MasterCalibratorUser> MasterCalibratorUserList { get; set; }
        public int recordId { get; set; }
        public string CustomErrorMessage { get; set; }
    }
}
