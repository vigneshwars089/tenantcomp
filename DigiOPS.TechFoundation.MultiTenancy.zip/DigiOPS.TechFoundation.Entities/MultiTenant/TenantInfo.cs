﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    public class TenantInfo : BaseInfo
    {
       public TenantInfo(){
           DatabaseDetails = new DatabaseInfo();
           TenantDetails = new TenantInstanceInfo();
       }
        public DatabaseInfo DatabaseDetails{ get; set; }
        public TenantInstanceInfo TenantDetails { get; set; }
        //Insert/Update/Delete
        public string OperationName { get; set; }
        public string Output { get; set; }
    }
    public class DatabaseInfo
    {
        //For tblTenantDBDetails
        public string ServerName { get; set; }
        public string DataBaseName { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        //To excute ps scripts
        public string PSScriptPath { get; set; }
        public string SQLScriptPath { get; set; }
    }
    public class TenantInstanceInfo
    {
        //For tblQuartTenantmaster      
        public string TenantName { get; set; }
        public string InstanceName { get; set; }
        public int TenantUserID { get; set; }
        public string LicenseKey { get; set; }
        public bool SameURL { get; set; }
        public string URL { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }
        public int Vertical { get; set; }
        public int AccountId { get; set; }

        public int TenantDBID { get; set; }
    }
}
