﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Exchange.WebServices.Data;

namespace DigiOPS.TechFoundation.Entities
{
    public class EMailInfo : BaseInfo
    {
        public EMailInfo()
        {
            EmailInputList = new List<EmailInput>();
            // CaseCreationInputList = new List<CaseCreationInput>();

        }

        public List<EmailInput> EmailInputList { get; set; }
        //public List<CaseCreationInput> CaseCreationInputList { get; set; }

        // public StringBuilder ErrorMessage { get; set; }

        //output
        // public string result { get; set; }

        public string strMailStarHeader { get; set; }
        public string CurrentTime { get; set; }
        public string EMailBoxId { get; set; }
        public string eMailType { get; set; }
        // public string CreationType { get; set; }



    }

    public class CaseCreationInput
    {
        // public string CaseIdKeyword { get; set; }
        // public int currentStatus { get; set; }
        // public string sCaseID { get; set; }
        // public string caseID { get; set; }
        public DateTime spDate { get; set; }
        public string spMailFolderId { get; set; }
        public string spStatusId { get; set; }
        public string spSubject { get; set; }
        public string spMessage { get; set; }
        public string spSender { get; set; }
        public string toadd { get; set; }
        public string ccaddress { get; set; }
        public string bccaddress { get; set; }
        public bool Priority { get; set; }
        // public string subcaseid { get; set; }
        public string GUID { get; set; }
        public string ScreenShotfileName { get; set; }//attachment is screenshot
        public string FileAttachmentName { get; set; }//attachment is FileAttachment
        public string ItemAttachmentFileName { get; set; }//attachment is ItemAttachment
        public byte[] MailFileAttachmentContentBytes { get; set; }
    }

    public class EmailInput : MainBoxInfo
    {
        public EmailInput()
        {
            IgnoreList = new List<IgnoreList>();
            // GUIDList = new List<GUIDList>();
        }
        //public string Mailfolderid { get; set; }
        // public string ServiceExchangeUrl { get; set; }
        //public string SourceFolder { get; set; }       
        public string MailHeader { get; set; }
        // public string EMailId { get; set; }
        // public string LoginEMailId { get; set; }
        public string TimeZone { get; set; }
        // public string ClientExVersion { get; set; }
        //public string Password { get; set; }
        public List<IgnoreList> IgnoreList { get; set; }
        //public string DestinationFolder { get; set; }
        public string DestinationIgnoreFolder { get; set; }
        // public string Domain { get; set; }
        //public List<GUIDList> GUIDList { get; set; }
        //public ExchangeService service { get; set; }
    }

    public class IgnoreList
    {
        public string Item { get; set; }
    }

    public class MainBoxInfo : BaseInfo
    {
        public string ServiceExchangeUrl { get; set; }
        public string LoginEMailId { get; set; }
        public string ClientExVersion { get; set; }
        public string Domain { get; set; }
        public string Password { get; set; }
        public ExchangeService service { get; set; }
        public string EMailId { get; set; }
        public WellKnownFolderName SourceFolder { get; set; }
    }

    //public class GUIDList
    //{
    //    public string GUID { get; set; }
    //}

    public class MailBoxInfo : BaseInfo
    {
        public string ServiceExchangeUrl { get; set; }
        public string LoginEMailId { get; set; }
        public string ClientExVersion { get; set; }
        public string Domain { get; set; }
        public string Password { get; set; }
        //public ExchangeService service { get; set; }
        public string EMailId { get; set; }
        //public WellKnownFolderName SourceFolder { get; set; }
        public bool IsLocked { get; set; }
    }


    //Entity related to Conversations table
    public class ConversationInfo : BaseInfo
    {
        public Int32 Id;
        public string EmailDate;
        public string EmailFrom;
        public string EmailTo;
        public string EmailCc;
        public string EmailBcc;
        public string Subject;
        public string Content;
        public string ConversationType;// mail sent or received 
        public bool IsHighImportance;
        public bool IsShowQuotedText;
        public string CreatedBy;
        public string CreatedDate;//date the transaction was created in system
        public List<AttachmentInfo> lstAttachments;
        public List<AttachmentInfo> lstInlineAttachments;
        public StringBuilder ErrorMessage;
    }

    //Entity related to Attachments table - only for file attachaments
    public class AttachmentInfo : BaseInfo
    {
        public Int32 Id;
        public string FileName;
        public string ContentType;
        public byte[] FileContent;
        public string CreatedDate;
        public string AttachmentType;
        public Int32 AttachmentTypeId;
    }

    //Entity related to Comments
    public class CommentsInfo : BaseInfo
    {
        public string CommentDescription;
        public string CommentedDate;
        public string CommentedBy;
    }

    public class SignatureInfo : BaseInfo
    {
        public int SignatureID;
        public string Signature;
        public string LastModifiedDate;
    }

}
