﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    [Serializable]
    public class SupportTicketEntity : BaseTransportEntity
    {

        public int IssueId { get; set; }

        public string UserName { get; set; }
        public string EmailId { get; set; }
        public string FileAttachement { get; set; }

        public string QuartLoginId { get; set; }
        public string IssueSummary { get; set; }

        public string IssueDesc { get; set; }

        public string IssueModule { get; set; }
        public string IssueType { get; set; }
        public string PriorityType { get; set; }

        public bool IsActive { get; set; }
        public int CreatedBy { get; set; }
        public string CreatedUserName { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public string Status { get; set; }
        public string Comments { get; set; }

        public bool IsEditMode { get; set; }
        public string Action { get; set; }

        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public DropDownEntity ddlIssueModule { get; set; }
        public DropDownEntity ddlIssueType { get; set; }
        public DropDownEntity ddlIssuePriority { get; set; }
        public DropDownEntity ddlSupportStatus { get; set; }
        public float WorkEffort { get; set; }

        public string SelectedIssueModule { get; set; }
        public string SelectedIssueType { get; set; }
        public string SelectedPriorityType { get; set; }
        public string SelectedStatus { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string CustomMessage { get; set; }
        public string CallType { get; set; }
    }

    /// <summary>
    /// SupportTicketTrailEntity class
    /// </summary>
    [Serializable]
    public class SupportTicketTrailEntity : BaseTransportEntity
    {


        public int IssueTrailId { get; set; }
        public int IssueId { get; set; }
        public int StatusId { get; set; }
        public string Status { get; set; }
        public float WorkEffort { get; set; }
        public string Comments { get; set; }
        public string CreatedUserName { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    /// <summary>
    /// SupportTicketViewModel class
    /// </summary>
    public class SupportTicketViewModel : BaseTransportEntity
    {

        public string CustomMessage { get; set; }
        /// <summary>
        /// FOR SUPPORT TICKET VIEW constructor
        /// </summary>
        public SupportTicketViewModel()
        {

            SupportTicketList = new List<SupportTicketEntity>();
            SupportTicket = new SupportTicketEntity();

            ddlSupportStatus = new DropDownEntity();

        }


        public List<SupportTicketEntity> SupportTicketList { get; set; }
        public SupportTicketEntity SupportTicket { get; set; }
        public DropDownEntity ddlSupportStatus { get; set; }

    }

    /// <summary>
    ///  SupportTicketTrailModel class
    /// </summary>
    public class SupportTicketTrailModel : BaseTransportEntity
    {
        /// <summary>
        /// SUPPORT TICKET TRAIL LIST
        /// </summary>
        public SupportTicketTrailModel()
        {
            SupportTicketTrailList = new List<SupportTicketTrailEntity>();
        }
        public List<SupportTicketTrailEntity> SupportTicketTrailList { get; set; }

    }
    /// <summary>
    /// SupportTicketSendMailEntity class
    /// </summary>
    [Serializable]
    public class SupportTicketSendMailEntity : BaseTransportEntity
    {

        public string UserName { get; set; }
        public string EmailId { get; set; }
        public int IssueId { get; set; }
        public string UserID { get; set; }
        public string IssueSummary { get; set; }
        public string IssueDescription { get; set; }
        public string Sender { get; set; }
        public string szSentTo { get; set; }
        public string szSentCC { get; set; }
        public string szSentFrom { get; set; }
        public string szSentSubj { get; set; }
        public Boolean bMailSent { get; set; }
        public string FileName { get; set; }
        public string Fileext { get; set; }
        public int iMailTypeId { get; set; }





    }
}
