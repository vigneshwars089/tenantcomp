﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
   public class MailBoxLoginDetailsEntity
    {
       public string LoginEmailId {get;set;}
       public string pd { get; set; }
       public string confirmpd { get; set; }
       public bool IsLocked { get; set; }
       public bool IsActive { get; set; }
    }
}
