﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    public class AddONsToBeConfiguredEntity
    {
        public bool IsADLogin { get; set; }
        public bool IsSubjectEditable { get; set; }
        public bool IsGMBtoGMB { get; set; }
        public bool IsCustomizableCaseId { get; set; }
        public bool IsConversationHistory { get; set; }
    }
}
