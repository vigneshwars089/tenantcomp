﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    public class MailFeatureEntity
    {
        public string MailBoxName { get; set; }
        public string MailBoxAddress { get; set; }
        public string MailBoxFolderPath { get; set; }
        public string TimeZone { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedById { get; set; }
        public string SLATime { get; set; }
        public bool IsQCRequired { get; set; }
        public bool IsActive { get; set; }
        public bool IsReplyNotRequired { get; set; }
        public bool IsLocked { get; set; }
        public bool IsMailTriggerRequired { get; set; }
        public bool IsVOCSurvey { get; set; }
        public string Domain { get; set; }
        public string TATInHours { get; set; }
        public int TATInSeconds { get; set; }
        public string IsEMailBoxAddressOptional { get; set; }
        public string Offset { get; set; }
        public bool IsADLogin { get; set; }
        public bool IsCustomizableCaseId { get; set; }
        public bool IsGMBtoGMB { get; set; }
        public bool IsSubjectEditable { get; set; }
        public bool IsConversationHistory { get; set; }
        public string TenantName { get; set; }
        public string AppId { get; set; }
        public int TenantId { get; set; }
        public string HierarchyValuetobeTakenName { get; set; }
        public string HierarchyLevelNameValuetobeTaken { get; set; }


    }
}
