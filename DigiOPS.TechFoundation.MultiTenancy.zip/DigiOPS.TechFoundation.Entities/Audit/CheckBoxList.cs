﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// CheckBoxList class
    /// </summary>
    public class CheckBoxList : BaseTransportEntity
    {
        public string Value { get; set; }
        public string Text { get; set; }
        public Boolean IsSelected { get; set; }
    }
}
