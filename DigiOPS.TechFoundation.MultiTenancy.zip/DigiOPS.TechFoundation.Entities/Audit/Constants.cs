﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml.Linq;


namespace DigiOPS.TechFoundation.Entities
{
    public class Constants
    {
        #region Default constructor for readonly variables
        private Constants()
        {

        }
        #endregion

        #region ENTITY_NAMES
        public const string ENTITY_Program = "ProgramEntity";
        public const string ENTITY_Process = "ProcessEntity";
        public const string ENTITY_SubProcess = "SubProcessEntity";
        public const string ENTITY_Account = "AccountEntity";
        public const string ENTITY_Vertical = "VerticalEntity";
        public const string ENTITY_Zone = "ZoneEntity";
        public const string ENTITY_DataElement = "DataElementEntity";
        public const string ENTITY_DataElementSeq = "DataElementSequence";
        public const string ENTITY_DataElementType = "DataElementTypeEntity";
        //public const string ENTITY_User = "User";
        public const string ENTITY_AuditConfig = "AuditConfigEntity";
        public const string ENTITY_AutoExtNeed = "AutoExtNeededEntity";
        public const string ENTITY_Rating = "RatingEntity";
        public const string ENTITY_RatingGroup = "RatingGroupEntity";
        public const string ENTITY_DataType = "DataTypeEntity";
        public const string ENTITY_CodesEntity = "CodesEntity";
        public const string ENTITY_CodeGroupEntity = "CodeGroupEntity";
        public const string ProgramHierarchy = "ProgramHierarchyEntity";
        public const string CombinedAccuracy = "CombinedAccuracyEntity";
        public const string HeadingDetail = "HeadingDetailsEntity";
        public const string ENTITY_CoreStatus = "CoreStatusEntity";
        public const string LOGIN = "LoginEntity";
        public const string HOLIDAY = "HolidayEntity";
        public const string REPORT = "ReportEntity";

        public const string VIEWNAME_UserManagementGroupUser = "UserManagementGroupUser";

        public const string ENTITY_AuditDetailsEntity = "AuditDetailsEntity";
        public const string ENTITY_SendMailEntity = "SendMailEntity";
        public const string ENTITY_AuditDOEntity = "AuditDOEntity";
        public const string ENTITY_TransElementConfig = "TransElementConfig";

        public const string ENTITY_SubProcess_Validation = "ConfigurationValidationEntity";
        public const string ENTITY_SubProcess_Validation_Update = "SubProcessvalidationEntity";

        public const string ENTITY_Workflow_AuditConfig = "ConfigurationEntity";
        public const string ENTITY_TransactionType = "TransactionTypeEntity";
        public const string ENTITY_CategoryType = "CategoryTypeEntity";
        public const string ENTITY_ExtAuditType = "ExternalAuditTypeEntity";
        public const string ENTITY_UGMProgram = "UGMProgramEntity";
        public const string ENTITY_UserProgramGroupMapping = "UserProgramGroupMappingEntity";
        public const string ENTITY_GroupUser = "GroupUser";
        public const string ENTITY_GroupUserMapping = "GroupUserMapping";

        public const string ENTITY_UserProgramGroupManagement = "UserProgramGroupManagementEntity";
        public const string ENTITY_RolePermissionMapping = "RolePermissionMapping";

        public const string ENTITY_ManualAllocation = "ManualAllocation";
        public const string ENTITY_SearchElementConfig = "SearchElementConfig";
        public const string ENTITY_BulkUpload = "BulkuploadEntity";
        public const string ENTITY_BatchFeed = "BatchFeedEntity";
        public const string ENTITY_SearchElementConfigViewModel = "SearchElementConfigViewModel";

        public const string PROGRAM = "Program";
        public const string PROCESS = "Process";
        public const string SUBPROCESSLIST = "SubProcess";
        public const string UserGroupMaster = "UserGroupMaster";
        public const string DefectOpportunity = "DefectOpportunityEntity";
        public const string SubDefectOpportunity = "SubDefectEntity";
        public const string RATING = "RATING";
        public const string RATINGGROUP = "RATINGGROUP";
        public const string ENTITY_User = "User";
        public const string ENTITY_AddUserMgmt = "AddUser";
        //public const string ENTITY_GroupUser = "GroupUser";
        public const string ENTITY_UserMapping = "UserMapping";
        public const string ENTITY_UserRoleMapping = "UserRoleMappingEntity";
        public const string ENTITY_UserRoleMappingEntity = "UserRoleMapping";
        public const string ENTITY_Sampling = "SamplingEntity";
        public const string ENTITY_Role = "Role";
        public const string ENTITY_TransRecordData = "TransRecordData";
        public const string ENTITY_TransReferenceConfig = "TransReferenceConfig";
        public const string ENTITY_ChangeroleEntity = "ChangeroleEntity";
        public const string ENTITY_TransactionListViewModalList = "TransactionListViewModalList";
        public const string ENTITY_TransactionListViewModal = "TransactionListViewModal";
        public const string ENTITY_AuditTransactionListViewModal = "AuditTransactionListViewModal";
        public const string ENTITY_SubDefectEntity = "SubDefectDetailsEntity";
        public const string ENTITY_FeedbackAuditList = "FeedbackAuditList";
        public const string ENTITY_AuditRework = "AuditRework";
        public const string ENTITY_ProgramFeatures = "ProgramFeatureSetUp";
        public const string ENTITY_SupportTicket = "SupportTicketEntity";

        public const string ENTITY_SupportTicketSendMailEntity = "SupportTicketSendMailEntity";

        public const string ENTITY_SupportTicketTrail = "SupportTicketTrailEntity";
        public const string ENTITY_SupportTicketStatus = "SupportTicketStatus";
        public const string MAILTRIGGER = "MailTriggerEntity";
        public const string MASTERCALIBRATOR = "MasterCalibratorEntity";
        public const string ENTITY_DASHBOARD = "DashboardEntity";
        public const string ENTITY_AHT = "AHTEntity";
        public const string ENTITY_REC = "RecommendationEntity";
        public const string ENTITY_ACCESSDENIED = "DenyAccessEntity";
        public const string ENTITY_RecommendationHistoryUsers = "RecommendationEntity";
        public const string ENTITY_SLAConfiguration = "SLAConfigurationEntity";



        //Added for CL  
        public const string ENTITY_StatisticalEntity = "StatisticalSamplingEntity";
        public const string ENTITY_StatisticalViewModel = "StatisticalSamplingViewModel";
        public const string ENTITY_Update_DataPurgeDetails = "DataPurgeModel";
        public const string ENTITY_DataPurge = "BaseTransportEntity";
        public const string ENTITY_DataPurgeGrid = "DataPurgeGrid";








        public const int DefectOpportunity_Category_Level = 1;
        public const int DefectOpportunity_Heading_Level = 2;
        public const int DefectOpportunity_Checkpoint_Level = 3;
        public const int DefectOpportunity_SubDefect1_Level = 4;
        public const int DefectOpportunity_SubDefect2_Level = 5;
        public const int DefectOpportunity_SubDefect3_Level = 8;
        public const int DefectOpportunity_SubDefect4_Level = 9;
        public const int DefectOpportunity_SubDefect5_Level = 10;
        public const int DefectOpportunity_WeightageConfig = 6;
        public const int DefectOpportunity_CTQGroup_Level = 7;
        public const string ENTITY_SLA = "SLAEntity";        //Added for SLA changes

        #endregion

        #region VARIABLE_NAMES

        //Session Variables
        public const string SYSUSERID = "SYSUSERID";
        public const string ROLEID = "RoleID";
        public const string PROGRAMID = "ProgramId";
        public const string PROCESSID = "ProcessId";
        public const string SUBPROCESSID = "SubProcessId";

        //Default Values
        private static int? nULL_INT = null;
        private static short? nULL_SHORT = null;
        private static string eMPTY = string.Empty;

        public const string NULL_STR = null;
        public static int? NULL_INT { get { return nULL_INT; } set { value = nULL_INT; } }
        public static short? NULL_SHORT { get { return nULL_SHORT; } set { value = nULL_SHORT; } }
        public static string EMPTY { get { return eMPTY; } set { value = eMPTY; } }
        public const bool TRUE = true;
        public const bool FALSE = false;

        public const string DESC = "desc";
        public const string ACTION_Insert = "INSERT";
        public const string ACTION_Update = "UPDATE";
        public const string ACTION_Delete = "DELETE";
        public const string ACTION_Select = "SELECT";
        public const string EDIT = "EDIT";
        public const string INFOTYPE_CORESTATUS = "CoreStatus";
        public const string INFOTYPE_CORESTATUSREASON = "CoreStatusReason";

        public const string SUPERVISOR_ACCEPT = "NOERROR";
        public const string SUPERVISOR_REJECT = "ERROR";
        #endregion

        #region AUDIT_TYPES
        public const string SUPERVISOR = "Supervisor";
        public const string SUPERVISOR_AUDITTYPEID = "1";
        public const string INTERNAL = "Cognizant";
        public const string INTERNAL_AUDITTYPEID = "2";
        //public const string EXTERNAL = "HIG FAO Team";
        public const string EXTERNAL = "External";
        public const string EXTERNAL_AUDITTYPEID = "3";
        //public const string BUSINESS = "HIG Process Owner";
        public const string BUSINESS = "Business";
        public const string BUSINESS_AUDITTYPEID = "4";
        public const string TOTALVOLUME = "Total Volume";
        public const string TOTALVOLUME_AUDITTYPEID = "5";
        public const string CALIBRATOR = "Calibrator";
        public const string CALIBRATOR_AUDITTYPEID = "6";
        public const string MCALIBRATOR = "Master Calibrator";
        public const string MASTERCALIBRATOR_AUDITTYPEID = "7";
        #endregion

        #region STATUS_TYPES
        public const string APPROVED = "Approved";
        public const string APPROVED_STATUSID = "15";
        public const string REJECTED = "Rejected";
        public const string REJECTED_STATUSID = "16";
        #endregion

        #region SP_NAMES


        public const string SP_GET_DEPARTMENTS = "USP_GET_DEPARTMENTS";
        public const string SP_GET_QRTPROGRAM = "USP_GET_QRTPROGRAM";
        public const string SP_INSERT_QRTPROGRAM = "USP_INSERT_QRTPROGRAM";
        public const string SP_DELETE_QRTPROGRAM = "USP_DELETE_QRTPROGRAM";

        public const string SP_SET_PROGRAMMASTER = "USP_SET_PROGRAMMASTER";
        public const string SP_GET_PROG_COL = "USP_GET_PROGRAMCOLLECTION";
        public const string SP_GET_TRANS_ELE_CONFIG_COL = "USP_GET_TRANSELEMENTCOLLECTION";

        public const string SP_GET_PROGRAMMASTER = "USP_GET_PROGRAMMASTER";
        public const string SP_GET_PROCESSMASTER = "USP_GET_PROCESSMASTER";
        public const string SP_GET_SUBPROCESSMASTER = "USP_GET_SUBPROCESSMASTER";
        public const string SP_GET_ACCOUNTMASTER = "USP_GET_ACCOUNTMASTER";
        public const string SP_GET_VERTICALMASTER = "USP_GET_VERTICALMASTER";
        public const string SP_GET_ZONEMASTER = "USP_GET_ZONEMASTER";
        public const string SP_GET_AUDITMASTER = "USP_GET_AUDITMASTER";
        public const string SP_GET_AUDITMASTER_REALLOCATION = "USP_GET_AUDITMASTER_REALLOCATION";
        public const string SP_GET_ATTACHMENTREQUIRED = "USP_GET_ATTACHMENTREQUIRED";


        public const string SP_GET_TRANSELEMENTLIST = "USP_GET_TRANSELEMENTLIST";
        public const string SP_GET_AUDITDEFECTOPPORTUNTIES = "USP_GET_AUDITDEFECTOPPORTUNITY";
        public const string SP_GET_AUDITMAILERDETAILS = "USP_GET_AUDITMAILERDETAILS";
        public const string SP_GET_TRANSACTIONRECORDMAILERDETAILS = "USP_GET_TRANSACTIONRECORDMAILERDETAILS";
        public const string GET_QS_CORRECTIONSTATUS = "GET_QS_CORRECTIONSTATUS";
        public const string SP_GET_AUDIT_AND_DELETE_STATUS = "USE_GET_AUDIT_AND_DELETE_STATUS";
        public const string SP_GET_TRANSELEMENTCONFIG = "USP_GET_TRANSELEMENTCONFIG";
        public const string SP_GET_ELEMENTTYPE = "USP_GET_ELEMENTTYPEMASTER";
        public const string SP_GET_DATATYPE = "USP_GET_DATATYPEMASTER";
        public const string SP_SET_TRANSELEMENTCONFIG = "USP_SET_TRANSELEMENTCONFIG";
        public const string SP_SET_TRANSELEMENTSEQUENCE = "USP_SET_TRANSELEMENTSEQUENCE";

        public const string SP_GET_CODESDATA = "USP_GET_CODESDATA";
        public const string SP_SET_CODESDATA = "USP_SET_CODESDATA";
        public const string SP_GET_CODESDATALIST_BYID = "USP_GET_CODESDATALIST_BYID";
        public const string USP_SET_USERMASTER = "USP_SET_USERMASTER";

        public const string SP_SET_PROCESSMASTER = "USP_SET_PROCESSMASTER";
        public const string SP_SET_RATINGMASTER = "USP_SET_AUDITRATINGMASTER";
        public const string SP_SET_RATINGGROUPMASTER = "USP_SET_AUDITRATINGGRPMASTER";
        public const string SP_SET_BULKUPLOADDATA = "USP_SET_BULKUPLOADDATA";
        public const string SP_SET_BATCHUPLOADDATA = "USP_SET_BATCHUPLOADDATA";


        public const string SP_SET_BULKUPLOADDATA_USERTEMPLATE = "SP_BULKUPLOAD_USERDETAILS";
        public const string SP_SET_BULKUPLOADTEMPLATE = "USP_SET_BULKUPLOADTEMPLATE";
        public const string SP_SET_BULKUPLOADVALIDATION = "USP_SET_BULKUPLOADVALID";
        public const string SP_AUTH_USER = "USP_AUTH_USER";

        public const string SP_SET_AUDITFINDINGDATA = "USP_SET_AUDITFINDINGDATA";
        public const string SP_SET_HOLIDAYS = "usp_set_HolidayMaster";
        public const string SP_GET_HOLIDAYS = "usp_Get_HolidayMaster";
        public const string SP_SET_SupportTicket = "usp_set_SupportTicketDataMaster";
        public const string SP_SET_AHT = "USP_SET_AHTDATA";
        public const string SP_SET_AUDITFINDINGDATA_CALIBRATION = "USP_SET_AUDITFINDINGDATA_calibration";

        public const string SP_SET_MAILTRIGGER = "USP_SET_AUDITMAILTRIGGER";
        public const string SP_GET_MAILTRIGGER = "USP_GET_AUDITMAILTRIGGERCOLLECTION";
        public const string SP_GET_AUDITSUBDEFECTOPPORTUNITY = "USP_GET_AUDITSUBDEFECTOPPORTUNITY";

        //Added for SLA changes
        public const string SP_SET_SLAMASTERDATA = "USP_SET_SLASERVICEMASTER";
        public const string SP_GET_SLASERVICELEVELMASTER = "USP_GET_SLASERVICELEVELMASTER";
        //Added for CL 

        public const string SP_GET_STATISTICALSAMPLING_DETAILS = "USP_GET_STATISTICALSAMPLING_DETAILS";
        public const string SP_SET_STATISTICALSAMPLING_ADMIN = "USP_SET_STATISTICALSAMPLING_ADMIN";
        public const string USP_INSERT_AUDITSTATSTRIAL = "USP_INSERT_AUDITSTATSTRIAL";
        public const string USP_STATISTICAL_SUBPROCESSLIST = "usp_Get_Statistical_SubProcessList_GRID";
        public const string USP_GET_STATITICAL_SUBPROCESSTRAILLIST = "USP_GET_STATS_SUBPROCESSLIST_TRAIL";
        public const string USP_GET_PROCESSEDBYLIST = "USP_GET_ASSOCIATEROLE_USERS_BY_SUBPROCESSID";

        public const string SP_GET_STATICCONDITIONS = "USP_GET_STATICCONDITIONS";
        public const string SP_UPDATE_STATICCONDITIONS = "USP_UPDATE_STATICCONDITIONS";
        public const string SP_UPDATE_CHILDSTATICCONDITIONS = "USP_GET_CHILDSTATICCONDITIONS";








        #endregion SP_NAMES

        #region PARAMETERS
        public const string PAR_ViewName = "@ViewName";

        public const string PAR_iElementId = "@iElementId";
        public const string PAR_szElementName = "@szElementName";
        public const string PAR_szDisplayName = "@szDisplayName";
        public const string PAR_iElementTypeId = "@iElementTypeId";
        public const string PAR_iDataTypeId = "@iDataTypeId";
        public const string PAR_szSplChars = "@szSplChars";
        public const string PAR_iElementLength = "@iElementLength";
        public const string PAR_iSequenceNo = "@iSequenceNo";
        public const string PAR_bMandatoryElement = "@bMandatoryElement";
        public const string PAR_bAuditFormElement = "@bAuditFormElement";
        public const string PAR_bUniqueElement = "@bUniqueElement";
        public const string PAR_bSearchableElement = "@bSearchableElement";
        public const string PAR_bGridViewElement = "@bGridViewElement";
        public const string PAR_bReportableField = "@bReportableField";
        public const string PAR_bSamplingThreshold = "@bSamplingThreshold";
        public const string PAR_bIsDirectAuditLevel = "@bIsDirectAuditLevel";
        public const string PAR_iDirectAuditLevelId = "@iDirectAuditLevelId";
        public const string PAR_szMinAuditRange = "@szMinAuditRange";
        public const string PAR_szMaxAuditRange = "@szMaxAuditRange";
        public const string PAR_szMinSamplingRange = "@szMinSamplingRange";
        public const string PAR_szMaxSamplingRange = "@szMaxSamplingRange";
        public const string PAR_iSubProcessId = "@iSubProcessId";
        public const string PAR_iProcessId = "@iProcessId";
        public const string PAR_siProgramId = "@siProgramId";
        public const string PAR_iSystemUserId = "@iSystemUserId";
        public const string PAR_szProgramName = "@szProgramName";
        public const string PAR_iAccountId = "@iAccountId";
        public const string PAR_iVerticalId = "@iVerticalId";
        public const string PAR_iZoneId = "@iZoneId";

        public const string PAR_iCodeId = "@iCodeId";
        public const string PAR_szCodeDesc = "@szCodeDesc";
        public const string PAR_szCodeValue = "@szCodeValue";
        public const string PAR_szCodeGroupId = "@szCodeGroupId";
        public const string PAR_szParentGroupId = "@szParentGroupId";
        public const string PAR_iLevel = "@iLevel";

        public const string PAR_dsEffectiveFrom = "@dsEffectiveFrom";
        public const string PAR_dsEffectiveTo = "@dsEffectiveTo";
        public const string PAR_bIsActive = "@bIsActive";
        public const string PAR_iCreatedBy = "@iCreatedBy";
        public const string PAR_dsCreatedDate = "@dsCreatedDate";
        public const string PAR_iModifiedBy = "@iModifiedBy";
        public const string PAR_dsModifiedDate = "@dsModifiedDate";
        public const string PAR_szOpertaionName = "@szOpertaionName";
        public const string PAR_iRectrictedElementCount = "@iRectrictedElementCount";

        public const string PAR_iReturnValue = "@iReturnValue";
        public const string PAR_xmlParam = "@XMLParam";

        public const string PAR_iAuditId = "@iAuditId";
        public const string PAR_AuditorID = "@iAuditorid";
        public const string PAR_iMailTypeId = "@iMailTypeId";
        public const string PAR_iAuditFindingId = "@iAuditFindingId";
        public const string PAR_fQualityScore = "@fQualityScore";
        public const string PAR_fFieldQualityScore = "@fFieldQualityScore";
        public const string PAR_szComment = "@szComment";
        public const string PAR_szAuditFeedBack = "@szAuditFeedBack";
        public const string PAR_szTATFeedback = "@szTATFeedback";
        public const string PAR_szTATFeedbackComments = "@szTATFeedbackComments";
        public const string PAR_szAuditNotes = "@szAuditNotes";
        public const string PAR_szFatalStatus = "@szFatalStatus";
        public const string PAR_szApproverComments = "@szApproverComments";
        public const string PAR_szUploadFilePath = "@szUploadFilePath";
        public const string PAR_szRecommendationComments = "@szRecommendationComments";
        public const string PAR_szApprovalStatus = "@szApprovalStatus";
        public const string PAR_iTotDO_Cnt = "@iTotDO_Cnt";
        public const string PAR_iTotAppDO_Cnt = "@iTotAppDO_Cnt";
        public const string PAR_iTotNotAppDO_Cnt = "@iTotNotAppDO_Cnt";
        public const string PAR_iTotAppDOWithDefects_Cnt = "@iTotAppDOWithDefects_Cnt";
        public const string PAR_iTotAppDOWithNoDefects_Cnt = "@iTotAppDOWithNoDefects_Cnt";
        public const string PAR_iTotHeadings_Cnt = "@iTotHeadings_Cnt";
        public const string PAR_iTotAppHeadings_Cnt = "@iTotAppHeadings_Cnt";
        public const string PAR_iTotNotAppHeadings_Cnt = "@iTotNotAppHeadings_Cnt";
        public const string PAR_iTotAppHeadingsWithDefects_Cnt = "@iTotAppHeadingsWithDefects_Cnt";
        public const string PAR_iTotAppHeadingsWithNoDefects_Cnt = "@iTotAppHeadingsWithNoDefects_Cnt";
        public const string PAR_fTotDO_Wt = "@fTotDO_Wt";
        public const string PAR_fTotAppDO_Wt = "@fTotAppDO_Wt";
        public const string PAR_fTotNotAppDO_Wt = "@fTotNotAppDO_Wt";
        public const string PAR_fTotAppDOWithDefects_Wt = "@fTotAppDOWithDefects_Wt";
        public const string PAR_fTotAppDOWithNoDefects_Wt = "@fTotAppDOWithNoDefects_Wt";
        public const string PAR_fTotHeadings_Wt = "@fTotHeadings_Wt";
        public const string PAR_fTotAppHeadings_Wt = "@fTotAppHeadings_Wt";
        public const string PAR_fTotNotAppHeadings_Wt = "@fTotNotAppHeadings_Wt";
        public const string PAR_fTotAppHeadingsWithDefects_Wt = "@fTotAppHeadingsWithDefects_Wt";
        public const string PAR_fTotAppHeadingsWithNoDefects_Wt = "@fTotAppHeadingsWithNoDefects_Wt";
        public const string PAR_xmlAuditDO = "@xmlAuditDO";
        public const string PAR_xmlAuditSubDO = "@xmlAuditSubDO";

        public const string PAR_iAuditedBy = "@iAuditedBy";
        public const string PAR_szPageName = "@szPageName";

        public const string PAR_iDOId = "@iDOId";
        public const string PAR_iParentSubDOId = "@iParentSubDOId";


        public const string PAR_szCtsUserId = "@szCtsUserId";
        public const string PAR_szClientUserId = "@szClientUserId";
        public const string PAR_szFirstName = "@szFirstName";
        public const string PAR_szLastName = "@szLastName";
        public const string PAR_szEmail = "@szEmail";
        public const string PAR_RETURN_VALUE = "@RETURN_VALUE";


        //Rating
        public const string PARAM_SET_RATINGMASTER_ID = "@iRatingId";
        public const string PARAM_SET_RATINGMASTER_DESC = "@szRatingDesc";
        public const string PARAM_SET_RATINGMASTER_DSPYNAME = "@szDisplayName";
        public const string PARAM_SET_RATINGMASTER_SUBPROCESSID = "@iSubProcessId";
        public const string PARAM_SET_RATINGMASTER_NOTAPP = "@bIsNotApplicable";
        public const string PARAM_SET_RATINGMASTER_DONEBY = "@iDoneBy";
        public const string PARAM_SET_RATINGMASTER_OPERTAIONNAME = "@sOpertaionName";

        //Rating Group
        public const string PARAM_SET_RATINGGROUPMASTER_ID = "@iRatingGroupId";
        public const string PARAM_SET_RATINGGROUPMASTER_DESC = "@szRatingGroupName";
        public const string PARAM_SET_RATINGGROUPMASTER_SUBPROCESSID = "@iSubProcessId";
        public const string PARAM_SET_RATINGGROUPMASTER_RATINGID = "@szRatingIds";
        public const string PARAM_SET_RATINGGROUPMASTER_DONEBY = "@iDoneBy";
        public const string PARAM_SET_RATINGGROUPMASTER_OPERTAIONNAME = "@sOpertaionName";

        //Bulk Upload
        public const string PARAM_SET_BULKUPLOADDATA_FILEPATH = "@FilePathName";
        public const string PARAM_SET_BULKUPLOADDATA_FILEEXTN = "@FileExtension";
        public const string PARAM_SET_BULKUPLOADDATA_UPLOADBY = "@UploadedBy";
        public const string PARAM_SET_BULKUPLOADDATA_SUBPROCESS = "@SubProcessId";
        public const string PARAM_SET_BULKUPLOADDATA_ERRORPATH = "@ErrorFilePath";
        public const string PARAM_SET_BULKUPLOADTEMPLATE_ID = "@SubProcessId";
        public const string PARAM_SET_BULKUPLOADDATA_EXCELCOLUMN = "@ExcelColumn";
        public const string PARAM_SET_BULKUPLOADDATA_COLUMN = "@Column";
        public const string PARAM_SET_BULKUPLOADDATA_DATEFORMATCON = "@dateformatcon";
        public const string PARAM_SET_BULKUPLOADDATA_EXCELDATA = "@ExcelData";
        public const string PARAM_SET_BATCHUPLOAD_MAX_COUNT = "@BtchFdCount";
        public const string PARAM_SET_BULKUPLOAD_MAX_COUNT = "@BulkUdCount";

        //Process
        public const string PARAM_SET_PROCESSMASTER_PROCESSID = "@iProcessId";
        public const string PARAM_SET_PROCESSMASTER_PROGRAMID = "@siProgramId";
        public const string PARAM_SET_PROCESSMASTER_PROCESSNAME = "@szProcessName";
        public const string PARAM_SET_PROCESSMASTER_EFFECTIVEFROM = "@dsEffectiveFrom";
        public const string PARAM_SET_PROCESSMASTER_EFFECTIVETO = "@dsEffectiveTo";
        public const string PARAM_SET_PROCESSMASTER_ISACTIVE = "@IsActive";
        public const string PARAM_SET_PROCESSMASTER_DONEBY = "@iDoneBy";
        public const string PARAM_SET_PROCESSMASTER_OPERTAIONNAME = "@sOpertaionName";

        //Added for SLA changes
        public const string PARAM_SET_SLAMASTER_SLALEVELID = "@iSLALevelID";
        public const string PARAM_SET_SLAMASTER_SERVICELEVELNAME = "@szServiceLevelName";
        public const string PARAM_SET_SLAMASTER_REFERENCETOSCHEDULE01 = "@szReferencetoSchedule01";
        public const string PARAM_SET_SLAMASTER_SLACRITICALITYID = "@iSLACriticalityID";
        public const string PARAM_SET_SLAMASTER_QUALITYTARGET = "@szQualityTarget";
        public const string PARAM_SET_SLAMASTER_ISACTIVE = "@IsActive";
        public const string PARAM_SET_SLAMASTER_DONEBY = "@iDoneBy";
        public const string PARAM_SET_SLAMASTER_OPERATIONNAME = "@sOpertaionName";

        #endregion

        #region TABS
        public const int ADDUSERTAB = 0;
        public const int USERMAPPINGTAB = 1;
        public const int TAB_CORESTATUS = 0;
        public const int TAB_CORESTATUSREASON = 1;
        public const string TAB_TXT_CORESTATUS = "Core Status";
        public const string TAB_TXT_CORESTATUSREASON = "Core Status Reason";
        #endregion

        #region DROPDOWNLIST

        public const string DDL_VALUE = "Value";
        public const string DDL_TEXT = "Text";

        public const string DDL_DO_VALUE = "DOId";
        public const string DDL_DO_TEXT = "DisplayName";
        public const string DDL_CRITICALITY_VALUE_CRITICAL = "1";
        public const string DDL_CRITICALITY_VALUE_NONCRITICAL = "2";
        public const string DDL_FATAL_VALUE_FATAL = "3";
        public const string DDL_CRITICALITY_TEXT_CRITICAL = "Critical";
        public const string DDL_CRITICALITY_TEXT_NONCRITICAL = "Non-Critical";
        public const string DDL_FATAL_TEXT_FATAL = "Fatal";

        #endregion

        #region APPLICATION MESSAGES

        #region PROGRAM APPLICATION MESSAGES

        private static string mSG_Prg_AddedSuccessfully = RenameText("clientConfigKeyLbl-program-program") + " Added Successfully.";
        private static string mSG_Prg_UpdatedSuccessfully = RenameText("clientConfigKeyLbl-program-program") + " Updated Successfully.";
        private static string mSG_Prg_DeletedSuccessfully = RenameText("clientConfigKeyLbl-program-program") + " Deleted Successfully.";

        public static string MSG_Prg_AddedSuccessfully { get { return mSG_Prg_AddedSuccessfully; } set { value = mSG_Prg_AddedSuccessfully; } }
        public static string MSG_Prg_UpdatedSuccessfully { get { return mSG_Prg_UpdatedSuccessfully; } set { value = mSG_Prg_UpdatedSuccessfully; } }
        public static string MSG_Prg_DeletedSuccessfully { get { return mSG_Prg_DeletedSuccessfully; } set { value = MSG_CL_DeletedSuccessfully; } }

        private static string mSG_Prg_AlreadyExists = RenameText("clientConfigKeyLbl-program-program") + " Name Already Exists";
        private static string mSG_Prg_AlreadyExistsUpdate = RenameText("clientConfigKeyLbl-program-program") + " Name Already Exists in Activate/De-Activate State";
        private static string mSG_Prg_ProcessEffToDateLess = RenameText("clientConfigKeyLbl-program-program") + " Effective To Date Must be Greater than Effective To Date of Process";
        private static string mSG_PrgUserGroupEffToDateLess = RenameText("clientConfigKeyLbl-program-program") + " Effective To Date Must be Greater than Effective To Date of User Group";
        private static string mSG_Prg_InsertionFailed = "Insertion Failed.";
        private static string mSG_Prg_UpdationFailed = "Updation Failed.";
        private static string mSG_Prg_DeletionFailed = "Deletion Failed.";

        public static string MSG_Prg_AlreadyExists { get { return mSG_Prg_AlreadyExistsUpdate; } set { value = mSG_Prg_AlreadyExists; } }
        public static string MSG_Prg_AlreadyExistsUpdate { get { return mSG_Prg_AlreadyExistsUpdate; } set { value = mSG_Prg_AlreadyExistsUpdate; } }
        public static string MSG_Prg_ProcessEffToDateLess { get { return mSG_Prg_ProcessEffToDateLess; } set { value = mSG_Prg_ProcessEffToDateLess; } }
        public static string MSG_PrgUserGroupEffToDateLess { get { return mSG_PrgUserGroupEffToDateLess; } set { value = mSG_PrgUserGroupEffToDateLess; } }
        public static string MSG_Prg_InsertionFailed { get { return mSG_Prg_InsertionFailed; } set { value = mSG_Prg_InsertionFailed; } }
        public static string MSG_Prg_UpdationFailed { get { return mSG_Prg_UpdationFailed; } set { value = mSG_Prg_UpdationFailed; } }
        public static string MSG_Prg_DeletionFailed { get { return mSG_Prg_DeletionFailed; } set { value = mSG_Prg_DeletionFailed; } }

        #endregion

        #region DATA ELEMENT APPLICATION MESSAGES

        private static string mSG_DE_AddedSuccessfully = "Data Element Added Successfully.";
        private static string mSG_DE_UpdatedSuccessfully = "Data Element Updated Successfully.";
        private static string mSG_DE_DeletedSuccessfully = "Data Element Deleted Successfully.";

        public static string MSG_DE_AddedSuccessfully { get { return mSG_DE_AddedSuccessfully; } set { value = mSG_DE_AddedSuccessfully; } }
        public static string MSG_DE_UpdatedSuccessfully { get { return mSG_DE_UpdatedSuccessfully; } set { value = mSG_DE_UpdatedSuccessfully; } }
        public static string MSG_DE_DeletedSuccessfully { get { return mSG_DE_DeletedSuccessfully; } set { value = mSG_DE_DeletedSuccessfully; } }

        private static string mSG_DE_AlreadyExists = "Data Element Already Exists";
        private static string mSG_DE_AlreadyExistsAsDeleted = "Data Element Already Exists in Deteled State";
        private static string mSG_DE_InsertionFailed = "Insertion Failed.";
        private static string mSG_DE_UpdationFailed = "Updation Failed.";
        private static string mSG_DE_DeletionFailed = "Deletion Failed.";


        public static string MSG_DE_AlreadyExists { get { return mSG_DE_AlreadyExists; } set { value = mSG_DE_AlreadyExists; } }
        public static string MSG_DE_AlreadyExistsAsDeleted { get { return mSG_DE_AlreadyExistsAsDeleted; } set { value = mSG_DE_AlreadyExistsAsDeleted; } }
        public static string MSG_DE_InsertionFailed { get { return mSG_DE_InsertionFailed; } set { value = mSG_DE_InsertionFailed; } }
        public static string MSG_DE_UpdationFailed { get { return mSG_DE_UpdationFailed; } set { value = mSG_DE_UpdationFailed; } }
        public static string MSG_DE_DeletionFailed { get { return mSG_DE_DeletionFailed; } set { value = mSG_DE_DeletionFailed; } }

        #endregion

        #region CODES LIST APPLICATION MESSAGES

        private static string mSG_CL_AddedSuccessfully = "List Item Added Successfully.";
        private static string mSG_CL_RenewedSuccessfully = "List Item Already Available in Deleted State Renewed Successfully.";
        private static string mSG_CL_UpdatedSuccessfully = "List Item Updated Successfully.";
        private static string mSG_CL_DeletedSuccessfully = "List Item Deleted Successfully.";

        public static string MSG_CL_AddedSuccessfully { get { return mSG_CL_AddedSuccessfully; } set { value = mSG_CL_AddedSuccessfully; } }
        public static string MSG_CL_RenewedSuccessfully { get { return mSG_CL_RenewedSuccessfully; } set { value = mSG_CL_RenewedSuccessfully; } }
        public static string MSG_CL_UpdatedSuccessfully { get { return mSG_CL_UpdatedSuccessfully; } set { value = mSG_CL_UpdatedSuccessfully; } }
        public static string MSG_CL_DeletedSuccessfully { get { return mSG_CL_DeletedSuccessfully; } set { value = mSG_CL_DeletedSuccessfully; } }


        private static string mSG_CL_AlreadyExists = "List Item Already Exists";
        private static string mSG_CL_InsertionFailed = "Insertion Failed.";
        private static string mSG_CL_UpdationFailed = "Updation Failed.";
        private static string mSG_CL_DeletionFailed = "Deletion Failed.";

        public static string MSG_CL_AlreadyExists { get { return mSG_CL_AlreadyExists; } set { value = mSG_CL_AlreadyExists; } }
        public static string MSG_CL_InsertionFailed { get { return mSG_CL_InsertionFailed; } set { value = mSG_CL_InsertionFailed; } }
        public static string MSG_CL_UpdationFailed { get { return mSG_CL_UpdationFailed; } set { value = mSG_CL_UpdationFailed; } }
        public static string MSG_CL_DeletionFailed { get { return mSG_CL_DeletionFailed; } set { value = mSG_CL_DeletionFailed; } }

        #endregion

        #region CORE STATUS APPLICATION MESSAGES

        private static string mSG_CoreStatus_WfConfigPending = "Worflow Configuration pending for this " + RenameText("clientConfigKeyLbl-program-subprocess") + "!";
        private static string mSG_CoreStatus_CoreStatusNA = RenameText("clientConfigKeyLbl-corestatus-core") + "Status is not applicable for this " + RenameText("clientConfigKeyLbl-program-subprocess") + "!";

        private static string mSG_CoreStatus_CoreStatusReasonNA = RenameText("clientConfigKeyLbl-corestatus-Status") + " Reason is not applicable for this " + RenameText("clientConfigKeyLbl-program-subprocess") + "!";


        public static string MSG_CoreStatus_WfConfigPending { get { return mSG_CoreStatus_WfConfigPending; } set { value = mSG_CoreStatus_WfConfigPending; } }
        public static string MSG_CoreStatus_CoreStatusNA { get { return mSG_CoreStatus_CoreStatusNA; } set { value = mSG_CoreStatus_CoreStatusNA; } }

        public static string MSG_CoreStatus_CoreStatusReasonNA { get { return mSG_CoreStatus_CoreStatusReasonNA; } set { value = mSG_CoreStatus_CoreStatusReasonNA; } }

        /*Core Status Creation/ Update/ Delete*/
        private static string mSG_CoreStatus_CoreStatusCreationSuccess = RenameText("clientConfigKeyLbl-corestatus-core") + "Status created successfully!";
        private static string mSG_CoreStatus_CoreStatusAlreadyExists = RenameText("clientConfigKeyLbl-corestatus-core") + "Status already exists!";
        private static string mSG_CoreStatus_CoreStatusReactivated = "Deleted " + RenameText("clientConfigKeyLbl-corestatus-core") + "Status reactivated along with the reasons, if applicable. Please check!";
        private static string mSG_CoreStatus_CoreStatusCreationFailure = RenameText("clientConfigKeyLbl-corestatus-core") + "Status creation failed!";
        private static string mSG_CoreStatus_CoreStatusUpdateSuccess = RenameText("clientConfigKeyLbl-corestatus-core") + "Status updated successfully along with the reasons, if applicable. Please check!";
        private static string mSG_CoreStatus_CoreStatusCreateAgain = "Cancel and Create the " + RenameText("clientConfigKeyLbl-corestatus-core") + "Status!";
        private static string mSG_CoreStatus_CoreStatusUpdateFailure = RenameText("clientConfigKeyLbl-corestatus-core") + "Status update failed!";
        private static string mSG_CoreStatus_CoreStatusDeleteSuccess = RenameText("clientConfigKeyLbl-corestatus-core") + "Status deleted successfully along with the " + RenameText("clientConfigKeyLbl-corestatus-Status") + " reasons, if applicable. Please check!";
        private static string mSG_CoreStatus_CoreStatusDeleteFailure = RenameText("clientConfigKeyLbl-corestatus-core") + "Status deletion failed!";



        public static string MSG_CoreStatus_CoreStatusCreationSuccess { get { return mSG_CoreStatus_CoreStatusCreationSuccess; } set { value = mSG_CoreStatus_CoreStatusCreationSuccess; } }
        public static string MSG_CoreStatus_CoreStatusAlreadyExists { get { return mSG_CoreStatus_CoreStatusAlreadyExists; } set { value = mSG_CoreStatus_CoreStatusAlreadyExists; } }
        public static string MSG_CoreStatus_CoreStatusReactivated { get { return mSG_CoreStatus_CoreStatusReactivated; } set { value = mSG_CoreStatus_CoreStatusReactivated; } }
        public static string MSG_CoreStatus_CoreStatusCreationFailure { get { return mSG_CoreStatus_CoreStatusCreationFailure; } set { value = mSG_CoreStatus_CoreStatusCreationFailure; } }
        public static string MSG_CoreStatus_CoreStatusUpdateSuccess { get { return mSG_CoreStatus_CoreStatusUpdateSuccess; } set { value = mSG_CoreStatus_CoreStatusUpdateSuccess; } }
        public static string MSG_CoreStatus_CoreStatusCreateAgain { get { return mSG_CoreStatus_CoreStatusCreateAgain; } set { value = mSG_CoreStatus_CoreStatusCreateAgain; } }
        public static string MSG_CoreStatus_CoreStatusUpdateFailure { get { return mSG_CoreStatus_CoreStatusUpdateFailure; } set { value = mSG_CoreStatus_CoreStatusUpdateFailure; } }
        public static string MSG_CoreStatus_CoreStatusDeleteSuccess { get { return mSG_CoreStatus_CoreStatusDeleteSuccess; } set { value = mSG_CoreStatus_CoreStatusDeleteSuccess; } }
        public static string MSG_CoreStatus_CoreStatusDeleteFailure { get { return mSG_CoreStatus_CoreStatusDeleteFailure; } set { value = mSG_CoreStatus_CoreStatusDeleteFailure; } }


        /*Core Status Reason Creation/ Update/ Delete*/
        private static string mSG_CoreStatus_CoreStatusReasonCreationSuccess = RenameText("clientConfigKeyLbl-corestatus-Status") + " Reason created successfully!";
        private static string mSG_CoreStatus_CoreStatusReasonAlreadyExists = RenameText("clientConfigKeyLbl-corestatus-Status") + " Reason already exists!";
        private static string mSG_CoreStatus_CoreStatusReasonReactivated = "Deleted " + RenameText("clientConfigKeyLbl-corestatus-Status") + " Reason reactivated along with the reasons. Please check!";
        private static string mSG_CoreStatus_CoreStatusReasonCreationFailure = RenameText("clientConfigKeyLbl-corestatus-Status") + " Reason creation failed!";
        private static string mSG_CoreStatus_CoreStatusReasonUpdateSuccess = RenameText("clientConfigKeyLbl-corestatus-Status") + " Reason updated successfully!";
        private static string mSG_CoreStatus_CoreStatusReasonCreateAgain = "Cancel and Create the " + RenameText("clientConfigKeyLbl-corestatus-Status") + " Reason!";
        private static string mSG_CoreStatus_CoreStatusReasonUpdateFailure = RenameText("clientConfigKeyLbl-corestatus-Status") + " Reason update failed!";
        private static string mSG_CoreStatus_CoreStatusReasonDeleteSuccess = RenameText("clientConfigKeyLbl-corestatus-Status") + " Reason deleted successfully!";
        private static string mSG_CoreStatus_CoreStatusReasonDeleteFailure = RenameText("clientConfigKeyLbl-corestatus-Status") + " Reason deletion failed!";

        public static string MSG_CoreStatus_CoreStatusReasonCreationSuccess { get { return mSG_CoreStatus_CoreStatusReasonCreationSuccess; } set { value = mSG_CoreStatus_CoreStatusReasonCreationSuccess; } }
        public static string MSG_CoreStatus_CoreStatusReasonAlreadyExists { get { return mSG_CoreStatus_CoreStatusReasonAlreadyExists; } set { value = mSG_CoreStatus_CoreStatusReasonAlreadyExists; } }
        public static string MSG_CoreStatus_CoreStatusReasonReactivated { get { return mSG_CoreStatus_CoreStatusReasonReactivated; } set { value = mSG_CoreStatus_CoreStatusReasonReactivated; } }
        public static string MSG_CoreStatus_CoreStatusReasonCreationFailure { get { return mSG_CoreStatus_CoreStatusReasonCreationFailure; } set { value = mSG_CoreStatus_CoreStatusReasonCreationFailure; } }
        public static string MSG_CoreStatus_CoreStatusReasonUpdateSuccess { get { return mSG_CoreStatus_CoreStatusReasonUpdateSuccess; } set { value = mSG_CoreStatus_CoreStatusReasonUpdateSuccess; } }
        public static string MSG_CoreStatus_CoreStatusReasonCreateAgain { get { return mSG_CoreStatus_CoreStatusReasonCreateAgain; } set { value = mSG_CoreStatus_CoreStatusReasonCreateAgain; } }
        public static string MSG_CoreStatus_CoreStatusReasonUpdateFailure { get { return mSG_CoreStatus_CoreStatusReasonUpdateFailure; } set { value = mSG_CoreStatus_CoreStatusReasonUpdateFailure; } }
        public static string MSG_CoreStatus_CoreStatusReasonDeleteSuccess { get { return mSG_CoreStatus_CoreStatusReasonDeleteSuccess; } set { value = mSG_CoreStatus_CoreStatusReasonDeleteSuccess; } }
        public static string MSG_CoreStatus_CoreStatusReasonDeleteFailure { get { return mSG_CoreStatus_CoreStatusReasonDeleteFailure; } set { value = mSG_CoreStatus_CoreStatusReasonDeleteFailure; } }


        #endregion

        #region HOLIDAY APPLICATION MESSAGES

        private static string mSG_CoreStatus_HolidayCreationSuccess = "Holiday created successfully!";
        private static string mSG_CoreStatus_HolidayAlreadyExists = "Holiday already exists!";
        private static string mSG_CoreStatus_HolidayReactivated = "Deleted Holiday reactivated!";
        private static string mSG_CoreStatus_HolidayCreationFailure = "Holiday creation failed!";
        private static string mSG_CoreStatus_HolidayUpdateSuccess = "Holiday updated successfully!";
        private static string mSG_CoreStatus_HolidayCreateAgain = "Cancel and Create the Holiday!";
        private static string mSG_CoreStatus_HolidayUpdateFailure = "Holiday update failed!";
        private static string mSG_CoreStatus_HolidayDeleteSuccess = "Holiday deleted successfully!";
        private static string mSG_CoreStatus_HolidayDeleteFailure = "Holiday deletion failed!";



        public static string MSG_CoreStatus_HolidayCreationSuccess { get { return mSG_CoreStatus_HolidayCreationSuccess; } set { value = mSG_CoreStatus_HolidayCreationSuccess; } }
        public static string MSG_CoreStatus_HolidayAlreadyExists { get { return mSG_CoreStatus_HolidayAlreadyExists; } set { value = mSG_CoreStatus_HolidayAlreadyExists; } }
        public static string MSG_CoreStatus_HolidayReactivated { get { return mSG_CoreStatus_HolidayReactivated; } set { value = mSG_CoreStatus_HolidayReactivated; } }
        public static string MSG_CoreStatus_HolidayCreationFailure { get { return mSG_CoreStatus_HolidayCreationFailure; } set { value = mSG_CoreStatus_HolidayCreationFailure; } }
        public static string MSG_CoreStatus_HolidayUpdateSuccess { get { return mSG_CoreStatus_HolidayUpdateSuccess; } set { value = mSG_CoreStatus_HolidayUpdateSuccess; } }
        public static string MSG_CoreStatus_HolidayCreateAgain { get { return mSG_CoreStatus_HolidayCreateAgain; } set { value = mSG_CoreStatus_HolidayCreateAgain; } }
        public static string MSG_CoreStatus_HolidayUpdateFailure { get { return mSG_CoreStatus_HolidayUpdateFailure; } set { value = mSG_CoreStatus_HolidayUpdateFailure; } }
        public static string MSG_CoreStatus_HolidayDeleteSuccess { get { return mSG_CoreStatus_HolidayDeleteSuccess; } set { value = mSG_CoreStatus_HolidayDeleteSuccess; } }
        public static string MSG_CoreStatus_HolidayDeleteFailure { get { return mSG_CoreStatus_HolidayDeleteFailure; } set { value = mSG_CoreStatus_HolidayDeleteFailure; } }
        #endregion

        #region USER MANAGEMENT APPLICATION MESSAGES

        private static string mSG_UserMgmt_CreationSuccess = "User added successfully!";
        private static string mSG_UserMgmt_AlreadyExists = "User already exists!";
        private static string mSG_UserMgmt_CreationFailure = "User insertion failed!";
        private static string mSG_UserMgmt_Reactivated = "User reactivated successfully!";
        private static string mSG_UserMgmt_UpdateSuccess = "User updated successfully!";
        private static string mSG_UserMgmt_UpdateFailure = "User update failed!";
        private static string mSG_UserMgmt_DeleteSuccess = "User deactivated successfully!";
        private static string mSG_UserMgmt_DeleteFailure = "User deactivation failed!";


        public static string MSG_UserMgmt_CreationSuccess { get { return mSG_UserMgmt_CreationSuccess; } set { value = mSG_UserMgmt_CreationSuccess; } }
        public static string MSG_UserMgmt_AlreadyExists { get { return mSG_UserMgmt_AlreadyExists; } set { value = mSG_UserMgmt_AlreadyExists; } }
        public static string MSG_UserMgmt_CreationFailure { get { return mSG_UserMgmt_CreationFailure; } set { value = mSG_UserMgmt_CreationFailure; } }
        public static string MSG_UserMgmt_Reactivated { get { return mSG_UserMgmt_Reactivated; } set { value = mSG_UserMgmt_Reactivated; } }
        public static string MSG_UserMgmt_UpdateSuccess { get { return mSG_UserMgmt_UpdateSuccess; } set { value = mSG_UserMgmt_UpdateSuccess; } }
        public static string MSG_UserMgmt_UpdateFailure { get { return mSG_UserMgmt_UpdateFailure; } set { value = mSG_UserMgmt_UpdateFailure; } }
        public static string MSG_UserMgmt_DeleteSuccess { get { return mSG_UserMgmt_DeleteSuccess; } set { value = mSG_UserMgmt_DeleteSuccess; } }
        public static string MSG_UserMgmt_DeleteFailure { get { return mSG_UserMgmt_DeleteFailure; } set { value = mSG_UserMgmt_DeleteFailure; } }


        private static string mSG_UserMgmt_RoleMappingSuccess = "User role mapped successfully!";
        private static string mSG_UserMgmt_RoleMappingFailure = "User role mapping failed";
        private static string mSG_UserMgmt_SameUserRoleMappingFailure = "Master calibrator and calibrator role can not be assigned to same user\n";
        private static string mSG_UserMgmt_RoleMappingDeleteSuccess = "User role mapping deleted successfully!";
        private static string mSG_UserMgmt_RoleMappingNOTExists = "No user role mapping exists";
        private static string mSG_UserMgmt_RoleMappingDeleteFailure = "User role mapping delete failed";

        private static string mSG_UserMgmt_RoleMappingPermSuccess = "Role permission mapped successfully!";
        private static string mSG_UserMgmt_RoleMappingPermFailure = "Role permission failed";
        private static string mSG_UserMgmt_RoleMappingPermNOTExists = "No role permission exists";

        private static string mSG_UserMgmt_GroupUserMappingCreationSuccess = "User grouped successfully!";
        private static string mSG_UserMgmt_GroupUserCreationSuccess = "User group created successfully!";
        private static string mSG_UserMgmt_GroupUserAlreadyExists = "User group already exists";
        private static string mSG_UserMgmt_GroupUserCreationFailure = "User group insertion failed";
        private static string mSG_UserMgmt_GroupUserUpdateSuccess = "User group updated successfully!";
        private static string mSG_UserMgmt_GroupUserUpdateFailure = "User group update failed";
        private static string mSG_UserMgmt_GroupUserEffectiveToDt = "Please check the effective period of the selected program";
        private static string mSG_UserMgmt_ProcessEffectiveToDt = "User Group Effective To Date must be greater than Effective to Date of the mapped processes";
        private static string mSG_UserMgmt_SubProcessEffectiveToDt = "User Group Effective To Date must be greater than Effective to Date of the mapped " + RenameText("clientConfigKeyLbl-program-subprocess");
        private static string mSG_UserMgmt_SubProcess = RenameText("clientConfigKeyLbl-program-subprocess") + " exist for below user group";

        private static string mSG_UserConfigMapping_CreationSuccess = "User mapping added successfully!";
        private static string mSG_UserConfigMapping_AlreadyExists = "User mapping already exists";
        private static string mSG_UserConfigMapping_CreationFailure = "User mapping insertion failed";
        private static string mSG_UserConfigMapping_UpdateSuccess = "User mapping updated successfully!";
        private static string mSG_UserConfigMapping_UpdateFailure = "User mapping update failed ";
        private static string mSG_UserConfigMapping_CreationFailureReason = "User mapping insertion failed as User does not exists in the system";
        private static string mSG_UserConfigMapping_CreationFailureReason2 = "User mapping insertion failed as User is inactive in the system";
        private static string mSG_UserConfigMapping_ReactivatedSuccess = "User mapping Reactivated!";
        private static string mSG_UserConfigMapping_DeactivatedSuccess = "User mapping Deactivated!";
        private static string mSG_UserConfigMapping_ProgramFeatures_Not_Exists = "Program Features is not yet configured!";



        public static string MSG_UserMgmt_RoleMappingSuccess { get { return mSG_UserMgmt_RoleMappingSuccess; } set { value = mSG_UserMgmt_RoleMappingSuccess; } }
        public static string MSG_UserMgmt_RoleMappingFailure { get { return mSG_UserMgmt_RoleMappingFailure; } set { value = mSG_UserMgmt_RoleMappingFailure; } }
        public static string MSG_UserMgmt_RoleMappingDeleteSuccess { get { return mSG_UserMgmt_RoleMappingDeleteSuccess; } set { value = mSG_UserMgmt_RoleMappingDeleteSuccess; } }
        public static string MSG_UserMgmt_RoleMappingNOTExists { get { return mSG_UserMgmt_RoleMappingNOTExists; } set { value = mSG_UserMgmt_RoleMappingNOTExists; } }
        public static string MSG_UserMgmt_RoleMappingDeleteFailure { get { return mSG_UserMgmt_RoleMappingDeleteFailure; } set { value = mSG_UserMgmt_RoleMappingDeleteFailure; } }
        public static string MSG_UserMgmt_SameUserRoleMappingFailure { get { return mSG_UserMgmt_SameUserRoleMappingFailure; } set { value = mSG_UserMgmt_SameUserRoleMappingFailure; } }

        public static string MSG_UserMgmt_RoleMappingPermSuccess { get { return mSG_UserMgmt_RoleMappingPermSuccess; } set { value = mSG_UserMgmt_RoleMappingPermSuccess; } }
        public static string MSG_UserMgmt_RoleMappingPermFailure { get { return mSG_UserMgmt_RoleMappingPermFailure; } set { value = mSG_UserMgmt_RoleMappingPermFailure; } }
        public static string MSG_UserMgmt_RoleMappingPermNOTExists { get { return mSG_UserMgmt_RoleMappingPermNOTExists; } set { value = mSG_UserMgmt_RoleMappingPermNOTExists; } }

        public static string MSG_UserMgmt_GroupUserMappingCreationSuccess { get { return mSG_UserMgmt_GroupUserMappingCreationSuccess; } set { value = mSG_UserMgmt_GroupUserMappingCreationSuccess; } }
        public static string MSG_UserMgmt_GroupUserCreationSuccess { get { return mSG_UserMgmt_GroupUserCreationSuccess; } set { value = mSG_UserMgmt_GroupUserCreationSuccess; } }
        public static string MSG_UserMgmt_GroupUserAlreadyExists { get { return mSG_UserMgmt_GroupUserAlreadyExists; } set { value = mSG_UserMgmt_GroupUserAlreadyExists; } }
        public static string MSG_UserMgmt_GroupUserCreationFailure { get { return mSG_UserMgmt_GroupUserCreationFailure; } set { value = mSG_UserMgmt_GroupUserCreationFailure; } }
        public static string MSG_UserMgmt_GroupUserUpdateSuccess { get { return mSG_UserMgmt_GroupUserUpdateSuccess; } set { value = mSG_UserMgmt_GroupUserUpdateSuccess; } }
        public static string MSG_UserMgmt_GroupUserUpdateFailure { get { return mSG_UserMgmt_GroupUserUpdateFailure; } set { value = mSG_UserMgmt_GroupUserUpdateFailure; } }
        public static string MSG_UserMgmt_GroupUserEffectiveToDt { get { return mSG_UserMgmt_GroupUserEffectiveToDt; } set { value = mSG_UserMgmt_GroupUserEffectiveToDt; } }
        public static string MSG_UserMgmt_ProcessEffectiveToDt { get { return mSG_UserMgmt_ProcessEffectiveToDt; } set { value = mSG_UserMgmt_ProcessEffectiveToDt; } }
        public static string MSG_UserMgmt_SubProcessEffectiveToDt { get { return mSG_UserMgmt_SubProcessEffectiveToDt; } set { value = mSG_UserMgmt_SubProcessEffectiveToDt; } }
        public static string MSG_UserMgmt_SubProcess { get { return mSG_UserMgmt_SubProcess; } set { value = mSG_UserMgmt_SubProcess; } }

        public static string MSG_UserConfigMapping_CreationSuccess { get { return mSG_UserConfigMapping_CreationSuccess; } set { value = mSG_UserConfigMapping_CreationSuccess; } }
        public static string MSG_UserConfigMapping_AlreadyExists { get { return mSG_UserConfigMapping_AlreadyExists; } set { value = mSG_UserConfigMapping_AlreadyExists; } }
        public static string MSG_UserConfigMapping_CreationFailure { get { return mSG_UserConfigMapping_CreationFailure; } set { value = mSG_UserConfigMapping_CreationFailure; } }
        public static string MSG_UserConfigMapping_UpdateSuccess { get { return mSG_UserConfigMapping_UpdateSuccess; } set { value = mSG_UserConfigMapping_UpdateSuccess; } }
        public static string MSG_UserConfigMapping_UpdateFailure { get { return mSG_UserConfigMapping_UpdateFailure; } set { value = mSG_UserConfigMapping_UpdateFailure; } }
        public static string MSG_UserConfigMapping_CreationFailureReason { get { return mSG_UserConfigMapping_CreationFailureReason; } set { value = mSG_UserConfigMapping_CreationFailureReason; } }
        public static string MSG_UserConfigMapping_CreationFailureReason2 { get { return mSG_UserConfigMapping_CreationFailureReason2; } set { value = mSG_UserConfigMapping_CreationFailureReason2; } }
        public static string MSG_UserConfigMapping_ReactivatedSuccess { get { return mSG_UserConfigMapping_ReactivatedSuccess; } set { value = mSG_UserConfigMapping_ReactivatedSuccess; } }
        public static string MSG_UserConfigMapping_DeactivatedSuccess { get { return mSG_UserConfigMapping_DeactivatedSuccess; } set { value = mSG_UserConfigMapping_DeactivatedSuccess; } }
        public static string MSG_UserConfigMapping_ProgramFeatures_Not_Exists { get { return mSG_UserConfigMapping_ProgramFeatures_Not_Exists; } set { value = mSG_UserConfigMapping_ProgramFeatures_Not_Exists; } }

        #endregion

        #region  DEFECTOPPORTUNITY MESSAGES

        private static string mSG_DO_Category_CreationSuccess = "Category Created Successfully!";
        private static string mSG_DO_Category_AlreadyExists = "Category Already Exists!";
        private static string mSG_DO_Category_CreationFailure = "Category Insertion Failed!";
        private static string mSG_DO_Category_Cannot_Delete = "Category cannot be deleted as it is mapped with active transaction!";
        private static string mSG_DO_Category_Reactivation = "Deleted Category Reactivated Successfully!";

        private static string mSG_DO_Category_UpdateSuccess = "Category Updated Successfully!";
        private static string mSG_DO_Category_UpdateFailure = "Category Update Failed!";
        private static string mSG_DO_Category_UpdateReactivation = "Cancel and Create the Category!";
        private static string mSG_DO_Category_DeleteSuccess = "Category Deleted Successfully!";
        private static string mSG_DO_Category_DeleteFailed = "Category Deletion Failed!";

        private static string mSG_DO_Heading_CreationSuccess = "Heading Created Successfully!";
        private static string mSG_DO_Heading_AlreadyExists = "Heading Already Exists!";
        private static string mSG_DO_Heading_CreationFailure = "Heading Insertion Failed!";
        private static string mSG_DO_Heading_Reactivation = "Deleted Heading Reactivated Successfully!";

        private static string mSG_DO_Heading_UpdateSuccess = "Heading Updated Successfully!";
        private static string mSG_DO_Heading_UpdateFailure = "Heading Update Failed!";
        private static string mSG_DO_Heading_UpdateReactivation = "Kindly Cancel and Create the Heading!";
        private static string mSG_DO_Heading_DeleteSuccess = "Heading Deleted Successfully!";
        private static string mSG_DO_Heading_DeleteFailed = "Heading Deletion Failed!";

        private static string mSG_DO_CTQGroup_CreationSuccess = "CTQ Group Created Successfully!";
        private static string mSG_DO_CTQGroup_AlreadyExists = "CTQ Group Already Exists!";
        private static string mSG_DO_CTQGroup_CreationFailure = "CTQ Group Insertion Failed!";
        private static string mSG_DO_CTQGroup_Reactivation = "Deleted CTQ Group Reactivated Successfully!";
        private static string mSG_DO_CTQGroup_Cannot_Delete = "CTQGroup cannot be deleted as CTQ is mapped to it!";

        private static string mSG_DO_CTQGroup_UpdateSuccess = "CTQ Group Updated Successfully!";
        private static string mSG_DO_CTQGroup_UpdateFailure = "CTQ Group Update Failed!";
        private static string mSG_DO_CTQGroup_UpdateReactivation = "Kindly Cancel and Create the CTQ Group!";
        private static string mSG_DO_CTQGroup_DeleteSuccess = "CTQ Group Deleted Successfully!";
        private static string mSG_DO_CTQGroup_DeleteFailed = "CTQ Group Deletion Failed!";



        public static string MSG_DO_Category_CreationSuccess { get { return mSG_DO_Category_CreationSuccess; } set { value = mSG_DO_Category_CreationSuccess; } }
        public static string MSG_DO_Category_AlreadyExists { get { return mSG_DO_Category_AlreadyExists; } set { value = mSG_DO_Category_AlreadyExists; } }
        public static string MSG_DO_Category_CreationFailure { get { return mSG_DO_Category_CreationFailure; } set { value = mSG_DO_Category_CreationFailure; } }
        public static string MSG_DO_Category_Cannot_Delete { get { return mSG_DO_Category_Cannot_Delete; } set { value = mSG_DO_Category_Cannot_Delete; } }
        public static string MSG_DO_Category_Reactivation { get { return mSG_DO_Category_Reactivation; } set { value = mSG_DO_Category_Reactivation; } }

        public static string MSG_DO_Category_UpdateSuccess { get { return mSG_DO_Category_UpdateSuccess; } set { value = mSG_DO_Category_UpdateSuccess; } }
        public static string MSG_DO_Category_UpdateFailure { get { return mSG_DO_Category_UpdateFailure; } set { value = mSG_DO_Category_UpdateFailure; } }
        public static string MSG_DO_Category_UpdateReactivation { get { return mSG_DO_Category_UpdateReactivation; } set { value = mSG_DO_Category_UpdateReactivation; } }
        public static string MSG_DO_Category_DeleteSuccess { get { return mSG_DO_Category_DeleteSuccess; } set { value = mSG_DO_Category_DeleteSuccess; } }
        public static string MSG_DO_Category_DeleteFailed { get { return mSG_DO_Category_DeleteFailed; } set { value = mSG_DO_Category_DeleteFailed; } }

        public static string MSG_DO_Heading_CreationSuccess { get { return mSG_DO_Heading_CreationSuccess; } set { value = mSG_DO_Heading_CreationSuccess; } }
        public static string MSG_DO_Heading_AlreadyExists { get { return mSG_DO_Heading_AlreadyExists; } set { value = mSG_DO_Heading_AlreadyExists; } }
        public static string MSG_DO_Heading_CreationFailure { get { return mSG_DO_Heading_CreationFailure; } set { value = mSG_DO_Heading_CreationFailure; } }
        public static string MSG_DO_Heading_Reactivation { get { return mSG_DO_Heading_Reactivation; } set { value = mSG_DO_Heading_Reactivation; } }

        public static string MSG_DO_Heading_UpdateSuccess { get { return mSG_DO_Heading_UpdateSuccess; } set { value = mSG_DO_Heading_UpdateSuccess; } }
        public static string MSG_DO_Heading_UpdateFailure { get { return mSG_DO_Heading_UpdateFailure; } set { value = mSG_DO_Heading_UpdateFailure; } }
        public static string MSG_DO_Heading_UpdateReactivation { get { return mSG_DO_Heading_UpdateReactivation; } set { value = mSG_DO_Heading_UpdateReactivation; } }
        public static string MSG_DO_Heading_DeleteSuccess { get { return mSG_DO_Heading_DeleteSuccess; } set { value = mSG_DO_Heading_DeleteSuccess; } }
        public static string MSG_DO_Heading_DeleteFailed { get { return mSG_DO_Heading_DeleteFailed; } set { value = mSG_DO_Heading_DeleteFailed; } }

        public static string MSG_DO_CTQGroup_CreationSuccess { get { return mSG_DO_CTQGroup_CreationSuccess; } set { value = mSG_DO_CTQGroup_CreationSuccess; } }
        public static string MSG_DO_CTQGroup_AlreadyExists { get { return mSG_DO_CTQGroup_AlreadyExists; } set { value = mSG_DO_CTQGroup_AlreadyExists; } }
        public static string MSG_DO_CTQGroup_CreationFailure { get { return mSG_DO_CTQGroup_CreationFailure; } set { value = mSG_DO_CTQGroup_CreationFailure; } }
        public static string MSG_DO_CTQGroup_Reactivation { get { return mSG_DO_CTQGroup_Reactivation; } set { value = mSG_DO_CTQGroup_Reactivation; } }
        public static string MSG_DO_CTQGroup_Cannot_Delete { get { return mSG_DO_CTQGroup_Cannot_Delete; } set { value = mSG_DO_CTQGroup_Cannot_Delete; } }

        public static string MSG_DO_CTQGroup_UpdateSuccess { get { return mSG_DO_CTQGroup_UpdateSuccess; } set { value = mSG_DO_CTQGroup_UpdateSuccess; } }
        public static string MSG_DO_CTQGroup_UpdateFailure { get { return mSG_DO_CTQGroup_UpdateFailure; } set { value = mSG_DO_CTQGroup_UpdateFailure; } }
        public static string MSG_DO_CTQGroup_UpdateReactivation { get { return mSG_DO_CTQGroup_UpdateReactivation; } set { value = mSG_DO_CTQGroup_UpdateReactivation; } }
        public static string MSG_DO_CTQGroup_DeleteSuccess { get { return mSG_DO_CTQGroup_DeleteSuccess; } set { value = mSG_DO_CTQGroup_DeleteSuccess; } }
        public static string MSG_DO_CTQGroup_DeleteFailed { get { return mSG_DO_CTQGroup_DeleteFailed; } set { value = mSG_DO_CTQGroup_DeleteFailed; } }


        private static string mSG_DO_Checkpoint_CreationSuccess = RenameText("clientConfigKeyLbl-qparameter-checkpoint") + " Created Successfully!";
        private static string mSG_DO_Checkpoint_AlreadyExists = RenameText("clientConfigKeyLbl-qparameter-checkpoint") + " Already Exists!";
        private static string mSG_DO_Checkpoint_CreationFailure = RenameText("clientConfigKeyLbl-qparameter-checkpoint") + " Insertion Failed!";
        private static string mSG_DO_Checkpoint_Reactivation = "Deleted " + RenameText("clientConfigKeyLbl-qparameter-checkpoint") + " Reactivated Successfully!";

        private static string mSG_DO_Checkpoint_UpdateSuccess = RenameText("clientConfigKeyLbl-qparameter-checkpoint") + " Updated Successfully!";
        private static string mSG_DO_Checkpoint_UpdateFailure = RenameText("clientConfigKeyLbl-qparameter-checkpoint") + " Update Failed!";
        private static string mSG_DO_Checkpoint_UpdateReactivation = "Cancel and Create the " + RenameText("clientConfigKeyLbl-qparameter-checkpoint") + "!";
        private static string mSG_DO_Checkpoint_DeleteSuccess = RenameText("clientConfigKeyLbl-qparameter-checkpoint") + " Deleted Successfully!";
        private static string mSG_DO_Checkpoint_DeleteFailed = RenameText("clientConfigKeyLbl-qparameter-checkpoint") + " Deletion Failed!";

        private static string mSG_DO_Weightage_CreationSuccess = "Weightage Created Successfully!";
        private static string mSG_DO_Weightage_AlreadyExists = "Weightage Already Exists!";
        private static string mSG_DO_Weightage_CreationFailure = "Weightage Insertion Failed!";

        private static string mSG_DO_CopyCTQ_CreationSuccess = RenameText("clientConfigKeyLbl-qparameter-checkpoint") + " Copied Successfully!";

        private static string mSG_DO_Weightage_UpdateSuccess = "Weightage Updated Successfully!";
        private static string mSG_DO_Weightage_UpdateFailure = "Weightage Update Failed!";

        private static string mSG_DO_subdefect1_CreationSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect1") + " Created Successfully!";
        private static string mSG_DO_subdefect1_AlreadyExists = RenameText("clientConfigKeyLbl-subdefects-subdefect1") + " Already Exists!";
        private static string mSG_DO_subdefect1_CreationFailure = RenameText("clientConfigKeyLbl-subdefects-subdefect1") + " Insertion Failed!";
        private static string mSG_DO_subdefect1_Reactivation = "Deleted " + RenameText("clientConfigKeyLbl-subdefects-subdefect1") + " Reactivated Successfully!";

        private static string mSG_DO_subdefect1_UpdateSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect1") + " Updated Successfully!";
        private static string mSG_DO_subdefect1_UpdateFailure = RenameText("clientConfigKeyLbl-subdefects-subdefect1") + " Update Failed!";
        private static string mSG_DO_subdefect1_UpdateReactivation = "Cancel and Create the " + RenameText("clientConfigKeyLbl-subdefects-subdefect1") + "!";
        private static string mSG_DO_subdefect1_DeleteSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect1") + " Deleted Successfully!";
        private static string mSG_DO_subdefect1_DeleteFailed = RenameText("clientConfigKeyLbl-subdefects-subdefect1") + " Deletion Failed!";



        private static string mSG_DO_subdefect2_CreationSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect2") + " Created Successfully!";
        private static string mSG_DO_subdefect2_AlreadyExists = RenameText("clientConfigKeyLbl-subdefects-subdefect2") + " Already Exists!";
        private static string mSG_DO_subdefect2_CreationFailure = RenameText("clientConfigKeyLbl-subdefects-subdefect2") + " Insertion Failed!";
        private static string mSG_DO_subdefect2_Reactivation = "Deleted " + RenameText("clientConfigKeyLbl-subdefects-subdefect2") + " Reactivated Successfully!";

        private static string mSG_DO_subdefect2_UpdateSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect2") + " Updated Successfully!";
        private static string mSG_DO_subdefect2_UpdateFailure = RenameText("clientConfigKeyLbl-subdefects-subdefect2") + " Update Failed!";
        private static string mSG_DO_subdefect2_UpdateReactivation = "Cancel and Create the " + RenameText("clientConfigKeyLbl-subdefects-subdefect2") + "!";
        private static string mSG_DO_subdefect2_DeleteSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect2") + " Deleted Successfully!";
        private static string mSG_DO_subdefect2_DeleteFailed = RenameText("clientConfigKeyLbl-subdefects-subdefect2") + " Deletion Failed!";


        private static string mSG_DO_subdefect3_CreationSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect3") + " Created Successfully!";
        private static string mSG_DO_subdefect3_AlreadyExists = RenameText("clientConfigKeyLbl-subdefects-subdefect3") + " Already Exists!";
        private static string mSG_DO_subdefect3_CreationFailure = RenameText("clientConfigKeyLbl-subdefects-subdefect3") + " Insertion Failed!";
        private static string mSG_DO_subdefect3_Reactivation = "Deleted " + RenameText("clientConfigKeyLbl-subdefects-subdefect3") + " Reactivated Successfully!";

        private static string mSG_DO_subdefect3_UpdateSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect3") + " Updated Successfully!";
        private static string mSG_DO_subdefect3_UpdateFailure = RenameText("clientConfigKeyLbl-subdefects-subdefect3") + " Update Failed!";
        private static string mSG_DO_subdefect3_UpdateReactivation = "Cancel and Create the " + RenameText("clientConfigKeyLbl-subdefects-subdefect3") + "!";
        private static string mSG_DO_subdefect3_DeleteSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect3") + " Deleted Successfully!";
        private static string mSG_DO_subdefect3_DeleteFailed = RenameText("clientConfigKeyLbl-subdefects-subdefect3") + " Deletion Failed!";


        private static string mSG_DO_subdefect4_CreationSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect4") + " Created Successfully!";
        private static string mSG_DO_subdefect4_AlreadyExists = RenameText("clientConfigKeyLbl-subdefects-subdefect4") + " Already Exists!";
        private static string mSG_DO_subdefect4_CreationFailure = RenameText("clientConfigKeyLbl-subdefects-subdefect4") + " Insertion Failed!";
        private static string mSG_DO_subdefect4_Reactivation = "Deleted " + RenameText("clientConfigKeyLbl-subdefects-subdefect4") + " Reactivated Successfully!";

        private static string mSG_DO_subdefect4_UpdateSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect4") + " Updated Successfully!";
        private static string mSG_DO_subdefect4_UpdateFailure = RenameText("clientConfigKeyLbl-subdefects-subdefect4") + " Update Failed!";
        private static string mSG_DO_subdefect4_UpdateReactivation = "Cancel and Create the " + RenameText("clientConfigKeyLbl-subdefects-subdefect4") + "!";
        private static string mSG_DO_subdefect4_DeleteSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect4") + " Deleted Successfully!";
        private static string mSG_DO_subdefect4_DeleteFailed = RenameText("clientConfigKeyLbl-subdefects-subdefect4") + " Deletion Failed!";

        private static string mSG_DO_subdefect5_CreationSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect5") + " Created Successfully!";
        private static string mSG_DO_subdefect5_AlreadyExists = RenameText("clientConfigKeyLbl-subdefects-subdefect5") + " Already Exists!";
        private static string mSG_DO_subdefect5_CreationFailure = RenameText("clientConfigKeyLbl-subdefects-subdefect5") + " Insertion Failed!";
        private static string mSG_DO_subdefect5_Reactivation = "Deleted " + RenameText("clientConfigKeyLbl-subdefects-subdefect5") + " Reactivated Successfully!";

        private static string mSG_DO_subdefect5_UpdateSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect5") + " Updated Successfully!";
        private static string mSG_DO_subdefect5_UpdateFailure = RenameText("clientConfigKeyLbl-subdefects-subdefect5") + " Update Failed!";
        private static string mSG_DO_subdefect5_UpdateReactivation = "Cancel and Create the " + RenameText("clientConfigKeyLbl-subdefects-subdefect5") + "!";
        private static string mSG_DO_subdefect5_DeleteSuccess = RenameText("clientConfigKeyLbl-subdefects-subdefect5") + " Deleted Successfully!";
        private static string mSG_DO_subdefect5_DeleteFailed = RenameText("clientConfigKeyLbl-subdefects-subdefect5") + " Deletion Failed!";



        public static string MSG_DO_Checkpoint_CreationSuccess { get { return mSG_DO_Checkpoint_CreationSuccess; } set { value = mSG_DO_Checkpoint_CreationSuccess; } }
        public static string MSG_DO_Checkpoint_AlreadyExists { get { return mSG_DO_Checkpoint_AlreadyExists; } set { value = mSG_DO_Checkpoint_AlreadyExists; } }
        public static string MSG_DO_Checkpoint_CreationFailure { get { return mSG_DO_Checkpoint_CreationFailure; } set { value = mSG_DO_Checkpoint_CreationFailure; } }
        public static string MSG_DO_Checkpoint_Reactivation { get { return mSG_DO_Checkpoint_Reactivation; } set { value = mSG_DO_Checkpoint_Reactivation; } }

        public static string MSG_DO_Checkpoint_UpdateSuccess { get { return mSG_DO_Checkpoint_UpdateSuccess; } set { value = mSG_DO_Checkpoint_UpdateSuccess; } }
        public static string MSG_DO_Checkpoint_UpdateFailure { get { return mSG_DO_Checkpoint_UpdateFailure; } set { value = mSG_DO_Checkpoint_UpdateFailure; } }
        public static string MSG_DO_Checkpoint_UpdateReactivation { get { return mSG_DO_Checkpoint_Reactivation; } set { value = mSG_DO_Checkpoint_Reactivation; } }
        public static string MSG_DO_Checkpoint_DeleteSuccess { get { return mSG_DO_Checkpoint_DeleteSuccess; } set { value = mSG_DO_Checkpoint_DeleteSuccess; } }
        public static string MSG_DO_Checkpoint_DeleteFailed { get { return mSG_DO_Checkpoint_DeleteFailed; } set { value = mSG_DO_Checkpoint_DeleteFailed; } }

        public static string MSG_DO_Weightage_CreationSuccess { get { return mSG_DO_Weightage_CreationSuccess; } set { value = mSG_DO_Weightage_CreationSuccess; } }
        public static string MSG_DO_Weightage_AlreadyExists { get { return mSG_DO_Weightage_AlreadyExists; } set { value = mSG_DO_Weightage_AlreadyExists; } }
        public static string MSG_DO_Weightage_CreationFailure { get { return mSG_DO_Weightage_CreationFailure; } set { value = mSG_DO_Weightage_CreationFailure; } }

        public static string MSG_DO_CopyCTQ_CreationSuccess { get { return mSG_DO_CopyCTQ_CreationSuccess; } set { value = mSG_DO_CopyCTQ_CreationSuccess; } }

        public static string MSG_DO_Weightage_UpdateSuccess { get { return mSG_DO_Weightage_UpdateSuccess; } set { value = mSG_DO_Weightage_UpdateSuccess; } }
        public static string MSG_DO_Weightage_UpdateFailure { get { return mSG_DO_Weightage_UpdateFailure; } set { value = mSG_DO_Weightage_UpdateFailure; } }

        public static string MSG_DO_subdefect1_CreationSuccess { get { return mSG_DO_subdefect1_CreationSuccess; } set { value = mSG_DO_subdefect1_CreationSuccess; } }
        public static string MSG_DO_subdefect1_AlreadyExists { get { return mSG_DO_subdefect1_AlreadyExists; } set { value = mSG_DO_subdefect1_AlreadyExists; } }
        public static string MSG_DO_subdefect1_CreationFailure { get { return mSG_DO_subdefect1_CreationFailure; } set { value = mSG_DO_subdefect1_CreationFailure; } }
        public static string MSG_DO_subdefect1_Reactivation { get { return mSG_DO_subdefect1_Reactivation; } set { value = mSG_DO_subdefect1_Reactivation; } }

        public static string MSG_DO_subdefect1_UpdateSuccess { get { return mSG_DO_subdefect1_UpdateSuccess; } set { value = mSG_DO_subdefect1_UpdateSuccess; } }
        public static string MSG_DO_subdefect1_UpdateFailure { get { return mSG_DO_subdefect1_UpdateFailure; } set { value = mSG_DO_subdefect1_UpdateFailure; } }
        public static string MSG_DO_subdefect1_UpdateReactivation { get { return mSG_DO_subdefect1_UpdateReactivation; } set { value = mSG_DO_subdefect1_UpdateReactivation; } }
        public static string MSG_DO_subdefect1_DeleteSuccess { get { return mSG_DO_subdefect1_DeleteSuccess; } set { value = mSG_DO_subdefect1_DeleteSuccess; } }
        public static string MSG_DO_subdefect1_DeleteFailed { get { return mSG_DO_subdefect2_DeleteFailed; } set { value = mSG_DO_subdefect2_DeleteFailed; } }



        public static string MSG_DO_subdefect2_CreationSuccess { get { return mSG_DO_subdefect2_CreationSuccess; } set { value = mSG_DO_subdefect2_CreationSuccess; } }
        public static string MSG_DO_subdefect2_AlreadyExists { get { return mSG_DO_subdefect2_AlreadyExists; } set { value = mSG_DO_subdefect2_AlreadyExists; } }
        public static string MSG_DO_subdefect2_CreationFailure { get { return mSG_DO_subdefect2_CreationFailure; } set { value = mSG_DO_subdefect2_CreationFailure; } }
        public static string MSG_DO_subdefect2_Reactivation { get { return mSG_DO_subdefect2_Reactivation; } set { value = mSG_DO_subdefect2_Reactivation; } }

        public static string MSG_DO_subdefect2_UpdateSuccess { get { return mSG_DO_subdefect2_UpdateSuccess; } set { value = mSG_DO_subdefect2_UpdateSuccess; } }
        public static string MSG_DO_subdefect2_UpdateFailure { get { return mSG_DO_subdefect2_UpdateFailure; } set { value = mSG_DO_subdefect2_UpdateFailure; } }
        public static string MSG_DO_subdefect2_UpdateReactivation { get { return mSG_DO_subdefect2_UpdateReactivation; } set { value = mSG_DO_subdefect2_UpdateReactivation; } }
        public static string MSG_DO_subdefect2_DeleteSuccess { get { return mSG_DO_subdefect2_DeleteSuccess; } set { value = mSG_DO_subdefect2_DeleteSuccess; } }
        public static string MSG_DO_subdefect2_DeleteFailed { get { return mSG_DO_subdefect2_DeleteFailed; } set { value = mSG_DO_subdefect2_DeleteFailed; } }

        public static string MSG_DO_subdefect3_CreationSuccess { get { return mSG_DO_subdefect3_CreationSuccess; } set { value = mSG_DO_subdefect3_CreationSuccess; } }
        public static string MSG_DO_subdefect3_AlreadyExists { get { return mSG_DO_subdefect3_AlreadyExists; } set { value = mSG_DO_subdefect3_AlreadyExists; } }
        public static string MSG_DO_subdefect3_CreationFailure { get { return mSG_DO_subdefect3_CreationFailure; } set { value = mSG_DO_subdefect3_CreationFailure; } }
        public static string MSG_DO_subdefect3_Reactivation { get { return mSG_DO_subdefect3_Reactivation; } set { value = mSG_DO_subdefect3_Reactivation; } }


        public static string MSG_DO_subdefect3_UpdateSuccess { get { return mSG_DO_subdefect3_UpdateSuccess; } set { value = mSG_DO_subdefect3_UpdateSuccess; } }
        public static string MSG_DO_subdefect3_UpdateFailure { get { return mSG_DO_subdefect3_UpdateFailure; } set { value = mSG_DO_subdefect3_UpdateFailure; } }
        public static string MSG_DO_subdefect3_UpdateReactivation { get { return mSG_DO_subdefect3_UpdateReactivation; } set { value = mSG_DO_subdefect3_UpdateReactivation; } }
        public static string MSG_DO_subdefect3_DeleteSuccess { get { return mSG_DO_subdefect3_DeleteSuccess; } set { value = mSG_DO_subdefect3_DeleteSuccess; } }
        public static string MSG_DO_subdefect3_DeleteFailed { get { return mSG_DO_subdefect3_DeleteFailed; } set { value = mSG_DO_subdefect3_DeleteFailed; } }


        public static string MSG_DO_subdefect4_CreationSuccess { get { return mSG_DO_subdefect4_CreationSuccess; } set { value = mSG_DO_subdefect4_CreationSuccess; } }
        public static string MSG_DO_subdefect4_AlreadyExists { get { return mSG_DO_subdefect4_AlreadyExists; } set { value = mSG_DO_subdefect4_AlreadyExists; } }
        public static string MSG_DO_subdefect4_CreationFailure { get { return mSG_DO_subdefect4_CreationFailure; } set { value = mSG_DO_subdefect4_CreationFailure; } }
        public static string MSG_DO_subdefect4_Reactivation { get { return mSG_DO_subdefect4_Reactivation; } set { value = mSG_DO_subdefect4_Reactivation; } }


        public static string MSG_DO_subdefect4_UpdateSuccess { get { return mSG_DO_subdefect4_UpdateSuccess; } set { value = mSG_DO_subdefect4_UpdateSuccess; } }
        public static string MSG_DO_subdefect4_UpdateFailure { get { return mSG_DO_subdefect4_UpdateFailure; } set { value = mSG_DO_subdefect4_UpdateFailure; } }
        public static string MSG_DO_subdefect4_UpdateReactivation { get { return mSG_DO_subdefect4_UpdateReactivation; } set { value = mSG_DO_subdefect4_UpdateReactivation; } }
        public static string MSG_DO_subdefect4_DeleteSuccess { get { return mSG_DO_subdefect4_DeleteSuccess; } set { value = mSG_DO_subdefect4_DeleteSuccess; } }
        public static string MSG_DO_subdefect4_DeleteFailed { get { return mSG_DO_subdefect4_DeleteFailed; } set { value = mSG_DO_subdefect4_DeleteFailed; } }

        public static string MSG_DO_subdefect5_CreationSuccess { get { return mSG_DO_subdefect5_CreationSuccess; } set { value = mSG_DO_subdefect5_CreationSuccess; } }
        public static string MSG_DO_subdefect5_AlreadyExists { get { return mSG_DO_subdefect5_AlreadyExists; } set { value = mSG_DO_subdefect5_AlreadyExists; } }
        public static string MSG_DO_subdefect5_CreationFailure { get { return mSG_DO_subdefect5_CreationFailure; } set { value = mSG_DO_subdefect5_CreationFailure; } }
        public static string MSG_DO_subdefect5_Reactivation { get { return mSG_DO_subdefect5_Reactivation; } set { value = mSG_DO_subdefect5_Reactivation; } }


        public static string MSG_DO_subdefect5_UpdateSuccess { get { return mSG_DO_subdefect5_UpdateSuccess; } set { value = mSG_DO_subdefect5_UpdateSuccess; } }
        public static string MSG_DO_subdefect5_UpdateFailure { get { return mSG_DO_subdefect5_UpdateFailure; } set { value = mSG_DO_subdefect5_UpdateFailure; } }
        public static string MSG_DO_subdefect5_UpdateReactivation { get { return mSG_DO_subdefect5_UpdateReactivation; } set { value = mSG_DO_subdefect5_UpdateReactivation; } }
        public static string MSG_DO_subdefect5_DeleteSuccess { get { return mSG_DO_subdefect5_DeleteSuccess; } set { value = mSG_DO_subdefect5_DeleteSuccess; } }
        public static string MSG_DO_subdefect5_DeleteFailed { get { return mSG_DO_subdefect5_DeleteFailed; } set { value = mSG_DO_subdefect5_DeleteFailed; } }


        #endregion

        #region  SUBPROCESS MESSAGES

        private static string mSG_SB_CreationSuccess = RenameText("clientConfigKeyLbl-program-subprocess") + " Created Successfully!";
        private static string mSG_SB_AlreadyExists = RenameText("clientConfigKeyLbl-program-subprocess") + " Already Exists!";
        private static string mSG_SB_CreationFailure = RenameText("clientConfigKeyLbl-program-subprocess") + " Insertion Failed!";
        private static string mSG_SB_Reactivation = "Deleted " + RenameText("clientConfigKeyLbl-program-subprocess") + " Reactivated Successfully!";
        private static string mSG_SB_EffectiveToDt = "Please check the effective period of the selected Process";
        private static string mSG_USERGROUP_EffectiveToDt = "Please check the effective period of the User Group";
        private static string mSG_SB_UpdateSuccess = RenameText("clientConfigKeyLbl-program-subprocess") + " Updated Successfully!";
        private static string mSG_SB_UpdateFailure = RenameText("clientConfigKeyLbl-program-subprocess") + " Update Failed!";
        private static string mSG_SB_UpdateReactivation = "Cancel and Create the " + RenameText("clientConfigKeyLbl-program-subprocess") + "!";

        private static string mSG_SB_DeleteSuccess = RenameText("clientConfigKeyLbl-program-subprocess") + " Deleted Successfully!";
        private static string mSG_SB_DeleteFailed = RenameText("clientConfigKeyLbl-program-subprocess") + " Deletion Failed!";
        private static string mSG_SB_NotDelete_AuditUsed = RenameText("clientConfigKeyLbl-program-subprocess") + " Deletion Failed due to " + RenameText("clientConfigKeyLbl-program-subprocess") + " has been used for " + RenameText("clientConfigKeyLbl-audit-audit") + "!";
        //ADD for SLA page changes
        private static string mSG_SB_NotUpdated_SLAMapped = "Updation Failed due to SLA already mapped to " + RenameText("clientConfigKeyLbl-program-subprocess") + "!";
        private static string mSG_SB_SLA_CreationSuccess = "SLA Created Successfully!";
        private static string mSG_SB_SLA_AlreadyExists = "SLA Already Exists!";
        private static string mSG_SB_SLA_CreationFailure = "SLA Insertion Failed!";
        private static string mSG_SB_SLA_Reactivation = "SLA Reactivated Successfully!";
        private static string mSG_SB_SLA_UpdateSuccess = "SLA Updated Successfully!";
        private static string mSG_SB_SLA_UpdateFailure = "SLA Updation Failed!";
        private static string mSG_SB_SLA_UpdateReactivation = "SLA Reactivated Successfully!";


        public static string MSG_SB_CreationSuccess { get { return mSG_SB_CreationSuccess; } set { value = mSG_SB_CreationSuccess; } }
        public static string MSG_SB_AlreadyExists { get { return mSG_SB_AlreadyExists; } set { value = mSG_SB_AlreadyExists; } }
        public static string MSG_SB_CreationFailure { get { return mSG_SB_CreationFailure; } set { value = mSG_SB_CreationFailure; } }
        public static string MSG_SB_Reactivation { get { return mSG_SB_Reactivation; } set { value = mSG_SB_Reactivation; } }
        public static string MSG_SB_EffectiveToDt { get { return mSG_SB_EffectiveToDt; } set { value = mSG_SB_EffectiveToDt; } }
        public static string MSG_USERGROUP_EffectiveToDt { get { return mSG_USERGROUP_EffectiveToDt; } set { value = mSG_USERGROUP_EffectiveToDt; } }
        public static string MSG_SB_UpdateSuccess { get { return mSG_SB_UpdateSuccess; } set { value = mSG_SB_UpdateSuccess; } }
        public static string MSG_SB_UpdateFailure { get { return mSG_SB_UpdateFailure; } set { value = mSG_SB_UpdateFailure; } }
        public static string MSG_SB_UpdateReactivation { get { return mSG_SB_UpdateReactivation; } set { value = mSG_SB_UpdateReactivation; } }

        public static string MSG_SB_DeleteSuccess { get { return mSG_SB_DeleteSuccess; } set { value = mSG_SB_DeleteSuccess; } }
        public static string MSG_SB_DeleteFailed { get { return mSG_SB_DeleteFailed; } set { value = mSG_SB_DeleteFailed; } }
        public static string MSG_SB_NotDelete_AuditUsed { get { return mSG_SB_NotDelete_AuditUsed; } set { value = mSG_SB_NotDelete_AuditUsed; } }


        public static string MSG_SB_NotUpdated_SLAMapped { get { return mSG_SB_NotUpdated_SLAMapped; } set { value = mSG_SB_NotUpdated_SLAMapped; } }
        public static string MSG_SB_SLA_CreationSuccess { get { return mSG_SB_SLA_CreationSuccess; } set { value = mSG_SB_SLA_CreationSuccess; } }
        public static string MSG_SB_SLA_AlreadyExists { get { return mSG_SB_SLA_AlreadyExists; } set { value = mSG_SB_SLA_AlreadyExists; } }
        public static string MSG_SB_SLA_CreationFailure { get { return mSG_SB_SLA_CreationFailure; } set { value = mSG_SB_SLA_CreationFailure; } }
        public static string MSG_SB_SLA_Reactivation { get { return mSG_SB_SLA_Reactivation; } set { value = mSG_SB_SLA_Reactivation; } }
        public static string MSG_SB_SLA_UpdateSuccess { get { return mSG_SB_SLA_UpdateSuccess; } set { value = mSG_SB_SLA_UpdateSuccess; } }
        public static string MSG_SB_SLA_UpdateFailure { get { return mSG_SB_SLA_UpdateFailure; } set { value = mSG_SB_SLA_UpdateFailure; } }
        public static string MSG_SB_SLA_UpdateReactivation { get { return mSG_SB_SLA_UpdateReactivation; } set { value = mSG_SB_SLA_UpdateReactivation; } }


        #endregion
        #region SUPPORTTICKET MESSAGES

        private static string mSG_ST_CreationSuccess = "Ticket Created Successfully!";
        private static string mSG_ST_AlreadyExists = "Ticket Already Exists!";
        private static string mSG_ST_CreationFailure = "Ticket Insertion Failed!";

        public static string MSG_ST_CreationSuccess { get { return mSG_ST_CreationSuccess; } set { value = mSG_ST_CreationSuccess; } }
        public static string MSG_ST_AlreadyExists { get { return mSG_ST_AlreadyExists; } set { value = mSG_ST_AlreadyExists; } }
        public static string MSG_ST_CreationFailure { get { return mSG_ST_CreationFailure; } set { value = mSG_ST_CreationFailure; } }
        #endregion

        #region PROGRAMROLEMAP MESSAGES
        private static string mSG_PRM_CreationSuccess = "Program Role Mapped Successfully!";
        private static string mSG_PRM_CreationFailure = "Program Role Mapped Failed!";

        public static string MSG_PRM_CreationSuccess { get { return mSG_PRM_CreationSuccess; } set { value = mSG_PRM_CreationSuccess; } }
        public static string MSG_PRM_CreationFailure { get { return mSG_PRM_CreationFailure; } set { value = mSG_PRM_CreationFailure; } }

        #endregion
        #region AHT MESSAGES
        private static string msg_AHT_CreationSuccess = "AHT Created Successfully!";
        private static string msg_AHT_AlreadyExists = "AHT Already Exists!";
        private static string msg_AHT_CreationFailure = "AHT Insertion Failed!";
        private static string msg_AHT_Updation = "AHT Updated Successfully!";

        public static string MSG_AHT_CreationSuccess { get { return msg_AHT_CreationSuccess; } set { value = msg_AHT_CreationSuccess; } }
        public static string MSG_AHT_AlreadyExists { get { return msg_AHT_AlreadyExists; } set { value = msg_AHT_AlreadyExists; } }
        public static string MSG_AHT_CreationFailure { get { return msg_AHT_CreationFailure; } set { value = msg_AHT_CreationFailure; } }
        public static string MSG_AHT_Updation { get { return msg_AHT_Updation; } set { value = msg_AHT_Updation; } }

        #endregion

        #region  MANUAL ALLOCATION MESSAGES
        private static string mSG_ManualAllocation_AllocatedSuccessfully = "Transaction(s) Allocated Successfully!";
        private static string mSG_ManualAllocation_AllocationFailed = "Transaction(s) Allocation Failed!";
        private static string mSG_ManualAllocation_AlreadysomeTransactionAllocated = "Transaction(s) Allocated Successfully/ Some Already Allocated!";

        public static string MSG_ManualAllocation_AllocatedSuccessfully { get { return mSG_ManualAllocation_AllocatedSuccessfully; } set { value = mSG_ManualAllocation_AllocatedSuccessfully; } }
        public static string MSG_ManualAllocation_AllocationFailed { get { return mSG_ManualAllocation_AllocationFailed; } set { value = mSG_ManualAllocation_AllocationFailed; } }
        public static string MSG_ManualAllocation_AlreadysomeTransactionAllocated { get { return mSG_ManualAllocation_AlreadysomeTransactionAllocated; } set { value = mSG_ManualAllocation_AlreadysomeTransactionAllocated; } }

        #endregion

        #region  REALLOCATION MESSAGES
        private static string mSG_Reallocation_ReallocatedSuccessfully = "Transaction(s) Reallocated Successfully!";
        private static string mSG_Reallocation_RellocationFailed = "Transaction(s) Reallocation Failed!";

        public static string MSG_Reallocation_ReallocatedSuccessfully { get { return mSG_Reallocation_ReallocatedSuccessfully; } set { value = mSG_Reallocation_ReallocatedSuccessfully; } }
        public static string MSG_Reallocation_RellocationFailed { get { return mSG_Reallocation_RellocationFailed; } set { value = mSG_Reallocation_RellocationFailed; } }
        #endregion

        #region  SEARCH TRANSACTION MESSAGES
        private static string mSG_SearchTransactions_DeletedSuccessfully = "Transaction Deleted Successfully!";
        private static string mSG_SearchTransactions_DeletionFailed = "Transaction Deletion Failed!";
        private static string mSG_SearchTransactions_DeletionFailedDueToStatus = "Transaction Deletion Failed! Transaction is already Audited By Some Other User";


        public static string MSG_SearchTransactions_DeletedSuccessfully { get { return mSG_SearchTransactions_DeletedSuccessfully; } set { value = mSG_SearchTransactions_DeletedSuccessfully; } }
        public static string MSG_SearchTransactions_DeletionFailed { get { return mSG_SearchTransactions_DeletionFailed; } set { value = mSG_SearchTransactions_DeletionFailed; } }
        public static string MSG_SearchTransactions_DeletionFailedDueToStatus { get { return mSG_SearchTransactions_DeletionFailedDueToStatus; } set { value = mSG_SearchTransactions_DeletionFailedDueToStatus; } }
        #endregion

        #region  TRANSACTION CREATION MESSAGES

        private static string mSG_TransactionCreation_MANUAL_CASE_CREATION_NOT_CONFIGURED = " Manual Case Creation is either not configured or not active for this " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";
        private static string mSG_TransactionCreation_DATAELEMENT_NOT_CONFIGURED = " DataElement(s) for the current role is either not configured or not active for the " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";
        private static string mSG_TransactionCreation_CORESTATUS_NOT_CONFIGURED = RenameText("clientConfigKeyLbl-corestatus-core") + " Status is either not configured or not active for the " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";
        private static string mSG_TransactionCreation_CORESTATUSREASON_NOT_CONFIGURED = RenameText("clientConfigKeyLbl-corestatus-Status") + " Reason(s) is either not configured or not active for the status in the " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";
        private static string mSG_TransactionCreation_AUDITCONFIGURATION_NOT_CONFIGURED = " " + RenameText("clientConfigKeyLbl-audit-audit") + " Configuration is either not configured or not active for this " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";



        public static string MSG_TransactionCreation_MANUAL_CASE_CREATION_NOT_CONFIGURED { get { return mSG_TransactionCreation_MANUAL_CASE_CREATION_NOT_CONFIGURED; } set { value = mSG_TransactionCreation_MANUAL_CASE_CREATION_NOT_CONFIGURED; } }
        public static string MSG_TransactionCreation_DATAELEMENT_NOT_CONFIGURED { get { return mSG_TransactionCreation_DATAELEMENT_NOT_CONFIGURED; } set { value = mSG_TransactionCreation_DATAELEMENT_NOT_CONFIGURED; } }
        public static string MSG_TransactionCreation_CORESTATUS_NOT_CONFIGURED { get { return mSG_TransactionCreation_CORESTATUS_NOT_CONFIGURED; } set { value = mSG_TransactionCreation_CORESTATUS_NOT_CONFIGURED; } }
        public static string MSG_TransactionCreation_CORESTATUSREASON_NOT_CONFIGURED { get { return mSG_TransactionCreation_CORESTATUSREASON_NOT_CONFIGURED; } set { value = mSG_TransactionCreation_CORESTATUSREASON_NOT_CONFIGURED; } }
        public static string MSG_TransactionCreation_AUDITCONFIGURATION_NOT_CONFIGURED { get { return mSG_TransactionCreation_AUDITCONFIGURATION_NOT_CONFIGURED; } set { value = mSG_TransactionCreation_AUDITCONFIGURATION_NOT_CONFIGURED; } }



        private static string mSG_TransactionCreation_DATAELEMENT_CONFIGURATION_INCOMPLETE = " DataElement Configuration is incomplete (Data's missing for List) for the " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";
        private static string mSG_TransactionCreation_WORKFLOW_CONFIGURATION_INCOMPLETE = "Workflow Configuration is not configured for the " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";
        private static string mSG_TransactionCreation_PEER_CHECKER_INCOMPLETE = "Peer Checker is either not configured or not active - Map more than one Associate in user role mapping\n";
        private static string mSG_TransactionCreation_SLACATEGORY_INCOMPLETE = "Consolidated SLA (Category) is either not configured or not active for the " + RenameText("clientConfigKeyLbl-program-subprocess") + "\n";

        private static string mSG_TransactionCreation_CreatedSuccessfully = "Transaction Created Successfully!";
        private static string mSG_TransactionCreation_CreatedFailed = "Transaction Creation Failed ";
        private static string mSG_TransactionCreation_ALREADY_EXISTS = "Transaction Already Exists";
        private static string mSG_TransactionCreation_UpdatedSuccessfully = "Transaction Updated Successfully!";
        private static string mSG_TransactionCreation_UpdationFailed = "Transaction Updation Failed!";
        private static string mSG_TransactionCreation_UpdationFailed_Retry = "Transaction Updation Failed. Please try again!";
        private static string mSG_TransactionCreation_NotExists = "Transaction Not Exists";
        private static string mSG_TransactionCreation_DeletedSuccessfully = "Transaction Deleted Successfully!";
        private static string mSG_TransactionCreation_DeletionFailed = "Transaction Deletion Failed!";



        public static string MSG_TransactionCreation_DATAELEMENT_CONFIGURATION_INCOMPLETE { get { return mSG_TransactionCreation_DATAELEMENT_CONFIGURATION_INCOMPLETE; } set { value = mSG_TransactionCreation_DATAELEMENT_CONFIGURATION_INCOMPLETE; } }
        public static string MSG_TransactionCreation_WORKFLOW_CONFIGURATION_INCOMPLETE { get { return mSG_TransactionCreation_WORKFLOW_CONFIGURATION_INCOMPLETE; } set { value = mSG_TransactionCreation_WORKFLOW_CONFIGURATION_INCOMPLETE; } }
        public static string MSG_TransactionCreation_PEER_CHECKER_INCOMPLETE { get { return mSG_TransactionCreation_PEER_CHECKER_INCOMPLETE; } set { value = mSG_TransactionCreation_PEER_CHECKER_INCOMPLETE; } }
        public static string MSG_TransactionCreation_SLACATEGORY_INCOMPLETE { get { return mSG_TransactionCreation_SLACATEGORY_INCOMPLETE; } set { value = mSG_TransactionCreation_SLACATEGORY_INCOMPLETE; } }

        public static string MSG_TransactionCreation_CreatedSuccessfully { get { return mSG_TransactionCreation_CreatedSuccessfully; } set { value = mSG_TransactionCreation_CreatedSuccessfully; } }
        public static string MSG_TransactionCreation_CreatedFailed { get { return mSG_TransactionCreation_CreatedFailed; } set { value = mSG_TransactionCreation_CreatedFailed; } }
        public static string MSG_TransactionCreation_ALREADY_EXISTS { get { return mSG_TransactionCreation_ALREADY_EXISTS; } set { value = mSG_TransactionCreation_ALREADY_EXISTS; } }
        public static string MSG_TransactionCreation_UpdatedSuccessfully { get { return mSG_TransactionCreation_UpdatedSuccessfully; } set { value = mSG_TransactionCreation_UpdatedSuccessfully; } }
        public static string MSG_TransactionCreation_UpdationFailed { get { return mSG_TransactionCreation_UpdationFailed; } set { value = mSG_TransactionCreation_UpdationFailed; } }
        public static string MSG_TransactionCreation_UpdationFailed_Retry { get { return mSG_TransactionCreation_UpdationFailed_Retry; } set { value = mSG_TransactionCreation_UpdationFailed_Retry; } }
        public static string MSG_TransactionCreation_NotExists { get { return mSG_TransactionCreation_NotExists; } set { value = mSG_TransactionCreation_NotExists; } }
        public static string MSG_TransactionCreation_DeletedSuccessfully { get { return mSG_TransactionCreation_DeletedSuccessfully; } set { value = mSG_TransactionCreation_DeletedSuccessfully; } }
        public static string MSG_TransactionCreation_DeletionFailed { get { return mSG_TransactionCreation_DeletionFailed; } set { value = mSG_TransactionCreation_DeletionFailed; } }

        #endregion

        #endregion

        #region sp_Return_values

        public const string SUCCESS = "1";
        public const string ALREADYEXISTS = "2";
        public const string FAILURE = "3";
        public const string MAILFAILURE = "-1";
        public const string USER_NOT_EXISTS = "4";
        public const string USER_EXISTS_BUT_NOT_ACTIVE = "5";
        public const string REACTIVATED = "5";
        public const string CREATENEW = "4";
        public const string CHECK_ON_EFFECTIVETODT = "6";
        public const string REACTIVATED_USERCONFIG = "6";
        public const string DEACTIVATED = "7";
        public const string CANNOT_MODIFY_DIRECT_EXTERNAL = "8";
        public const string CANNOT_MODIFY_DIRECT_BUSINESS = "9";
        public const string CANNOT_MODIFY_DIRECT_SUPERVISOR = "10";
        public const string USERGROUP_EFFECTIVETODT = "10";
        public const string PROCESS_EFFECTIVETODT = "11";
        public const string PROGRAMFEATURES_NOT_EXISTS = "12";
        public const string FAILURE_RETRY_MSG = "13";
        public const string ALLOCATEDWITH_ALREADYALLOCATED = "14";
        public const string CATEGORY_CANNOT_DELETE = "15";
        public const string CTQGROUP_CANNOT_DELETE = "15";
        public const string SUBPROCESS_EXIST = "16";
        public const string CANNOT_DELETE_ALREADYAUDITED = "17";
        public const string GROUPEXIST = "20";
        public const string DEFAULTVALUE = "21";
        public const string CANNOT_UPDATED_SLA = "22";
        public const string CANNOT_ASSIGN_ROLESTOSAMEUSER = "23";
        #endregion

        #region sp_Return_values_TRANSACTION_CREATION
        public const string MANUAL_CASE_CREATION_CHECK = "-1";
        public const string DATA_ELEMENT_CHECK = "-2";
        public const string CORE_STATUS_CHECK = "-3";
        public const string CORE_STATUS_REASON_CHECK = "-4";
        public const string AUDIT_CONFIG_CHECK = "-5";
        public const string DATA_ELEMENT_INCOMPLETE_CHECK = "-6";
        public const string WORKFLOW_INCOMPLETE_CHECK = "-7";
        public const string PEERCHECKERNOTENABLED = "-8";
        public const string SLACATEGORYNOTENABLED = "-9";

        #endregion

        #region Pagination and Sorting

        public const string PAGESIZE = "PageSize";
        public const int DEFAULT_MAXIMUMROWS = 0;
        public const int DEFAULT_STARTROWINDEX = 1;
        public const string DEFAULT_ORDERBY = "DESC";
        public const string DEFAULT_SORTCOLUMN_CORESTATUSREASON = "iCodeId";
        public const string DEFAULT_SORTCOLUMN_CORESTATUS = "iCoreTransStatusId";
        public const string DEFAULT_SORTCOLUMN_HOLIDAY = "iHolidayId";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_CATEGORY = "ADM.[iDOId]";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_HEADING = "Headinglist.[iDOId]";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_CTQGroup = "ADG.iDOGroupId";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_WeightageConfig = "ADG.iDOGroupId";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_CHECKPOINT = "Checkpointlist.[iDOId]";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_SUBDEFECT1 = "SUBLIST.iSubDOId";
        public const string DEFAULT_SORTCOLUMN_DEFECTOPPORTUNITY_GROUPMAP = "iDOGroupMapId";
        public const string DEFAULT_SORTCOLUMN_RECORDID = "Record ID";
        public const string DEFAULT_SORTCOLUMN_UserGroupRoleMapId = "iUserGroupRoleMapId";
        public const string DEFAULT_SORTCOLUMN_PermissionMappingId = "iRolePermissionMappingId";
        public const string DEFAULT_SORTCOLUMN_iSystemUserId = "iSystemUserId";
        public const string DEFAULT_SORTCOLUMN_iUserGroupId = "iUserGroupId";
        public const string DEFAULT_SORTCOLUMN_iUserGroupMapId = "iUserGroupMapId";
        public const string DEFAULT_SORTCOLUMN_iUserAdminMappingId = "iUserAdminMappingId";


        #endregion

        #region VIEWS

        #region COMMON
        public const string View_Home = "Home";
        #endregion

        #region CORE STATUS
        public const string Partial_CoreStatus = "_CoreStatus";
        public const string Partial_CoreStatusList = "_CoreStatusList";
        public const string Partial_CoreStatusReason = "_CoreStatusReason";
        public const string Partial_CoreStatusReasonList = "_CoreStatusReasonList";
        #endregion

        #region HOLIDAY
        public const string Partial_HolidayList = "_HolidayList";
        #endregion

        #region DEFECT OPPORTUNITY

        public const string Partial_DO_Category = "Category";
        public const string Partial_DO_Heading = "Heading";
        public const string Partial_DO_Checkpoint_Group = "CheckPointGroup";
        public const string Partial_DO_Checkpoint = "Checkpoint";
        public const string Partial_DO_SubDefect1 = "SubDefect1";
        public const string Partial_DO_SubDefect2 = "SubDefect2";
        public const string Partial_DO_SubDefect3 = "SubDefect3";
        public const string Partial_DO_SubDefect4 = "SubDefect4";
        public const string Partial_DO_SubDefect5 = "SubDefect5";
        public const string Partial_DO_Weightage = "WeightageConfig";
        public const string Partial_DO_CopyCheckpoint = "CopyCheckpoint";
        public const string Partial_DO_CateogoryList = "_GetCategorylist";
        public const string Partial_DO_HeadingList = "_GetHeadinglist";
        public const string Partial_DO_CTQGroupList = "_GetCTQGrouplist";
        public const string Partial_DO_CheckpointList = "_GetCheckpointlist";
        public const string Partial_DO_SubDefect1List = "_GetSubDefect1list";
        public const string Partial_DO_SubDefect2List = "_GetSubDefect2list";
        public const string Partial_DO_SubDefect3List = "_GetSubDefect3list";
        public const string Partial_DO_SubDefect4List = "_GetSubDefect4list";
        public const string Partial_DO_SubDefect5List = "_GetSubDefect5list";
        public const string Partial_DO_WeightageList = "_GetWeightageConfiglist";
        public const string Partial_DO_CopyCheckpointList = "_GetCopyCheckpointlist";
        #endregion

        #region ALLOCATION
        public const string Partial_MANUAL_ALLOCATION_GRID = "_AllocationGrid";
        public const string Partial_REALLOCATION_GRID = "_ReallocationGrid";
        public const string VIEW_NAME_REALLOCATION = "ReAllocation";

        #endregion

        #region MasteCalibrator TRANSACTIONS
        public const string View_MC_TRANSACTIONS_INDEX = "Index";
        public const string Partial_MC_TRANSACTIONS = "_MCAllocationTransactions";
        public const string Partial_MC_TRANSACTIONS_LIST = "_MCAllocationTransactionList";
        public const string Partial_Calibrators = "MapCalibrators";


        public const string MC_TRANSACTIONS_INDEX_URL = "../MasterCalibratorAllocation/Index";

        #endregion

        #region SEARCH TRANSACTIONS
        public const string View_SEATCH_TRANSACTIONS_INDEX = "Index";
        public const string Partial_SEARCH_TRANSACTIONS = "_SearchTransactions";
        public const string Partial_SEARCH_TRANSACTIONS_LIST = "_SearchTransactionList";

        public const string VIEW_TRANSACTIONS_INDEX = "ViewIndex";
        public const string Partial_VIEW_TRANSACTIONS = "_ViewTransactions";
        public const string Partial_VIEW_TRANSACTIONS_LIST = "_ViewTransactionList";

        public const string VIEW_NAME_SEARCH_DELETE = "SearchDelete";
        public const string VIEW_NAME_SEARCH_FIELDS = "SearchFields";
        public const string VIEW_NAME_GET_SEARCH_LIST = "GetSearchList";
        public const string VIEW_SEARCH_LIST = "ViewSearchList";
        public const string CIPHERPASSWORD = "CIPHERPASSWORD";

        public const string SEARCH_TRANSACTIONS_INDEX_URL = "../SearchTransactions/Index";
        public const string SCORECORRECTION = "SCORECORRECTION";

        #endregion

        #region SEARCH TRANSACTIONS
        public const string View_TRANSACTIONS_HOME = "Home";
        public const string Partial_TRANSACTIONS_CREATION = "_TransactionCreation";
        public const string Partial_TRANSACTIONS = "Transactions";
        public const string Partial_TRANSACTIONS_LIST = "TransactionList";



        #endregion

        #endregion

        #region SP Exec Timout

        public const string QUERYEXECUTIONTIMEOUT = "30";
        public const string BULKUPLOADQUERYEXECTIMEOUT = "120";

        #endregion

        #region Mail Template Type
        public const string AUDITMAIL = "AuditMail";
        public const string DELETEMAIL = "DeleteMail";
        public const string SUPPORTTICKETMAIL = "SupportTicketMail";
        public const string RATINGDIFFMAIL = "RatingDiffMail";
        #endregion

        public static string RenameText(string txtToBeRenamed)
        {
            string replaceText = string.Empty;
            string[] arr = txtToBeRenamed.Split('-');

            if (arr != null)
            {
                if (arr.Length != 0)
                {
                    if (arr[0] == "clientConfigKeyLbl")
                    {

                        string XmlSettingPath = ConfigurationManager.AppSettings["RenameConfig"];
                        XElement root = XElement.Load(System.Web.HttpContext.Current.Server.MapPath(XmlSettingPath));

                        string ProgramId = string.Empty;
                        if (HttpContext.Current.Session["ProgramId"] != null)
                        {
                            ProgramId = HttpContext.Current.Session["ProgramId"].ToString();
                        }

                        var allroot1 =
                       from e in root.Elements("Program")

                       where ((string)e.Attribute("id") == ProgramId)
                       select e;


                        var allroot =
                        from e in allroot1.Elements()
                        where ((string)e.Attribute("id") == arr[1].ToString())

                        select e;
                        var ElementCount = allroot.Count();
                        for (int i = 0; i < ElementCount; i++)
                        {
                            if (ElementCount != 0)
                            {
                                replaceText = allroot.ElementAt(i).Element(arr[2].ToString()).Value;
                            }
                        }
                    }
                }
            }
            return replaceText;
        }


    }
}

