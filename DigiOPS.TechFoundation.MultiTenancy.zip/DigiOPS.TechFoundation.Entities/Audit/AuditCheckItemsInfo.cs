﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DigiOPS.TechFoundation.Entities
{
    public class AuditCheckItemsInfo : BaseInfo
    {
        public bool IsActive { get; set; }
        // public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsEditMode { get; set; }
        public string OperationName { get; set; }

        public int CategoryId { get; set; }
        public string CategoryDisplayName { get; set; }
        public bool CategoryIsactive { get; set; }

        public int HeadId { get; set; }
        public string HeadDisplayName { get; set; }
        public bool HeadingIsactive { get; set; }

        public int CriticalityId { get; set; }
        public string CriticalityType { get; set; }
        public int RatingGroupId { get; set; }
        public string CheckItemGroupName { get; set; }
        public int CheckItemGroupId { get; set; }
        public bool CheckitemGroupIsactive { get; set; }
        public int SubProcessId { get; set; }
        public int AuditingLogicId { get; set; }

        public XElement xmlAuditCheckItem { get; set; }
        public XElement xmlAuditRootCauseItem { get; set; }
        public List<AuditCheckItemInfo> AuditCheckItemList { get; set; }
        public List<RootCauseInfo> AuditRootCauseList { get; set; }

        public string DeleteCTQIDs { get; set; }
    }

    //public class AuditCheckCategoryInfo
    //{

    //    public string CategoryName { get; set; }
    //    public string CategoryDescription { get; set; }
    //    public int CategoryOrdinalNumber { get; set; }
    //    public List<AuditCheckHeadingInfo> Headings { get; set; }
    //    public int Level { get; set; }
    //}

    //public class AuditCheckHeadingInfo
    //{
    //    public int HeadingOrdinalNumber { get; set; }
    //    public string HeadingName { get; set; }
    //    public string HeadingDescription { get; set; }
    //    public List<AuditCheckItemInfo> CheckItems { get; set; }
    //    public string HeadingGUID { get; set; }
    //    public int Level { get; set; }
    //}

    public class AuditCheckItemInfo
    {
        public string CheckItemId { get; set; }
        public string CheckItemName { get; set; }
        public string CheckItemDescription { get; set; }
        public string OLCheckItemDescription { get; set; }//OL->Other Language
        public string CheckItemGUID { get; set; }
        public List<RootCauseInfo> RootCauseItems { get; set; }
        public int Level { get; set; }
        public bool IsActive { get; set; }
    }


    public class RootCauseInfo
    {
        public string RootCauseItemName { get; set; }
        public string OLRootCauseItemName { get; set; }
        public int RootCauseId { get; set; }
        public int ParentCheckItemId { get; set; }
        public int ParentRootCauseId { get; set; }
        public string RootCauseGUID { get; set; }
        public string ParentRootCauseGUID { get; set; }
        public string CheckItemGUID { get; set; }
        public int Level { get; set; }
        public bool IsActive { get; set; }
    }

    public class TransDropDownlist
    {


        public string criticality { get; set; }
        public string ForeignKey { get; set; }
        public bool IsNA { get; set; }
        public bool IsSelected { get; set; }
        public string Score { get; set; }
        public string TempId { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
    }
}
