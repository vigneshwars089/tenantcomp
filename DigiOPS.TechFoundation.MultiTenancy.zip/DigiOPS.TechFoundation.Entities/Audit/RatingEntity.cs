﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.ComponentModel;
//using System.ComponentModel.DataAnnotations;



namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// RatingEntity class
    /// </summary>
    [Serializable]
    public class RatingEntity : BaseInfo
    {
        public int RatingId { get; set; }

        public string RatingDesc { get; set; }

        public string RatingDisplayName { get; set; }

        public int SubProcessId { get; set; }

        public bool blnNotApplicable { get; set; }

        public string CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public string ModifiedBy { get; set; }

        public DateTime dsModifiedDate { get; set; }

        public int selectedProgramId { get; set; }

        public string selectedProgramName { get; set; }

        public int selectedProcessId { get; set; }

        public string selectedProcessName { get; set; }

        public int selectedSubProcessId { get; set; }

        public string selectedSubProcessName { get; set; }

        public bool IsEditMode { get; set; }

        public bool IsChecked { get; set; }

        public string action { get; set; }

        public bool IsActive { get; set; }

        public bool IsDropdownlist { get; set; }

        public int ValidNA { get; set; }
        public int CanRatingEnable { get; set; }

        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public string eventAction { get; set; }
        public string EntityName { get; set; }
    }

    /// <summary>
    /// RatingViewModel class
    /// </summary>
    public class RatingViewModel : BaseTransportEntity
    { 
        /// <summary>
        /// Rating view model
        /// </summary>
        /// <returns></returns>
        public RatingViewModel()
        {
            RatingList = new List<RatingEntity>();
            Rating = new RatingEntity();

        }

        public List<SelectListItem> ProgramList { get; set; }
        public List<SelectListItem> ProcessList { get; set; }
        public List<SelectListItem> SubprocessList { get; set; }



        public List<RatingEntity> RatingList { get; set; }
        public RatingEntity Rating { get; set; }

    }


}
