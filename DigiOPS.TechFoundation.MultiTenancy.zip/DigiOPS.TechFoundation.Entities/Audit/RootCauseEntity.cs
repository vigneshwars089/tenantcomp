﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// SubDefectEntity class
    /// </summary>
    public class RootCauseEntity : CheckItemEntity
    {
        public int SubDOId { get; set; }
        public int DOId { get; set; }
        public int Level { get; set; }
       // public string SubDefectDesc { get; set; }
        public string DisplayName { get; set; }
        public Nullable<int> ParentSubDOId { get; set; }
        public int SubProcessId { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public System.DateTime ModifiedDate { get; set; }

        public bool IsEditMode { get; set; }

        //public string CategoryName { get; set; }
        public int CategoryID_DOId { get; set; }
       // public string HeadingName { get; set; }
        public int HeadingID_DOId { get; set; }
             
        public string ActionName { get; set; }
        public bool isDropdowndetails { get; set; }

        public int? StartRowIndex { get; set; }
        public int? MaximumRows { get; set; }
        public int? TotalRows { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
        public Boolean IsDefault { get; set; }
        //public bool SelectedDefaultfield { get; set; }
        public bool Isdefaultneeded { get; set; }
       
    }

    public class TranDropDown : RootCauseEntity
    {


        public string criticality { get; set; }
        public string ForeignKey { get; set; }
        public bool IsNA { get; set; }
        public bool IsSelected { get; set; }
        public string Score { get; set; }
        public string TempId { get; set; }
        public string Text { get; set; }
        public string Value { get; set; }
    }
}
