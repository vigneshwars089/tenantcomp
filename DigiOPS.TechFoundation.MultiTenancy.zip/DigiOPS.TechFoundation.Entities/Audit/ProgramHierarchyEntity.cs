﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// ProgramHierarchyEntity class
    /// </summary>
    [Serializable]
    public class ProgramHierarchyEntity : BaseTransportEntity
    {
        public string EntityLevelName { get; set; }
        public int Id { get; set; }
        public int UserGroupId { get; set; }
    }

    /// <summary>
    /// ProgramHierarchyEntityViewModel class
    /// </summary>
    [Serializable]
    public class ProgramHierarchyEntityViewModel
    {
        public string CustomMessage { get; set; }
        /// <summary>
        /// ProgramHierarchyEntityViewModel constructor
        /// </summary>
        public ProgramHierarchyEntityViewModel()
        {
            SubProcessList = new List<TransDropDown>();
            ProgramList = new List<TransDropDown>();
            ProcessList = new List<TransDropDown>();

        }

        public int SubProcessId { get; set; }
        public int ProcessId { get; set; }
        public int ProgramId { get; set; }
        public int UserGroupId { get; set; }
        public string CurrentRoleId { get; set; }
        public List<TransDropDown> SubProcessList { get; set; }
        public List<TransDropDown> ProgramList { get; set; }
        public List<TransDropDown> ProcessList { get; set; }
    }
}
