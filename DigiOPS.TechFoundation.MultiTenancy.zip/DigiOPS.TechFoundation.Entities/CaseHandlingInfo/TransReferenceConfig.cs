﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// TransReferenceConfig class
    /// </summary>
    [Serializable]
    public class TransReferenceConfig : BaseEntity
    {
        public int SubProcessId { get; set; }
        public int RecordId { get; set; }
        public int CoreTransStatusId { get; set; }
        public string CoreTransStatusDesc { get; set; }
        public int ReasonElementTypeId { get; set; }
        public bool IsReasonNeeded { get; set; }
        public string ReasonElementData { get; set; }
        public string ReasonCodeGroupId { get; set; }
        public string SelectedReasonId { get; set; }
        public int ReferenceId { get; set; }
        public int AuditId { get; set; }

        /// <summary>
        /// TransReferenceConfig  constructor
        /// </summary>
        public TransReferenceConfig()
        {
            ReasonList = new List<TransReasonList>();
            SelectItem = new SelectReferenceReason();
        }
        public List<TransReasonList> ReasonList { get; set; }
        public SelectReferenceReason SelectItem { get; set; }
    }

    /// <summary>
    /// SelectReferenceReason
    /// </summary>
    [Serializable]
    public class SelectReferenceReason : BaseTransportEntity
    {
        public string SelectedReasonId { get; set; }
        public string SelectedCoreTransStatusId { get; set; }
        public string ReasonText { get; set; }
    }
}
