﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// TransElementData class
    /// </summary>
    [Serializable]
    public class TransElementData : BaseEntity
    {
        public int RecordElementId { get; set; }
        public int ElementId { get; set; }
        public int RecordId { get; set; }
        public string ElementData { get; set; }
        public Nullable<bool> IsMultiItemValue { get; set; }
        public string ModifiedBy { get; set; }
        public Guid GuidTransElement { get; set; }
        public List<TransElementItemData> elementItemDataList { get; set; }
        public string ProcessedDate { get; set; }
    }
}
