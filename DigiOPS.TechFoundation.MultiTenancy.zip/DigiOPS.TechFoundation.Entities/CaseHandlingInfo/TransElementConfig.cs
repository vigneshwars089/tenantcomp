﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// TransElementConfig class
    /// </summary>
    [Serializable]
    public class TransElementConfig : BaseEntity
    {
        public int SubProcessId { get; set; }
        public int RecordId { get; set; }
        public int ElementId { get; set; }
        public string ElementName { get; set; }
        public string DisplayName { get; set; }
        public int ElementTypeId { get; set; }
        public string ElementTypeName { get; set; }
        public int DataTypeId { get; set; }
        public string DataTypeName { get; set; }
        public string CodeGroupId { get; set; }
        public int SequenceNo { get; set; }
        public bool MandatoryElement { get; set; }
        public bool UniqueElement { get; set; }
        public Nullable<int> ElementLength { get; set; }
        public string ValidChars { get; set; }

        public bool IsChecked { get; set; }
        public bool IsActive { get; set; }
        public Nullable<System.DateTime> EffectiveTo { get; set; }
        public int StatusID { get; set; }

        public string Comment { get; set; }

        public string ProcessedTime { get; set; }

        public string ProcessedDate { get; set; }
        public string ReceivedDate { get; set; }

        public string ElementData { get; set; }
        public bool IsMultiItemValue { get; set; }
        public int NoOfEmployee { get; set; }
        public int NoofLine { get; set; }
        public int iSubcategory { get; set; }
        public string SelectedItemId { get; set; }
        public string SelectedItemName { get; set; }
        public int ProcessedBy { get; set; }
        public bool AuditStatus { get; set; }
        public string SelectedPeerCheckerId { get; set; }
        public string SelectedPeerCheckerName { get; set; }
        public string PeerCheckerId { get; set; }
        public string SelectedSLACategoryId { get; set; }
        public string SelectedSLACategoryName { get; set; }
        public string SLACategoryId { get; set; }
        public bool IsAuditDataExists { get; set; }
        public bool CanCrtlVisible { get; set; }
        public bool DirectAuditReq { get; set; }

        public bool IsPeerCheckerRequired { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public string action { get; set; }
        public List<TransDropDown> lstItems { get; set; }
        public List<TransDropDown> PeerCheckerList { get; set; }
        
        public int CoreTransStatusId { get; set; }
        public int CoreTransStatusReasonId { get; set; }
        public string CoreTransStatusReason { get; set; }

        public int AuditID { get; set; }
        public string ViewType { get; set; }
        public string URL { get; set; }

        public string DataEntryByIds { get; set; }
    }
}
