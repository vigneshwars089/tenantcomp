﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{
    /// <summary>
    /// TransStatusData class
    /// </summary>
    [Serializable]
    public class TransStatusData : BaseEntity
    {
        public int TransStatusId { get; set; }
        public int RecordId { get; set; }
        public int StatusId { get; set; }
        public int PrevStatusId { get; set; }
        public System.DateTime StatusEndDate { get; set; }
        public string Comment { get; set; }
        public int SubProcessId { get; set; }
    }
}
