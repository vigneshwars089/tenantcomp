﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Runtime;
using System.Web;
using System.Web.UI;

using System.Reflection;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Collections.Specialized;
using System.IO;



namespace DigiOPS.TechFoundation.Collaboration
{
    public class MailCollaboration : BaseCollaboration
    {
        static bool mailSent = false;
        public override void send(CollaborationInfo ObjEMailInfo)
        {
           
            EMailInfo objInfo = (EMailInfo)ObjEMailInfo;
            
            //private Logger proxyLogger = new Logger();
         
              EMailInfo sentData = new  EMailInfo();
             
                MailMessage mailMessage = new MailMessage();
                MailDefinition mailDef = new MailDefinition();
                EmbeddedMailObject emo = null;
                ListDictionary replacements = new ListDictionary();

                string strFrom = string.Empty;
                string strTo = string.Empty;
                string strCC = string.Empty;
                string strBody = string.Empty;

                try
                {
                    strFrom = objInfo.Sender == null ? string.Empty : objInfo.Sender;

                    foreach (var To in objInfo.ToAddressList)
                    {
                        if (string.IsNullOrEmpty(strTo))
                            strTo = To.ToAddress;
                        else
                            strTo = strTo + ", " + To.ToAddress;
                    }
                    if (ValidateMailObject(objInfo).ResultStatus)
                    {
                        if (objInfo.IsBodyWithEmbededObjects == true)
                        {
                            mailDef.From = strFrom;
                            foreach (var embedObjList in objInfo.EmbededObjectsList)
                            {
                                emo = new EmbeddedMailObject();
                                emo.Path = embedObjList.szPATH;
                                emo.Name = embedObjList.szName;
                                mailDef.EmbeddedObjects.Add(emo);
                            }
                            mailDef.BodyFileName = HttpContext.Current.Server.MapPath(objInfo.szPath) + "\\" + objInfo.szMailBodyFileName;
                            mailDef.IsBodyHtml = true;
                            replacements = ReplaceMailContent(objInfo);
                            mailMessage = mailDef.CreateMailMessage(strTo, replacements, new Label());

                        }
                        else if (objInfo.IsBodyWithReplaceChar == true)
                        {
                            strBody = new MailContentTemplate().GetTemplate(objInfo);
                            //strBody = //collaborationFactory.ReplaceMailContent("").GetHtmlTemplate(objInfo);
                            mailMessage.Body = strBody;
                        }
                        else
                        {
                            mailMessage.Body = objInfo.szMailBody;
                        }

                        AlternateView htmlView = AlternateView.CreateAlternateViewFromString(mailMessage.Body, null, "text/html");
                        mailMessage.AlternateViews.Add(htmlView);

                        foreach (var cc in objInfo.CCAddressList)
                        {
                            if (string.IsNullOrEmpty(strCC))
                                strCC = cc.CCAddress;
                            else
                                strCC = strCC + ", " + cc.CCAddress;

                            if (!string.IsNullOrEmpty(cc.CCAddress))
                                mailMessage.CC.Add(cc.CCAddress);
                        }

                        mailMessage.From = new MailAddress(strFrom, objInfo.szMailName, System.Text.Encoding.UTF8);
                        mailMessage.Subject = objInfo.szSentSubj;
                        mailMessage.SubjectEncoding = System.Text.Encoding.UTF8;
                        mailMessage.IsBodyHtml = true;

                        switch (objInfo.szMailPriority)
                        {
                            case "Low":
                                {
                                    mailMessage.Priority = MailPriority.Low;
                                    break;
                                }
                            case "Normal":
                                {
                                    mailMessage.Priority = MailPriority.Normal;
                                    break;
                                }
                            case "High":
                                {
                                    mailMessage.Priority = MailPriority.High;
                                    break;
                                }
                            default:
                                {
                                    mailMessage.Priority = MailPriority.High;
                                    break;
                                }
                        }
                        sentData.iMailTrackerId = objInfo.iMailTrackerId;
                        sentData.szSentTo = strTo;
                        sentData.szSentCC = strCC;
                        sentData.szSentFrom = strFrom;
                        sentData.szSentSubj = objInfo.szSentSubj;

                        using (SmtpClient client = new SmtpClient())
                        {
                            client.Port = Convert.ToInt32(objInfo.szPort);
                            client.Host = objInfo.szHost;
                            client.EnableSsl = false;
                            client.SendCompleted += client_SendCompleted;
                            client.Send(mailMessage);
                        }
                        mailSent = true;
                    }
                }
                //catch (QuartException ex)
                //{
                //    proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //}
                catch (Exception ex)
                {
                    //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                }
                finally
                {

                    replacements.Clear();
                    replacements = null;
                    emo = null;

                    if (mailMessage != null)
                    {
                        mailMessage.Dispose();
                    }

                    if (mailDef != null)
                    {
                        mailDef = null;
                    }

                    //if (collaborationFactory != null)
                    //{
                    //    collaborationFactory = null;
                    //}
                }

                sentData.bMailSent = mailSent;

                //return sentData;
            }
        private void client_SendCompleted(object sender, AsyncCompletedEventArgs e)
        {
            MailMessage mail = (MailMessage)e.UserState;

            try
            {
                string subject = mail.Subject;

                if (e.Cancelled)
                {
                    string cancelled = string.Format("[{0}] Send canceled.", subject);
                    //proxyLogger.Log.Error(cancelled);
                }

                if (e.Error != null)
                {
                    string error = String.Format("[{0}] {1}", subject, Convert.ToString(e.Error));
                    //proxyLogger.Log.Error(error);
                }
                else
                {
                    mailSent = true;
                }
               ((MailMessage)e.UserState).Dispose();
            }

            catch (SmtpFailedRecipientException ex)
            {
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw ex;
            }
            catch (SmtpException ex)
            {
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw ex;
            }
            catch (ApplicationException ex)
            {
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw ex;
            }
            finally
            {
                if (mail != null)
                    mail.Dispose();
            }
        }
       
        private ListDictionary ReplaceMailContent(EMailInfo objInfo)
        {
            ListDictionary replacements = new ListDictionary();
            try
            {
                if (objInfo.MailMergeContentList != null && objInfo.MailMergeContentList.Count >0)
                {
                    foreach (var rplcmailContentList in objInfo.MailMergeContentList)
                    {
                        if (!string.IsNullOrWhiteSpace(rplcmailContentList.szReplaceName))
                            replacements.Add(rplcmailContentList.szReplaceName, rplcmailContentList.szReplaceValue);
                    }
                }
            }
            catch (Exception ex)
            {
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            }
            return replacements;
        }

      
        

         
          

  
    }
}
