﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Logging;
////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :ManualCheckItem.cs
// Namespace : DigiOps.TechFoundation.Audit
// Class Name(s) :ManualCheckItem
// Author :M.Priyadharshini.
// Creation Date : 4/6/2017
// Purpose : This class will be used to configure CheckItem .
//
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////
namespace DigiOPS.TechFoundation.Audit
{
    public class ManualCheckItem : BaseAuditCheckItem
    {
        DefectOpportunityDataAccess doDAO = null;
        
        public override string AddAuditCheckItems(AuditCheckItemsInfo objDo)
        {
            doDAO = new DefectOpportunityDataAccess(objDo.TenantName, objDo.AppID);
            return doDAO.AddAuditCheckItems(objDo);

        }
        public override string AddeditDefectOpportunity(CheckItemEntity objDo)
        {
            doDAO = new DefectOpportunityDataAccess(objDo.TenantName, objDo.AppID);
            return doDAO.AddeditDefectOpportunity(objDo);

        }
        public override string CopyDefOpp(CheckItemEntity objDo)
        {
            doDAO = new DefectOpportunityDataAccess(objDo.TenantName, objDo.AppID);
            return doDAO.CopyDefOpp(objDo);

        }

        public override List<CheckItemEntity> GetDefectOppList(CheckItemEntity objdo)
        {
            doDAO = new DefectOpportunityDataAccess(objdo.TenantName, objdo.AppID);
            return doDAO.GetDefectOppList(objdo);

        }

        public override List<AuditConfigEntity> GetAuditCheckItems(AuditConfigEntity objaudconfig)
        {
            doDAO = new DefectOpportunityDataAccess(objaudconfig.TenantName, objaudconfig.AppID);
            return doDAO.GetAuditCheckItems(objaudconfig);

        }
        public override AuditCheckItemsInfo GetCTQItems(AuditCheckItemsInfo objDo)
        {
            doDAO = new DefectOpportunityDataAccess(objDo.TenantName, objDo.AppID);
            return doDAO.GetCTQItems(objDo);
        }


    }
}

