﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :AuditFactory.cs
// Namespace : DigiOps.TechFoundation.Audit
// Class Name(s) :AuditFactory
// Author :M.Priyadharshini.
// Creation Date : 4/6/2017
// Purpose : This class will be used to create the object of Configuration Type class depending on the user input.
//
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////
namespace DigiOPS.TechFoundation.Audit
{
    public struct S_Cofig_Type
    {

        public const string Manual = "Manual";
        public const string BulkUpload  = "BulkUplaod";
    }

    public struct S_Configuration
    {

        public const string Checkitems = "Checkitems";
        public const string Rating = "Rating";
        public const string Rootcause = "Rootcause";
        public const string CombinedAccuracy = "CombinedAccuracy";
        
    }


    public class AuditFactory : IAuditFactory
    {

        public IAuditCheckItem GetAuditTypeHandler(string ConfigType, string Configuration)
        {
            IAuditCheckItem objAuditFactory = null;

            switch (ConfigType)
            {
                case S_Cofig_Type.Manual:
                    switch (Configuration)
                    {
                        case S_Configuration.Checkitems:
                            objAuditFactory = new ManualCheckItem();
                            break;
                        case S_Configuration.Rootcause:
                            objAuditFactory = new ManualRootCause();
                            break;
                        case S_Configuration.Rating:
                            objAuditFactory = new ManualAuditRating();
                            break;
                        case S_Configuration.CombinedAccuracy:
                            objAuditFactory = new ManualCombinedAccuracy();
                            break;
                        default:
                            return null;   
                    }


                    return objAuditFactory;

            }
            return null;

        }
    }
    
}


