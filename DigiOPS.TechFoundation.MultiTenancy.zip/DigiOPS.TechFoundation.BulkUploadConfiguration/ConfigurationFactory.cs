﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.BulkUploadConfiguration
{
   public class ConfigurationFactory:IConfigurationFactory
    {

       public IConfiguration ConfigurationHandler(string ConfigurationType)
        {
            IConfiguration objConfiguration = null;

            switch (ConfigurationType)
            {
                case Constants.HIERARCHY:
                    objConfiguration = new HierarchyConfiguration();
                    break;
                case Constants.USER:
                    objConfiguration = new UserConfiguration();
                    break;
                case Constants.AUDIT:
                    objConfiguration = new AuditConfiguration();
                    break;
            }
            return objConfiguration;
        }
    }
}
