﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using Excel;
using System.Collections;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Xml.Linq;

namespace DigiOPS.TechFoundation.BulkUploadConfiguration
{
    public class ExcelRead
    {


    }
}
