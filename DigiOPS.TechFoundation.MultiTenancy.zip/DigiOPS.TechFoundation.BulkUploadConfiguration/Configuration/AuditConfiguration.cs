﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
//using System.Text;
using Excel;
using System.Collections;
using System.IO;
using System.Xml;
using System.Configuration;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.DataAccessLayer.BulkUploadConfiguration;

namespace DigiOPS.TechFoundation.BulkUploadConfiguration
{
   public class AuditConfiguration:BaseConfiguration
    {
      // Audit ad = new Audit();
        string error = "";
        string table = "TEMPRatingType";
        //SqlConnection ConnStr = ConfigurationManager.ConnectionStrings["SQLConnectionBlkUpload"];

        public override Dictionary<string, System.Data.DataTable> Configuration(string ExcelFilePath, string ExcelTemplate)
        {
            Dictionary<string, System.Data.DataTable> dictData = new Dictionary<string, System.Data.DataTable>();
            try
            {

                //log.InfoFormat("Reading Excel File: {0}", ExcelFilePath);
                string ExcelTemplateSource = ConfigurationManager.AppSettings["ExcelTemplateSource"].ToLower().Trim();
                ExcelTemplate excelTemplate = new ExcelTemplate();
                string strDataSet = string.Empty;
                string strProcDetails = string.Empty;
                string strError = string.Empty;


                excelTemplate = excelTemplate.LoadFromFile(ExcelTemplateSource);
                excelTemplate.Workbook = new List<WorkbookTemplate>()
                        {
                            excelTemplate.Workbook.Where(W=>W.Template_Name==ExcelTemplate).SingleOrDefault()
                        };

                //ExcelRead ER = new ExcelRead();
                dictData = ReadExcelData(excelTemplate, ExcelFilePath);
                //dictData = ReadExcelData(excelTemplate, ExcelFilePath);
                System.Data.DataTable dt1 = dictData["RatingType"];
                System.Data.DataTable dt2 = dictData["RatingGroup"];
                System.Data.DataTable dt3 = dictData["Category"];
                System.Data.DataTable dt4 = dictData["Heading"];
                System.Data.DataTable dt5 = dictData["CTQ"];
                System.Data.DataTable dt6 = dictData["SubDefect1"];
                System.Data.DataTable dt7 = dictData["SubDefect2"];
                System.Data.DataTable dt8 = dictData["SubDefect3"];
                System.Data.DataTable dt9 = dictData["SubDefect4"];
                System.Data.DataTable dt10 = dictData["SubDefect5"];
                System.Data.DataTable dt11 = dictData["CombinedAccuracy"];

                DataSet objTablesData = new DataSet();

                objTablesData.Tables.Add(dt1);
                objTablesData.Tables.Add(dt2);
                objTablesData.Tables.Add(dt3);
                objTablesData.Tables.Add(dt4);
                objTablesData.Tables.Add(dt5);
                objTablesData.Tables.Add(dt6);
                objTablesData.Tables.Add(dt7);
                objTablesData.Tables.Add(dt8);
                objTablesData.Tables.Add(dt9);
                objTablesData.Tables.Add(dt10);
                objTablesData.Tables.Add(dt11);

                AuditConfigurationDAO AC = new AuditConfigurationDAO();
                //HierarchyDataAccess HD = new HierarchyDataAccess();
                //DataSet ds = HD.InsertHierarchyrans(objTablesData);


            }

            catch (Exception excep)
            {
                // log.Error(excep.Message);
                // log.Error(excep.StackTrace);
                throw excep;
            }

            return dictData;
        }

        //public override Dictionary<string, System.Data.DataTable> ExcelReader(string excelFilePath, string templateName)
        //{
        //    try
        //    {
        //        LoggingFactory objloggingfactory = new LoggingFactory();
        //        LogInfo objlog = new LogInfo();

        //        string ExcelTemplateSource = ConfigurationManager.AppSettings["ExcelTemplateSource"].ToLower().Trim();
        //        ExcelTemplate excelTemplate = new ExcelTemplate();

        //        if (ExcelTemplateSource == "database")
        //        {
        //            //  DAL dal = new DAL();
        //            //User us = new User();
        //            DataSet dataset = ad.GetExcelTemplate();
        //            if (dataset.Tables.Count > 0 && dataset.Tables[0].Rows.Count > 0)
        //            {
        //                string xmlData = dataset.Tables[0].Rows[0]["TemplateData"].ToString();
        //                excelTemplate = excelTemplate.LoadFromXml(xmlData);
        //                excelTemplate.Workbook = new List<WorkbookTemplate>()
        //                {
        //                    excelTemplate.Workbook.Where(W=>W.Template_Name==templateName).SingleOrDefault()
        //                };
        //                return ReadExcelData(excelTemplate, excelFilePath);
        //            }
        //            else
        //            {
        //                throw new ApplicationException("No  excel template data found in database");
        //            }
        //        }
        //        else
        //        {
        //            excelTemplate = excelTemplate.LoadFromFile(ExcelTemplateSource);
        //            excelTemplate.Workbook = new List<WorkbookTemplate>()
        //                {
        //                    excelTemplate.Workbook.Where(W=>W.Template_Name==templateName).SingleOrDefault()
        //                };
        //            return ReadExcelData(excelTemplate, excelFilePath);
        //        }
        //    }
        //    catch (Exception excep)
        //    {
        //        //log.Error(excep.Message);
        //        //log.Error(excep.StackTrace);
        //        throw excep;
        //    }
        //}
        //private Dictionary<string, System.Data.DataTable> ReadExcelData(ExcelTemplate excelTemplate, string ExcelFilePath)
        //{
        //    try
        //    {
        //        Dictionary<string, System.Data.DataTable> dicDT = new Dictionary<string, System.Data.DataTable>();
        //        FileStream stream = File.Open(ExcelFilePath, FileMode.Open, FileAccess.Read);
        //        IExcelDataReader excelReader = null;

        //        if (ExcelFilePath.ToLower().EndsWith("xlsx"))
        //            excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream); //Reading from a OpenXml Excel file (2007 format; *.xlsx)
        //        else if (ExcelFilePath.ToLower().EndsWith("xls"))
        //            excelReader = ExcelReaderFactory.CreateBinaryReader(stream); //Reading from a binary Excel file ('97-2003 format; *.xls)
        //        DataSet result = excelReader.AsDataSet();
        //        excelReader.IsFirstRowAsColumnNames = false;
        //        if (excelTemplate.Workbook.Count > 0 && result.Tables.Count > 0)
        //        {
        //            for (int i = 0; i < excelTemplate.Workbook[0].WorkSheet.Count; i++)
        //            {
        //                System.Data.DataTable dTab = new System.Data.DataTable();
        //                dTab.TableName = excelTemplate.Workbook[0].WorkSheet[i].WorkSheetName;
        //                //inserting the header row
        //                for (int Col = 0; Col < excelTemplate.Workbook[0].WorkSheet[i].columnTemplate.Count; Col++)
        //                    dTab.Columns.Add(excelTemplate.Workbook[0].WorkSheet[i].columnTemplate[Col].Col_header_name);
        //                int TabIndex = GetTableIndex(result.Tables, dTab.TableName);
        //                if (TabIndex >= 0)
        //                {
        //                    System.Data.DataTable tempTab = result.Tables[TabIndex].Rows.Cast<DataRow>().
        //                                                    Where(row => !row.ItemArray.
        //                                                        All(field => field is System.DBNull)).
        //                                                    CopyToDataTable();
        //                    foreach (var column in result.Tables[TabIndex].Columns.Cast<DataColumn>().ToArray())
        //                    {
        //                        if (result.Tables[TabIndex].AsEnumerable().All(dr => dr.IsNull(column)))
        //                            result.Tables[TabIndex].Columns.Remove(column);
        //                    }

        //                    int HeaderStartRow = Convert.ToInt32(excelTemplate.Workbook[0].WorkSheet[i].headerTemplate.Header_Row_No.ToString()) - 1;
        //                    int DataStartRow = Convert.ToInt32(excelTemplate.Workbook[0].WorkSheet[i].headerTemplate.Data_Start_Row) - 1;
        //                    dTab = ReadDataToTable(excelTemplate.Workbook[0].WorkSheet[i].columnTemplate, tempTab, dTab, HeaderStartRow, DataStartRow);

        //                    //int HeaderStartRow = GetHeaderStartRow(excelTemplate.Workbook[0].WorkSheet[i].headerTemplate.Data_Start_Row.ToString(), tempTab, excelTemplate.Workbook[0].WorkSheet[i].columnTemplate);
        //                    //int DataStartRow;// = Convert.ToInt32(excelTemplate.Workbook[0].WorkSheet[i].headerTemplate.Data_Start_Row);
        //                    //if (HeaderStartRow >= 0)
        //                    //{
        //                    //    DataStartRow = HeaderStartRow + 1;
        //                    //    dTab = ReadDataToTable(excelTemplate.Workbook[0].WorkSheet[i].columnTemplate, tempTab, dTab, HeaderStartRow, DataStartRow);
        //                    //}
        //                }
        //                dTab.AcceptChanges();
        //                dicDT.Add(dTab.TableName.ToString(), dTab);
        //            }
        //        }



        //        excelReader.Close();
        //        //log.InfoFormat("BGV Reading completed for the file: {0}", ExcelFilePath);
        //        return dicDT;
        //    }
        //    catch (Exception ex)
        //    {
        //        //log.Error(ex.Message);
        //        //log.Error(ex.StackTrace);
        //        throw ex;
        //    }
        //}

        //private int GetHeaderStartRow(string DataStartRowVal, System.Data.DataTable tempTab, List<ColumnTemplate> columnTemplates)
        //{
        //    try
        //    {
        //        int ColHeaderRow = -1;
        //        Dictionary<string, int> ColHeaderDict = new Dictionary<string, int>();
        //        if (DataStartRowVal == null)
        //            return ColHeaderRow;
        //        else
        //        {
        //            if (int.TryParse(DataStartRowVal.Trim(), out ColHeaderRow))
        //                return ColHeaderRow;
        //            else
        //            {
        //                foreach (ColumnTemplate colTemplate in columnTemplates)
        //                {
        //                    bool flag = false;
        //                    string columnheadername = colTemplate.Col_header_name;
        //                    for (int row = 0; row < tempTab.Rows.Count; row++)
        //                    {
        //                        for (int col = 0; col < tempTab.Columns.Count; col++)
        //                        {
        //                            string colName = tempTab.Rows[row].ItemArray[col].ToString().Trim().ToUpper();
        //                            if (colName == columnheadername.Trim().ToUpper())
        //                            {
        //                                ColHeaderDict.Add(columnheadername, row);
        //                                break;
        //                            }
        //                        }
        //                        if (flag)
        //                            break;
        //                    }
        //                }
        //                ColHeaderRow = Convert.ToInt32(ColHeaderDict.OrderByDescending(r => r.Value)
        //                                .Select(r => r.Value)
        //                                .Take(1));
        //                return ColHeaderRow;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //log.Error(ex.Message);
        //        //log.Error(ex.StackTrace);
        //        throw ex;
        //    }
        //}

        //private System.Data.DataTable ReadDataToTable(List<ColumnTemplate> columnTemplates, System.Data.DataTable tempTab, System.Data.DataTable dTab1, int HeaderStartRow, int DataStartRow)
        //{
        //    try
        //    {
        //        int rowRange = tempTab.Rows.Count;
        //        int colRange = tempTab.Columns.Count;
        //        Dictionary<int, string> columnIndex = new Dictionary<int, string>();
        //        foreach (ColumnTemplate colTemplate in columnTemplates)
        //        {
        //            if (colTemplate.Readiability.Equals("T"))
        //            {
        //                string columnheadername = colTemplate.Col_header_name;
        //                int columnnumber = -1;
        //                for (int j = 0; j < colRange; j++)
        //                {
        //                    string colName = tempTab.Rows[HeaderStartRow].ItemArray[j].ToString().Trim().ToUpper();
        //                    if (colName == columnheadername.Trim().ToUpper())
        //                    {
        //                        columnnumber = j;
        //                        break;
        //                    }
        //                }
        //                if (columnnumber != -1)
        //                    columnIndex.Add(columnnumber, "T");
        //                else
        //                    columnIndex.Add(Convert.ToInt32(colTemplate.Col_no) - 1, "F");
        //            }
        //            else
        //                columnIndex.Add(Convert.ToInt32(colTemplate.Col_no) - 1, "T");
        //        }

        //        //Extract Data
        //        DataSet result1 = new DataSet();
        //        DataSet result2 = new DataSet();
        //        DataSet result3 = new DataSet();
        //        for (int rowIndex = DataStartRow; rowIndex < rowRange; rowIndex++)
        //        {
        //            DataRow dRow = dTab1.NewRow();
        //            int colinc = 0;
        //            foreach (var pair in columnIndex)
        //            {
        //                if (pair.Key <= colRange && pair.Value == "T")
        //                {
        //                    dRow[colinc++] = tempTab.Rows[rowIndex].ItemArray[pair.Key].ToString().Trim();
        //                    //Console.WriteLine(tempTab.Rows[rowIndex].ItemArray[pair.Key].ToString());
        //                }
        //                else
        //                    dRow[colinc++] = string.Empty;
        //            }
        //            if (!dRow.ItemArray.All(i => (i is DBNull || string.Compare(i as string, string.Empty) == 0)))
        //            {
        //                dTab1.Rows.Add(dRow);
        //                dTab1.AcceptChanges();

        //               // DataSet result1 = new DataSet();
                        
                       
        //                result1.Tables.Add(dTab1);
        //                //result2.Tables.Add(dTab1);
        //                //result3.Tables.Add(dTab1);
        //                //ad.excelreader(result1);

        //                result1.Tables.Remove(dTab1);
        //            }
        //        }
        //        if (dTab1.TableName == "RatingType")
        //        {
        //            ad.Ratingtype(dTab1);
        //        }
        //        else if (dTab1.TableName == "RatingGroup")
        //        {
        //            ad.Ratinggroup(dTab1);
        //        }
        //        else if (dTab1.TableName == "Category" || dTab1.TableName == "Heading" || dTab1.TableName == "CTQ")  
        //        {

        //            ad.defectopportunity(dTab1);
        //        }
        //        else if(dTab1.TableName == "SubDefect1" || dTab1.TableName == "SubDefect2" || dTab1.TableName == "SubDefect3" || dTab1.TableName == "SubDefect4" || dTab1.TableName == "SubDefect5")
        //        {
        //            ad.subdefectopportunity(dTab1);
        //        }

        //        else if(dTab1.TableName == "CombinedAccuracy")
        //        {
        //            ad.CombinedAccuracy(dTab1);
        //        }
                               
        //    }
        //    catch (Exception ex)
        //    {
        //        //log.Error(ex.Message);
        //        //log.Error(ex.StackTrace);
        //        throw ex;
        //    }
        //    return dTab1;
        //    // excelReader.IsFirstRowAsColumnNames = true;



        //}

        //private int GetTableIndex(DataTableCollection dataTableCollection, string sheetName)
        //{
        //    for (int ctr = 0; ctr <= dataTableCollection.Count && ctr < dataTableCollection.Count; ctr++)
        //    {
        //        if (dataTableCollection[ctr].TableName.Trim().ToLower() == sheetName.Trim().ToLower())
        //            return ctr;
        //    }
        //    return -1;
        //}        
    }
}
