﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using Excel;
using System.Collections;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Xml.Linq;


namespace DigiOPS.TechFoundation.BulkUploadConfiguration
{
    public class HierarchyConfiguration:BaseConfiguration
    {
        public override Dictionary<string, System.Data.DataTable> Configuration(string ExcelFilePath, string ExcelTemplate)
        {
            Dictionary<string, System.Data.DataTable> dictData = new Dictionary<string, System.Data.DataTable>();
            try
            {

                //log.InfoFormat("Reading Excel File: {0}", ExcelFilePath);
                string ExcelTemplateSource = ConfigurationManager.AppSettings["ExcelTemplateSource"].ToLower().Trim();
                ExcelTemplate excelTemplate = new ExcelTemplate();
                string strDataSet = string.Empty;
                string strProcDetails = string.Empty;
                string strError = string.Empty;


                excelTemplate = excelTemplate.LoadFromFile(ExcelTemplateSource);
                excelTemplate.Workbook = new List<WorkbookTemplate>()
                        {
                            excelTemplate.Workbook.Where(W=>W.Template_Name==ExcelTemplate).SingleOrDefault()
                        };

                //ExcelRead ER = new ExcelRead();
                dictData = ReadExcelData(excelTemplate, ExcelFilePath);
                //dictData = ReadExcelData(excelTemplate, ExcelFilePath);
                System.Data.DataTable dt1 = dictData["Process"];
                System.Data.DataTable dt2 = dictData["SubProcess"];

                DataSet objTablesData = new DataSet();

                objTablesData.Tables.Add(dt1);
                objTablesData.Tables.Add(dt2);
               
                HierarchyDataAccess HD = new HierarchyDataAccess();
               DataSet ds = HD.InsertHierarchyrans(objTablesData);
               

            }

            catch (Exception excep)
            {
                // log.Error(excep.Message);
                // log.Error(excep.StackTrace);
                throw excep;
            }
         
            return dictData;
        }
        

    }
}
