﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.BulkUploadConfiguration
{
   public interface IConfiguration
    {
       Dictionary<string, System.Data.DataTable> Configuration(string ExcelFilePath, string ExcelTemplate);
    }
}
