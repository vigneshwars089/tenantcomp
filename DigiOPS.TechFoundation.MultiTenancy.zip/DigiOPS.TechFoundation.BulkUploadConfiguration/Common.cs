﻿using System;
using System.Diagnostics;
using System.Xml.Serialization;
using System.Collections;
using System.Xml.Schema;
using System.ComponentModel;
using System.IO;
using System.Text;
using System.Collections.Generic;


namespace DigiOPS.TechFoundation.BulkUploadConfiguration
{
    
    [Serializable]
    public class ColumnTemplate
    {
        [XmlAttributeAttribute("_SEQ_NO")]
        public string Seq_no { get; set; }

        [XmlAttributeAttribute("_COL_NO")]
        public string Col_no { get; set; }

        [XmlAttributeAttribute("_COL_HEADER_NAME")]
        public string Col_header_name { get; set; }

        [XmlAttributeAttribute("_COL_DATA_TYPE")]
        public string Col_data_type { get; set; }

        [XmlAttributeAttribute("_READIABILITY")]
        public string Readiability { get; set; }
    }


    [Serializable]
    public class HeaderTemplate
    {
        [XmlAttributeAttribute("_ROW_NO")]
        public string Header_Row_No { get; set; }

        [XmlAttributeAttribute("_DATA_START_ROW")]
        public string Data_Start_Row { get; set; }
    }

    [Serializable]
    public class WorkSheetTemplate
    {
        [XmlAttributeAttribute("_NAME")]
        public string WorkSheetName { get; set; }

        [XmlAttributeAttribute("_HEADER_PRESENT")]
        public string HEADER_PRESENT { get; set; }

        [XmlAttributeAttribute("_SINGLE_ROW")]
        public string SINGLE_ROW { get; set; }

        [XmlElement("HEADER")]
        public HeaderTemplate headerTemplate { get; set; }

        [XmlElement("COLUMN")]
        public List<ColumnTemplate> columnTemplate { get; set; }

    }

    [Serializable]
    public class WorkbookTemplate
    {
        [XmlElement("WORKSHEET")]
        public List<WorkSheetTemplate> WorkSheet { get; set; }

        [XmlAttributeAttribute("_NAME")]
        public string Template_Name { get; set; }

        [XmlAttributeAttribute("_MULTISHEET")]
        public string Multisheet { get; set; }
    }

    [Serializable]
    [XmlRoot("EXCEL_TEMPLATE_DEFINITIONS")]
    public class ExcelTemplate
    {
        [XmlElement("TEMPLATE")]
        public List<WorkbookTemplate> Workbook { get; set; }

        #region Serialize/Deserialize
        /// <summary>
        /// Serializes current ExcelTemplate object into an XML document
        /// </summary>
        /// <returns>string XML value</returns>
        private string Serialize()
        {
            System.IO.StreamReader streamReader = null;
            System.IO.MemoryStream memoryStream = null;
            try
            {
                memoryStream = new System.IO.MemoryStream();
                XmlSerializer serializer = new XmlSerializer(typeof(ExcelTemplate));

                serializer.Serialize(memoryStream, this);
                memoryStream.Seek(0, System.IO.SeekOrigin.Begin);
                streamReader = new System.IO.StreamReader(memoryStream);
                return streamReader.ReadToEnd();
            }
            finally
            {
                if ((streamReader != null))
                {
                    streamReader.Dispose();
                }
                if ((memoryStream != null))
                {
                    memoryStream.Dispose();
                }
            }
        }


        private ExcelTemplate Deserialize(string xml)
        {
            System.IO.StringReader stringReader = null;
            try
            {
                stringReader = new System.IO.StringReader(xml);
                XmlSerializer serializer = new XmlSerializer(typeof(ExcelTemplate));
                return ((ExcelTemplate)(serializer.Deserialize(System.Xml.XmlReader.Create(stringReader))));
            }
            finally
            {
                if ((stringReader != null))
                {
                    stringReader.Dispose();
                }
            }
        }


        public void SaveToFile(string fileName)
        {
            System.IO.StreamWriter streamWriter = null;
            try
            {
                string xmlString = this.Serialize();
                System.IO.FileInfo xmlFile = new System.IO.FileInfo(fileName);
                streamWriter = xmlFile.CreateText();
                streamWriter.WriteLine(xmlString);
                streamWriter.Close();
            }
            finally
            {
                if ((streamWriter != null))
                {
                    streamWriter.Dispose();
                }
            }
        }

        public ExcelTemplate LoadFromFile(string fileName)
        {
            System.IO.FileStream file = null;
            System.IO.StreamReader sr = null;
            try
            {
                file = new System.IO.FileStream(fileName, FileMode.Open, FileAccess.Read);
                sr = new System.IO.StreamReader(file);
                string xmlString = sr.ReadToEnd();
                sr.Close();
                file.Close();
                return Deserialize(xmlString);
            }
            finally
            {
                if ((file != null))
                {
                    file.Dispose();
                }
                if ((sr != null))
                {
                    sr.Dispose();
                }
            }
        }

        public ExcelTemplate LoadFromXml(string xml)
        {
            return Deserialize(xml);
        }

        #endregion
    }
}
