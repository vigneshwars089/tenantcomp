﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Security;
using Microsoft.Exchange.WebServices.Data;

namespace DigiOPS.TechFoundation.EmailCaseCreation
{
    public class OutLookMailReading : BaseMailReading
    {
        ILoggingFactory objlog = new LoggingFactory();

        public string _applicationError = string.Empty;
             
        public ExchangeService service;
       // public Guid propertySetId = new Guid("{F4FD924D-5489-4AE1-BD43-25491342529B}");       
        static String encryptionKey = ConfigurationSettings.AppSettings["ENCRYPTIONKEY"].ToString();
        static String encryptionmode = ConfigurationSettings.AppSettings["ENCRYPT/DECRYPT"].ToString();
            
       
        public override void readMail(EMailInfo emailInfo)
        {
            SecureString sec_strPassword = new SecureString();
                 
            emailInfo.strMailStarHeader = ExchangeConstants.STAR;
            emailInfo.currentTime = Convert.ToString(DateTime.Now);
            emailInfo.strMailStarHeader = emailInfo.strMailStarHeader + ExchangeConstants.NEW_LINE + "RunTime: " + emailInfo.currentTime;
            emailInfo.filename = string.Empty;
                       
            var doneEvents = new List<ManualResetEvent>();
            var list = new List<int>();
            int s = 0;

            try
            {               
                EmailInput input = new EmailInput();

                // Main loop for different mail box
                foreach (var emlist in emailInfo.EmailInputList)
                {
                    input.strpath = emlist.strpath;
                    input.strname = emlist.strname;
                    //emailInfo.strname = "cts";
                    input.strMailHeader = ExchangeConstants.NEW_LINE + "Mail Box Name:" + input.strname + ExchangeConstants.NEW_LINE;
                   // emailInfo.EMailId = "Megha.Patil@cognizant.com";
                    input.EMailId = emlist.EMailId;
                    input.LoginEMailId = emlist.LoginEMailId;
                   // emailInfo.LoginEMailId = "391099";
                    
                    if (encryptionmode == "ON")
                    {
                        OutLookMailReading miscObj = new OutLookMailReading();
                        CryptInfo cryptInfo = new CryptInfo();
                        SecurityFactory securityFactory = new SecurityFactory();
                        cryptInfo.CryptKey = encryptionKey;
                        cryptInfo.ValueToCrypt = ((emlist.password != null && emlist.password != "") ? emlist.password : "");
                        SecureString secureString = new SecureString();

                        sec_strPassword = miscObj.convertToSecureString(securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo));
                    }

                    else
                    {
                        OutLookMailReading miscObj2 = new OutLookMailReading();
                        //sec_strPassword = miscObj2.convertToSecureString(((ds.Tables[0].Rows[s][ExchangeConstants.SP_DATASET_PASSWORD] != null && ds.Tables[0].Rows[s][ExchangeConstants.SP_DATASET_PASSWORD].ToString() != "") ? ds.Tables[0].Rows[s][ExchangeConstants.SP_DATASET_PASSWORD].ToString() : ""));
                        //sec_strPassword = miscObj2.convertToSecureString("meghjeen-2");
                        sec_strPassword = miscObj2.convertToSecureString(emlist.password);
                    }


                    input.intmailfolderid = emlist.intmailfolderid;
                    input.strMailHeader = emlist.strMailHeader + ExchangeConstants.NEW_LINE + "S.No" + "," + "Action" + "," + "CaseId" + "," + "FolderName" + "," + "ActualEml" + "," + "TargetEml" + "," + "ReceivedDate" + "," + "CreatedDate" + ExchangeConstants.NEW_LINE;
                    input.TimeZone = ((emlist.TimeZone != null && emlist.TimeZone != "") ? (emlist.TimeZone) : "");

                    Console.WriteLine("Connecting to Exchange Online, please wait...");
                    
                    if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2013_SP1")
                    {
                        service = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                    }
                    else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2007_SP1")
                    {
                        service = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
                    }
                    else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2010")
                    {
                        service = new ExchangeService(ExchangeVersion.Exchange2010);
                    }
                    else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2010_SP1")
                    {
                        service = new ExchangeService(ExchangeVersion.Exchange2010_SP1);
                    }
                    else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2010_SP2")
                    {
                        service = new ExchangeService(ExchangeVersion.Exchange2010_SP2);
                    }
                    else if (System.Configuration.ConfigurationSettings.AppSettings.Get("ClientExVersion") == "Exchange2013")
                    {
                        service = new ExchangeService(ExchangeVersion.Exchange2013);
                    }
                    else
                    {
                        service = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                    }

                    OutLookMailReading miscObj1 = new OutLookMailReading();
                    service.Url = new Uri(input.strpath);
                    if (System.Configuration.ConfigurationSettings.AppSettings.Get("Domian").ToString() != "")
                        service.Credentials = new WebCredentials(input.LoginEMailId, miscObj1.convertToUNSecureString(sec_strPassword), System.Configuration.ConfigurationSettings.AppSettings.Get("Domian").ToString());
                    else
                        service.Credentials = new WebCredentials(input.LoginEMailId, miscObj1.convertToUNSecureString(sec_strPassword));
                    service.TraceEnabled = false;
                                       
                    var resetEvent = new ManualResetEvent(false);

                    list.Add(s);
                    var processorcount = Environment.ProcessorCount;
                                       
                    ThreadPool.QueueUserWorkItem(
                         new WaitCallback(x =>
                         {
                             FindEmail(new MainBoxInfo
                             {
                                 CIntmailfolderid = input.intmailfolderid,
                                 CEMailId = input.EMailId,
                                 CLoginEMailId = input.LoginEMailId,
                                 CTimeZone = input.TimeZone,
                                 CService = service
                             });
                             resetEvent.Set();
                         }), list[s]);

                    doneEvents.Add(resetEvent);

                   s++;
                  // string strParam1 = "yes";
                  // Trace.WriteLine("param1: " + strParam1);
                }
                              
                WaitHandle.WaitAll(doneEvents.ToArray());               
            }

            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;          
            }
           
        }

        public void FindEmail(object threadState)
        {
            EMailInfo emailInfo = new EMailInfo();

            var emailBoxInfo = (MainBoxInfo)threadState;
            string intmailfolderid = emailBoxInfo.CIntmailfolderid;
            string EMailBoxId = emailBoxInfo.CEMailId;
            string LoginEMailId = emailBoxInfo.CLoginEMailId;
            string TimeZone = emailBoxInfo.CTimeZone;
            ExchangeService service = emailBoxInfo.CService;           
            int rv = 0;

            try
            {               
               
               
                EmailCaseCreationDAO p1 = new EmailCaseCreationDAO();
                emailInfo.subject_flag = 0;
                string caseid = string.Empty;
                string strSubject = string.Empty;
                string BodyText = "";
                string strFrom = string.Empty;
                string objTo = string.Empty;
                string objCC = "";
                string objBCC = "";
                               
                string folder = string.Empty;
                string mailPath = ConfigurationSettings.AppSettings["MailPath"];
                string SubjectKeyword = ConfigurationSettings.AppSettings["SubjectKeyword"];//18jun2014
                string CaseIdKeyword = ConfigurationSettings.AppSettings["CaseIdKeyword"];// 18jun2014

                CryptInfo cryptInfo = new CryptInfo();
                SecurityFactory securityFactory = new SecurityFactory();

                folder = mailPath;
                DateTime dtrec;
                ShowMessage("Searching E-mail, please wait...");

                Mailbox EMailBox = new Mailbox(emailInfo.EMailBoxId);
                FolderId FolderId = new FolderId(WellKnownFolderName.Inbox, EMailBox);
                FolderId RootFolderId = new FolderId(WellKnownFolderName.MsgFolderRoot, EMailBox);
                System.Threading.Thread.Sleep(2000);


                // View creation with Cap limit of reading mails in Received Date Asc order 
                var iv = new ItemView(30);
                iv.OrderBy.Add(ItemSchema.DateTimeReceived, SortDirection.Ascending);

               
                FindItemsResults<Item> foundItems = service.FindItems(FolderId, iv);
                
                Folder readmailFolder = GetFolderFromName(service, "Read", RootFolderId);
                System.Threading.Thread.Sleep(2000);

                Folder unreadmailFolder = GetFolderFromName(service, "UnRead", RootFolderId);

                string dtMailPullingStartTime = DateTime.Now.ToLongTimeString();
                int NewMailCount = 0;
                int FollowupMailCount = 0;
                int flag = 0;
                foreach (EmailMessage item in foundItems)
                {
                   
                    item.Load();
                    strFrom = string.Empty;
                    objTo = string.Empty;
                    objCC = string.Empty;
                    objBCC = string.Empty;
                    BodyText = "";
                    emailInfo.spSubject = string.Empty;
                                       
                    string[] str = new string[50];

                    if (item is EmailMessage)
                    {
                        bool ReadMoved = false;

                        EmailMessage foundEmail = (EmailMessage)item;
                        EmailMessage message = EmailMessage.Bind(service, new ItemId(item.Id.ToString()), new PropertySet(BasePropertySet.FirstClassProperties, ItemSchema.Attachments, ItemSchema.Body));

                    
                        dtrec = foundEmail.DateTimeReceived;

                        if (message.Subject != null)
                            emailInfo.spSubject = Convert.ToString(message.Subject);

                        if (!emailInfo.spSubject.ToLower().Contains("out of office autoreply") && !emailInfo.spSubject.ToLower().Contains("message recall failure:") && !emailInfo.spSubject.ToLower().Contains("read:") && !emailInfo.spSubject.ToLower().Contains("message recall success:") && !emailInfo.spSubject.ToLower().Trim().Contains("undeliverable:") && !emailInfo.spSubject.ToLower().Contains("not read:") && !emailInfo.spSubject.ToLower().Contains("automatic reply") && !emailInfo.spSubject.ToLower().Contains("auto acknowledgement") && !emailInfo.spSubject.ToLower().Contains("delivery delayed"))
                        {

                            if (message.Body != null)
                                BodyText = Convert.ToString(message.Body);
                            if (message.From.Address != null)
                                strFrom = Convert.ToString(message.From.Address);
                            if (message.ToRecipients != null)
                            {
                                for (int j = 0; j < message.ToRecipients.Count; j++)
                                {
                                    if (j >= 1)
                                        objTo = objTo + ";" + message.ToRecipients[j].Address;
                                    else
                                        objTo = message.ToRecipients[j].Address;
                                }
                            }
                            if (message.CcRecipients != null)
                            {
                                for (int j = 0; j < message.CcRecipients.Count; j++)
                                {
                                    if (j >= 1)
                                        objCC = objCC + ";" + message.CcRecipients[j].Address;
                                    else
                                        objCC = message.CcRecipients[j].Address;
                                }
                            }

                            bool Priority = (message.Importance.ToString() == "Low" || message.Importance.ToString() == "Normal" ? false : true);

                            if (!Priority)
                            {
                                if (emailInfo.spSubject.ToLower().Contains("urgent"))
                                {
                                    Priority = true;
                                }
                            }

                            objBCC = string.Empty;

                            StringBuilder mailShortInfo = new StringBuilder();
                            mailShortInfo.Append("<div style='border: none; border-top: solid #B5C4DF 1.0pt; padding: 3.0pt 0in 0in 0in'><p class='MsoNormal'><b><span style='font-size: 10.0pt; font-family: Tahoma,sans-serif'>");
                            mailShortInfo.Append("From: ");
                            mailShortInfo.Append("</span></b><span style='font-size: 10.0pt; font-family: Tahoma,sans-serif'>");
                            mailShortInfo.Append(strFrom + "<br/>");
                            mailShortInfo.Append("<b>Sent: </b>" + message.DateTimeSent.ToLongDateString() + " " + message.DateTimeSent.ToShortTimeString() + "<br/>");
                            mailShortInfo.Append("<b>To: </b>" + objTo.ToString() + "<br/>");
                            if (objCC.Length > 0)
                            {
                                mailShortInfo.Append("<b>Cc: </b>" + objCC.ToString() + "<br/>");
                            }
                            if (objBCC.Length > 0)
                            {
                                mailShortInfo.Append("<b>Bcc: </b>" + objBCC.ToString() + "<br/>");
                            }
                            mailShortInfo.Append("<b>Subject: </b>" + emailInfo.spSubject.ToString());
                            if (Priority)
                                mailShortInfo.Append("<br/><b>Importance: </b>" + message.Importance.ToString());
                            mailShortInfo.Append("</span>");
                            mailShortInfo.Append("</p></div><br/>");

                            string LOAN = string.Empty;
                            string loanno = string.Empty;

                            // GET FROM,TO,CC,BCC,SUBJECT..

                            if (BodyText != null)
                            {
                                if (BodyText.Contains("<html"))
                                {
                                    BodyText = concat(BodyText.ToString(), mailShortInfo.ToString());
                                }
                                else
                                {
                                    BodyText = mailShortInfo.ToString() + BodyText.ToString();

                                    string st = BodyText;
                                    st = BodyText.Replace("\r\n", "<br/>");
                                    st = st.Replace("\n", "<br/>");
                                    st = st.Replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;");
                                    BodyText = st;
                                }

                                LOAN = GetStringInBetween("Loan no:", "Adr :", BodyText);
                                loanno = HTMLToText(LOAN);
                            }
                            else
                            {
                                BodyText = "";
                                LOAN = "";
                                loanno = "";
                            }

                            string newSubject = emailInfo.spSubject;
                            string strCaseID = string.Empty;

                           
                            if (emailInfo.spSubject.ToLower().Contains(CaseIdKeyword))
                            {
                                try
                                {
                                    List<string> listCase = new List<string>();
                                    listCase = ExtractNumbers(emailInfo.spSubject);
                                    strCaseID = listCase[0].ToString();
                                    string strSubCaseid = string.Empty;

                                    if (listCase[1] != null)
                                    {
                                        if (listCase[1] == "-")
                                        {
                                            if (listCase.Count > 2)
                                            {
                                                if (isNumeric(Convert.ToString(listCase[2]), System.Globalization.NumberStyles.Integer))
                                                {
                                                    strSubCaseid = Convert.ToString(listCase[2]);
                                                }
                                            }
                                        }
                                        else
                                            strCaseID = string.Empty;

                                    }

                              
                                    if (strCaseID != "")
                                        newSubject = newSubject.Replace(strCaseID, "");

                                    if (strSubCaseid.Length > 0)
                                    {
                                        newSubject = newSubject.Replace(strSubCaseid, "");
                                    }

                                    newSubject = newSubject.Replace("CaseID", "").Replace("CASEID:  - ", "");
                                }
                                catch (Exception ex)
                                {
                                    objlog.GetLoggingHandler("Log4net").LogException(ex);
                                    throw;
                                }
                            }

                            //Checking Inline Images/screenshots

                            string sourceText = BodyText;
                            var imgSrcMatches = System.Text.RegularExpressions.Regex.Matches(sourceText,
                                  string.Format("<img.+?src=[\"'](.+?)[\"'].*?>"),
                                                                
                                        RegexOptions.CultureInvariant | RegexOptions.IgnoreCase |
                                        RegexOptions.Multiline);

                            List<string> imgSrcs = new List<string>();
                            foreach (Match match in imgSrcMatches)
                            {
                                string[] Names = match.Groups[1].Value.Split('@');

                                imgSrcs.Add(Names[0].Replace("cid:", ""));

                            }

                            try
                            {
                                if (imgSrcs.Count > 0)
                                {
                                    for (int i = 0; i < imgSrcs.Count; i++)
                                    {
                                        if (imgSrcs[i].ToString().Contains("\\"))
                                        {
                                            imgSrcs[i] = imgSrcs[i].ToString().Replace("\\", "/");
                                        }

                                        var imgmatchs = System.Text.RegularExpressions.Regex.Matches(BodyText,
                                            string.Format("<img.+?src=[\"'](cid:" + imgSrcs[i].ToString() + ".+?)[\"'].*?>"),
                                            RegexOptions.CultureInvariant | RegexOptions.IgnoreCase |
                                            RegexOptions.Multiline);

                                        foreach (Match match in imgmatchs)
                                        {
                                           
                                            if (!imgSrcs[i].ToString().Contains(".png"))
                                                BodyText = BodyText.Replace(match.Groups[1].Value, "cid:" + imgSrcs[i].ToString() + ".png");
                                            else
                                                BodyText = BodyText.Replace(match.Groups[1].Value, "cid:" + imgSrcs[i].ToString());
                                                                                        
                                            break;
                                        }
                                       
                                    }
                                }

                            }
                            catch (Exception ex)
                            {
                                objlog.GetLoggingHandler("Log4net").LogException(ex);
                                throw;                          
                            }
                            EMailInfo ec = new EMailInfo();
                            ec.caseID = strCaseID;
                            //int currentStatus = p1.GetCaseStatus(strCaseID);
                            int currentStatus = p1.GetCaseStatus(ec);
                          
                            if (emailInfo.spSubject.ToLower().Contains(CaseIdKeyword) && currentStatus != 10 && strCaseID != "")
                            {
                                emailInfo.subject_flag = 2;
                                List<string> caselist = new List<string>();
                                caselist = ExtractNumbers(emailInfo.spSubject);
                                emailInfo.caseID = caselist[0].ToString();
                                string subcaseid = null;
                                if (caselist[1] != null)
                                {
                                    if (caselist[1] == "-")
                                    {
                                        if (isNumeric(Convert.ToString(caselist[2]), System.Globalization.NumberStyles.Integer))
                                        {
                                            subcaseid = Convert.ToString(caselist[2]);
                                        }
                                    }
                                }
                                //encryption     
                                if (encryptionmode == "ON")
                                {
                                    cryptInfo.CryptKey = encryptionKey;
                                    cryptInfo.ValueToCrypt = emailInfo.spSubject;
                                    string encryptedstrSubject = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
                                    emailInfo.spSubject = encryptedstrSubject;
                                    cryptInfo.ValueToCrypt = BodyText;
                                    string encryptedBodyText = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
                                    BodyText = encryptedBodyText;
                                }

                                //int rv = p1.FollowupMail(caseid, dtrec.ToString(), intmailfolderid, "1", strSubject, BodyText, strFrom, objTo.ToString(), objCC.ToString(), objBCC.ToString(), subcaseid, Priority);
                                EMailInfo ec1=new EMailInfo();
                                ec1.caseID=caseid;
                                ec1.spDate = dtrec;
                                ec1.spMailFolderId=intmailfolderid;
                                ec1.spSubject= "1"; 
                                ec1.spMessage= strSubject;
                                ec1.spSender=BodyText;
                                ec1.toadd=strFrom;
                                ec1.ccaddress=objCC.ToString();
                                ec1.bccaddress=objBCC.ToString();
                                ec1.subcaseid=subcaseid;
                                ec1.Priority = Priority;
        
                                rv = p1.FollowupMail(ec1);

                                if (!ReadMoved)
                                {
                                    item.Move(readmailFolder.Id);
                                }
                                ++FollowupMailCount;

                                
                            }
                            else
                            {
                                emailInfo.subject_flag = 1;
                                rv = 0;
                                //CONVERT DATA FROM MAILBOX timezone to UTC.
                                String strUtcDateTime = TransformDateTime.GetUtcTimeFromZonedTime(dtrec.ToString("dd/MM/yyyy HH:mm:ss"), TimeZone);
                                DateTime dtUTCRec = DateTime.ParseExact(strUtcDateTime, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);

                                //encrypt
                                if (encryptionmode == "ON")
                                {
                                    cryptInfo.CryptKey = encryptionKey;
                                    cryptInfo.ValueToCrypt = newSubject;
                                    string encryptednewSubject = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
                                    newSubject = encryptednewSubject;
                                    cryptInfo.ValueToCrypt = BodyText;
                                    string encryptedBodyText = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
                                    BodyText = encryptedBodyText;
                                }

                               // rv = p1.InsertMail(dtUTCRec, intmailfolderid, "4", newSubject, BodyText, strFrom, objTo.ToString(), objCC.ToString(), objBCC.ToString(), Priority);
                                EMailInfo ec2=new EMailInfo();
                                
                                ec2.spDate = dtUTCRec;
                                ec2.spMailFolderId = intmailfolderid;
                                ec2.spStatusId = "4";
                                ec2.spSubject = newSubject;
                                ec2.spMessage=BodyText;
                                ec2.spSender=strFrom;
                                ec2.toadd = objTo.ToString();
                                ec2.ccaddress = objCC.ToString();
                                ec2.bccaddress=objBCC.ToString(); 
                                ec2.Priority=Priority;
                                
                                rv = p1.InsertMail(ec2);
                                                                
                                if (!ReadMoved)
                                {
                                    item.Move(readmailFolder.Id);
                                }
                                ++NewMailCount;

                                
                            }
                        }
                        else
                        {
                            item.Move(unreadmailFolder.Id);
                            ++NewMailCount;
                        }
                    }                    
                }
               
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            finally
            {

            }
                        
        }

        public Folder GetFolderFromName(ExchangeService service, String FolderName, FolderId rfRootFolderId)
        {
            Folder rtReturnFolder = null;
            try
            {
                FolderView fvFolderView = new FolderView(1);
                SearchFilter sfSearchFilter = new SearchFilter.IsEqualTo(FolderSchema.DisplayName, FolderName);
                FindFoldersResults ffResults = service.FindFolders(rfRootFolderId, sfSearchFilter, fvFolderView);
                if (ffResults.TotalCount == 1)
                {
                    rtReturnFolder = ffResults.Folders[0];
                }
                else
                {
                    throw new Exception("Parent Folder not found");

                }
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;     
            }
            return rtReturnFolder;
        }

        /// <summary>
        /// SecureString Method
        /// </summary>
        /// <param name="strPassword"></param>
        /// <returns></returns>
        public SecureString convertToSecureString(string strPassword)
        {
            var secureStr = new SecureString();
            if (strPassword.Length > 0)
            {
                foreach (var c in strPassword.ToCharArray()) secureStr.AppendChar(c);
            }
            return secureStr;
        }

        /// <summary>
        /// SecureString method to retrive the data
        /// </summary>
        /// <param name="secstrPassword"></param>
        /// <returns></returns>
        public string convertToUNSecureString(SecureString secstrPassword)
        {
            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(secstrPassword);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

        static void ShowMessage(string message)
        {
            Console.Clear();
            Console.WriteLine("************************************************");
            Console.WriteLine(message);
            Console.WriteLine("************************************************");
        }

        public string concat(string str, string insertstr)
        {
            string retst = string.Empty;
            try
            {
                if (str.Contains("<body"))
                {
                    int ln = str.Length;
                    int pos = str.LastIndexOf("<body ");
                    if (pos == -1)
                    {
                        pos = str.LastIndexOf("<body");
                    }
                    int strlen = 0;

                    if (ln > 0)
                    {
                        for (int i = pos; i < ln; i++)
                        {
                            strlen = strlen + 1;
                            if (str[i] == '>')
                                break;
                        }
                        retst = str.Substring(0, pos + strlen) + insertstr + str.Substring(pos + strlen);
                    }
                }
                else
                {
                    retst = insertstr + str;
                }
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

            return retst;
        }

        public string GetStringInBetween(string strBegin, string strEnd, string strSource)
        {
            string result = "";
            try
            {
                int iIndexOfBegin = strSource.IndexOf(strBegin);
                if (iIndexOfBegin != -1)
                {
                    strSource = strSource.Substring(iIndexOfBegin + strBegin.Length);
                    int iEnd = strSource.IndexOf(strEnd);
                    if (iEnd != -1)
                    {
                        if (strEnd == "")
                            result = strSource;
                        else
                            result = strSource.Substring(0, iEnd);
                    }
                }
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;

            }
            return result;
        }

        public static string HTMLToText(string HTMLCode)
        {
            // Remove new lines since they are not visible in HTML
            HTMLCode = HTMLCode.Replace("\n", " ");

            // Remove tab spaces
            HTMLCode = HTMLCode.Replace("\t", " ");

            // Remove multiple white spaces from HTML
            HTMLCode = Regex.Replace(HTMLCode, "\\s+", " ");

            // Remove HEAD tag
            HTMLCode = Regex.Replace(HTMLCode, "<head.*?</head>", ""
                                , RegexOptions.IgnoreCase | RegexOptions.Singleline);

            // Remove any JavaScript
            HTMLCode = Regex.Replace(HTMLCode, "<script.*?</script>", ""
              , RegexOptions.IgnoreCase | RegexOptions.Singleline);

            // Replace special characters like &, <, >, " etc.
            StringBuilder sbHTML = new StringBuilder(HTMLCode);
            // Note: There are many more special characters, these are just
            // most common. You can add new characters in this arrays if needed
            string[] OldWords = { "&nbsp;", "&amp;", "&quot;", "&lt;", "&gt;", "&reg;", "&copy;", "&bull;", "&trade;", "&#8211;" };
            string[] NewWords = { " ", "&", "\"", "<", ">", "®", "©", "•", "™", "-" };
            for (int i = 0; i < OldWords.Length; i++)
            {
                sbHTML.Replace(OldWords[i], NewWords[i]);
            }

            // Check if there are line breaks (<br>) or paragraph (<p>)
            sbHTML.Replace("<br>", "\n<br>");
            sbHTML.Replace("<br ", "\n<br ");
            sbHTML.Replace("<p ", "\n<p ");

            // Finally, remove all HTML tags and return plain text
            return System.Text.RegularExpressions.Regex.Replace(
              sbHTML.ToString(), "<[^>]*>", "");
        }

        /// <summary>
        /// Method to get the case id from subject line.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns> 
        private List<string> ExtractNumbers(string Expression)
        {
            List<string> caselist = new List<string>();
            try
            {

                string[] folsubcount = Expression.Trim().Split(' ');
                for (int index = 0; index < folsubcount.Length; index++)
                {
                    if (folsubcount[index].ToLower() == "caseid:")
                    {
                        caselist.Add(folsubcount[index + 1]);
                        if (folsubcount.Length > (2 + index))
                            caselist.Add(folsubcount[index + 2]);
                        else
                            caselist.Add("");

                        if (folsubcount.Length > (3 + index))
                            caselist.Add(folsubcount[index + 3]);
                        else
                            caselist.Add("");

                    }
                }
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

            return caselist;
        }

        public static bool isNumeric(string val, System.Globalization.NumberStyles NumberStyle)
        {
            Double result;
            return Double.TryParse(val, NumberStyle,
                System.Globalization.CultureInfo.CurrentCulture, out result);

        }

        
    }
}
