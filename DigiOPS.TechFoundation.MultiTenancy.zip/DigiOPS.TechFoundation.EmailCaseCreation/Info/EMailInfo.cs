﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace DigiOPS.TechFoundation.EmailCaseCreation
{
    public class EMailInfo 
    {
        public EMailInfo()
      {

      }
    public string AttachmentName { get; set; }
    public string AttachmentData { get; set; }
    public string ContentType { get; set; }
    public int AttachmentType { get; set; }
    public string CreatedBy { get; set; }
      public string FromMail { get; set; }
      public string ToMail { get; set; }
      public string CCMail { get; set; }
      public string BCCMail { get; set; }
      public string Subject { get; set; }
      public string Body { get; set; }
      public string caseID { get; set; }
      public DateTime spDate { get; set; }
      public string spMailFolderId { get; set; }
      public string spStatusId { get; set; }
      public string spSubject { get; set; }
      public string spMessage { get; set; }
      public string spSender { get; set; }
      public string toadd { get; set; }
      public string ccaddress { get; set; }
      public string bccaddress{ get; set; }
      public bool Priority{ get; set; }
      public string casel { get; set; }
      public string subcaseid { get; set; }
      public string FileName{ get; set; }
    public Byte[] fileBytes{ get; set; }
     public string CASEID { get; set; }
 
      //Pranay 6 Sept ---for getting Inline-Attachments 
     public DataSet MailAttachments { get; set; }
     
 
 //@AttachmentData IMAGE,      


    }
}
