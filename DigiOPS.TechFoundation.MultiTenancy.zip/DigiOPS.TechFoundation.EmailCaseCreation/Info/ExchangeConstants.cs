﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.EmailCaseCreation
{
   public class ExchangeConstants
    {
        #region MAIL_SP_NAME
        public const string SP_GETDETAIL = "USP_Get_MailBoxDetails";
        public const string SP_GETCASESTATUS = "USP_GetCaseCurrentStatus";
        public const string SP_INSERT_DETAIL = "USP_Insert_MailCaseDetails";
        public const string SP_INSERT_FOLLOWUP_DETAIL = "USP_Update_Followup_Details";
        public const string SP_FOLDER_DETAILS = "USP_Get_MaxCaseId_EmailMaster";
        public const string SP_UPDATE_DETAILS = "USP_Update_EMailAttachment_Details";
        public const string SP_Insert_Mail_Attachment = "USP_Insert_Mail_Attachment";
        public const string SP_LOCKEMAIL = "USP_LOCKEMAIL";
        //Pranay
        public const string SP_GETACKTEMPLATEDETAIL = "USP_Get_AcknowledgeTemplate_Details";
        public const string SP_AUTO_ACKNOWLEDGEMENT = "USP_SET_AUTO_ACKNOWLEDGEMENT";
        #endregion MAIL_SP_NAME

        #region MAIL_SP_PARAMETER

        public const string SP_PARAMETER_CASEID = "@CaseId";
        public const string SP_PARAMETER_RECEIVED_DATE = "@Received_date";
        public const string SP_PARAMETER_MAILFOLDER_ID = "@MailFolder_Id";
        public const string SP_PARAMETER_STATUS_ID = "@Status_Id";
        public const string SP_PARAMETER_SUBJECT = "@Subject";
        public const string SP_PARAMETER_MESSAGE = "@Message";
        public const string SP_PARAMETER_FROMADD = "@From_Add";
        public const string SP_PARAMETER_TOADD = "@Toaddress";
        public const string SP_PARAMETER_CCADD = "@CCaddress";
        public const string SP_PARAMETER_BCCADD = "@BCCaddress";
        public const string SP_PARAMETER_PRIORITY = "@Priority";
        public const string SP_PARAMETER_FILENAME = "@filename";
        public const string SP_PARAMETER_SUBCASEID = "@SubCaseId";
        public const string SP_PARAMETER_WORKID = "@Work_Id";
        public const string SP_PARAMETER_ATTACHMENTNAME = "@AttachmentName";
        public const string SP_PARAMETER_ATTACHMENTDATA = "@AttachmentData";
        public const string SP_PARAMETER_ATTACHMENTTYPE = "@AttachmentType";
        public const string SP_PARAMETER_CONTENTTYPE = "@ContentType";
        public const string SP_PARAMETER_CREATEDBY = "@CreatedBy";
        public const string SP_PARAMETER_EMAILBOXTYPE = "@EMAILBOXTYPE";
        public const string SP_PARAMETER_EMAILID = "@EMAILID";
        //Pranay
        public const string SP_PARAMETER_AUTOACKNOWLEDGEMENT = "@AutoAcknowledgement";

        #endregion MAIL_SP_PARAMETER

        #region DATASET_NAME
        public const string SP_DATASET_MAILFOLDER_PATH = "EMAILFOLDERPATH";
        public const string SP_DATASET_MAILFOLDER_NAME = "EMAILBOXNAME";

        public const string SP_DATASET_EMAILID = "EMAILBOXADDRESS";
        public const string SP_DATASET_LOGINEMAILID = "LOGINEMAILID";
        public const string SP_DATASET_PASSWORD = "Password";
        public const string SP_DATASET_MAILFOLDER_ID = "EMAILBOXID";
        #endregion DATASET_NAME

        #region CONNECTION_PATH
        public const string CONNECTION_STRING = "connection";
        #endregion CONNECTION_PATH

        #region GENERAL

        public const string WORKID = "workid";
        public const string STAR = "***************************************************************************************************************************";
        public const string NEW_LINE = "\r\n";

        // Added for EMT on 25June2014
        public const string NotFoundInStore_MailFolder = "The specified folder could not be found in the store.";
        public const string NotFoundInStore_Mailbox = "The specified object was not found in the store.";
        public const string Unauthorized = "The request failed. The remote server returned an error: (401) Unauthorized.";
        public const int NotFoundInStoreEMailTypeId = 0;
        public const int UnauthorizedEMailTypeId = 1;

        #endregion GENERAL
        
    }
}
