﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.EmailCaseCreation
{
   public interface ICaseCreationFactory
    {
       IEmailReadingFactory CaseCreationHandler(EMailInfo eInfo);
    }
}
