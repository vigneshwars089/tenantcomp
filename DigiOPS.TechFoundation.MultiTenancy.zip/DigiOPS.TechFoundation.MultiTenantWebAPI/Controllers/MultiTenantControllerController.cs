﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DigiOPS.TechFoundation.MultiTenancy;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.MultiTenantWebAPI.Controllers
{
    public class MultiTenantControllerController : ApiController
    {
        MultiTenant objMultiTenant = new MultiTenant();
        MultiTenantOutput objMultiTenantOutput = new MultiTenantOutput();
        [HttpPost]
        public string CreateDataBase([FromBody]MultiTenancyInfo MultiTenancyInfo)
        {
            string output = string.Empty;

            try
            {
               objMultiTenantOutput= objMultiTenant.GenerateDataBase(MultiTenancyInfo);
               output = objMultiTenantOutput.Output;
               return output;

            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
