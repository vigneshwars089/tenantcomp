﻿////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :BaseScoringAlgorithm.cs
// Namespace : DigiOps.TechFoundation.Logging
// Class Name(s) :LoggingFactory
// Author : Sujitha
// Creation Date : 13/2/2017
// Purpose : LoggingFactory Methods 
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//13-Feb-2017    Sujitha     LoggingFactory            Added LoggingFactory Methods 
//////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.Logging
{
    public class LoggingFactory : ILoggingFactory
    {
        
        public ICustomLogger GetLoggingHandler(string loggerType)
        {
            switch (loggerType)
            {
                case S_LoggerTypes.Log4net:
                    return new Log4NetLogger();
           
                default:
                    return null;
            }
        }
    }
}
