﻿////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :BaseScoringAlgorithm.cs
// Namespace : DigiOps.TechFoundation.Logging
// Class Name(s) :ICustomLogger
// Author : Sujitha
// Creation Date : 13/2/2017
// Purpose : Logger Methods 
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//13-Feb-2017    Sujitha     ICustomLogger            Added Custom Logger Interface  
//////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Logging
{
   public interface ICustomLogger
    {
       void LogInfo(LogInfo loginfo);

       void LogDebug(Object logdebug);

       void LogDebug(Object logdebug, Exception ex);

       void LogDebug(object logdebug, string TenantName, string AppId);

       void LogException(Exception ex);

       void LogException(Exception ex, string TenantName, string AppId);
    }
}
