﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Data;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using System.Data.OleDb;
using System.IO;
using System.Configuration;
using System.Xml.Linq;
using System.Web;
using DigiOPS.TechFoundation.Logging;
namespace DigiOPS.TechFoundation.Configuration
{
    public class DataElementBulkConfiguration:BaseCustomConfiguration
    {
        DataElementDataAccess dataelmntda = null;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();

        public override DataSet BulkUploadDataElement(Template objtemplate)
        {
            dataelmntda = new DataElementDataAccess(objtemplate.TenantName,objtemplate.AppID);
            // BulkUpload _objBALBlkUpld = new BulkUpload();
            StringBuilder strMessage = new StringBuilder();
            OleDbConnection objConn = null;
            OleDbCommand objCmd = new OleDbCommand();
            OleDbDataAdapter objDA = new OleDbDataAdapter();
            DataTable dtTableName = null;
            DataTable dtColumnName = null;
            DataTable dt = new DataTable();
            DataSet dsUpload = new DataSet();

            string CurrentUserID = objtemplate.CurrentUserID;
            int SubProcessId = int.Parse(objtemplate.SubProcessId);
            int ProgId = objtemplate.ProgramID;
            bool flag = true;
            DataElementEntity groupUser = new DataElementEntity();
            string sortOrder = groupUser._SortOrder;
            string sortColumn = groupUser._SortColumn;
            int? startRowIndex = groupUser._StartRowIndex;
            StringBuilder totalCount = new StringBuilder();
            StringBuilder errorCount = new StringBuilder();
            string errorLogFile = string.Empty;
            int TotalCnt = 0;
            int ErrorCnt = 0;
            var fileName = Path.GetFileName(objtemplate.FileName);
            var fileExtension = Path.GetExtension(objtemplate.FileName);
            // string filePath = Path.GetFullPath(objtemplate.FileName);
            MemoryStream fileStream = new MemoryStream(objtemplate.FileContent);
            MemoryFile file = new MemoryFile(fileStream, "application/octet-stream", fileName + "" + fileExtension);
            var Errorpath = "";
            try
            {
                if (file != null && file.ContentLength > 0)
                {
                    // extract only the fielname

                    if ((fileExtension == ".xls") || (fileExtension == ".xlsx"))
                    {
                        string date = Convert.ToString(System.DateTime.Now);
                        date = date.Replace("/", "_").Replace(":", "_");
                       

                        if (CurrentUserID != null)
                        {
                            fileName = fileName.Insert(fileName.IndexOf('.'), "_" + "_" + date + "_" + CurrentUserID + "_" + Convert.ToString(SubProcessId));
                            if (!Directory.Exists(System.AppDomain.CurrentDomain.BaseDirectory + ConfigurationManager.AppSettings["DATAELEMENT_UPLD_TEMP"]))
                            {
                                Directory.CreateDirectory(System.AppDomain.CurrentDomain.BaseDirectory + ConfigurationManager.AppSettings["DATAELEMENT_UPLD_TEMP"]);
                            }
                           // var path = System.AppDomain.CurrentDomain.BaseDirectory + "Bulkupload\\" + fileName;
                             var path = System.AppDomain.CurrentDomain.BaseDirectory + ConfigurationManager.AppSettings["DATAELEMENT_UPLD_TEMP"] + fileName;
                            file.SaveAs(path);
                            //String connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;HDR=YES;IMEX=1;ImportMixedTypes=Text;TypeGuessRows=0;'";
                            String connString = String.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;Importmixedtypes=text;typeguessrows=0;\"", path);
                            fileName = fileName.Insert(fileName.IndexOf('.'), "_ErrorLog");
                            Errorpath = "";//Server.MapPath(ConfigurationManager.AppSettings["DATAELEMENT_UPLD_ERROR_PATH"] + fileName);
                            // Create connection object by using the preceding connection string.
                            objConn = new OleDbConnection(connString);
                            // Open connection with the database.
                            objConn.Open();
                            // Get the data table containg the schema guid.
                            object[] objArrRestrict;
                           
                                objArrRestrict = new object[] { null, null, "DataElementConfiguration$", null };
                           
                            dtTableName = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            dtColumnName = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Columns, objArrRestrict);

                            if (dtTableName.Rows.Count > 0)
                            {
                                                      
                                  DataRow[]  TableName = dtTableName.Select("TABLE_NAME = 'DataElementConfiguration$'");
                               
                                if (TableName.Length == 0)
                                {
                                    strMessage.Append("Sheet Name is incorrect!");
                                }
                                else
                                {
                                    objCmd.Connection = objConn;
                                    
                                        objCmd.CommandText = "SELECT * From [DataElementConfiguration$]"; 
                                  
                                    objDA.SelectCommand = objCmd;
                                    objDA.Fill(dt);
                                    dt.TableName = "Data";
                                    DataView view = new DataView(dtColumnName);
                                    // Sort by Program column in ascending order
                                    view.Sort = "ORDINAL_POSITION";

                                    string strExcelDataxml = string.Empty;
                                    using (TextWriter writer = new StringWriter())
                                    {
                                        dt.WriteXml(writer);
                                        strExcelDataxml = writer.ToString();
                                    }
                                    string strExcelColumn = "";
                                    string strColumn = "";
                                    int k = 0;

                                    foreach (DataRow row in view.ToTable().Rows)
                                    {
                                        if (row["DATA_TYPE"].ToString() == "7")
                                        {
                                            strExcelColumn = strExcelColumn + "[" + row["COLUMN_NAME"].ToString() + "]  Datetimeoffset" + " ,";
                                            strColumn = strColumn + "Cast(" + "[" + row["COLUMN_NAME"].ToString() + "] as datetime) as [" + row["COLUMN_NAME"].ToString() + "] ,";
                                        }
                                        else
                                        {
                                            strExcelColumn = strExcelColumn + "[" + row["COLUMN_NAME"].ToString() + "]  NVarchar(Max)" + " ,";
                                            strColumn = strColumn + "[" + row["COLUMN_NAME"].ToString() + "] ,";
                                        }
                                        k++;
                                    }
                                    strExcelColumn = strExcelColumn.TrimEnd(',');
                                    strColumn = strColumn.TrimEnd(',');
                                    string pathCOnfig = ("/ConfigurationFiles/" + objtemplate.TenantName);
                                    // var path = Server.MapPath(ConfigurationManager.AppSettings["ConfigFile"] + TenantName);

                                    if (!Directory.Exists(pathCOnfig))
                                    {
                                        Directory.CreateDirectory(pathCOnfig);
                                    }
                                    pathCOnfig = ("/ConfigurationFiles/" + objtemplate.TenantName + "/" + "ProgramSetup.xml");
                                    //string XMLconfigpath = ConfigurationManager.AppSettings["RenameConfig"];
                                    string XmlConfigPath = pathCOnfig;
                                  //  string XmlConfigPath = ConfigurationManager.AppSettings["ProgramSettings"];
                                    string pathrestric = ("/ConfigurationFiles/" + objtemplate.TenantName);
                                    // var path = Server.MapPath(ConfigurationManager.AppSettings["ConfigFile"] + TenantName);

                                    if (!Directory.Exists(pathrestric))
                                    {
                                        Directory.CreateDirectory(pathrestric);
                                    }
                                    pathrestric = ("/ConfigurationFiles/" + objtemplate.TenantName + "/" + "RestrictedElementNames.xml");
                                    //string XMLconfigpath = ConfigurationManager.AppSettings["RenameConfig"];
                                    //string XmlConfigPath = pathCOnfig;
                                    string xmlRestrictedNameList = pathrestric;//ConfigurationManager.AppSettings["DATAELEMENT_RESTRICTED_NAMES"];

                                    string RestrictedNames = string.Empty;
                                    if (!string.IsNullOrEmpty(xmlRestrictedNameList))
                                    {
                                        //var doc = XDocument.Load(Server.MapPath(xmlRestrictedNameList));
                                        XElement varxelement = XElement.Load(System.AppDomain.CurrentDomain.BaseDirectory + xmlRestrictedNameList);

                                        var list = from item in varxelement.Elements("Element")
                                                   select item.Attribute("labelName").Value;
                                        RestrictedNames = String.Join(",", list);
                                    }

                                    XElement xelement = XElement.Load(System.AppDomain.CurrentDomain.BaseDirectory+XmlConfigPath);

                                    var ElementCnt = from item in xelement.Elements("Program")
                                                     where (int)item.Attribute("Id") == ProgId
                                                     select item.Attribute("NoOfElement").Value;
                                    int ECnt = 0;
                                    if (ElementCnt.Any())
                                    {
                                       // ECnt = string.IsNullOrEmpty(ElementCnt.First()) ? 0 : Convert.ToInt32(ElementCnt.First());
                                        ECnt =  Convert.ToInt32(ElementCnt.First());
                                    }

                                    Hashtable hstbl = new Hashtable();

                                    hstbl.Add("FilePath", path ?? string.Empty);
                                    hstbl.Add("FileExtention", fileExtension ?? string.Empty);
                                    hstbl.Add("SubProcessID", Convert.ToString(SubProcessId));
                                    hstbl.Add("CurrentUserID", CurrentUserID ?? string.Empty);
                                    hstbl.Add("ErrorPath", Errorpath ?? string.Empty);
                                    hstbl.Add("StrExcelColumn", strExcelColumn ?? string.Empty);
                                    hstbl.Add("StrColumn", strColumn);
                                    hstbl.Add("StrExcelDataxml", strExcelDataxml.Replace("'", "''"));
                                    // hstbl.Add("StrExcelDataxml", strExcelDataxml);
                                    hstbl.Add("ActionType", "DataElement");
                                    hstbl.Add("DateFormatCon", null);
                                    hstbl.Add("UploadType", null);
                                    hstbl.Add("BulkUploadId", 0);
                                    hstbl.Add("RestrictedElementName", objtemplate.RestrictedNames);
                                    hstbl.Add("MaximumDECount", Convert.ToString(ECnt) ?? "15");
                                    dsUpload = dataelmntda.BulkUploadDataElement(hstbl, objtemplate.AppID, objtemplate.TenantName);
                                   
                                }
                            }
                        }
                    }
                }
               
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objtemplate.TenantName, objtemplate.AppID);
                //ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
            }
            return dsUpload;
        }
    


        //public override DataSet BulkUploadDataElement(Hashtable hs, string AppId, int TenantId)
        //{

        //    return dataelmntda.BulkUploadDataElement(hs, AppId, TenantId);
        //}
    }
}

