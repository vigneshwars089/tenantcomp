﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;

namespace DigiOPS.TechFoundation.Configuration
{
    public class ManualHierarchyConfiguration : BaseCustomConfiguration
    {
        ManualHierarchyDataAccess manhierda = null;
        /// <summary>
        /// used to add/edit the program
        /// </summary>
        /// <param name="Program">ProgramEntity</param>
        /// <returns>string- returns the success/failure message upon adding/editing the program</returns>
        public override string AddUpdateProgram(ProgramEntity programEnt)
        {
            manhierda = new ManualHierarchyDataAccess(programEnt.TenantName, programEnt.AppID);
            return manhierda.AddUpdateDeleteProgram(programEnt);
        }
        /// <summary>
        /// used to delete the program
        /// </summary>
        /// <param name="programid">int</param>
        /// <param name="modifiedby">string</param>
        /// <param name="eventAction">string</param>
        /// <returns>ActionResult- returns the success/failure message upon deletion of program</returns>
        public override string DeleteProgram(int programid, string modifiedby, string eventAction, string AppID, string TenantName)
        {
            manhierda = new ManualHierarchyDataAccess(TenantName, AppID);
            ProgramEntity pgent = new ProgramEntity();
            pgent.programId = programid;
            pgent.eventAction = eventAction;
            pgent.modifiedBy = modifiedby;
            pgent.AppID = AppID;
            pgent.TenantName = TenantName;
            return manhierda.AddUpdateDeleteProgram(pgent);

        }
        /// <summary>
        /// used to add/edit the process for the selected program
        /// </summary>
        /// <param name="objprocess">ProcessEntity</param>
        /// <returns>returns the success/failure message upon adding/editing the process </returns>
        public override string AddUpdateProcess(ProcessEntity objprocess)
        {
            manhierda = new ManualHierarchyDataAccess(objprocess.TenantName, objprocess.AppID);
            return manhierda.AddUpdateDelProcess(objprocess);
        }
        /// <summary>
        /// used to delete the process
        /// </summary>
        /// <param name="processid">int</param>
        /// <param name="ModifiedBy">string</param>
        /// <param name="eventAction">string</param>
        /// <returns>ActionResult- returns the success/failure message upon deletion of process</returns>
        public override string DeleteProcess(int processid, string eventAction, string ModifiedBy, string AppID, string TenantName)
        {
            manhierda = new ManualHierarchyDataAccess(TenantName, AppID);
            ProcessEntity pgent = new ProcessEntity();
            pgent.processId = processid;
            pgent.eventAction = eventAction;
            pgent.modifiedBy = ModifiedBy;
            pgent.AppID = AppID;
            pgent.TenantName = TenantName;
            return manhierda.AddUpdateDelProcess(pgent);

        }
        /// <summary>
        /// used to diplay all the list of Processes mapped to that program
        /// </summary>
        /// <param name="ManualHierarchyInfo">ManualHierarchyInfo</param>
        /// <returns>returns the list of process mapped to that program</returns>
        public override List<ProcessEntity> GetProcessList(ManualHierarchyInfo objinfo)
        {
            manhierda = new ManualHierarchyDataAccess(objinfo.TenantName, objinfo.AppID);
            return manhierda.GetProcessList(objinfo);
        }
        /// <summary>
        ///  is used to add/edit/delete the subprocess
        /// </summary>
        /// <param name="SubProcess">SubProcessEntity</param>
        /// <returns>returns success/failure message upon creation/updating/deleting of subprocess.</returns>
        public override string AddUpdateSubProcess(SubProcessEntity objsubprocess)
        {
            manhierda = new ManualHierarchyDataAccess(objsubprocess.TenantName, objsubprocess.AppID);
            return manhierda.AddUpdateDeleteSubProcess(objsubprocess);
        }
        /// <summary>
        /// used to delete the subprocess
        /// </summary>
        /// <param name="subprocessid">int</param>
        /// <param name="ModifiedBy">string</param>
        /// <param name="ModifiedDate">string</param>
        /// <param name="eventAction">string</param>
        /// <returns>ActionResult- returns the success/failure message upon deletion of subprocess</returns>
        public override string DeleteSubProcess(int subprocessid, string eventAction, string ModifiedBy, string ModifiedDate, string AppID, string TenantName)
        {
            manhierda = new ManualHierarchyDataAccess(TenantName, AppID);
            SubProcessEntity pgent = new SubProcessEntity();
            pgent.SubProcessId = subprocessid;
            pgent.eventAction = eventAction;
            pgent.ModifiedBy = ModifiedBy;
            pgent.ModifiedDate = Convert.ToDateTime(ModifiedDate);
            pgent.AppID = AppID;
            pgent.TenantName = TenantName;
            return manhierda.AddUpdateDeleteSubProcess(pgent);

        }
        /// <summary>
        /// used to get subProcess list 
        /// </summary>
        /// <param name="ManualHierarchyInfo">ManualHierarchyInfo</param>
        /// <returns>returns the subProcess list for the selected program and process</returns>
        public override List<SubProcessEntity> GetSubProcessList(ManualHierarchyInfo objinfo)
        {
            manhierda = new ManualHierarchyDataAccess(objinfo.TenantName, objinfo.AppID);
            return manhierda.GetSubProcessList(objinfo);
        }
        /// <summary>
        /// used to get usergroup list based on the selected program and process 
        /// </summary>
        /// <param name="ManualHierarchyInfo">ManualHierarchyInfo</param>
        /// <returns>returns the usergroup list based on the selected program and process</returns>
        public override List<List<ProcessEntity>> GetProcessUsergrp(ManualHierarchyInfo objinfo)
        {
            manhierda = new ManualHierarchyDataAccess(objinfo.TenantName, objinfo.AppID);
            return manhierda.GetProcessUsergrp(objinfo);
        }
        /// <summary>
        /// used to diplay all the program details
        /// </summary>
        /// <param name="objinfo">ManualHierarchyInfo</param>
        /// <returns>ActionResult - returns the details of all programs </returns>
        public override List<List<ProgramEntity>> GetProgramList(ManualHierarchyInfo objinfo)
        {
            manhierda = new ManualHierarchyDataAccess(objinfo.TenantName, objinfo.AppID);
            return manhierda.GetProgramList(objinfo);
        }
       
        
    }
}
