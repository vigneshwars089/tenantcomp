﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
namespace DigiOPS.TechFoundation.Configuration
{
    public class DataElementConfiguration : BaseCustomConfiguration
    {
        DataElementDataAccess dataelmntda = null;
        /// <summary>
        /// Method to Configure Data Element Based On Data Element Entity
        /// </summary>
        /// <returns>string- returns the success/failure message upon adding/editing the dataelement</returns>
        public override string AddUpdateDataElement(List<DataElementEntity> DataElements)
        {
            dataelmntda = new DataElementDataAccess(DataElements[0].TenantName, DataElements[0].AppID);
            return dataelmntda.AddUpdateDataElement(DataElements);
        }

        /// <summary>
        /// used to delete the dataelement
        /// </summary>
        /// <param name="processid">int</param>
        /// <param name="ModifiedBy">string</param>
        /// <param name="eventAction">string</param>
        /// <returns>ActionResult- returns the success/failure message upon deletion of process</returns>
        //public override string DeleteDataelemnt(int ElemtId, string eventAction, string modifiedBy,string AppID, int TenantID)
        //{
        //    DataElementEntity datent = new DataElementEntity();
        //    datent.ElementId = ElemtId;
        //    datent.eventAction = eventAction;
        //    datent.modifiedBy = modifiedBy;
        //    datent.AppID = AppID;
        //    datent.TenantID = TenantID;
        //    return dataelmntda.DeleteDataElement(datent);

        //}
        /// <summary>
        /// Method to get Data Element Collection List
        /// </summary>
        /// <param name="_obj">DataElementInfo</param>
        /// <returns>List<List<DataElementEntity>></returns>
        public override List<List<DataElementEntity>> GetDataElements(DataElementInfo _obj)
        {
            dataelmntda = new DataElementDataAccess(_obj.TenantName, _obj.AppID);
            return dataelmntda.GetDataElements(_obj);
        }
        public override List<DataElementStaticConditon> GetChildStaticConditions(int configid, string AppID, string TenantName)
        {
            dataelmntda = new DataElementDataAccess(TenantName, AppID);
            return dataelmntda.GetChildStaticConditions(configid, AppID, TenantName);
        }
        public override List<DataElementStaticConditon> GetDataElementStaticCondition(int subprocessid, string AppID, string TenantName)
        {
            dataelmntda = new DataElementDataAccess(TenantName, AppID);
            return dataelmntda.GetDataElementStaticCondition(subprocessid, AppID, TenantName);
        }
        public override string UpdateStaticConditions(List<DataElementStaticConditon> objConditions, string AppID, string TenantName)
        {
            dataelmntda = new DataElementDataAccess(TenantName, AppID);
           return dataelmntda.UpdateStaticConditions(objConditions, AppID, TenantName);
       }
        public override List<DataElementEntity> GetDirectAuditLevelList(int SubProcessID, string AppID, string TenantName)
        {
            dataelmntda = new DataElementDataAccess(TenantName, AppID);
            return dataelmntda.GetDirectAuditLevelList(SubProcessID, AppID, TenantName);
        }
        public override string SetRanking(ElementSequence ElementSequence, string AppID, string TenantName)
        {
            dataelmntda = new DataElementDataAccess(TenantName, AppID);
            return dataelmntda.SetRanking(ElementSequence, AppID, TenantName);
        }
        public override string AddList(CodesEntity ListItem)
        {
            dataelmntda = new DataElementDataAccess(ListItem.TenantName, ListItem.AppID);
            return dataelmntda.AddList(ListItem);
        }
        public override CodeGroupEntity GetAddListViewModel(CodeGroupEntity _Codes)
        {
            dataelmntda = new DataElementDataAccess(_Codes.TenantName, _Codes.AppID);
            return dataelmntda.GetCodesList(_Codes);
        }
        public override bool IsAutoAudit(DataElementInfo obj)
        {
            dataelmntda = new DataElementDataAccess(obj.TenantName, obj.AppID);
            return dataelmntda.IsAutoAudit(obj);
        }
        public override string DeleteDataelemnt(List<DataElementEntity> DataElements, string modifiedBy, string AppID, string TenantName)
        {
            dataelmntda = new DataElementDataAccess(TenantName, AppID);
            return dataelmntda.DeleteDataElement(DataElements, modifiedBy, AppID, TenantName);

        } 
          public override List<DataElementEntity> GetDataElementRecordList(DataElementEntity _Obj)
        {
            dataelmntda = new DataElementDataAccess(_Obj.TenantName, _Obj.AppID);
            return dataelmntda.GetDataElementRecordList(_Obj);

        } 

    }
}
