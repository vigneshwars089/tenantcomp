﻿using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Configuration
{
    public class ProgramConfiguration : BaseCustomConfiguration
    {
        MailBoxConfigurationDataAccess objMBDA1 = new MailBoxConfigurationDataAccess();
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();

        public override ResponseInfo HierarchyCreation(int HierarchyLevel, string HierarchyLevelName, string HierarchyName, string HierarchyDesc, bool IsActive, string createdby, string tenantname, string parenthierarchy, string parenthierarchyvalue, string HierarchyPOC, string appId, int TenantId)
        {
          //  objMBDA1 = new MailBoxConfigurationDataAccess();
            ResponseInfo objResponseInfo = new ResponseInfo();
            objResponseInfo.ErrorMessage = new StringBuilder();
            int result = 0;
            try
            {
                if ((HierarchyLevel) != 0 || string.IsNullOrEmpty(HierarchyLevelName) || string.IsNullOrEmpty(HierarchyName) || string.IsNullOrEmpty(HierarchyDesc) || (IsActive == null) || string.IsNullOrEmpty(createdby) || string.IsNullOrEmpty(tenantname) || string.IsNullOrEmpty(parenthierarchy) || string.IsNullOrEmpty(parenthierarchyvalue) || string.IsNullOrEmpty(HierarchyPOC) || string.IsNullOrEmpty(appId) || TenantId == 0)
                    objResponseInfo.ErrorMessage.Append("Inputs are null");
                else if ((HierarchyLevel != 0 && string.IsNullOrEmpty(HierarchyLevelName) && string.IsNullOrEmpty(HierarchyName) && string.IsNullOrEmpty(tenantname) && string.IsNullOrEmpty(appId) && TenantId == 0) || appId != null && HierarchyLevel != null && tenantname != null && HierarchyLevelName != null && HierarchyName != null)
                    objResponseInfo.ErrorMessage.Append("Inputs are null");
                else
                    result = objMBDA1.HierarchyCreation(HierarchyLevel, HierarchyLevelName, HierarchyName, HierarchyDesc, IsActive, createdby, tenantname, parenthierarchy, parenthierarchyvalue, HierarchyPOC, appId, TenantId);
                if (result == 0)
                    objResponseInfo.ResultStatus = false;
                else
                {
                    objResponseInfo.ErrorMessage.Append("Inserted Successfully"); objResponseInfo.ResultStatus = true;
                }
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex, tenantname, appId); }
            return objResponseInfo;
        }

        public override ResponseInfo MailBoxDetails(TenantInfo objTenantInfo)
        {
           // objMBDA1 = new MailBoxConfigurationDataAccess();
            ResponseInfo objResponseInfo = new ResponseInfo();
            objResponseInfo.ErrorMessage=new StringBuilder();
            int result = 0;
            try
            {
                if (string.IsNullOrEmpty(objTenantInfo.DatabaseDetails.UserName) || string.IsNullOrEmpty(objTenantInfo.DatabaseDetails.Password) || string.IsNullOrEmpty(objTenantInfo.TenantName) || (objTenantInfo.DatabaseDetails.IsLocked == null) || objTenantInfo.DatabaseDetails.IsActive == null || string.IsNullOrEmpty(objTenantInfo.AppID) || objTenantInfo.TenantID == 0)
                    objResponseInfo.ErrorMessage.Append("Inputs are null");
                else if ((string.IsNullOrEmpty(objTenantInfo.DatabaseDetails.UserName) && string.IsNullOrEmpty(objTenantInfo.DatabaseDetails.Password) && string.IsNullOrEmpty(objTenantInfo.TenantName)) || objTenantInfo.DatabaseDetails.UserName != null && objTenantInfo.DatabaseDetails.Password != null && objTenantInfo.TenantName != null)
                    objResponseInfo.ErrorMessage.Append("Inputs are null");
                else
                    result = objMBDA1.GetMailBoxLoginDetails(objTenantInfo.DatabaseDetails.UserName, objTenantInfo.DatabaseDetails.Password, objTenantInfo.TenantName, objTenantInfo.DatabaseDetails.IsLocked, objTenantInfo.DatabaseDetails.IsActive, objTenantInfo.AppID, objTenantInfo.TenantID);
                if (result == 0)
                    objResponseInfo.ResultStatus = false;
                else
                {
                    objResponseInfo.ErrorMessage.Append("Inserted Successfully"); objResponseInfo.ResultStatus = true;
                }
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex, objTenantInfo.TenantName, objTenantInfo.AppID); }
            return objResponseInfo;
        }

        public override ResponseInfo MailBoxCredentials(MailFeatureEntity objMailBoxConfigurationEntity)
        {
           // objMBDA1 = new MailBoxConfigurationDataAccess();
            ResponseInfo objResponseInfo = new ResponseInfo();
            objResponseInfo.ErrorMessage = new StringBuilder();
            int result = 0;
            try
            {
                if (objMailBoxConfigurationEntity != null)
                    result = objMBDA1.GetMailBoxConfigurationDetails
                        (objMailBoxConfigurationEntity.MailBoxName, objMailBoxConfigurationEntity.MailBoxAddress, objMailBoxConfigurationEntity.Domain, objMailBoxConfigurationEntity.MailBoxFolderPath, objMailBoxConfigurationEntity.TATInHours, objMailBoxConfigurationEntity.TATInSeconds,
                        objMailBoxConfigurationEntity.TimeZone, objMailBoxConfigurationEntity.CreatedById, objMailBoxConfigurationEntity.CreatedDate, objMailBoxConfigurationEntity.IsQCRequired, objMailBoxConfigurationEntity.IsActive,
                    objMailBoxConfigurationEntity.IsReplyNotRequired, objMailBoxConfigurationEntity.IsMailTriggerRequired, objMailBoxConfigurationEntity.Offset, objMailBoxConfigurationEntity.IsEMailBoxAddressOptional, objMailBoxConfigurationEntity.IsVOCSurvey, objMailBoxConfigurationEntity.IsADLogin, objMailBoxConfigurationEntity.IsSubjectEditable, objMailBoxConfigurationEntity.IsGMBtoGMB, objMailBoxConfigurationEntity.IsCustomizableCaseId, objMailBoxConfigurationEntity.IsConversationHistory, objMailBoxConfigurationEntity.TenantName, objMailBoxConfigurationEntity.AppId, objMailBoxConfigurationEntity.TenantId,
                    objMailBoxConfigurationEntity.HierarchyValuetobeTakenName, objMailBoxConfigurationEntity.HierarchyLevelNameValuetobeTaken);
                if (result != 0)
                {
                    objResponseInfo.ErrorMessage.Append("Inserted Successfully"); objResponseInfo.ResultStatus = true;
                }
                else
                { objResponseInfo.ErrorMessage.Append("Inputs are null"); objResponseInfo.ResultStatus = false; }
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex, objMailBoxConfigurationEntity.TenantName, objMailBoxConfigurationEntity.AppId); }
            return objResponseInfo;
        }

        public override ResponseInfo AuditSettings(MailFeatureEntity objMailBoxConfigurationEntity)
        {
          //  objMBDA1 = new MailBoxConfigurationDataAccess();
            ResponseInfo objResponseInfo = new ResponseInfo();
           
            return objResponseInfo;
        }

        public override ResponseInfo Set_ZoneANDMenu_Deatils(TenantInfo objTenantInfo)
        {
          //  objMBDA1 = new MailBoxConfigurationDataAccess();
            ResponseInfo objResponseInfo = new ResponseInfo();
            objResponseInfo.ErrorMessage = new StringBuilder();
            int result = 0;
            try
            {
                if (objTenantInfo != null)
                    result = objMBDA1.Set_ZoneANDMenu_Deatils(objTenantInfo);
                if (result != 0)
                {
                    objResponseInfo.ErrorMessage.Append("Inserted Successfully"); objResponseInfo.ResultStatus = true;
                }
                else
                { objResponseInfo.ErrorMessage.Append("Inputs are null"); objResponseInfo.ResultStatus = false; }
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex, objTenantInfo.AuditFeatures.MenuInfo.TenantName, objTenantInfo.AuditFeatures.MenuInfo.AppID); }
            return objResponseInfo;
 
        }

        public override TenantInfo GetHierarchy(string TenantName, string HierarchyName, int HierarchyLevel)
        {
           // objMBDA1 = new MailBoxConfigurationDataAccess();
            TenantInfo objTenantInfo = new TenantInfo();
            try
            {
                objTenantInfo = objMBDA1.GetHierarchy(TenantName, HierarchyName, HierarchyLevel);
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex); }
            return objTenantInfo;
 
        }

        public override TenantInfo GetTenantConfiguration(string TenantName)
        {
           // objMBDA1 = new MailBoxConfigurationDataAccess();
            TenantInfo objTenantInfo = new TenantInfo();
            try
            {
                objTenantInfo = objMBDA1.GetTenantConfigurationDeatils(TenantName);
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex); }
            return objTenantInfo;

        }

        public override TenantInfo Get_ZoneANDMenuDeatils(string TenantName)
        {
           // objMBDA1 = new MailBoxConfigurationDataAccess();
            TenantInfo objTenantInfo = new TenantInfo();
            try
            {
                objTenantInfo = objMBDA1.GetZoneANDMenuDeatils(TenantName);
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex); }
            return objTenantInfo;
        }

        public override TenantInfo GetLookUp(string TenantName, string LookUpName, int LookUpLevel)
        {
          //  objMBDA1 = new MailBoxConfigurationDataAccess();
            TenantInfo objTenantInfo = new TenantInfo();
            try
            {
                objTenantInfo = objMBDA1.GetLookUp(TenantName, LookUpName, LookUpLevel);
            }
            catch (Exception ex)
            { 
                objlog.GetLoggingHandler("Log4net").LogException(ex);
            }
            return objTenantInfo;
        }

        public override ResponseInfo SetLookup(int LookupLevel, string LookupLevelName, string LookupName, string LookupDesc, string LookupValue, bool IsActive, string createdby, string tenantname, string parentLookup, string parentLookupvalue, string appId, int TenantId)
        {
           // objMBDA1 = new MailBoxConfigurationDataAccess();
                ResponseInfo objResponseInfo = new ResponseInfo();
            objResponseInfo.ErrorMessage = new StringBuilder();
            int result = 0;
            try
            {
                if ((LookupLevel) != 0 || string.IsNullOrEmpty(LookupLevelName) || string.IsNullOrEmpty(LookupName) || string.IsNullOrEmpty(LookupDesc) || (IsActive == null) || string.IsNullOrEmpty(createdby) || string.IsNullOrEmpty(tenantname) || string.IsNullOrEmpty(parentLookup) || string.IsNullOrEmpty(parentLookupvalue) || string.IsNullOrEmpty(LookupValue) || string.IsNullOrEmpty(appId) || TenantId == 0)
                    objResponseInfo.ErrorMessage.Append("Inputs are null");
                else if ((LookupLevel != 0 && string.IsNullOrEmpty(LookupLevelName) && string.IsNullOrEmpty(LookupName) && string.IsNullOrEmpty(tenantname) && string.IsNullOrEmpty(appId) && TenantId == 0) || appId != null && LookupLevel != null && tenantname != null && LookupLevelName != null && LookupName != null)
                    objResponseInfo.ErrorMessage.Append("Inputs are null");
                else
                    result = objMBDA1.LookUpCreation(LookupLevel,LookupLevelName,LookupName,LookupDesc,LookupValue,IsActive, createdby,tenantname, parentLookup, parentLookupvalue, appId, TenantId);
                if (result == 0)
                    objResponseInfo.ResultStatus = false;
                else
                {
                    objResponseInfo.ErrorMessage.Append("Inserted Successfully"); objResponseInfo.ResultStatus = true;
                }
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex, tenantname, appId); }
            return objResponseInfo;
            }

        public override ResponseInfo InsertIntoPM(string ZoneName, string AccountName, string ProgramName, DateTime From, DateTime To, string CreadtedBy, string ModifedBy, string ConnectionString)
        {            
            ResponseInfo objResponseInfo = new ResponseInfo();
            objResponseInfo.ErrorMessage = new StringBuilder();
            int result = 0;
            try
            {
                if (string.IsNullOrEmpty(ZoneName) && string.IsNullOrEmpty(AccountName) && string.IsNullOrEmpty(ProgramName) && From != null && To != null && string.IsNullOrEmpty(CreadtedBy) && string.IsNullOrEmpty(ModifedBy) && string.IsNullOrEmpty(ConnectionString))
                    objResponseInfo.ErrorMessage.Append("Inputs are null");
                else
                     result = objMBDA1.InsertIntoPM(ZoneName, AccountName, ProgramName, From, To, CreadtedBy, ModifedBy, ConnectionString);
                if (result == 0)
                    objResponseInfo.ResultStatus = false;
                else
                {
                    objResponseInfo.ErrorMessage.Append("Inserted Successfully"); objResponseInfo.ResultStatus = true;
                }
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex); }
            return objResponseInfo;
        }

        public override ResponseInfo SetProgramFeatures(TenantInfo objBaseT, string connectionString)
        {           
            ResponseInfo objResponseInfo = new ResponseInfo();
            objResponseInfo.ErrorMessage = new StringBuilder();
            string result = string.Empty;
            try
            {
                if (objBaseT == null || string.IsNullOrEmpty(connectionString) )
                    objResponseInfo.ErrorMessage.Append("Inputs are null");                
                else
                    result = objMBDA1.SetProgramFeatures(objBaseT, connectionString);
                //if (result == 0)                //    objResponseInfo.ResultStatus = false;
                //else
                //{
                //    objResponseInfo.ErrorMessage.Append("Inserted Successfully"); objResponseInfo.ResultStatus = true;
                //}
                objResponseInfo.Message = result;
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex, objBaseT.TenantName, objBaseT.AppID); }
            return objResponseInfo;
        }

        //public TenantInfo Set_Transactions_ToNativeDatabase(TenantInfo objTenant, string EN, string ProgramName, DateTime From, DateTime To, string ConnectionString)
        //  {
        //      string connectionstring = string.Empty;
        //      int flag = 0;
        //      TenantInfo objTenantinfo = new TenantInfo();
        //      ResponseInfo objResp = new ResponseInfo();
        //      ProgramConfiguration pc = new ProgramConfiguration();
        //    if(objTenant.AppID.ToUpper()=="EMT")
        //        connectionstring = ConfigurationManager.ConnectionStrings["EMTConn"].ConnectionString;
        //    else if (objTenant.AppID.ToUpper() == "QUART")
        //        connectionstring = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
        //    switch (objTenant.AppID.ToUpper())
        //    {
        //        case "QUART":
        //            objTenantinfo = pc.GetLookUp(objTenant.TenantName, objTenant.LookupInfo.LookupName, objTenant.LookupInfo.LookupLevel);
        //             if(objTenantinfo.ResultStatus!=false)
        //            objTenantinfo = pc.GetHierarchy(objTenant.TenantName, objTenant.HierarchyInfoList[0].HierarchyName, objTenant.HierarchyInfoList[0].HierarchyLevel);
        //             if (objTenantinfo.ResultStatus != false)
        //             {
        //                 objResp = pc.InsertIntoPM(EN, ProgramName, From, To, ConnectionString);
        //                 objTenant.ResultStatus = objResp.ResultStatus;
        //                 objTenant.Message = "Success";
        //             }
        //             else
        //             {
        //                 objTenant.ResultStatus = false;
        //                 objTenant.Message = "Failed";
        //             }
        //           // [USP_INSERT_PROGRAM] -To Insert into PrgmMaster
        //           // objTenantinfo=pc.GetHierarchy(objTenant.TenantName, objTenant.HierarchyInfoList[0].HierarchyName, objTenant.HierarchyInfoList[0].HierarchyLevel);
        //            //1.call Zone details
        //            //2. Call Hierarchy
        //        //3. call programfeatures
        //            break;
        //        default:
        //            break;
        //    }
        //      return objTenant;
        //  }


       
    }
}
