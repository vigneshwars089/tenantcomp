﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
namespace DigiOPS.TechFoundation.Configuration
{
    public class WorkflowQCConfiguration : BaseCustomConfiguration
    {
        WorkflowConfigDataAccess wrkflwconfigda = null;

        /// <summary>
        /// Method to Save Workflow Configuration
        /// </summary>
        /// <param name="objconfig">WorkflowConfigurationEntity</param>
        /// <returns>ActionResult</returns>
        public override string AddUpdateWorkflowQC(WorkflowConfigurationEntity objconfig)
        {
            wrkflwconfigda = new WorkflowConfigDataAccess(objconfig.TenantName, objconfig.AppID);
            return wrkflwconfigda.AddUpdateWorkflowQC(objconfig);
        }
        /// <summary>
        /// Method To Get Configuration Details Based On SubProcessID
        /// </summary>
        /// <param name="objinfo">WorkflowConfigInfo</param>
        /// <returns>ActionResult</returns>
        public override List<WorkflowConfigurationEntity> GetWrkflowConfig(WorkflowConfigInfo objinfo)
        {
            wrkflwconfigda = new WorkflowConfigDataAccess(objinfo.TenantName, objinfo.AppID);
            return wrkflwconfigda.GetWrkflowConfig(objinfo);
        }
    }
}
