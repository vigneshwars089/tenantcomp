﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Configuration
{
    public class Constants
    {
        public const string HIERARCHY = "Hierarchy";
        public const string  USER= "User";
        public const string AUDIT = "Audit";
        public const string MANUAL = "Manual";
        public const string BULKUPLOAD = "BulkUpload"; 
    }
}
