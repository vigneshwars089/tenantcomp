﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Configuration
{
   public class DynamicDataElementInfo
    {
       public DataElementDefinitionInfo DataElementDefinition { get; set; }
       public DataElementValidationInfo DataElementValidation { get; set; }
       public DataElementDispAreaInfo DataElementDispArea { get; set; }
       public HierarchyInfo selectedHierarchy { get; set; }
       public DataElementScopeInfo DataElementScope { get; set; }
        
    }


   public class DataElementDefinitionInfo
   {
       public int ElementId { get; set; }
       public string ElementName { get; set; }
       public string DisplayName { get; set; }
       public int DataTypeId { get; set; }
       public string ElementDataTypeName { get; set; }
       public int SequenceNo { get; set; }
   }


   public class DataElementUIInfo
   {
       public int UIElementTypeId { get; set; }
       public string UIElementTypeName { get; set; }
       public Boolean ElementIsList { get; set; }
   }

   public class DataElementValidationInfo
   {
       public Boolean isMandatory { get; set; }
       public Boolean isUniqueElement { get; set; }
       public int ElementLength { get; set; }
       public string splChars { get; set; }
   }

   public class DataElementDispAreaInfo
   {
    
       public Boolean AuditFormElement { get; set; }
       public Boolean SearchableElement { get; set; }
       public Boolean IsReportField { get; set; }
       public Boolean GridViewElement { get; set; }
       public Boolean SamplingThreshold { get; set; }
       public Boolean IsDirectAuditLevel { get; set; }
       public int DirectAuditLevelId { get; set; }
       public string DirectAuditLevel { get; set; }
   }

   public class DataElementScopeInfo
   {
       public Boolean isActive { get; set; }
       public DateTime effectiveFrom { get; set; }
       public DateTime effectiveTo { get; set; }
       public string createdBy { get; set; }
       public DateTime createdDate { get; set; }
       public string modifiedBy { get; set; }
       public DateTime modifiedDate { get; set; }
   }

}
