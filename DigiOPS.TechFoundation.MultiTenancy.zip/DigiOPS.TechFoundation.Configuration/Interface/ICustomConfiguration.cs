﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Data;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Configuration
{
    public interface ICustomConfiguration
    {
        void ReadConfiguration(ConfigurationInfo fieldconfig, ref List<DataElementEntity> DataElements);
        void WriteConfiguration(ConfigurationInfo fieldconfig, ref string value);
        string Configuration(string ExcelFilePath, string ExcelTemplate, string ExcelSourceTemplate, string Errorpath, BaseInfo objBaseInfo, byte[] bt);
        string AddUpdateProgram(ProgramEntity programEnt);
        string DeleteProgram(int programid, string modifiedby, string eventAction, string AppID, string TenantName);
        List<List<ProgramEntity>> GetProgramList(ManualHierarchyInfo objinfo);
        string AddUpdateProcess(ProcessEntity objprocess);
        string DeleteProcess(int processid, string eventAction, string ModifiedBy, string AppID, string TenantName);
        List<ProcessEntity> GetProcessList(ManualHierarchyInfo objinfo);
        string AddUpdateSubProcess(SubProcessEntity objsubprocess);
        string DeleteSubProcess(int subprocessid, string eventAction, string ModifiedBy, string ModifiedDate, string AppID, string TenantName);
        List<SubProcessEntity> GetSubProcessList(ManualHierarchyInfo objinfo);
        List<List<ProcessEntity>> GetProcessUsergrp(ManualHierarchyInfo objinfo);
        string AddUpdateWorkflowQC(WorkflowConfigurationEntity objconfig);
        List<WorkflowConfigurationEntity> GetWrkflowConfig(WorkflowConfigInfo objinfo);
        string AddUpdateDataElement(List<DataElementEntity> DataElements);
        //string DeleteDataelemnt(int ElemtId, string eventAction, string modifiedBy, string AppID, int TenantID);
        List<List<DataElementEntity>> GetDataElements(DataElementInfo _obj);
        DataSet BulkUploadDataElement(Template objtemplate);
        List<DataElementStaticConditon> GetChildStaticConditions(int configid, string AppID, string TenantName);
        List<DataElementStaticConditon> GetDataElementStaticCondition(int subprocessid, string AppID, string TenantName);
        string UpdateStaticConditions(List<DataElementStaticConditon> objConditions, string AppID, string TenantName);
        List<DataElementEntity>  GetDirectAuditLevelList(int SubProcessID, string AppID,string TenantName);
        string SetRanking(ElementSequence ElementSequence, string AppID, string TenantName);
        string AddList(CodesEntity ListItem);
        CodeGroupEntity GetAddListViewModel(CodeGroupEntity _Codes);
        bool IsAutoAudit(DataElementInfo obj);
        string DeleteDataelemnt(List<DataElementEntity> DataElements, string modifiedBy, string AppID, string TenantName);
        List<DataElementEntity> GetDataElementRecordList(DataElementEntity _Obj);

         ResponseInfo HierarchyCreation(int HierarchyLevel, string HierarchyLevelName, string HierarchyName, string HierarchyDesc, bool IsActive, string createdby, string tenantname, string parenthierarchy, string parenthierarchyvalue, string HierarchyPOC, string appId, int TenantId);
        
      ResponseInfo MailBoxDetails(TenantInfo objTenantInfo);
        

         ResponseInfo MailBoxCredentials(MailFeatureEntity objMailBoxConfigurationEntity);
       

       ResponseInfo AuditSettings(MailFeatureEntity objMailBoxConfigurationEntity);
       ResponseInfo Set_ZoneANDMenu_Deatils(TenantInfo objTenantInfo);

     TenantInfo GetHierarchy(string TenantName, string HierarchyName, int HierarchyLevel);
       
         TenantInfo GetMailBoxConfiguration(string TenantName);
         TenantInfo GetTenantConfiguration(string TenantName);
         TenantInfo Get_ZoneANDMenuDeatils(string TenantName);
         TenantInfo GetLookUp(string TenantName, string LookUpName, int LookUpLevel);
     ResponseInfo SetLookup(int LookupLevel, string LookupLevelName, string LookupName, string LookupDesc, string LookupValue, bool IsActive, string createdby, string tenantname, string parentLookup, string parentLookupvalue, string appId, int TenantId);

     ResponseInfo InsertIntoPM(string ZoneName, string AccountName, string ProgramName, DateTime From, DateTime To, string CreadtedBy, string ModifedBy, string ConnectionString);
     ResponseInfo SetProgramFeatures(TenantInfo objBaseT, string connectionString); 
       
        
    }
}
