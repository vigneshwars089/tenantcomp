﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.Configuration
{
    interface IMailBoxConfigurationDetails
    {
        void SubProcessCreation(string Program,string SubProcess,string ProcessOwner,bool IsActive);
        MailBoxLoginDetailsEntity GetMailBoxLoginDetails(string LoginEmailId, string pd, string confirmpd, bool islocked, bool isactive);
        MailFeatureEntity GetMailBoxConfigurationDetails(string MailBoxName, string MailBoxAddress, string MailBoxFolderPath, string MailBoxLoginId, string SubProcess, string TimeZone, string SLATime, bool IsQCRequired, bool IsActive, bool IsReplyNotRequired, bool IsLocked);
       // AddONsToBeConfiguredEntity AddONsToBeConfigured(bool IsADLogin, bool IsSubjectEditable, bool IsGMBtoGMB, bool IsCustomizableCaseId, bool IsConversationHistory);
            
    }
}
