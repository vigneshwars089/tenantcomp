﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Configuration
{
   public interface IConfiguration
    {
       string Configuration(string ExcelFilePath, string ExcelTemplate, string Errorpath);
    }
}
