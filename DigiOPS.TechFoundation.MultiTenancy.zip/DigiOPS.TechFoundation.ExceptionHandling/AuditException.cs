﻿////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :AuditException.cs
// Namespace : DigiOps.TechFoundation.ExceptionHandling
// Class Name(s) :AuditException
// Author : Sujitha
// Creation Date : 18/5/2017
// Purpose : Audit Exception Methods 
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.ExceptionHandling
{
    public class AuditException : BaseException
    {
       
         public AuditException()
        {

        }

        /// <summary>
        /// Custom Exception Constructor with message
        /// </summary>
        /// <param name="message">string</param>
        public AuditException(string message) : base(message)
        {
            this.customMessage = message;
        }

        /// <summary>
        /// Custom Exception Constructor with message and inner exception
        /// </summary>
        /// <param name="message">string</param>
        /// <param name="inner">Exception</param>
        public AuditException(string message, Exception inner)
            : base(message, inner)
        {
            this.customMessage = message;
            this.innerException = inner;
        }
    }
}
