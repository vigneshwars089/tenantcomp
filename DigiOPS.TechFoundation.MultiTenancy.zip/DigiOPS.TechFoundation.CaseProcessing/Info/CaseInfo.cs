﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.CaseProcessing
{
   public class CaseInfo : BaseInfo
    {
       public CaseInfo() 
            {
                Attachments = new List<AttachmentInfo>();
                Comments = new List<CommentsInfo>();
                Traversal = new List<TraversalInfo>();  
              
            }
       public string CaseID { get; set; }
       public string EmailInfo { get; set; }
       public List<AttachmentInfo> Attachments { get; set; }
       public List<CommentsInfo> Comments { get; set; }
       public List<TraversalInfo> Traversal { get; set; }
    }
   public class AttachmentInfo : CaseInfo 
   {
   }
   public class CommentsInfo : CaseInfo
   {
   }
   public class TraversalInfo : CaseInfo
   {
   }
}
