﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.DataTransfer
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :DataTransferFactory.cs
    // Namespace : DigiOps.TechFoundation.DataTransfer
    // Class Name(s) :DataTransferFactory
    // Author : Sujitha
    // Creation Date : 5/9/2017
    // Purpose : For the Case Creation 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //9-May-2017    Megha     CCHandler            Added CCHandler method  
    //9-May-2017    Megha     GetFileDataTransferHandler           Handler for case creation by file  
    //9-May-2017    Megha     GetMailDataTransferHandler            Handler for case creation by mail  
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public class DataTransferFactory : IDataTransferFactory
    {
        public struct S_eMailType
        {

            public const string GMail = "GMAIL";
            public const string OutBox365 = "OUTBOX365";
            public const string OutLook = "OUTLOOK";

        }
        public struct S_DataTransferFileTypes
        {
            public const string Excel = "Excel";
            public const string PDF = "PDF";
        }

        /// <summary>
        /// const for the case creation type
        /// </summary>
        public struct S_CaseCreationType
        {

            public const string EMT = "EMT";
            public const string TrackWork = "TRACKWORK";
            public const string Quart = "QUART";

        }

        public struct s_DataTransferExcelExportTypes
        {
            public const string Html = "HTML";
            public const string Excel = "EXCEL";
        }
        public IDataTransfer GetFileDataTransferHandler(string Type)
        {
            if (string.IsNullOrEmpty(Type))
            {
                return new BaseDocuDataTransfer();
            }
            else if (Type.ToUpper().Trim() == s_DataTransferExcelExportTypes.Excel || Type.ToUpper().Trim() == s_DataTransferExcelExportTypes.Html)
            {
               
            }
            else
            {
                return new BaseDocuDataTransfer();
            }
           
            switch (Type)
            {

                case S_DataTransferFileTypes.Excel:
                    return new ExcelDataTransfer();

                default:
                    return null;

            }





        }

        public IMailDataTransfer GetMailDataTransferHandler(string Type)
        {
            if (string.IsNullOrEmpty(Type))
            {
                return new BaseMailDataTransfer();
            }
            else if (Type.ToUpper().Trim() == S_eMailType.GMail || Type.ToUpper().Trim() == S_eMailType.OutBox365 || Type.ToUpper().Trim() == S_eMailType.OutLook)
            {
                
            }
            else
            {
                return new BaseMailDataTransfer();
            }
            
            switch (Type)
            {


                case S_eMailType.GMail:
                    return new GmailDataTransfer();
                //case S_eMailType.OutBox365:
                //    return new OutBox365MailReading();
                //case S_eMailType.OutLook:
                //    return new OutlookDataTransfer();
                default:
                    return null;




            }
        }



        /// <summary>
        /// Quart Case Creation
        /// </summary>
        /// <param name="eInfo"></param>
        /// <returns></returns>
        public ICaseCreation CaseCreationHandler(string Type)
        {
            if (string.IsNullOrEmpty(Type))
            {
                return new BaseCaseCreation();
            }
            else if (Type.ToUpper().Trim() == S_CaseCreationType.EMT || Type.ToUpper().Trim() == S_CaseCreationType.TrackWork || Type.ToUpper().Trim() == S_CaseCreationType.Quart)
            {
                
            }
            else
            {
                return new BaseCaseCreation();
            }
            switch (Type)
            {
                case S_CaseCreationType.Quart:
                    return new CaseHandling();
                   
                default:
                    return null;
            }
        }
    }
}
