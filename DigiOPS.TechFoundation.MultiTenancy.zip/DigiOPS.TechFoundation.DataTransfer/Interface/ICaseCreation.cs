﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.DataTransfer
{
   public interface ICaseCreation
    {
      // string validateInput(CaseCreationInput eInfo);
       //string CreateCases(EmailResponceInfo eInfo, string MailFolderId, string StatusId, string caseID, string subcaseid);
       string CreateCases(ElementDatas elementdata);
       //List<TransactionListViewModal> RetrieveTransactions(CaseCreationInfo casecreationinfo);
       // List<TransactionListViewModal> Retrieve(CaseCreationInfo casecreationinfo);
       string Update(CaseCreationInfo casecreationinfo);
       string Delete(CaseCreationInfo casecreationinfo);
       void Search(CaseCreationInfo casecreationinfo);
       void Purge(CaseCreationInfo casecreationinfo);
    }
}
