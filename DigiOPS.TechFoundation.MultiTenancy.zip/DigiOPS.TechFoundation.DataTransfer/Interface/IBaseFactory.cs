﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.DataTransfer
{
    public interface IBaseFactory
    {
        //ICaseCreation validateFactory(EMailInfo eInfo);
        //ICaseCreation EMTCCHandler(EMailInfo eInfo);
        //ICaseCreation TrackworkCCHandler(EMailInfo eInfo);
        //ICaseCreation QuartCCHandler(EMailInfo eInfo);  
        ICaseCreation CCHandler(EMailInfo eInfo);  
               
    }
}
