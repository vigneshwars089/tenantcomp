﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.DataTransfer
{
    public interface IEmailReading 
    {
        //EMailInfo readMail(EMailInfo emailInfo);
        EmailResponceInfo ReadMails(EMailInfo emailInfo);
        EmailResponceInfo MoveMails(MoveMailsInfo emailInfo);
    }
}
