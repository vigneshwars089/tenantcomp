﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataTransfer
{
    public interface IDataTransfer
    {
        DataTransferInfo ReadfromSource(CaseCreationInfo CaseCreationInfo);
        DataTransferInfo TransformSourceDataInfo(DataTransferInfo dataTransferinfo);
        DataTransferInfo CreateCaseforSourceData(ExcelTemplate objExcelTemplate);

        DataTransferInfo SavetoDestination();

        DataTransferInfo UploadToServer(CaseCreationInfo CaseCreationInfo);

        DataTransferInfo DownloadtoClient(string filePath, string sheetName, DataTransferInfo dataTransferInfo);


    }
}
