﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using NodaTime;
using NodaTime.Text;
using System.Globalization;
using System.Xml;
using System.Web;
using NodaTime.TimeZones;

namespace DigiOPS.TechFoundation.DataTransfer
{
    class DateTimePatterns
    {
        public const string longDateTimePattern = "dd/MM/yyyy HH:mm:ss";
        public const string shortDatePattern = "dd-MM-yyyy";
        public const string twelveHourPattern = "dd-MM-yyyy hh:mm:ss tt";

        // Nodatime does not work with leading Zero. Hence removing leading zero format for Parsing

        public const string nodaDateTimePattern = "d/M/yyyy H:m:s";
        public const string nodaLongDateTimePattern = "d/M/yyyy H:m:s";
        public const string nodaDatePattern = "d/M/yyyy";
        public const string nodaTwelveHourPattern = "d/M/yyyy h:m:s tt";

    }
    public class TransformDateTime
    {


        /// <summary>
        /// Method to convert mentioned time to a specific time zone.
        /// </summary>
        /// <param name="dateTimeString">datetime to be converted</param>
        /// <param name="isUtcTime"> is the datetime inout in utc?</param>
        /// <param name="clientTimeZoneID">destination time zone to which the datetime has to be converted to</param>
        /// <param name="isDate">is the output expected in date format?</param>
        /// <returns></returns>
        public static string GetZonedDateTimeToDisplay(string dateTimeString, bool isUtcTime, string clientTimeZoneID, bool isDate)
        {

            string zonedDateTimeStr = string.Empty;
            string dateTimePattern = DateTimePatterns.nodaDateTimePattern;
            string outPutPattern = DateTimePatterns.longDateTimePattern;
            string configuredTimeZoneID = string.Empty;
            try
            {
                dateTimeString = dateTimeString.Replace("-", "/");
                string timeZoneID = System.Configuration.ConfigurationSettings.AppSettings.Get("ServerTimeZoneFormat").ToString();
                if (!String.IsNullOrEmpty(timeZoneID))
                {
                    configuredTimeZoneID = timeZoneID;
                }
                TzdbDateTimeZoneSource source = new TzdbDateTimeZoneSource("NodaTime.TimeZones.Tzdb");
                string NodaClientTimeZoneId = source.MapTimeZoneId(TimeZoneInfo.FindSystemTimeZoneById(clientTimeZoneID));
                string NodaConfiguredTimeZoneId = source.MapTimeZoneId(TimeZoneInfo.FindSystemTimeZoneById(configuredTimeZoneID));
                DateTimeZone configuredTimeZone = DateTimeZoneProviders.Tzdb[NodaConfiguredTimeZoneId];// that of server?? eg IST
                DateTimeZone clientTimeZone = DateTimeZoneProviders.Tzdb[NodaClientTimeZoneId];//Eastern Standard Time??
                if (isDate)
                {
                    outPutPattern = DateTimePatterns.shortDatePattern;
                }
                if (!isUtcTime)
                {
                    if (dateTimeString.IndexOf("AM") > 0 || dateTimeString.IndexOf("PM") > 0)
                    {
                        dateTimePattern = DateTimePatterns.nodaTwelveHourPattern;
                    }
                    else
                    {
                        dateTimePattern = DateTimePatterns.nodaDateTimePattern;
                        if (dateTimeString.IndexOf(":") < 0)
                        {
                            dateTimePattern = DateTimePatterns.nodaDatePattern;
                        }
                        else if (dateTimeString.IndexOf("/") == 4)
                        {
                            dateTimePattern = DateTimePatterns.nodaLongDateTimePattern;
                        }
                    }

                    LocalDateTimePattern pattern = LocalDateTimePattern.CreateWithInvariantCulture(dateTimePattern);

                    ParseResult<LocalDateTime> parseResult = pattern.Parse(dateTimeString);
                    if (!parseResult.Success)
                    {
                        throw new Exception("NodaTime Parse failed  - " + parseResult.Value.ToString());
                    }
                    else
                    {
                        LocalDateTime localDateTime = parseResult.Value;
                        ZonedDateTime clientDateTime = localDateTime.InZoneLeniently(configuredTimeZone);
                        LocalDateTime zonedDateTimeOutput = clientDateTime.ToInstant().InZone(clientTimeZone).LocalDateTime;
                        zonedDateTimeStr = zonedDateTimeOutput.ToString(outPutPattern, CultureInfo.InvariantCulture);
                    }
                }
                else
                {
                    DateTime utcDateTime = DateTime.SpecifyKind(DateTime.Parse(dateTimeString), DateTimeKind.Utc);
                    Instant inst = Instant.FromDateTimeUtc(utcDateTime);
                    ZonedDateTime zonedDt = new ZonedDateTime(inst, clientTimeZone);

                    zonedDateTimeStr = zonedDt.LocalDateTime.ToString(outPutPattern, CultureInfo.InvariantCulture);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return zonedDateTimeStr;
        }

        //public static string CurrentTimeToZonedTime(string serverTimeZoneID)
        //{
        //    string zonedDateTimeStr = string.Empty;
        //    string dateTimePattern = string.Empty;
        //    string outPutPattern = "dd-MM-yyyy HH:mm:ss";
        //    var serverTimeZone = DateTimeZoneProviders.Tzdb[serverTimeZoneID];
        //    try
        //    {
        //        DateTime utcDateTime = DateTime.UtcNow;
        //        var inst = Instant.FromDateTimeUtc(utcDateTime);
        //        var zonedDt = new ZonedDateTime(inst, serverTimeZone);

        //        zonedDateTimeStr = zonedDt.LocalDateTime.ToString(outPutPattern, CultureInfo.InvariantCulture);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return zonedDateTimeStr;
        //}

        /// <summary>
        /// Method to convert the date and time from a specific timezone to UTC
        /// </summary>
        /// <param name="dateTimeString">String representing the date and time to be converted to utc</param>
        /// <param name="timeZoneID">timezone from which the mentioned date has to be converted to utc</param>
        /// <returns></returns>
        public static string GetUtcTimeFromZonedTime(string dateTimeString, string timeZoneID)
        {
            string utcTime = string.Empty;
            string dateTimePattern = string.Empty;

            dateTimeString = dateTimeString.Replace("-", "/");
            try
            {
                if (dateTimeString.IndexOf("1900") > 0)
                {
                    utcTime = dateTimeString;
                }
                else
                {
                    if (dateTimeString.IndexOf(":") > 0)
                    {
                        dateTimePattern = DateTimePatterns.longDateTimePattern;
                        if (dateTimeString.IndexOf("AM") > 0 || dateTimeString.IndexOf("PM") > 0)
                        {
                            dateTimePattern = DateTimePatterns.nodaTwelveHourPattern;
                        }
                        else if (dateTimeString.IndexOf("/") == 4)
                        {
                            dateTimePattern = DateTimePatterns.longDateTimePattern;
                        }
                    }
                    else
                    {
                        dateTimePattern = DateTimePatterns.nodaDatePattern;
                    }
                    LocalDateTimePattern pattern = LocalDateTimePattern.CreateWithInvariantCulture(dateTimePattern);
                    ParseResult<LocalDateTime> parseResult = pattern.Parse(dateTimeString);
                    if (!parseResult.Success)
                    {
                        throw new Exception("NodaTime Parse failed  - " + parseResult.Value.ToString());
                    }
                    else
                    {
                        LocalDateTime localDateTime = parseResult.Value;

                        TzdbDateTimeZoneSource source = new TzdbDateTimeZoneSource("NodaTime.TimeZones.Tzdb");
                        string NodatimeZoneID = source.MapTimeZoneId(TimeZoneInfo.FindSystemTimeZoneById(timeZoneID));
                        DateTimeZone timeZone = DateTimeZoneProviders.Tzdb[NodatimeZoneID];
                        ZonedDateTime zonedDateTime = localDateTime.InZoneLeniently(timeZone);
                        utcTime = zonedDateTime.ToDateTimeUtc().ToString(dateTimePattern, CultureInfo.InvariantCulture);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return utcTime;
        }


    }
}
