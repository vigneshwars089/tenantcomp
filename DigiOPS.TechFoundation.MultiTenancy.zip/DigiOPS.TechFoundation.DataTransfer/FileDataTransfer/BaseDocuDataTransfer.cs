﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;
using System.Configuration;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
namespace DigiOPS.TechFoundation.DataTransfer
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :BaseDocuDataTransfer.cs
    // Namespace : DigiOps.TechFoundation.DataTransfer
    // Class Name(s) :BaseDocuDataTransfer
    // Author : Sadhesh
    // Creation Date : 5/22/2017
    // Purpose : base class for Case Creation Through Excel or PDF
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //22-May-2017    Sadhesh     CreateCaseforSourceData            Added CreateCases method  
    //22-May-2017    Sadhesh     DownloadtoClient            Download the Excel or PDF  
    //22-May-2017    Sadhesh     ReadfromSource            Read content from source file 
    //22-May-2017    Sadhesh     SavetoDestination            Save file to destination path
    //22-May-2017    Sadhesh     TransformSourceDataInfo           TransformSourceDataInfo
    //22-May-2017    Sadhesh     UploadToServer            Save to server 
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class BaseDocuDataTransfer : IDataTransfer
    {

        public virtual DataTransferInfo CreateCaseforSourceData(ExcelTemplate objExcelTemplate)
        {

            throw new NotImplementedException();
        }

        
        public virtual DataTransferInfo DownloadtoClient(string filePath, string sheetName, DataTransferInfo dataTransferInfo)
        {
            throw new NotImplementedException();
        }

        public virtual DataTransferInfo ReadfromSource(CaseCreationInfo CaseCreationInfo)
        {
            throw new NotImplementedException();
        }

        public virtual DataTransferInfo SavetoDestination()
        {
            throw new NotImplementedException();
        }

        public virtual DataTransferInfo TransformSourceDataInfo(DataTransferInfo dataTransferinfo)
        {
            throw new NotImplementedException();
        }

        public virtual DataTransferInfo UploadToServer(CaseCreationInfo CaseCreationInfo)
        {
            throw new NotImplementedException();
        }
    }
}
