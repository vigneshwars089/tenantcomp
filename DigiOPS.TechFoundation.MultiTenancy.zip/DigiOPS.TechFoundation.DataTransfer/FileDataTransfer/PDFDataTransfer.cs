﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataTransfer
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :ExcelDataTransfer.cs
    // Namespace : DigiOps.TechFoundation.DataTransfer
    // Class Name(s) :ExcelDataTransfer
    // Author : Sadhesh
    // Creation Date : 5/22/2017
    // Purpose : Case Creation Through PDF 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class PDFDataTransfer : BaseDocuDataTransfer
    {
      
    }
}
