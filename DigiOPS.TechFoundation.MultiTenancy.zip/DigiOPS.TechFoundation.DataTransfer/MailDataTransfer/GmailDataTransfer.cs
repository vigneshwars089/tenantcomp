﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataTransfer
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :BaseMailDataTransfer.cs
    // Namespace : DigiOps.TechFoundation.DataTransfer
    // Class Name(s) :BaseMailDataTransfer
    // Author : Sadhesh
    // Creation Date : 5/22/2017
    // Purpose : base class for Case Creation Through Gmail 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //22-May-2017    Sadhesh     CreateCaseforSourceData            Added CreateCases method  
    //22-May-2017    Sadhesh     DownloadtoClient            Download the Excel or PDF  
    //22-May-2017    Sadhesh     ReadfromSource            Read content from source file 
    //22-May-2017    Sadhesh     SavetoDestination            Save file to destination path
    //22-May-2017    Sadhesh     TransformSourceDataInfo           TransformSourceDataInfo
    //22-May-2017    Sadhesh     UploadToServer            Save to server 
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class GmailDataTransfer : BaseMailDataTransfer
    {


        //public override DataTransferInfo CreateCaseforSourceData()
        //{
        //    throw new NotImplementedException();
        //}

        public override DataTransferInfo DownloadtoClient()
        {
            throw new NotImplementedException();
        }

        public override DataTransferInfo ReadAttachementfromSource(EMailInfo emailInfo)
        {
            throw new NotImplementedException();
        }

        public override DataTransferInfo ReadfromSource(EMailInfo EMailInfo)
        {
            throw new NotImplementedException();
        }

        public override DataTransferInfo SavetoDestination()
        {
            throw new NotImplementedException();
        }

        public override DataTransferInfo TransformSourceDataInfo(MoveMailsInfo MoveMailsInfo)
        {
            throw new NotImplementedException();
        }

        public override DataTransferInfo UploadToServer()
        {
            throw new NotImplementedException();
        }
    }
}
