﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;


namespace DigiOPS.TechFoundation.Allocation
{////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :FifoAllocation.cs
    // Namespace : DigiOps.TechFoundation.Allocation
    // Class Name(s) :FifoAllocation
    // Author : Venkata Lakshmi CH.
    // Creation Date : 5/12/2017
    // Purpose : Allocation Component
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public class FifoAllocation : BaseAllocation
    {
        ////////////////////////////////////////////////////////////////////////////////////
        // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
        ////////////////////////////////////////////////////////////////////////////////////
        // File Name :FifoAllocation.cs
        // Namespace : DigiOps.TechFoundation.Allocation
        // Method Name(s) :DoAllocate
        // Author : Venkata Lakshmi CH.
        // Creation Date : 5/12/2017
        // Purpose : InsertAllocationDetails method added for Allocation Component
        //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
        // Date           Name               Method Name                        Description
        // ----------   --------             -------------------------- --------------------------------------------------
        //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
        //////////////////////////////////////////////////////////////////////////////////////////////////////

        public override AllocatedDetails Allocate(AllocationDetails allocationDetails)
        {

            allocationDetails = AllocationValidation(allocationDetails);
            AllocatedDetails allocatedDetails = new AllocatedDetails();
            //int RecordCount = allocatedDetails.
            if (allocationDetails.ResultStatus)
            {

                allocatedDetails.CreatedBy = allocationDetails.CreatedBy;
                allocatedDetails.CreatedOn = allocationDetails.CreatedOn;
                if (allocationDetails.AllocateToUsers.Count > 1)
                {
                    allocatedDetails.ErrorMessage.Append("User" + ErrorMessgae.Not_More_thanOne);
                }
                else
                {
                    string userid = allocationDetails.AllocateToUsers[0].UserID;
                    //var RecordDetails = allocationDetails.RecordDetails.ToList().OrderByDescending()
                    var RecordDetails = allocationDetails.RecordDetails.ToList().OrderBy(x => x.TransID).Take(3);


                    //ColHeaderRow = Convert.ToInt32(ColHeaderDict.OrderByDescending(r => r.Value)
                    //                   .Select(r => r.Value)
                    //                   .Take(1));

                    // var RecordDetails = allocationDetails.RecordDetails.ToList().OrderByDescending(x => x.TransID)
                    //.Take(allocationDetails.TotalRecordsToAllocate);


                    var LstAllocatedDetails = (from x in RecordDetails
                                               select new AllocatedDetail { TransID = x.TransID, UserID = userid }).ToList();
                    allocatedDetails.AllocatedDetailsList = LstAllocatedDetails;
                    //  objALD.TransListDetailsToAllocate = objTransListDetailsToAllocate;

                    // var LstAllocatedDetails = new List<AllocatedDetails>();
                    // var a =from _AllocationDetails in allocationDetails select new AllocatedDetailsllo{ _AllocationDetails.RecordDetails.TransID,  }
                }
            }
            //var user = allocationDetails.AllocateToUsers[0].UserID;
            return allocatedDetails;

        }
    }
}
