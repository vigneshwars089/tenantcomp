﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
//using DigiOPS.TechFoundation.DataAccessLayer;

namespace DigiOPS.TechFoundation.Allocation
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :ReAllocation.cs
    // Namespace : DigiOps.TechFoundation.Allocation
    // Class Name(s) :ReAllocation
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/27/2017
    // Purpose : Added ReAllocation to Allocation Component
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class ReAllocation : BaseAllocation
    {
        //public override string DoAllocate(AllocationListDetails TLDA)
        //{
        //    BaseAllocation objBase = new BaseAllocation();
        //    AllocationListDetails objALD = new AllocationListDetails();

        //    /// Call Validation method
        //    objALD = objBase.AllocationValidation(TLDA);

        //   if (objALD.ResultStatus)
        //   {

        //       string rtnVal;
        //       AllocationDataAccess AllocationDA = new AllocationDataAccess();

        //       rtnVal = AllocationDA.InsertAllocatedTrans(TLDA);
        //       objALD.ErrorMessage.Append(rtnVal.ToString());
        //   }
        //   return objALD.ErrorMessage.ToString();
        //}

        public override AllocatedDetails Allocate(AllocationDetails allocationDetails)
        {

            allocationDetails = AllocationValidation(allocationDetails);
            AllocatedDetails allocatedDetails = new AllocatedDetails();
            if (allocationDetails.ResultStatus)
            {

                allocatedDetails.CreatedBy = allocationDetails.CreatedBy;
                allocatedDetails.CreatedOn = allocationDetails.CreatedOn;
                if (allocationDetails.AllocateToUsers.Count > 1)
                {
                    allocatedDetails.ErrorMessage.Append("User" + ErrorMessgae.Not_More_thanOne);
                }
                else
                {
                    if (allocationDetails.ReAllocateType == Constants.Pushback)
                    {

                        //  var user = allocationDetails.AllocateToUsers[0].UserID;
                        foreach (var allocationDetailsList in allocationDetails.RecordDetails)
                        {
                            var AllocatedDetailsList = new AllocatedDetail();
                            AllocatedDetailsList.UserID = "";
                            AllocatedDetailsList.TransID = allocationDetailsList.TransID;

                            allocatedDetails.AllocatedDetailsList.Add(AllocatedDetailsList);
                        }
                    }
                    else if (allocationDetails.ReAllocateType == Constants.Reallocate)
                    {

                        var user = allocationDetails.AllocateToUsers[0].UserID;
                        foreach (var allocationDetailsList in allocationDetails.RecordDetails)
                        {
                            var AllocatedDetailsList = new AllocatedDetail();
                            AllocatedDetailsList.UserID = user;
                            AllocatedDetailsList.TransID = allocationDetailsList.TransID;

                            allocatedDetails.AllocatedDetailsList.Add(AllocatedDetailsList);
                        }
                    }

                }

            }

            return allocatedDetails;
        }
    }
}
