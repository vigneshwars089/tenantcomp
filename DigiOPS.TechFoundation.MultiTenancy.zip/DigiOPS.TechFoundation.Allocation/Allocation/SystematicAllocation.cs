﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
//using DigiOPS.TechFoundation.DataAccessLayer;

namespace DigiOPS.TechFoundation.Allocation
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :SystematicAllocation.cs
    // Namespace : DigiOps.TechFoundation.Allocation
    // Class Name(s) :SystematicAllocation
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/27/2017
    // Purpose : Added SystematicAllocation to Allocation Component
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class SystematicAllocation : BaseAllocation
    {
        public override AllocatedDetails Allocate(AllocationDetails allocationDetails)
        {
            allocationDetails = AllocationValidation(allocationDetails);
            AllocatedDetails allocatedDetails = new AllocatedDetails();
            if (allocationDetails.ResultStatus)
            {

                allocatedDetails.CreatedBy = allocationDetails.CreatedBy;
                allocatedDetails.CreatedOn = allocationDetails.CreatedOn;
                int usercount = allocationDetails.AllocateToUsers.Count;
                allocatedDetails.AllocatedDetailsList = new List<AllocatedDetail>();
                //  foreach (var user in allocationDetails.AllocateToUsers)
                // {
                int UserIndex = 0;
                if (usercount > 0)
                {
                    foreach (var allocationDetailsList in allocationDetails.RecordDetails)
                    {

                        var AllocatedDetailsList = new AllocatedDetail();
                        AllocatedDetailsList.UserID = allocationDetails.AllocateToUsers[UserIndex].UserID;
                        AllocatedDetailsList.TransID = allocationDetailsList.TransID;

                        allocatedDetails.AllocatedDetailsList.Add(AllocatedDetailsList);
                        UserIndex += 1;
                        if (UserIndex == usercount) UserIndex = 0;
                    }
                }
                //}
            }
            else
            {
                allocatedDetails = null;
            }
            return allocatedDetails;
        }
    }
}
