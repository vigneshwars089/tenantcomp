﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Allocation
{

    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :Constants.cs
    // Namespace : DigiOps.TechFoundation.Allocation
    // Class Name(s) :Constants
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/27/2017
    // Purpose : Added Constants to Allocation Component
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public class Constants
    {
        #region ALLOCATION_TYPES
        public const string SYSTEMATIC = "Systematic";
        public const string LIVEAUDIT = "LiveAudit";
        public const string REALLOCATION = "ReAllocation";
        public const string FIFO = "Fifo";

        public const string Pushback = "Push back";
        public const string Reallocate = "Re allocate";
        #endregion
    }
}
