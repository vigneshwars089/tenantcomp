﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Allocation
{

    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :IAllocation.cs
    // Namespace : DigiOps.TechFoundation.Allocation
    // Interface Name(s) :IAllocation
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/27/2017
    // Purpose : Added DoAllocate method
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public interface IAllocation
    {
        //string DoAllocate(int BatchID, int CreatedBy, int SubProcessId);
        AllocatedDetails Allocate(AllocationDetails TLDA);
    }
}
