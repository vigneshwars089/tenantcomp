﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Allocation
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :AllocationFactory.cs
    // Namespace : DigiOps.TechFoundation.Allocation
    // Class Name(s) :AllocationFactory
    // Author : Venkata Lakshmi CH.
    // Creation Date : 4/27/2017
    // Purpose : Create new Objects at runtime for Allocation Component
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name               Method Name                        Description
    // ----------   --------             -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX              SXXXXX                              Added XXX method   
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public class AllocationFactory:IAllocationFactory
    {

        public IAllocation GetAllocateHandler(string AllocationType)
        {
            IAllocation objAllocation = null;
            switch (AllocationType)
            {
                case Constants.SYSTEMATIC:
                    objAllocation = new SystematicAllocation();
                    break;
               case Constants.LIVEAUDIT:
                    objAllocation = new LiveAuditAllocation();
                    break;
                case Constants.REALLOCATION:
                    objAllocation = new ReAllocation();
                    break;
                case Constants.FIFO:
                    objAllocation = new FifoAllocation();
                    break;
            }
            return objAllocation;
        }
    }
}
