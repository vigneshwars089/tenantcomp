﻿using DigiOPS.TechFoundation.Calibration.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.Calibration.WorkBucket
{
    public class BaseWorkBucket : IWorkBucket
    {
        public List<AuditTransactionListViewModal> GetAuditTransactionList(AuditTransactionListViewModal objBase)
        {
            throw new NotImplementedException();
        }
    }
}
