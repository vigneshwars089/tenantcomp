﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class ProgramFeaturesDataAccess
    {
        ProgramFeaturesDAO prodao = null;

        ProgramFeatureTransformer programtrans = new ProgramFeatureTransformer();
         LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
         public ProgramFeaturesDataAccess()
        {
            objloginfo.Message = ("ProgramFeaturesDataAccess - Called." + "Tenant Name and AppId is not passed");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
         }
         public ProgramFeaturesDataAccess(string TenantName, string AppId)
        {
            prodao = new ProgramFeaturesDAO(TenantName, AppId);            
        }
        public string AddUpdateProgramFeatures(ProgramFeatureSetUp programEnt)
        {
            //prodao = new ProgramFeaturesDAO(programEnt.AppID, programEnt.TenantID);
            string createRecVal = string.Empty;
            createRecVal = prodao.SetProgramFeatures(programEnt);
            return createRecVal;
        }
        public List<ProgramFeatureSetUp> GetProgramFeatures(int programId,string AppID,string TenantName)
        {
            //prodao = new ProgramFeaturesDAO(AppID, TenantID);
            List<ProgramFeatureSetUp> listprog = new List<ProgramFeatureSetUp>();
            DataTable dt = new DataTable();
            dt = prodao.GetProgramFeatures(programId, TenantName,AppID);
            if (dt.Rows.Count <= 0)
                return listprog;
            else
            {
                listprog = programtrans.MapToProgramFeatureList(dt);
            }
            return listprog;
        }
    }
}
