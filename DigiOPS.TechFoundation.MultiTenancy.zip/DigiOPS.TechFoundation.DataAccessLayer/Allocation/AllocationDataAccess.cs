﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using DigiOPS.TechFoundation.Entities;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class AllocationDataAccess
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        AllocationDAO AllocationDao = null;

        public AllocationDataAccess()
        {
            objloginfo.Message = ("AllocationDataAccess - Called."+"Tenant Name and AppId is not passed");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
         }
        public AllocationDataAccess(string TenantName, string AppId)
        {
            AllocationDao = new AllocationDAO(TenantName, AppId);
            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }

        public string InsertAllocatedTrans(AllocationListDetails TLDA)
        {
            string createRecVal = string.Empty;
            string Auditorsxml = string.Empty;
            string Transxml = string.Empty;

            Auditorsxml = SerializeToString(TLDA.AuditorsListDetails);
            Transxml = SerializeToString(TLDA.TransListDetailsToAllocate);

            try
            {
                createRecVal = AllocationDao.InsertAllocationDetails(Transxml, Auditorsxml, TLDA.CreatedBy, TLDA.SubProcessId, TLDA.AllocationType);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return createRecVal;
        }
        public string SerializeToString(object value)
        {
            var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
            var serializer = new XmlSerializer(value.GetType());
            var settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.OmitXmlDeclaration = true;

            using (var stream = new StringWriter())
            using (var writer = XmlWriter.Create(stream, settings))
            {
                serializer.Serialize(writer, value, emptyNamepsaces);
                string str = stream.ToString().Replace("<TransactionListResponse>\r\n ", "");
                str = str.Replace("\r\n</TransactionListResponse>", "");

                return str;

            }
        }

    }
}
