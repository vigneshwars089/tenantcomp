﻿using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class AuditConfigurationDataAccess : AuditConfigurationRepository
    {
        AuditConfigurationDAO objconfigurationDAO = null;
        LoggingFactory objlog = new LoggingFactory();
          LogInfo objloginfo = new LogInfo();
         public AuditConfigurationDataAccess()
        {
            objloginfo.Message = ("AuditConfigurationDataAccess - Called." + "Tenant Name and AppId is not passed");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
         }
         public AuditConfigurationDataAccess(string TenantName, string AppId)
        {
            objconfigurationDAO = new AuditConfigurationDAO(TenantName, AppId);           
        }
        public override System.Data.DataSet GetExcelTemplate()
        {
            DataSet dsconfigurationDAO = new DataSet();

            try
            {
                dsconfigurationDAO = objconfigurationDAO.GetExcelTemplate();
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return dsconfigurationDAO;
        }

        public override System.Data.DataSet InsertAuditConfigDetails(System.Data.DataSet ds)
        {
            DataSet dsconfigurationDAO = new DataSet();

            try
            {
                dsconfigurationDAO = objconfigurationDAO.InsertAuditConfigDetails(ds);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return dsconfigurationDAO;
        }

        public override string defectopportunity(System.Data.DataTable result1)
        {
            string strconfiguration = string.Empty;

            try
            {
                strconfiguration = objconfigurationDAO.defectopportunity(result1);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return strconfiguration;
        }

        public override string subdefectopportunity(System.Data.DataTable result1)
        {
            string strconfiguration = string.Empty;

            try
            {
                strconfiguration = objconfigurationDAO.subdefectopportunity(result1);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return strconfiguration;
        }

        public override string Ratingtype(System.Data.DataTable result1)
        {
            string strratingtype = string.Empty;

            try
            {
                strratingtype = objconfigurationDAO.Ratingtype(result1);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return strratingtype;
        }

        public override string Ratinggroup(System.Data.DataTable result1)
        {
            string strRatinggroup = string.Empty;

            try
            {
                strRatinggroup = objconfigurationDAO.Ratinggroup(result1);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return strRatinggroup;
        }

        public override string CombinedAccuracy(System.Data.DataTable result1)
        {
            string strCombinedAccuracy = string.Empty;

            try
            {
                strCombinedAccuracy = objconfigurationDAO.CombinedAccuracy(result1);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return strCombinedAccuracy;
        }

        public override System.Data.DataSet DefectSubDefectValidation()
        {
            DataSet dsconfigurationDAO = new DataSet();

            try
            {
                dsconfigurationDAO = objconfigurationDAO.DefectSubDefectValidation();
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return dsconfigurationDAO;
        }

        public override System.Data.DataSet RatingTypeValidation()
        {
            DataSet dsconfigurationDAO = new DataSet();

            try
            {
                dsconfigurationDAO = objconfigurationDAO.RatingTypeValidation();
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return dsconfigurationDAO;
        }

        public override System.Data.DataSet CombinedAccuracyValidation()
        {
            DataSet dsconfigurationDAO = new DataSet();

            try
            {
                dsconfigurationDAO = objconfigurationDAO.CombinedAccuracyValidation();
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return dsconfigurationDAO;
        }
    }
}
