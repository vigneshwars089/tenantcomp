﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DigiOPS.TechFoundation.Logging;
using System.IO;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class UserConfigurationDAO
    {
        LoggingFactory objloggingfactory = new LoggingFactory();
        LogInfo objlog = new LogInfo();
        private string __connectionString = "";
        string error = "";
        string user = "TemptblUserMaster";
        string UserGroup = "TemptblUserGroupMaster";
        string UserGroupUserMapping = "TemptblUseGroupRoleMap";
        // string UserRoleMapping = "UserRoleMapping";
        string RolePermissionMapping = "TemptblUserRolePermsMaster";

       // string strC = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;

        public UserConfigurationDAO()
        {
            __connectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;

        }
        public UserConfigurationDAO(string TenantName, string AppId)
        {

            __connectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }
        public UserConfigurationDAO(string appId, int tenantId)
        {
            //__connectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
            ConnectionString conn = new ConnectionString();
            __connectionString = conn.GetConnectionString(appId, tenantId);
        }
       
             
        
        public DataSet UserDetailsValidation()
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(__connectionString);
                connection.Open();
                DataSet ds = new DataSet();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandText = "SP_BULKUPLOAD_USERMANAGEMENT";
                    command.CommandType = CommandType.StoredProcedure;
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(ds);
                    }
                }
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if ((connection != null) && (connection.State == ConnectionState.Open))
                {
                    connection.Close();
                }
            }
        }


        public DataSet InsertUserDetails(DataSet result1)
        {
            
            SqlConnection conStr = new SqlConnection(__connectionString);
            //using (SqlConnection conStr = new SqlConnection(__connectionString))
            //{
            using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conStr.ConnectionString))
            {
                try
                {
                    
                    foreach (DataTable table in result1.Tables)
                    {
                        if (table.TableName == "User")
                        {
                            UserData(table);
                        }
                        else if (table.TableName == "UserGroup")
                        {
                            UserGroupData(table);
                        }
                        else if (table.TableName == "UserGroup-UserMapping" || table.TableName == "UserRoleMapping")
                        {
                            USerGroupUserMapping(table);
                        }
                        else if (table.TableName == "RolePermissionMapping")
                        {
                            RolePermission(table);
                        }
                         
                    }
                    
                   
                }
                catch (Exception ex)
                {
                   // error = "Table Content Out of bounds";

                }
               
            //}
            }
            return UserDetailsValidation();
            
        }

        public string UserData(DataTable result1)
        {
            SqlConnection conStr = new SqlConnection(__connectionString);
            using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conStr.ConnectionString))
            {
                try
                {
                    bulkcopy.DestinationTableName = user;
                    bulkcopy.BatchSize = result1.Rows.Count;
                    conStr.Open();
                    bulkcopy.WriteToServer(result1);
                    bulkcopy.Close();
                    conStr.Close();
                    error = "User Data Inserted Successfully";
                }
                catch (Exception ex)
                {
                    error = "Table Content Out of bounds";

                }
                return error;
            }
        }
        public string UserGroupData(DataTable result1)
        {
            SqlConnection conStr = new SqlConnection(__connectionString);
            using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conStr.ConnectionString))
            {
                try
                {
                    bulkcopy.DestinationTableName = UserGroup;
                    bulkcopy.BatchSize = result1.Rows.Count;
                    conStr.Open();
                    bulkcopy.WriteToServer(result1);
                    bulkcopy.Close();
                    conStr.Close();
                    error = "User Group Data Inserted Successfully";
                }
                catch (Exception ex)
                {
                    error = "Table Content Out of bounds";

                }

                return error;
            }

        }

        public string USerGroupUserMapping(DataTable result1)
        {
            SqlConnection conStr = new SqlConnection(__connectionString);
            using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conStr.ConnectionString))
            {
                try
                {
                    bulkcopy.DestinationTableName = UserGroupUserMapping;
                    bulkcopy.BatchSize = result1.Rows.Count;
                    conStr.Open();
                    bulkcopy.WriteToServer(result1);
                    bulkcopy.Close();
                    conStr.Close();
                    error = "User Group User data Inserted Successfully";
                }
                catch (Exception ex)
                {
                    error = "Table Content Out of bounds";

                }
                return error;
            }
        }

        //public string UserRole(DataSet result1)
        //{
        //    SqlConnection conStr = new SqlConnection(strC);
        //    using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conStr.ConnectionString))
        //    {
        //        try
        //        {
        //            bulkcopy.DestinationTableName = UserRoleMapping;
        //            bulkcopy.BatchSize = result1.Tables[0].Rows.Count;
        //            conStr.Open();
        //            bulkcopy.WriteToServer(result1.Tables[0]);
        //            bulkcopy.Close();
        //            conStr.Close();
        //            error = "UserRole Mapped Successfully";
        //        }
        //        catch (Exception ex)
        //        {
        //            error = "Table Content Out of bounds";

        //        }
        //        return error;
        //    }
        //}


        public string RolePermission(DataTable result1)
        {
            SqlConnection conStr = new SqlConnection(__connectionString);
            using (SqlBulkCopy bulkcopy = new SqlBulkCopy(conStr.ConnectionString))
            {
                try
                {
                    bulkcopy.DestinationTableName = RolePermissionMapping;
                    bulkcopy.BatchSize = result1.Rows.Count;
                    conStr.Open();
                    bulkcopy.WriteToServer(result1);
                    bulkcopy.Close();
                    conStr.Close();
                    error = "User Role Permissions Mapped Successfully";
                }
                catch (Exception ex)
                {
                    error = "Table Content Out of bounds";

                }
                return error;
            }


        }

    }
}

