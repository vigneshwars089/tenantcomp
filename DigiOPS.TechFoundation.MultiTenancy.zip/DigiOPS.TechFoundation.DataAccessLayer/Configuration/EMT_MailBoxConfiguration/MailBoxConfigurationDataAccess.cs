﻿using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class MailBoxConfigurationDataAccess
    {
        MailBoxConfigurationDAO objmbconfigdao = null;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
         public MailBoxConfigurationDataAccess()
        {
            objloginfo.Message = ("MailBoxConfigurationDataAccess - Called." + "Tenant Name and AppId is not passed");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
         }
         public MailBoxConfigurationDataAccess(string TenantName, string AppId)
        {
            objmbconfigdao = new MailBoxConfigurationDAO(TenantName, AppId);           
        }
        public int HierarchyCreation(int HierarchyLevel, string HierarchyLevelName, string HierarchyName, string HierarchyDesc, bool IsActive, string createdby, string tenantname, string parenthierarchy, string parenthierarchyvalue, string HierarchyPOC, string appId, int TenantId)
        {
           int result = 0;
           try
           {
               objmbconfigdao = new MailBoxConfigurationDAO();
               result = objmbconfigdao.HierarchyCreation(HierarchyLevel, HierarchyLevelName, HierarchyName, HierarchyDesc, IsActive, createdby, tenantname, parenthierarchy, parenthierarchyvalue, HierarchyPOC, appId, TenantId);
           }
           catch (Exception ex)
           {
               objlog.GetLoggingHandler("Log4net").LogException(ex, tenantname, appId);
           }
            return result;
        }

        public int GetMailBoxLoginDetails(string LoginEmailId, string pd, string TenantName, bool islocked, bool isactive, string appId, int TenantId)
        {
            objmbconfigdao = new MailBoxConfigurationDAO();
            int result = 0;
             try
           {
            
            result = objmbconfigdao.GetMailBoxLoginDetails( LoginEmailId, pd,TenantName, islocked, isactive,appId, TenantId);
           }
             catch (Exception ex)
             {
                 objlog.GetLoggingHandler("Log4net").LogException(ex, TenantName,appId);
             }
            return result;
        }

        public int GetMailBoxConfigurationDetails(string MailBoxName, string MailBoxAddress, string Domain, string MailBoxFolderPath,
            string TATInHours, int TATInSeconds, string TimeZone, string CreatedById, DateTime CreatedDate, bool IsQCRequired, bool IsActive,
            bool IsReplyNotRequired, bool IsMailTriggerRequired, string Offset, string IsEMailBoxAddressOptional, bool IsVOCSurvey,
            bool IsADLogin, bool IsSubjectEditable, bool IsGMBtoGMB, bool IsCustomizableCaseId, bool IsConversationHistory, string TenantName, string AppId, int TenantId, string HierarchyValuetobeTakenName, string HierarchyLevelNameValuetobeTaken)
        {
            objmbconfigdao = new MailBoxConfigurationDAO();
            int result = 0;
            try
            {
            result = objmbconfigdao.GetMailBoxConfigurationDetails
                (MailBoxName,MailBoxAddress,Domain,MailBoxFolderPath,TATInHours,TATInSeconds,TimeZone,CreatedById,CreatedDate,IsQCRequired,IsActive,
            IsReplyNotRequired, IsMailTriggerRequired, Offset, IsEMailBoxAddressOptional, IsVOCSurvey, IsADLogin, IsSubjectEditable, IsGMBtoGMB, IsCustomizableCaseId, IsConversationHistory, TenantName, HierarchyValuetobeTakenName, HierarchyLevelNameValuetobeTaken, AppId);
             }
           catch (Exception ex)
           {
               objlog.GetLoggingHandler("Log4net").LogException(ex, TenantName, AppId);
           }
            return result;
        }

        public int Set_ZoneANDMenu_Deatils(TenantInfo objTenantInfo)
        {
            objloginfo.Message = ("MailBoxConfigurationDetailsDAO - GetMailBoxLoginDetails - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);                    
            int ret=0;
            try
            {
                objmbconfigdao = new MailBoxConfigurationDAO();
                ret = objmbconfigdao.Set_ZoneANDMenu_Deatils(objTenantInfo);
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objTenantInfo.AuditFeatures.MenuInfo.TenantName, objTenantInfo.AuditFeatures.MenuInfo.AppID); throw;
            }           

            return ret;
 
        }

        public TenantInfo GetHierarchy(string TenantName, string HierarchyName, int HierarchyLevel) 
        {
            DataSet dt = new DataSet();
            TenantInfo objTenantInfo = new TenantInfo();
            HierarchyInfo objHierarchyInfo = new HierarchyInfo();
            objmbconfigdao = new MailBoxConfigurationDAO();
            try
            {
                dt = objmbconfigdao.GetHierarchy(TenantName, HierarchyName,HierarchyLevel);                
                if (dt.Tables.Count > 0)
                {
                    objHierarchyInfo = new HierarchyInfo();
                    for (int i = 0; i < dt.Tables.Count; i++)
                    {
                        objHierarchyInfo.HierarchyID = (dt.Tables[i].Rows[0]["HierarchyID"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[i].Rows[0]["HierarchyID"].ToString());
                        objHierarchyInfo.HierarchyLevel = (dt.Tables[i].Rows[0]["HierarchyLevel"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[i].Rows[0]["HierarchyLevel"].ToString());
                        objHierarchyInfo.HierarchyLevelName = (dt.Tables[i].Rows[0]["HierarchyLevelName"] == DBNull.Value) ? string.Empty : dt.Tables[i].Rows[0]["HierarchyLevelName"].ToString();
                        objHierarchyInfo.HierarchyName = (dt.Tables[i].Rows[0]["HierarchyName"] == DBNull.Value) ? string.Empty : dt.Tables[i].Rows[0]["HierarchyName"].ToString();
                        objHierarchyInfo.HierarchyDesc = (dt.Tables[i].Rows[0]["HierarchyDesc"] == DBNull.Value) ? string.Empty : dt.Tables[i].Rows[0]["HierarchyDesc"].ToString();
                        objHierarchyInfo.ParentId = (dt.Tables[i].Rows[0]["ParentId"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[i].Rows[0]["ParentId"].ToString());
                        objHierarchyInfo.IsActive = (dt.Tables[i].Rows[0]["IsActive"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[i].Rows[0]["IsActive"].ToString());
                        objHierarchyInfo.CreatedBy = (dt.Tables[i].Rows[0]["CreatedBy"] == DBNull.Value) ? string.Empty : dt.Tables[i].Rows[0]["CreatedBy"].ToString();
                        objHierarchyInfo.CreatedOn = (dt.Tables[i].Rows[0]["CreatedDate"] == DBNull.Value) ? DateTime.MinValue : Convert.ToDateTime(dt.Tables[i].Rows[0]["CreatedDate"].ToString());
                        objHierarchyInfo.HierarchyPOC = (dt.Tables[i].Rows[0]["HierarchyPOC"] == DBNull.Value) ? string.Empty : dt.Tables[i].Rows[0]["HierarchyPOC"].ToString();
                        objTenantInfo.HierarchyInfoList.Add(objHierarchyInfo);
                    }
                    objTenantInfo.ResultStatus = true;                    
                    }
                else
                    objTenantInfo.ResultStatus = false;
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex); }
            return objTenantInfo;            
        }

        //public TenantInfo GetEmailBox(string TenantName)
        //{
        //    DataTable dt = new DataTable();
        //    TenantInfo objTenantInfo = new TenantInfo();
        //    try
        //    {
        //        dt = objmbconfigdao.GetEmailBox(TenantName);
              
        //        if (dt.Rows.Count > 0)
        //        {
        //            objTenantInfo.DatabaseDetails.UserName = dt.Rows[0]["UserId"].ToString();
        //             objTenantInfo.DatabaseDetails.Password = dt.Rows[0]["Password"].ToString();
        //             objTenantInfo.DatabaseDetails.IsLocked = Convert.ToBoolean(dt.Rows[0]["IsLocked"].ToString());
        //             objTenantInfo.DatabaseDetails.IsActive = Convert.ToBoolean(dt.Rows[0]["IsActive"].ToString());
                   
        //        }
        //    }
        //    catch (Exception ex)
        //    { objlog.GetLoggingHandler("Log4net").LogException(ex); }
        //    return objTenantInfo;
        //}

        //internal HierarchyInfo MapToDataElementList(DataTable dt)
        //{
        //    HierarchyInfo baseEntityList = new HierarchyInfo();
        //    baseEntityList = (from p in dt.AsEnumerable()
        //                      select new HierarchyInfo
        //                      {
        //                          HierarchyID = p.Table.Columns.Contains("HierarchyID") == true ? Convert.ToInt32(p["HierarchyID"] == DBNull.Value ? 0 : p["HierarchyID"]) : 0,
        //                          HierarchyLevel = p.Table.Columns.Contains("HierarchyLevel") == true ? Convert.ToInt32(p["HierarchyLevel"] == DBNull.Value ? 0 : p["HierarchyLevel"]) : 0,
        //                          HierarchyLevelName = p.Table.Columns.Contains("HierarchyLevelName") == true ? Convert.ToString(p["HierarchyLevelName"] == DBNull.Value ? string.Empty : p["HierarchyLevelName"]) : string.Empty,
        //                          HierarchyName = p.Table.Columns.Contains("HierarchyName") == true ? Convert.ToString(p["HierarchyName"] == DBNull.Value ? string.Empty : p["HierarchyName"]) : string.Empty,
        //                          HierarchyDesc =  p.Table.Columns.Contains("HierarchyDesc") == true ? Convert.ToString(p["HierarchyDesc"] == DBNull.Value ? string.Empty : p["HierarchyDesc"]) : string.Empty,
        //                          ParentId = p.Table.Columns.Contains("ParentId") == true ? Convert.ToInt32(p["ParentId"] == DBNull.Value ? 0 : p["ParentId"]) : 0,
        //                          IsActive = p.Table.Columns.Contains("IsActive") == true ? Convert.ToBoolean(p["IsActive"]) : false,
        //                          CreatedBy = p.Table.Columns.Contains("CreatedBy") == true ? Convert.ToString(p["CreatedBy"] == DBNull.Value ? string.Empty : p["CreatedBy"]) : string.Empty,
        //                          CreatedOn = Convert.ToDateTime(p["CreatedDate"] == DBNull.Value ? string.Empty : p["CreatedDate"]),
        //                          HierarchyPOC = p.Table.Columns.Contains("HierarchyPOC") == true ? Convert.ToString(p["HierarchyPOC"] == DBNull.Value ? string.Empty : p["HierarchyPOC"]) : string.Empty
                                
	
	
	
        //                          });

        //    return baseEntityList;
        //}

        public TenantInfo GetTenantConfigurationDeatils(string TenantName)
        {
            DataSet dt = new DataSet();
            TenantInfo objTenantInfo = new TenantInfo();
            objmbconfigdao = new MailBoxConfigurationDAO();
            try
            {
                dt = objmbconfigdao.GetTenantConfigurationDeatils(TenantName);
                if (dt.Tables.Count > 0)
                {
                    //for (int i = 0; i < dt.Tables.Count; i++)
                    //{
                    if (dt.Tables[0].Rows.Count > 0)
                    {
                    if (dt.Tables[0].Rows[0][0] != DBNull.Value && dt.Tables[0].Rows.Count == 1)
                    {                        
                            objTenantInfo.ProgramFeatures.TenantProgramId = (dt.Tables[0].Rows[0]["TenantProgramId"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[0].Rows[0]["TenantProgramId"].ToString());
                            objTenantInfo.ProgramFeatures.TenantId = (dt.Tables[0].Rows[0]["TenantId"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[0].Rows[0]["TenantProgramId"].ToString());
                            objTenantInfo.ProgramFeatures.ProgramId = (dt.Tables[0].Rows[0]["ProgramId"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[0].Rows[0]["ProgramId"].ToString());
                            objTenantInfo.ProgramFeatures.AuditFeatureId = (dt.Tables[0].Rows[0]["AuditFeatureId"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[0].Rows[0]["AuditFeatureId"].ToString());
                            objTenantInfo.ProgramFeatures.MailFeatureId = (dt.Tables[0].Rows[0]["MailFeatureId"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[0].Rows[0]["MailFeatureId"].ToString());
                            objTenantInfo.ProgramFeatures.ProcessingFeatureId = (dt.Tables[0].Rows[0]["ProcessingFeatureId"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[0].Rows[0]["ProcessingFeatureId"].ToString());
                            objTenantInfo.ProgramFeatures.IsActive = (dt.Tables[0].Rows[0]["IsActive"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[0].Rows[0]["IsActive"].ToString());
                            objTenantInfo.ProgramFeatures.CreatedBy = (dt.Tables[0].Rows[0]["CreatedBy"] == DBNull.Value) ? string.Empty : dt.Tables[0].Rows[0]["CreatedBy"].ToString();
                            objTenantInfo.ProgramFeatures.CreatedOn = (dt.Tables[0].Rows[0]["CreatedDate"] == DBNull.Value) ? DateTime.MinValue : Convert.ToDateTime(dt.Tables[0].Rows[0]["CreatedDate"].ToString());
                            objTenantInfo.ProgramFeatures.ModifiedBy = (dt.Tables[0].Rows[0]["ModifiedBy"] == DBNull.Value) ? String.Empty : dt.Tables[0].Rows[0]["ModifiedBy"].ToString();
                            objTenantInfo.ProgramFeatures.ModifiedOn = (dt.Tables[0].Rows[0]["ModifiedDate"] == DBNull.Value) ? DateTime.MinValue : Convert.ToDateTime(dt.Tables[0].Rows[0]["ModifiedDate"].ToString());
                            objTenantInfo.ResultStatus = true;
                        }
                    }

                    if (dt.Tables[1].Rows.Count > 0)
                    {
                        if (dt.Tables[1].Rows[0][0] != DBNull.Value && dt.Tables[1].Rows.Count == 1)                        
                        {
                        
                            objTenantInfo.AuditFeatures.AuditFeatureId = (dt.Tables[1].Rows[0]["iProgramFeaturesSetUpId"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[1].Rows[0]["iProgramFeaturesSetUpId"].ToString());
 //objTenantInfo.AuditFeatures. = Convert.ToInt32(dt.Tables[i].Rows[0]["siProgramId"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsSupervisorAuditApplicable = (dt.Tables[1].Rows[0]["bIsSupervisorAuditApplicable"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsSupervisorAuditApplicable"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.AuditLogicName = (dt.Tables[1].Rows[0]["szAuditingLogic"] == DBNull.Value) ? String.Empty : dt.Tables[1].Rows[0]["szAuditingLogic"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.ScoringLogicName = (dt.Tables[1].Rows[0]["szScoringLogic"] == DBNull.Value) ? String.Empty : dt.Tables[1].Rows[0]["szScoringLogic"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsEmployeeApplicable = (dt.Tables[1].Rows[0]["bIsEmployeeApplicable"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsEmployeeApplicable"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsDataEntryByAuditorEnable = (dt.Tables[1].Rows[0]["bIsEnableDataEntryByAuditor"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsEnableDataEntryByAuditor"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsPeerToPeerAuditInfoEnable = (dt.Tables[1].Rows[0]["bIsEnablePeerToPeerAuditInfo"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsEnablePeerToPeerAuditInfo"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.NoOfElement = (dt.Tables[1].Rows[0]["iNoOfElement"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[1].Rows[0]["iNoOfElement"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.SystemEffectName = (dt.Tables[1].Rows[0]["szSystemEffects"] == DBNull.Value) ? string.Empty : dt.Tables[1].Rows[0]["szSystemEffects"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsDefaultRating = (dt.Tables[1].Rows[0]["bIsDefaultRating"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsDefaultRating"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsStratifiedSampling = (dt.Tables[1].Rows[0]["bIsStratifiedSamplingRequired"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsStratifiedSamplingRequired"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsSamplingFrozen = (dt.Tables[1].Rows[0]["bIsFreezingOfSamples"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsFreezingOfSamples"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsExternalSamplingFrozen = (dt.Tables[1].Rows[0]["bIsFreezingOfExternalSamples"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsFreezingOfExternalSamples"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsFatalErrorApplicable = (dt.Tables[1].Rows[0]["bIsFatalErrorApplicable"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsFatalErrorApplicable"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsSLAActivityApplicable = (dt.Tables[1].Rows[0]["bIsSLAActivityApplicable"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsSLAActivityApplicable"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsTotalVolumeApplicable = (dt.Tables[1].Rows[0]["bIsTotalVolumeApplicable"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsTotalVolumeApplicable"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsFeedbackMailTriggerApplicable = (dt.Tables[1].Rows[0]["bIsMailTriggerRequired"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsMailTriggerRequired"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsReworkRemainderMailTgrApplicable = (dt.Tables[1].Rows[0]["bIsReworkRemainderMailRequired"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsReworkRemainderMailRequired"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.MaxNoOfRemainder = (dt.Tables[1].Rows[0]["iMaxRemainderCnt"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[1].Rows[0]["iMaxRemainderCnt"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.MailFrequency = (dt.Tables[1].Rows[0]["iMailSchedulerFrequency"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[1].Rows[0]["iMailSchedulerFrequency"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.MailBoxName = (dt.Tables[1].Rows[0]["szMailboxName"] == DBNull.Value) ? String.Empty : dt.Tables[1].Rows[0]["szMailboxName"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.AuditTypes = (dt.Tables[1].Rows[0]["szAuditTypes"] == DBNull.Value) ? String.Empty : dt.Tables[1].Rows[0]["szAuditTypes"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.MaxCorrectionCnt = (dt.Tables[1].Rows[0]["iMaxCorrectionCnt"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[1].Rows[0]["iMaxCorrectionCnt"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsMetricsRequired = (dt.Tables[1].Rows[0]["bIsMetricsRequired"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsMetricsRequired"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsWorkFlowNeedforCorrection = (dt.Tables[1].Rows[0]["bIsWorkFlowNeedforCorrection"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsWorkFlowNeedforCorrection"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.createdDate = (dt.Tables[1].Rows[0]["dsCreatedDate"] == DBNull.Value) ? String.Empty : dt.Tables[1].Rows[0]["dsCreatedDate"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.modifiedBy = (dt.Tables[1].Rows[0]["iModifiedBy"] == DBNull.Value) ? String.Empty : dt.Tables[1].Rows[0]["iModifiedBy"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.modifiedDate = (dt.Tables[1].Rows[0]["dsModifiedDate"] == DBNull.Value) ? String.Empty : dt.Tables[1].Rows[0]["dsModifiedDate"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsLinesApplicable = (dt.Tables[1].Rows[0]["bIsLineApplicable"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsLineApplicable"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.MaxCorrectionDaysCnt = (dt.Tables[1].Rows[0]["iMaxCorrectionDayCnt"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[1].Rows[0]["iMaxCorrectionDayCnt"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsDaylimitforcorrectionApplicable = (dt.Tables[1].Rows[0]["bIsDayNeedforCorrection"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsDayNeedforCorrection"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsCriticalityApplicable = (dt.Tables[1].Rows[0]["bIsDOCriticality"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsDOCriticality"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsTATApplicable = (dt.Tables[1].Rows[0]["bIsTATEnable"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsTATEnable"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsCombinedAccuracyNeeded = (dt.Tables[1].Rows[0]["bIsCombinedAccuracy"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsCombinedAccuracy"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsDeletMailEnableTriggerApplicable = (dt.Tables[1].Rows[0]["bIsDeletMailEnable"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsDeletMailEnable"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.DateFormat = (dt.Tables[1].Rows[0]["szDateFormat"] == DBNull.Value) ? string.Empty : dt.Tables[1].Rows[0]["szDateFormat"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.sSamplingMethodforInternal = (dt.Tables[1].Rows[0]["szSamplingMethodInternal"] == DBNull.Value) ? string.Empty : dt.Tables[1].Rows[0]["szSamplingMethodInternal"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.sSamplingMethodforBusiness = (dt.Tables[1].Rows[0]["szSamplingMethodBusiness"] == DBNull.Value) ? string.Empty : dt.Tables[1].Rows[0]["szSamplingMethodBusiness"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IntAllocCnt = (dt.Tables[1].Rows[0]["iIntAllocCnt"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[1].Rows[0]["iIntAllocCnt"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.ExtAllocCnt = (dt.Tables[1].Rows[0]["iExtAllocCnt"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[1].Rows[0]["iExtAllocCnt"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.BusiAllocCnt = (dt.Tables[1].Rows[0]["iBusiAllocCnt"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[1].Rows[0]["iBusiAllocCnt"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.StaticFields = (dt.Tables[1].Rows[0]["szStaticFields"] == DBNull.Value) ? string.Empty : dt.Tables[1].Rows[0]["szStaticFields"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.AHTApplicability = (dt.Tables[1].Rows[0]["blsAHTEnable"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["blsAHTEnable"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.CTQComments = (dt.Tables[1].Rows[0]["blsCTQComments"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["blsCTQComments"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsRatingDifferenceMailApplicable = (dt.Tables[1].Rows[0]["bIsRatingDifferenceMailEnable"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsRatingDifferenceMailEnable"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsSLAAccuracyEnabled = (dt.Tables[1].Rows[0]["bIsSLAAccuracyEnabled"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsSLAAccuracyEnabled"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.SamplingPctCalculation = (dt.Tables[1].Rows[0]["szSamplingPctCalculation"] == DBNull.Value) ? string.Empty : dt.Tables[1].Rows[0]["szSamplingPctCalculation"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsFatalErrorApplicable = (dt.Tables[1].Rows[0]["IsFatalMailRequire"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["IsFatalMailRequire"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsSLABasedSubProcess = (dt.Tables[1].Rows[0]["IsSLABasedSubProcess"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["IsSLABasedSubProcess"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.szCombinedAccuracyType = (dt.Tables[1].Rows[0]["szCombinedAccuracyType"] == DBNull.Value) ? string.Empty : dt.Tables[1].Rows[0]["szCombinedAccuracyType"].ToString();
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsSamplingTypeCustommode = (dt.Tables[1].Rows[0]["bIsSamplingtypeCustomMode"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsSamplingtypeCustomMode"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsDataPurgingEnabled = (dt.Tables[1].Rows[0]["bIsDataPurgingEnabled"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsDataPurgingEnabled"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsSubProcessValidationEnabled = (dt.Tables[1].Rows[0]["bIsSubProcessValidationEnabled"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsSubProcessValidationEnabled"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsStaticConditionsEnabled = (dt.Tables[1].Rows[0]["bIsStaticConditionEnabled"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsStaticConditionEnabled"].ToString());
                            objTenantInfo.AuditFeatures.ProgramFeatureSetUp.IsTop5MailDataElementEnabled = (dt.Tables[1].Rows[0]["bIsTop5MailDataElement"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsTop5MailDataElement"].ToString());
                            objTenantInfo.ResultStatus = true;
                            
 // = Convert.ToInt32(dt.Tables[i].Rows[0]["bSamplingByVolume"].ToString());
//  = Convert.ToInt32(dt.Tables[i].Rows[0]["szRestriction_MaxLength"].ToString());                            
	
                        }
                        }
                    if (dt.Tables[2].Rows.Count > 0)
                    {
                        if (dt.Tables[2].Rows[0][0] != DBNull.Value && dt.Tables[2].Rows.Count == 1)
                        {
                           
                                //  objTenantInfo.MailFeatures.MailFeatureEntity. = Convert.ToInt32(dt.Tables[i].Rows[0]["EMailBoxFeatureId"].ToString());
                                objTenantInfo.MailFeatures.MailFeatureEntity.MailBoxName = (dt.Tables[2].Rows[0]["EMailBoxName"] == DBNull.Value) ? string.Empty : dt.Tables[2].Rows[0]["EMailBoxName"].ToString();
                                objTenantInfo.MailFeatures.MailFeatureEntity.MailBoxAddress = (dt.Tables[2].Rows[0]["EMailBoxAddress"] == DBNull.Value) ? string.Empty : dt.Tables[2].Rows[0]["EMailBoxAddress"].ToString();
                                objTenantInfo.MailFeatures.MailFeatureEntity.MailBoxFolderPath = (dt.Tables[2].Rows[0]["EMailFolderPath"] == DBNull.Value) ? string.Empty : dt.Tables[2].Rows[0]["EMailFolderPath"].ToString();
                                objTenantInfo.MailFeatures.MailFeatureEntity.Domain = (dt.Tables[2].Rows[0]["Domain"] == DBNull.Value) ? string.Empty : dt.Tables[2].Rows[0]["Domain"].ToString();
                                // = Convert.ToInt32(dt.Tables[i].Rows[0]["UserId"].ToString());
                                //= Convert.ToInt32(dt.Tables[i].Rows[0]["Password"].ToString());
                                // = Convert.ToInt32(dt.Tables[i].Rows[0]["CountryId"].ToString());
                                // = Convert.ToInt32(dt.Tables[i].Rows[0]["SubProcessGroupId"].ToString());
                                objTenantInfo.MailFeatures.MailFeatureEntity.TATInHours = (dt.Tables[2].Rows[0]["TATInHours"] == DBNull.Value) ? string.Empty : dt.Tables[2].Rows[0]["TATInHours"].ToString();
                                objTenantInfo.MailFeatures.MailFeatureEntity.IsActive = (dt.Tables[2].Rows[0]["IsActive"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[2].Rows[0]["IsActive"].ToString());
                                objTenantInfo.MailFeatures.MailFeatureEntity.IsQCRequired = (dt.Tables[2].Rows[0]["IsQCRequired"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[2].Rows[0]["IsQCRequired"].ToString());
                                objTenantInfo.MailFeatures.MailFeatureEntity.CreatedById = (dt.Tables[2].Rows[0]["CreatedById"] == DBNull.Value) ? string.Empty : dt.Tables[2].Rows[0]["CreatedById"].ToString();
                                objTenantInfo.MailFeatures.MailFeatureEntity.CreatedDate = (dt.Tables[2].Rows[0]["CreatedDate"] == DBNull.Value) ? DateTime.MinValue : Convert.ToDateTime(dt.Tables[2].Rows[0]["CreatedDate"].ToString());
                                objTenantInfo.MailFeatures.MailFeatureEntity.IsMailTriggerRequired = (dt.Tables[2].Rows[0]["IsMailTriggerRequired"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[2].Rows[0]["IsMailTriggerRequired"].ToString());
                                //     = Convert.ToInt32(dt.Tables[i].Rows[0]["EmailBoxLoginDetailId"].ToString());
                                objTenantInfo.MailFeatures.MailFeatureEntity.IsReplyNotRequired = (dt.Tables[2].Rows[0]["IsReplyNotRequired"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[2].Rows[0]["IsReplyNotRequired"].ToString());
                                objTenantInfo.MailFeatures.MailFeatureEntity.TATInSeconds = (dt.Tables[2].Rows[0]["TATInSeconds"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[2].Rows[0]["TATInSeconds"].ToString());
                                objTenantInfo.MailFeatures.MailFeatureEntity.TimeZone = (dt.Tables[2].Rows[0]["TimeZone"] == DBNull.Value) ? string.Empty : dt.Tables[2].Rows[0]["TimeZone"].ToString();
                                objTenantInfo.MailFeatures.MailFeatureEntity.Offset = (dt.Tables[2].Rows[0]["Offset"] == DBNull.Value) ? string.Empty : dt.Tables[2].Rows[0]["Offset"].ToString();
                                objTenantInfo.MailFeatures.MailFeatureEntity.IsEMailBoxAddressOptional = (dt.Tables[2].Rows[0]["EMailBoxAddressOptional"] == DBNull.Value) ? string.Empty : dt.Tables[2].Rows[0]["EMailBoxAddressOptional"].ToString();
                                objTenantInfo.MailFeatures.MailFeatureEntity.IsVOCSurvey = (dt.Tables[2].Rows[0]["IsVOCSurvey"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[2].Rows[0]["IsVOCSurvey"].ToString());
                                // = Convert.ToInt32(dt.Tables[i].Rows[0]["AddOnFeaturesId"].ToString());
                                objTenantInfo.MailFeatures.MailFeatureEntity.TenantId = (dt.Tables[2].Rows[0]["TenantId"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[2].Rows[0]["TenantId"].ToString());
                                objTenantInfo.ResultStatus = true;

                            }
                        }
                    if (dt.Tables[3].Rows.Count > 0)
                    {
                        if (dt.Tables[3].Rows[0][0] != DBNull.Value && dt.Tables[3].Rows.Count == 1)
                        {

                            objTenantInfo.MailFeatures.AddONsToBeConfiguredEntity.IsADLogin = (dt.Tables[3].Rows[0]["IsADLogin"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[3].Rows[0]["IsADLogin"].ToString());
                            objTenantInfo.MailFeatures.AddONsToBeConfiguredEntity.IsSubjectEditable = (dt.Tables[3].Rows[0]["IsSubjectEditable"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[3].Rows[0]["IsSubjectEditable"].ToString());
                            objTenantInfo.MailFeatures.AddONsToBeConfiguredEntity.IsGMBtoGMB = (dt.Tables[3].Rows[0]["IsGMBToGMB"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[3].Rows[0]["IsGMBToGMB"].ToString());
                            objTenantInfo.MailFeatures.AddONsToBeConfiguredEntity.IsCustomizableCaseId = (dt.Tables[3].Rows[0]["IsCustomizableCaseId"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[3].Rows[0]["IsCustomizableCaseId"].ToString());
                            objTenantInfo.MailFeatures.AddONsToBeConfiguredEntity.IsConversationHistory = (dt.Tables[3].Rows[0]["IsConversationHistory"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[3].Rows[0]["IsConversationHistory"].ToString());
                            objTenantInfo.ResultStatus = true;
                        }
                    }
                    else
                        objTenantInfo.ResultStatus = false;

                   // }
                   
                }
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex); }
            return objTenantInfo;
        }

        public TenantInfo GetZoneANDMenuDeatils(string TenantName)
        {
            DataSet dt = new DataSet();
            TenantInfo objTenantInfo = new TenantInfo();
            objmbconfigdao = new MailBoxConfigurationDAO();
            try
            {
                dt = objmbconfigdao.GetTenantConfigurationDeatils(TenantName);
                if (dt.Tables.Count > 0)
                {
                    //for (int i = 0; i < dt.Tables.Count; i++)
                    //{
                    if (dt.Tables[0].Rows.Count > 0)
                    {
                        if (dt.Tables[0].Rows[0][0] != DBNull.Value && dt.Tables[0].Rows.Count == 1)
                        {
                            objTenantInfo.AuditFeatures.MenuInfo.ZoneId = (dt.Tables[0].Rows[0]["iZoneId"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[0].Rows[0]["iZoneId"].ToString());
                            objTenantInfo.AuditFeatures.MenuInfo.ZoneName = (dt.Tables[0].Rows[0]["szZoneName"] == DBNull.Value) ? string.Empty : dt.Tables[0].Rows[0]["szZoneName"].ToString();
                            objTenantInfo.AuditFeatures.MenuInfo.ZoneDesc = (dt.Tables[0].Rows[0]["szZoneDesc"] == DBNull.Value) ? string.Empty : dt.Tables[0].Rows[0]["szZoneDesc"].ToString();
                            objTenantInfo.AuditFeatures.MenuInfo.ZoneOffsetName = (dt.Tables[0].Rows[0]["szZoneOffsetName"] == DBNull.Value) ? string.Empty : dt.Tables[0].Rows[0]["szZoneOffsetName"].ToString();
                            objTenantInfo.AuditFeatures.MenuInfo.ZoneOffsetDesc = (dt.Tables[0].Rows[0]["szZoneOffsetDesc"] == DBNull.Value) ? string.Empty : dt.Tables[0].Rows[0]["szZoneOffsetDesc"].ToString();
                        }
                    }
                    if (dt.Tables[1].Rows.Count > 0)
                    {
                        if (dt.Tables[1].Rows[0][0] != DBNull.Value && dt.Tables[1].Rows.Count == 1)
                        {
                            objTenantInfo.AuditFeatures.MenuInfo.MenuName = (dt.Tables[1].Rows[0]["szMenuName"] == DBNull.Value) ? string.Empty : dt.Tables[1].Rows[0]["szMenuName"].ToString();
                            objTenantInfo.AuditFeatures.MenuInfo.MenuDesc = (dt.Tables[1].Rows[0]["szMenuDesc"] == DBNull.Value) ? string.Empty : dt.Tables[1].Rows[0]["szMenuDesc"].ToString();
                            objTenantInfo.AuditFeatures.MenuInfo.MenuControllerName = (dt.Tables[1].Rows[0]["szMenuControllerName"] == DBNull.Value) ? string.Empty : dt.Tables[1].Rows[0]["szMenuControllerName"].ToString();
                            objTenantInfo.AuditFeatures.MenuInfo.MenuActionName = (dt.Tables[1].Rows[0]["szMenuActionName"] == DBNull.Value) ? string.Empty : dt.Tables[1].Rows[0]["szMenuActionName"].ToString();
                              objTenantInfo.AuditFeatures.MenuInfo.SequenceNo = (dt.Tables[1].Rows[0]["iSequenceNo"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[1].Rows[0]["iSequenceNo"].ToString());
                              objTenantInfo.AuditFeatures.MenuInfo.IsActive = (dt.Tables[1].Rows[0]["bIsActive"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Tables[1].Rows[0]["bIsActive"].ToString());                                                       
                        }
                    }
                    if (dt.Tables[2].Rows.Count > 0)
                    {
                        if (dt.Tables[2].Rows[0][0] != DBNull.Value && dt.Tables[2].Rows.Count == 1)
                        {
                            objTenantInfo.AuditFeatures.MenuInfo.AccessTypeId = (dt.Tables[0].Rows[0]["iAccessTypeId"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[0].Rows[0]["iAccessTypeId"].ToString());
                            objTenantInfo.AuditFeatures.MenuInfo.MenuId = (dt.Tables[2].Rows[0]["iMenuId"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Tables[2].Rows[0]["iMenuId"].ToString());
                            objTenantInfo.AuditFeatures.MenuInfo.AccessType = (dt.Tables[2].Rows[0]["szAccessType"] == DBNull.Value) ? string.Empty : dt.Tables[2].Rows[0]["szAccessType"].ToString();
                            objTenantInfo.AuditFeatures.MenuInfo.Category = (dt.Tables[2].Rows[0]["szCategory"] == DBNull.Value) ? string.Empty : dt.Tables[2].Rows[0]["szCategory"].ToString();
                            objTenantInfo.AuditFeatures.MenuInfo.IsActive = objTenantInfo.AuditFeatures.MenuInfo.IsActive;
                        }
                    }
                }
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex); }
            return objTenantInfo;
        }

        public int LookUpCreation(int LookupLevel, string LookupLevelName, string LookupName, string LookupDesc, string LookupValue, bool IsActive, string createdby, string tenantname, string parentLookup, string parentLookupvalue, string appId, int TenantId)
        {
            int result = 0;
            try
            {
                objmbconfigdao = new MailBoxConfigurationDAO();
                result = objmbconfigdao.LookUpCreation(LookupLevel, LookupLevelName, LookupName, LookupDesc, LookupValue, IsActive, createdby, tenantname, parentLookup, parentLookupvalue, appId, TenantId);
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex,tenantname,appId);
            }
            return result;
                      
        }

        public TenantInfo GetLookUp(string TenantName, string HierarchyName, int HierarchyLevel)
        {
            DataTable dt = new DataTable();
            TenantInfo objTenantInfo = new TenantInfo();           
            objmbconfigdao = new MailBoxConfigurationDAO();
            try
            {
                dt = objmbconfigdao.GetLookUp(TenantName, HierarchyName, HierarchyLevel);
                if (dt.Rows.Count > 0)
                {
                        objTenantInfo.LookupInfo.LookupID = (dt.Rows[0]["LookupID"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Rows[0]["LookupID"].ToString());
                        objTenantInfo.LookupInfo.LookupLevel = (dt.Rows[0]["LookupLevel"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Rows[0]["LookupLevel"].ToString());
                        objTenantInfo.LookupInfo.LookupLevelName = (dt.Rows[0]["LookupLevelName"] == DBNull.Value) ? string.Empty : dt.Rows[0]["LookupLevelName"].ToString();
                        objTenantInfo.LookupInfo.LookupName = (dt.Rows[0]["LookupName"] == DBNull.Value) ? string.Empty : dt.Rows[0]["LookupName"].ToString();
                        objTenantInfo.LookupInfo.LookupDesc = (dt.Rows[0]["LookupDesc"] == DBNull.Value) ? string.Empty : dt.Rows[0]["LookupDesc"].ToString();
                       objTenantInfo.LookupInfo.ParentId = (dt.Rows[0]["ParentId"] == DBNull.Value) ? 0 : Convert.ToInt32(dt.Rows[0]["ParentId"].ToString());
                        objTenantInfo.LookupInfo.IsActive = (dt.Rows[0]["IsActive"] == DBNull.Value) ? false : Convert.ToBoolean(dt.Rows[0]["IsActive"].ToString());
                        objTenantInfo.LookupInfo.CreatedBy = (dt.Rows[0]["CreatedBy"] == DBNull.Value) ? string.Empty : dt.Rows[0]["CreatedBy"].ToString();
                        objTenantInfo.LookupInfo.CreatedOn = (dt.Rows[0]["CreatedDate"] == DBNull.Value) ? DateTime.MinValue : Convert.ToDateTime(dt.Rows[0]["CreatedDate"].ToString());
                        objTenantInfo.LookupInfo.LookupValue = (dt.Rows[0]["LookupValue"] == DBNull.Value) ? string.Empty : dt.Rows[0]["LookupValue"].ToString();
                        objTenantInfo.ResultStatus = true;
                    }  
                else
                    objTenantInfo.ResultStatus = false;
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
            }
            return objTenantInfo;
        }

        public int InsertIntoPM(string ZoneName, string AccountName, string ProgramName, DateTime From, DateTime To, string CreadtedBy, string ModifedBy, string ConnectionString)
        {
            string result = string.Empty;
                int output=0;
            try
            {
                objmbconfigdao = new MailBoxConfigurationDAO();
                result = objmbconfigdao.InsertIntoPM(ZoneName,AccountName,ProgramName,From,To,CreadtedBy,ModifedBy, ConnectionString);
                if (result == "Success")
                    output = 1;
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
            }
            return output;
        }

        public string SetProgramFeatures(TenantInfo objBaseT, string connectionString)
        {
            string result = string.Empty;
            ProgramFeatureSetUp objprogrmFeatures = new ProgramFeatureSetUp();
            try
            {
                objmbconfigdao = new MailBoxConfigurationDAO();                
        objprogrmFeatures.ProgramId=objBaseT.AuditFeatures.ProgramFeatureSetUp.ProgramId ;
        objprogrmFeatures.SelectedProgramId = objBaseT.AuditFeatures.ProgramFeatureSetUp.SelectedProgramId;
        objprogrmFeatures.ProgramName = objBaseT.AuditFeatures.ProgramFeatureSetUp.ProgramName;
        objprogrmFeatures.eventAction = objBaseT.AuditFeatures.ProgramFeatureSetUp.eventAction;
        objprogrmFeatures.IsSupervisorAuditApplicable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsSupervisorAuditApplicable;
        objprogrmFeatures.AuditLogicId = objBaseT.AuditFeatures.ProgramFeatureSetUp.AuditLogicId;
        objprogrmFeatures.SelectedAuditLogicId = objBaseT.AuditFeatures.ProgramFeatureSetUp.SelectedAuditLogicId;
        objprogrmFeatures.AuditLogicName = objBaseT.AuditFeatures.ProgramFeatureSetUp.AuditLogicName;
        objprogrmFeatures.ScoringLogicId = objBaseT.AuditFeatures.ProgramFeatureSetUp.ScoringLogicId;
        objprogrmFeatures.SelectedScoringLogicId = objBaseT.AuditFeatures.ProgramFeatureSetUp.SelectedScoringLogicId;
        objprogrmFeatures.ScoringLogicName = objBaseT.AuditFeatures.ProgramFeatureSetUp.ScoringLogicName;
        objprogrmFeatures.IsEmployeeApplicable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsEmployeeApplicable;
        objprogrmFeatures.IsLinesApplicable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsLinesApplicable;
        objprogrmFeatures.Leveld = objBaseT.AuditFeatures.ProgramFeatureSetUp.Leveld;
        objprogrmFeatures.IsDataEntryByAuditorEnable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsDataEntryByAuditorEnable;
        objprogrmFeatures.IsPeerToPeerAuditInfoEnable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsPeerToPeerAuditInfoEnable;
        objprogrmFeatures.NoOfElement = objBaseT.AuditFeatures.ProgramFeatureSetUp.NoOfElement;
        objprogrmFeatures.DateFormat = objBaseT.AuditFeatures.ProgramFeatureSetUp.DateFormat;
        objprogrmFeatures.SystemEffectId = objBaseT.AuditFeatures.ProgramFeatureSetUp.SystemEffectId;
        objprogrmFeatures.SelectedSystemEffectId = objBaseT.AuditFeatures.ProgramFeatureSetUp.SelectedSystemEffectId;
        objprogrmFeatures.SystemEffectName = objBaseT.AuditFeatures.ProgramFeatureSetUp.SystemEffectName;
        objprogrmFeatures.IsDefaultRating = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsDefaultRating;
        objprogrmFeatures.IsStratifiedSampling = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsStratifiedSampling;
        objprogrmFeatures.IsSamplingFrozen = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsSamplingFrozen;
        objprogrmFeatures.IsFatalErrorApplicable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsFatalErrorApplicable;
        objprogrmFeatures.IsCriticalityApplicable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsCriticalityApplicable;
        objprogrmFeatures.IsDaylimitforcorrectionApplicable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsDaylimitforcorrectionApplicable;
        objprogrmFeatures.IsSLAActivityApplicable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsSLAActivityApplicable;
        objprogrmFeatures.IsFeedbackMailTriggerApplicable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsFeedbackMailTriggerApplicable;
        objprogrmFeatures.IsReworkRemainderMailTgrApplicable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsReworkRemainderMailTgrApplicable;
        objprogrmFeatures.IsDeletMailEnableTriggerApplicable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsDeletMailEnableTriggerApplicable;
        objprogrmFeatures.MaxNoOfRemainder = objBaseT.AuditFeatures.ProgramFeatureSetUp.MaxNoOfRemainder;
        objprogrmFeatures.MailFrequency = objBaseT.AuditFeatures.ProgramFeatureSetUp.MailFrequency;
        objprogrmFeatures.MailBoxName = objBaseT.AuditFeatures.ProgramFeatureSetUp.MailBoxName;
        objprogrmFeatures.AuditTypes = objBaseT.AuditFeatures.ProgramFeatureSetUp.AuditTypes;
        objprogrmFeatures.createdBy = objBaseT.AuditFeatures.ProgramFeatureSetUp.createdBy;
        objprogrmFeatures.createdDate = objBaseT.AuditFeatures.ProgramFeatureSetUp.createdDate;
        objprogrmFeatures.modifiedBy = objBaseT.AuditFeatures.ProgramFeatureSetUp.modifiedBy;
        objprogrmFeatures.modifiedDate = objBaseT.AuditFeatures.ProgramFeatureSetUp.modifiedDate;
        objprogrmFeatures.IsEditMode = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsEditMode;
        objprogrmFeatures.IsEditAllowed = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsEditAllowed;
        objprogrmFeatures.IsTotalVolumeApplicable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsTotalVolumeApplicable;
        objprogrmFeatures.IsExternalSamplingFrozen = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsExternalSamplingFrozen;
        objprogrmFeatures.MaxCorrectionCnt = objBaseT.AuditFeatures.ProgramFeatureSetUp.MaxCorrectionCnt;
        objprogrmFeatures.MaxCorrectionDaysCnt = objBaseT.AuditFeatures.ProgramFeatureSetUp.MaxCorrectionDaysCnt;
        objprogrmFeatures.IsMetricsRequired = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsMetricsRequired;
        objprogrmFeatures.IsTATApplicable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsTATApplicable;
        objprogrmFeatures.IsCombinedAccuracyNeeded = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsCombinedAccuracyNeeded;
        objprogrmFeatures.IsWorkFlowNeedforCorrection = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsWorkFlowNeedforCorrection;
        objprogrmFeatures.EntitySavedStatus = objBaseT.AuditFeatures.ProgramFeatureSetUp.EntitySavedStatus;
        objprogrmFeatures.ErrorMessage = objBaseT.AuditFeatures.ProgramFeatureSetUp.ErrorMessage;
        objprogrmFeatures.IntAllocCnt = objBaseT.AuditFeatures.ProgramFeatureSetUp.IntAllocCnt;
        objprogrmFeatures.ExtAllocCnt = objBaseT.AuditFeatures.ProgramFeatureSetUp.ExtAllocCnt;
        objprogrmFeatures.BusiAllocCnt = objBaseT.AuditFeatures.ProgramFeatureSetUp.BusiAllocCnt;
        objprogrmFeatures.sSamplingMethodforInternal = objBaseT.AuditFeatures.ProgramFeatureSetUp.sSamplingMethodforInternal;
        objprogrmFeatures.sSamplingMethodforBusiness = objBaseT.AuditFeatures.ProgramFeatureSetUp.sSamplingMethodforBusiness;
        objprogrmFeatures.StaticFields = objBaseT.AuditFeatures.ProgramFeatureSetUp.StaticFields;
        objprogrmFeatures.AHTApplicability = objBaseT.AuditFeatures.ProgramFeatureSetUp.AHTApplicability;
        objprogrmFeatures.CTQComments = objBaseT.AuditFeatures.ProgramFeatureSetUp.CTQComments;
        objprogrmFeatures.IsRatingDifferenceMailApplicable = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsRatingDifferenceMailApplicable;
        objprogrmFeatures.SamplingPctCalculation = objBaseT.AuditFeatures.ProgramFeatureSetUp.SamplingPctCalculation;
        objprogrmFeatures.IsSLAAccuracyEnabled = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsSLAAccuracyEnabled;
        objprogrmFeatures.szCombinedAccuracyType = objBaseT.AuditFeatures.ProgramFeatureSetUp.szCombinedAccuracyType;
        objprogrmFeatures.IsSLABasedSubProcess = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsSLABasedSubProcess;
        objprogrmFeatures.IsSamplingTypeCustommode = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsSamplingTypeCustommode;
        objprogrmFeatures.IsDataPurgingEnabled = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsDataPurgingEnabled;
        objprogrmFeatures.IsStaticConditionsEnabled = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsStaticConditionsEnabled;
        objprogrmFeatures.IsSubProcessValidationEnabled = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsSubProcessValidationEnabled;
        objprogrmFeatures.IsTop5MailDataElementEnabled = objBaseT.AuditFeatures.ProgramFeatureSetUp.IsTop5MailDataElementEnabled;
        result = objmbconfigdao.SetProgramFeatures(objprogrmFeatures,connectionString);
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objBaseT.TenantName, objBaseT.AppID);
            }
            return result;
        }
    }
}
