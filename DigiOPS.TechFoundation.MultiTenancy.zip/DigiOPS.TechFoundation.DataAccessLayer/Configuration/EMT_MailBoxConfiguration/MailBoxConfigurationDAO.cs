﻿using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class MailBoxConfigurationDAO
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        ConnectionString connectionstring = new ConnectionString();
          
        public MailBoxConfigurationDAO(string appId, int TenantId)
        {
            dbConnectionString = connectionstring.GetConnectionString(appId, TenantId);           
        }
        public MailBoxConfigurationDAO(string TenantName,string AppId)
        {
            dbConnectionString = connectionstring.GetConnectionString( TenantName);
        }

        public MailBoxConfigurationDAO()
        {
            dbConnectionString = ConfigurationManager.ConnectionStrings["CommonDBConnStr"].ConnectionString;
        }

        public int HierarchyCreation(int HierarchyLevel, string HierarchyLevelName, string HierarchyName, string HierarchyDesc, bool IsActive, string createdby, string tenantname, string parenthierarchy, string parenthierarchyvalue, string HierarchyPOC, string appId, int TenantId)
        {
            objloginfo.Message = ("MailBoxConfigurationDetailsDAO - SubProcessCreation - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            int ret=0;
             string resultValue = "-1";
             try
             {
                 using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                 {
                     sqlConnection.Open();
                     SqlCommand command = new SqlCommand("USP_SET_Hierarchy", sqlConnection);
                     command.CommandType = CommandType.StoredProcedure;
                     command.Parameters.Add("@HierarchyLevel", HierarchyLevel);
                     command.Parameters.Add("@HierarchyLevelName", HierarchyLevelName);
                     command.Parameters.Add("@HierarchyName", HierarchyName);
                     command.Parameters.Add("@HierarchyDesc", HierarchyDesc);
                     command.Parameters.Add("@IsActive", IsActive);
                     command.Parameters.Add("@CreatedBy", createdby);
                    // command.Parameters.Add("@CreatedDate", createdby);                     
                     command.Parameters.Add("@TenantName", tenantname);
                     command.Parameters.Add("@ParentHierarchyName", parenthierarchy);
                     command.Parameters.Add("@ParentHierarchyValue", parenthierarchyvalue);
                     command.Parameters.Add("@HierarchyPOC", HierarchyPOC);

                     resultValue = command.ExecuteScalar().ToString();

                 }
             }
             catch (SqlException ex)
             {
                 objlog.GetLoggingHandler("Log4net").LogException(ex, tenantname, appId);
                 throw;
             }
             catch (Exception ex)
             {
                 objlog.GetLoggingHandler("Log4net").LogException(ex, tenantname, appId); throw;
             }
            return ret=Convert.ToInt32(resultValue);     

        }

        public int GetMailBoxLoginDetails(string LoginEmailId, string pd, string TenantName, bool islocked, bool isactive, string appId, int TenantId)
        {
            objloginfo.Message = ("MailBoxConfigurationDetailsDAO - GetMailBoxLoginDetails - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            Hashtable hs = new Hashtable();            
            int ret=0;
             string resultValue = "-1";
             try
            {
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_SET_EMail_MailBoxLoginDetails", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@szUserId",LoginEmailId) ;
                    command.Parameters.Add("@szPassword",pd );
                    command.Parameters.Add("@IsLocked", islocked);
                    command.Parameters.Add("@IsActive", isactive);
                    command.Parameters.Add("@szTenantName", TenantName);                   
                     
                    resultValue =command.ExecuteNonQuery().ToString();
                }}
              
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, TenantName,appId);
                throw;
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, TenantName, appId); throw;
            }
           // return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_SET_EMail_MailBoxLoginDetails", hs));

             return ret=Convert.ToInt32(resultValue);
            }
           
        

        public int GetMailBoxConfigurationDetails(string MailBoxName, string MailBoxAddress,string Domain,string MailBoxFolderPath,
            string TATInHours,int TATInSeconds, string TimeZone, string CreatedById,DateTime CreatedDate,bool IsQCRequired, bool IsActive,
            bool IsReplyNotRequired, bool IsMailTriggerRequired, string Offset, string IsEMailBoxAddressOptional, bool IsVOCSurvey,
            bool IsADLogin, bool IsSubjectEditable, bool IsGMBtoGMB, bool IsCustomizableCaseId, bool IsConversationHistory, string HierarchyLevelName, string HierarchyValuetobeTakenName, string HierarchyLevelNameValuetobeTaken, string AppId)
        {
            objloginfo.Message = ("MailBoxConfigurationDetailsDAO - GetMailBoxLoginDetails - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@EMailBoxName", MailBoxName);
                hs.Add("@EMailBoxAddress ", MailBoxAddress);
                hs.Add("@EMailFolderPath ", MailBoxFolderPath);               
                hs.Add("@Domain", Domain);
                hs.Add("@TATInHours",TATInHours ); 
                hs.Add("@TimeZone", TimeZone);                
                hs.Add("@IsQCRequired", IsQCRequired);
                hs.Add("@IsActive", IsActive);
                hs.Add("@CreatedById ",CreatedById);
                hs.Add("@CreatedDate",CreatedDate);
                hs.Add("@IsMailTriggerRequired", IsMailTriggerRequired);                
                hs.Add("@IsReplyNotRequired ", IsReplyNotRequired);
                hs.Add("@TATInSeconds", TATInSeconds);
                hs.Add("@Offset",Offset);
                hs.Add("@EMailBoxAddressOptional",IsEMailBoxAddressOptional);
                hs.Add("@IsVOCSurvey",IsVOCSurvey); 
                hs.Add("@IsADLogin", IsADLogin);
                hs.Add("@IsSubjectEditable", IsSubjectEditable);
                hs.Add("@IsGMBToGMB ", IsGMBtoGMB);
                hs.Add("@IsCustomizableCaseId", IsCustomizableCaseId);
                hs.Add("@IsConversationHistory ", IsConversationHistory);
                hs.Add("@TenantName",HierarchyLevelName);
                hs.Add("@HierarchyName", HierarchyValuetobeTakenName);
                hs.Add("@HierarchyLevelName", HierarchyLevelNameValuetobeTaken);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, HierarchyLevelName, AppId);
                throw;
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, HierarchyLevelName, AppId); throw;
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_SET_MailBoxFeatures", hs)); 
        }

        public int Set_ZoneANDMenu_Deatils(TenantInfo objTenantInfo)
        {             
             objloginfo.Message = ("MailBoxConfigurationDetailsDAO - GetMailBoxLoginDetails - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            Hashtable hs = new Hashtable();            
            int ret=0;
             string resultValue = "-1";
             try
            {
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_SET_ZoneANDMenuDetails", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@szMenuName", objTenantInfo.AuditFeatures.MenuInfo.MenuName);
                    command.Parameters.Add("@szMenuDesc", objTenantInfo.AuditFeatures.MenuInfo.MenuDesc);
                    command.Parameters.Add("@szMenuControllerName", objTenantInfo.AuditFeatures.MenuInfo.MenuControllerName);
                    command.Parameters.Add("@szMenuActionName", objTenantInfo.AuditFeatures.MenuInfo.MenuActionName);
                    command.Parameters.Add("@iSequenceNo", objTenantInfo.AuditFeatures.MenuInfo.SequenceNo);
                    command.Parameters.Add("@bIsActive", objTenantInfo.AuditFeatures.MenuInfo.IsActive);
                    command.Parameters.Add("@szAccessType", objTenantInfo.AuditFeatures.MenuInfo.AccessType);
                    command.Parameters.Add("@szCategory", objTenantInfo.AuditFeatures.MenuInfo.Category);
                    command.Parameters.Add("@szZoneName", objTenantInfo.AuditFeatures.MenuInfo.ZoneName);
                    command.Parameters.Add("@szZoneDesc", objTenantInfo.AuditFeatures.MenuInfo.ZoneDesc);
                    command.Parameters.Add("@szZoneOffsetName", objTenantInfo.AuditFeatures.MenuInfo.ZoneOffsetName);
                    command.Parameters.Add("@szZoneOffsetDesc", objTenantInfo.AuditFeatures.MenuInfo.ZoneOffsetDesc);
                    command.Parameters.Add("@szTenantName", objTenantInfo.AuditFeatures.MenuInfo.TenantName); 
                    resultValue =command.ExecuteNonQuery().ToString();
                }}
              
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objTenantInfo.AuditFeatures.MenuInfo.TenantName, objTenantInfo.AuditFeatures.MenuInfo.AppID);
                throw;
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objTenantInfo.AuditFeatures.MenuInfo.TenantName, objTenantInfo.AuditFeatures.MenuInfo.AppID); throw;
            }
           // return Convert.ToInt32(new DBHelper().SelectSingleValue("USP_SET_EMail_MailBoxLoginDetails", hs));

             return ret=Convert.ToInt32(resultValue);
        }
        
        public DataSet GetHierarchy(string TenantName, string HierarchyName, int HierarchyLevel)
        {
            objloginfo.Message = ("MailBoxConfigurationDAO - GetHierarchy - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            try
            {

                DataSet _dt = new DataSet();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                    if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                        QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"                

                    SqlCommand command = new SqlCommand("USP_GET_Hierarchy", sqlConnection);                   
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                    command.Parameters.Add("@szTenantName", TenantName);
                    command.Parameters.Add("@szHierarchyName", HierarchyName);
                    command.Parameters.Add("@szHierarchyLevel", HierarchyLevel); 
                    
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    // da.Fill(ds);
                    adp.Fill(_dt);
                    sqlConnection.Close();

                }
                return _dt;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
 
        }

        //public DataTable GetEmailBox(string TenantName)
        //{
        //    objloginfo.Message = ("MailBoxConfigurationDAO - GetEmailBox - Called.");
        //    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        //    try
        //    {

        //        DataTable _dt = new DataTable();
        //        using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
        //        {
        //            sqlConnection.Open();
        //            string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

        //            if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
        //                QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"                

        //            SqlCommand command = new SqlCommand("USP_GET_EMailBox", sqlConnection);
        //            command.CommandType = CommandType.StoredProcedure;
        //            command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
        //            command.Parameters.Add("@szTenantName", TenantName);   
        //            SqlDataAdapter adp = new SqlDataAdapter(command);                    
        //            adp.Fill(_dt);
        //            sqlConnection.Close();

        //        }
        //        return _dt;
        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }

        //}

          public DataSet GetTenantConfigurationDeatils(string TenantName)
        {
            objloginfo.Message = ("MailBoxConfigurationDAO - GetTenantConfigurationDeatils - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            try
            {

                DataSet _dt = new DataSet();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                    if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                        QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"                

                    SqlCommand command = new SqlCommand("USP_GET_TenantConfigurationChanges", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                    command.Parameters.Add("@TenantName", TenantName);   
                    SqlDataAdapter adp = new SqlDataAdapter(command);                    
                    adp.Fill(_dt);
                    sqlConnection.Close();

                }
                return _dt;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

        }

          public DataSet GetZoneANDMenuDeatils(string TenantName)
          {
              objloginfo.Message = ("MailBoxConfigurationDAO - GetZoneANDMenuDeatils - Called.");
              objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
              try
              {

                  DataSet _dt = new DataSet();
                  using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                  {
                      sqlConnection.Open();
                      string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                      if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                          QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"                

                      SqlCommand command = new SqlCommand("USP_GET_ZoneANDMenuChanges", sqlConnection);
                      command.CommandType = CommandType.StoredProcedure;
                      command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                      command.Parameters.Add("@TenantName", TenantName);
                      SqlDataAdapter adp = new SqlDataAdapter(command);
                      adp.Fill(_dt);
                      sqlConnection.Close();

                  }
                  return _dt;
              }
              catch (SqlException ex)
              {
                  objlog.GetLoggingHandler("Log4net").LogException(ex);
                  throw;
              }

          }

          public int InsertZoneANDMenuDeatilsTONativeLocation(TenantInfo objTenantInfo)
          {
              int output = 0;
              objloginfo.Message = ("MailBoxConfigurationDAO - InsertZoneANDMenuDeatilsTONativeLocation - Called.");
              objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
              string resultValue = "-1";
              try
              {
                  using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                  {
                      sqlConnection.Open();
                      SqlCommand command = new SqlCommand(" ", sqlConnection);
                      command.CommandType = CommandType.StoredProcedure;
                      command.Parameters.Add("@szMenuName", objTenantInfo.AuditFeatures.MenuInfo.MenuName);
                      command.Parameters.Add("@szMenuDesc", objTenantInfo.AuditFeatures.MenuInfo.MenuDesc);
                      command.Parameters.Add("@szMenuControllerName", objTenantInfo.AuditFeatures.MenuInfo.MenuControllerName);
                      command.Parameters.Add("@szMenuActionName", objTenantInfo.AuditFeatures.MenuInfo.MenuActionName);
                      command.Parameters.Add("@iSequenceNo", objTenantInfo.AuditFeatures.MenuInfo.SequenceNo);
                      command.Parameters.Add("@bIsActive", objTenantInfo.AuditFeatures.MenuInfo.IsActive);

                      command.Parameters.Add("@szAccessType", objTenantInfo.AuditFeatures.MenuInfo.AccessType);
                      command.Parameters.Add("@szCategory", objTenantInfo.AuditFeatures.MenuInfo.Category);
                      command.Parameters.Add("@szZoneName", objTenantInfo.AuditFeatures.MenuInfo.ZoneName);
                      command.Parameters.Add("@szZoneDesc", objTenantInfo.AuditFeatures.MenuInfo.ZoneDesc);
                      command.Parameters.Add("@szZoneOffsetName", objTenantInfo.AuditFeatures.MenuInfo.ZoneOffsetName);
                      command.Parameters.Add("@szZoneOffsetDesc", objTenantInfo.AuditFeatures.MenuInfo.ZoneOffsetDesc);
                      command.Parameters.Add("@szTenantName", objTenantInfo.AuditFeatures.MenuInfo.TenantName);
                      resultValue = command.ExecuteNonQuery().ToString();
                  }
              }
              catch (SqlException ex)
              {
                  objlog.GetLoggingHandler("Log4net").LogException(ex);
                  throw;
              }
              return output;
          }

          public int LookUpCreation(int LookupLevel, string LookupLevelName, string LookupName, string LookupDesc,string LookupValue, bool IsActive, string createdby, string tenantname, string parentLookup, string parentLookupvalue, string appId, int TenantId)
          {
              objloginfo.Message = ("MailBoxConfigurationDetailsDAO - SubProcessCreation - Called.");
              objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
              int ret = 0;
              string resultValue = "-1";
              try
              {
                  using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                  {
                      sqlConnection.Open();
                      SqlCommand command = new SqlCommand("USP_SET_LookUp", sqlConnection);
                      command.CommandType = CommandType.StoredProcedure;
                      command.Parameters.Add("@LookUpLevel", LookupLevel);
                      command.Parameters.Add("@LookUpLevelName", LookupLevelName);
                      command.Parameters.Add("@LookUpName", LookupName);
                      command.Parameters.Add("@LookUpDesc", LookupDesc);
                       command.Parameters.Add("@LookUpValue", LookupValue);
                      command.Parameters.Add("@IsActive", IsActive);
                      command.Parameters.Add("@CreatedBy", createdby);                                         
                      command.Parameters.Add("@TenantName", tenantname);
                      command.Parameters.Add("@ParentLookUpName", parentLookup);
                      command.Parameters.Add("@ParentLookUpValue", parentLookupvalue); 
                      resultValue = command.ExecuteScalar().ToString();

                  }
              }
              catch (SqlException ex)
              {
                  objlog.GetLoggingHandler("Log4net").LogException(ex, tenantname,appId);
                  throw;
              }
              catch (Exception ex)
              {
                  objlog.GetLoggingHandler("Log4net").LogException(ex, tenantname, appId); throw;
              }
              return ret = Convert.ToInt32(resultValue);

          }

          public DataTable GetLookUp(string TenantName, string LookUpName, int LookUpLevel)
          {
              objloginfo.Message = ("MailBoxConfigurationDAO - GetHierarchy - Called.");
              objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
              try
              {

                  DataTable _dt = new DataTable();
                  using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                  {
                      sqlConnection.Open();
                      string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                      if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                          QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"                

                      SqlCommand command = new SqlCommand("USP_GET_LookUp", sqlConnection);
                      command.CommandType = CommandType.StoredProcedure;
                      command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                      command.Parameters.Add("@szTenantName", TenantName);
                      command.Parameters.Add("@szLookUpName", LookUpName);
                      command.Parameters.Add("@szLookUpLevel", LookUpLevel);                        
                      SqlDataAdapter adp = new SqlDataAdapter(command);
                      // da.Fill(ds);
                      adp.Fill(_dt);
                      sqlConnection.Close();

                  }
                  return _dt;
              }
              catch (SqlException ex)
              {
                  objlog.GetLoggingHandler("Log4net").LogException(ex);
                  throw;
              }

          }

          public string InsertIntoPM(string ZoneName, string AccountName, string ProgramName, DateTime From, DateTime To,string CreadtedBy,string ModifedBy, string ConnectionString) 
          {
              objloginfo.Message = ("MailBoxConfigurationDetailsDAO - SubProcessCreation - Called.");
              objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
              int ret = 0;
              string resultValue = "-1";
              try
              {
                  using (SqlConnection sqlConnection = new SqlConnection(ConnectionString))
                  {
                      sqlConnection.Open();
                      SqlCommand command = new SqlCommand("USP_INSERT_PROGRAM", sqlConnection);
                      command.CommandType = CommandType.StoredProcedure;                     
                      command.Parameters.Add("@ProgramName", ProgramName);
                      command.Parameters.Add("@effectiveFrom", From);
                      command.Parameters.Add("@effectiveTo", To);
                      command.Parameters.Add("@createdBy", CreadtedBy);
                      command.Parameters.Add("@ModifiedBy", ModifedBy);                        
                        command.Parameters.Add("@AccountName", AccountName);  
                      command.Parameters.Add("@ZoneName", ZoneName);                      
                      resultValue = command.ExecuteScalar().ToString();
                     // resultValue = command.ExecuteNonQuery().ToString();

                       
                  }
              }
              catch (SqlException ex)
              {
                  objlog.GetLoggingHandler("Log4net").LogException(ex);
                  throw;
              }
              catch (Exception ex)
              {
                  objlog.GetLoggingHandler("Log4net").LogException(ex); throw;
              }
              return resultValue;// ret = Convert.ToInt32(resultValue);     

          }

          public string SetProgramFeatures(ProgramFeatureSetUp objProgramFeatures, string connectionString)
          {
              objloginfo.Message = ("SetProgramFeatures - Called.");
              objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
              // proxyLogger.Log.Info("SetProgramFeatures - Called.");
              string resultValue = "-1";
              try
              {
                 // ProgramFeatureSetUp objProgramFeatures = new ProgramFeatureSetUp();
                  //objProgramFeatures = (ProgramFeatureSetUp)objBase;

                  XElement Parent = new XElement("root");
                  XElement root = new XElement("xmlArguments",
                       new XAttribute("iProgramFeaturesSetUpId", (objProgramFeatures.ProgramFeatureSetUpId == null) ? 0 : objProgramFeatures.ProgramFeatureSetUpId),
                       new XAttribute("siProgramId", (objProgramFeatures.SelectedProgramId == null) ? 0 : objProgramFeatures.SelectedProgramId),
                       new XAttribute("bIsSupervisorAuditApplicable", (objProgramFeatures.IsSupervisorAuditApplicable == null) ? false : objProgramFeatures.IsSupervisorAuditApplicable),
                       new XAttribute("szAuditingLogic", (objProgramFeatures.SelectedAuditLogicId == null) ? string.Empty : objProgramFeatures.SelectedAuditLogicId),
                       new XAttribute("szScoringLogic", (objProgramFeatures.SelectedScoringLogicId == null) ? string.Empty : objProgramFeatures.SelectedScoringLogicId),
                       new XAttribute("bIsEmployeeApplicable", (objProgramFeatures.IsEmployeeApplicable == null) ? false : objProgramFeatures.IsEmployeeApplicable),
                       new XAttribute("bIsEnableDataEntryByAuditor", (objProgramFeatures.IsDataEntryByAuditorEnable == null) ? false : objProgramFeatures.IsDataEntryByAuditorEnable),
                        new XAttribute("bIsEnablePeerToPeerAuditInfo", (objProgramFeatures.IsPeerToPeerAuditInfoEnable == null) ? false : objProgramFeatures.IsPeerToPeerAuditInfoEnable),
                         new XAttribute("iNoOfElement", (objProgramFeatures.NoOfElement == null) ? 0 : objProgramFeatures.NoOfElement),
                          new XAttribute("szSystemEffects", (objProgramFeatures.SelectedSystemEffectId == null) ? string.Empty : objProgramFeatures.SelectedSystemEffectId),
                      new XAttribute("bIsDefaultRating", (objProgramFeatures.IsDefaultRating == null) ? false : objProgramFeatures.IsDefaultRating),
                       new XAttribute("bIsStratifiedSamplingRequired", (objProgramFeatures.IsStratifiedSampling == null) ? false : objProgramFeatures.IsStratifiedSampling),
                       new XAttribute("bIsFreezingOfSamples", (objProgramFeatures.IsSamplingFrozen == null) ? false : objProgramFeatures.IsSamplingFrozen),
                        new XAttribute("bIsExternalFreezingOfSamples", (objProgramFeatures.IsExternalSamplingFrozen == null) ? false : objProgramFeatures.IsExternalSamplingFrozen),
                        new XAttribute("bIsFatalErrorApplicable", (objProgramFeatures.IsFatalErrorApplicable == null) ? false : objProgramFeatures.IsFatalErrorApplicable),


                       new XAttribute("bIsLineApplicable", (objProgramFeatures.IsLinesApplicable == null) ? false : objProgramFeatures.IsLinesApplicable),
                        new XAttribute("bSamplingByVolume", (objProgramFeatures.Leveld == null) ? false : objProgramFeatures.Leveld),
                        
                      
                      
                       new XAttribute("szDateFormat", (objProgramFeatures.DateFormat == null) ? string.Empty : objProgramFeatures.DateFormat),
                      
                       
                       
                       new XAttribute("bIsCriticalityApplicable", (objProgramFeatures.IsCriticalityApplicable == null) ? false : objProgramFeatures.IsCriticalityApplicable),
                       new XAttribute("bIsDaylimitforcorrectionApplicable", (objProgramFeatures.IsDaylimitforcorrectionApplicable == null) ? false : objProgramFeatures.IsDaylimitforcorrectionApplicable),
                       new XAttribute("bIsSLAActivityApplicable", (objProgramFeatures.IsSLAActivityApplicable == null) ? false : objProgramFeatures.IsSLAActivityApplicable),
                       new XAttribute("bIsMailTriggerRequired", (objProgramFeatures.IsFeedbackMailTriggerApplicable == null) ? false : objProgramFeatures.IsFeedbackMailTriggerApplicable),
                       new XAttribute("bIsReworkRemainderMailRequired", (objProgramFeatures.IsReworkRemainderMailTgrApplicable == null) ? false : objProgramFeatures.IsReworkRemainderMailTgrApplicable),
                       new XAttribute("iMaxRemainderCnt", (objProgramFeatures.MaxNoOfRemainder == null) ? 0 : objProgramFeatures.MaxNoOfRemainder),
                       new XAttribute("iMailSchedulerFrequency", (objProgramFeatures.MailFrequency == null) ? 0 : objProgramFeatures.MailFrequency),
                       new XAttribute("szMailboxName", (objProgramFeatures.MailBoxName == null) ? string.Empty : objProgramFeatures.MailBoxName),
                       new XAttribute("szAuditTypes", (objProgramFeatures.AuditTypes == null) ? string.Empty : objProgramFeatures.AuditTypes),
                       new XAttribute("iCreatedBy", (objProgramFeatures.createdBy == null) ? 0 : Convert.ToInt32(objProgramFeatures.createdBy)),
                       new XAttribute("iModifiedBy", (objProgramFeatures.modifiedBy == null) ? 0 : Convert.ToInt32(objProgramFeatures.modifiedBy)),
                       new XAttribute("szOpertaionName", objProgramFeatures.eventAction),
                       new XAttribute("bIsTotalVolumeApplicable", (objProgramFeatures.IsTotalVolumeApplicable == null) ? false : objProgramFeatures.IsTotalVolumeApplicable),
                       new XAttribute("IsWorkFlowNeedforCorrection", (objProgramFeatures.IsWorkFlowNeedforCorrection == null) ? false : objProgramFeatures.IsWorkFlowNeedforCorrection),
                       new XAttribute("MaxCorrectionCnt", (objProgramFeatures.MaxCorrectionCnt == null) ? 0 : objProgramFeatures.MaxCorrectionCnt),
                       new XAttribute("MaxCorrectionDaysCnt", (objProgramFeatures.MaxCorrectionDaysCnt == null) ? 0 : objProgramFeatures.MaxCorrectionDaysCnt),
                      
                       new XAttribute("bIsMetricsRequired", (objProgramFeatures.IsMetricsRequired == null) ? false : objProgramFeatures.IsMetricsRequired),
                       new XAttribute("bIsTATApplicable", (objProgramFeatures.IsTATApplicable == null) ? false : objProgramFeatures.IsTATApplicable),
                       new XAttribute("bIsCombinedAccuracy", (objProgramFeatures.IsCombinedAccuracyNeeded == null) ? false : objProgramFeatures.IsCombinedAccuracyNeeded),
                       new XAttribute("bIsDeletMailEnable", (objProgramFeatures.IsDeletMailEnableTriggerApplicable == null) ? false : objProgramFeatures.IsDeletMailEnableTriggerApplicable),
                       new XAttribute("iIntAllocCnt", (objProgramFeatures.IntAllocCnt == null) ? 0 : Convert.ToInt32(objProgramFeatures.IntAllocCnt)),
                       new XAttribute("iExtAllocCnt", (objProgramFeatures.ExtAllocCnt == null) ? 0 : Convert.ToInt32(objProgramFeatures.ExtAllocCnt)),
                       new XAttribute("iBusiAllocCnt", (objProgramFeatures.BusiAllocCnt == null) ? 0 : Convert.ToInt32(objProgramFeatures.BusiAllocCnt)),
                       new XAttribute("szSamplingMethodInternal", (objProgramFeatures.sSamplingMethodforInternal == null) ? "" : objProgramFeatures.sSamplingMethodforInternal),
                       new XAttribute("szSamplingMethodBusiness", (objProgramFeatures.sSamplingMethodforBusiness == null) ? "" : objProgramFeatures.sSamplingMethodforBusiness),
                       new XAttribute("szStaticFields", (objProgramFeatures.StaticFields == null) ? string.Empty : objProgramFeatures.StaticFields),
                       new XAttribute("blsAHTEnable", (objProgramFeatures.AHTApplicability == null) ? false : objProgramFeatures.AHTApplicability),
                       new XAttribute("blsCTQComments", (objProgramFeatures.CTQComments == null) ? false : objProgramFeatures.CTQComments),
                       new XAttribute("bIsRatingDifferenceMailEnable", (objProgramFeatures.IsRatingDifferenceMailApplicable == null) ? false : objProgramFeatures.IsRatingDifferenceMailApplicable),//Added for Rating Difference Email Configuration
                       new XAttribute("szCombinedAccuracyType", (objProgramFeatures.szCombinedAccuracyType == null) ? string.Empty : objProgramFeatures.szCombinedAccuracyType), //Added for Final Audit Update Configuration
                       new XAttribute("IsSLABasedSubProcess", (objProgramFeatures.IsSLABasedSubProcess == null) ? false : objProgramFeatures.IsSLABasedSubProcess), //Added for SLA need subprocess
                       new XAttribute("IsSamplingTypeCustommode", (objProgramFeatures.IsSamplingTypeCustommode == null) ? false : objProgramFeatures.IsSamplingTypeCustommode), //Added for Sampling type custom mode
                   new XAttribute("IsDataPurgingEnabled", (objProgramFeatures.IsDataPurgingEnabled == null) ? false : objProgramFeatures.IsDataPurgingEnabled) //Added for data purging required or not


                       );

                  using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                  {
                      sqlConnection.Open();
                      SqlCommand command = new SqlCommand("USP_SET_PROGRAM_FEATURES", sqlConnection);
                      command.CommandType = CommandType.StoredProcedure;



                      Parent.Add(root);
                      command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);
                      command.Parameters.Add(Constants.PAR_RETURN_VALUE, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;

                      command.ExecuteNonQuery();
                      resultValue = command.Parameters[Constants.PAR_RETURN_VALUE].Value.ToString();
                  }

              }
              catch (ArgumentException ex)
              {
                  objlog.GetLoggingHandler("Log4net").LogException(ex, objProgramFeatures.TenantName, objProgramFeatures.AppID);
                  // throw new QuartException(ex.Message, ex.InnerException);
              }
              catch (SqlException ex)
              {
                  objlog.GetLoggingHandler("Log4net").LogException(ex, objProgramFeatures.TenantName, objProgramFeatures.AppID); 
                  // throw new QuartException(ex.Message, ex.InnerException);
              }
              catch (ApplicationException ex)
              {
                  objlog.GetLoggingHandler("Log4net").LogException(ex, objProgramFeatures.TenantName, objProgramFeatures.AppID);
                  // throw new QuartException(ex.Message, ex.InnerException);
              }              
              return resultValue;

          }
      
    }
}
