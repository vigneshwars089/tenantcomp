﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using System.IO;
using System.Collections;
using System.Data;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    internal class ProcessTransformer
    {
        internal List<ProcessEntity> MapToProcessList(DataTable dt)
        {
            List<ProcessEntity> baseEntityList = new List<ProcessEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new ProcessEntity
                              {
                                  processId = Convert.ToInt16(p["iProcessId"] == DBNull.Value ? 0 : p["iProcessId"]),
                                  processName = Convert.ToString(p["szProcessName"] == DBNull.Value ? string.Empty : p["szProcessName"]),
                                  SelectedProgramId = Convert.ToInt16(p["siProgramId"] == DBNull.Value ? 0 : p["siProgramId"]),
                                  SelectedProgramName = Convert.ToString(p["szProgramName"] == DBNull.Value ? string.Empty : p["szProgramName"]),
                                  isActive = Convert.ToBoolean(p["bIsActive"]),
                                  effectiveFrom = Convert.ToDateTime(p["dsEffectiveFrom"] == DBNull.Value ? string.Empty : p["dsEffectiveFrom"]),
                                  effectiveTo = Convert.ToDateTime(p["dsEffectiveTo"] == DBNull.Value ? string.Empty : p["dsEffectiveTo"]),
                                  createdBy = Convert.ToString(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]),
                                  createdDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]),
                                  modifiedBy = Convert.ToString(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]),
                                  modifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"]),
                                  TotalRows = Convert.ToInt32(p["TotalRows"] == DBNull.Value ? 0 : p["TotalRows"])
                              }).ToList();
            return baseEntityList;
        }
        internal List<ProcessEntity> MapToDropDownList(DataTable dt)
        {
            List<ProcessEntity> EntityList = new List<ProcessEntity>();
            if (dt.Columns.Count > 2)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddlprocess
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1]),
                                  ForeignKey = Convert.ToString(p[2] == DBNull.Value ? string.Empty : p[2])
                              }).Cast<ProcessEntity>().ToList();
            }
            else if (dt.Columns.Count == 1)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddlprocess
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0])
                              }).Cast<ProcessEntity>().ToList();
            }
            else
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddlprocess
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1])
                              }).Cast<ProcessEntity>().ToList();

            }

            return EntityList;
        }
    }
}
