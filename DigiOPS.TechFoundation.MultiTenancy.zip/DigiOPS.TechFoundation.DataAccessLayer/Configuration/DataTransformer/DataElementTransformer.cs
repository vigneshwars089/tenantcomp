﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    internal class DataElementTransformer
    {
        internal List<DataElementEntity> MapToDataElementList(DataTable dt)
        {
            List<DataElementEntity> baseEntityList = new List<DataElementEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new DataElementEntity
                              {
                                  ElementId = p.Table.Columns.Contains("iElementId") == true ? Convert.ToInt32(p["iElementId"] == DBNull.Value ? 0 : p["iElementId"]) : 0,
                                  ElementName = p.Table.Columns.Contains("szElementName") == true ? Convert.ToString(p["szElementName"] == DBNull.Value ? string.Empty : p["szElementName"]) : string.Empty,
                                  FieldType = p.Table.Columns.Contains("szFieldType") == true ? Convert.ToString(p["szFieldType"] == DBNull.Value ? string.Empty : p["szFieldType"]) : string.Empty,
                                  DisplayName = p.Table.Columns.Contains("szDisplayName") == true ? Convert.ToString(p["szDisplayName"] == DBNull.Value ? string.Empty : p["szDisplayName"]) : string.Empty,
                                  ElementLength = p.Table.Columns.Contains("iElementLength") == true ? Convert.ToInt32(p["iElementLength"] == DBNull.Value ? 0 : p["iElementLength"]) : 0,
                                  CodeGroupId = p.Table.Columns.Contains("szCodeGroupId") == true ? Convert.ToString(p["szCodeGroupId"] == DBNull.Value ? string.Empty : p["szCodeGroupId"]) : string.Empty,
                                  SequenceNo = p.Table.Columns.Contains("iSequenceNo") == true ? Convert.ToInt32(p["iSequenceNo"] == DBNull.Value ? 0 : p["iSequenceNo"]) : 0,
                                  MandatoryElement = p.Table.Columns.Contains("bMandatoryElement") == true ? Convert.ToBoolean(p["bMandatoryElement"]) : false,
                                  AuditFormElement = p.Table.Columns.Contains("bAuditFormElement") == true ? Convert.ToBoolean(p["bAuditFormElement"] == DBNull.Value ? false : p["bAuditFormElement"]) : false, //AuditFormElement

                                  RoleNames = p.Table.Columns.Contains("szRoleIdName") == true ? Convert.ToString(p["szRoleIdName"] == DBNull.Value ? string.Empty : p["szRoleIdName"]) : string.Empty,
                                  DataEntryRoleId = p.Table.Columns.Contains("szDataEntryByIds") == true ? Convert.ToString(p["szDataEntryByIds"] == DBNull.Value ? string.Empty : p["szDataEntryByIds"]) : string.Empty,

                                  UniqueElement = p.Table.Columns.Contains("bUniqueElement") == true ? Convert.ToBoolean(p["bUniqueElement"]) : false,
                                  SearchableElement = p.Table.Columns.Contains("bSearchableElement") == true ? Convert.ToBoolean(p["bSearchableElement"]) : false,
                                  GridViewElement = p.Table.Columns.Contains("bGridViewElement") == true ? Convert.ToBoolean(p["bGridViewElement"]) : false,
                                  IsReportField = p.Table.Columns.Contains("bIsReportField") == true ? Convert.ToBoolean(p["bIsReportField"]) : false,
                                  SamplingThreshold = p.Table.Columns.Contains("bSamplingThreshold") == true ? Convert.ToBoolean(p["bSamplingThreshold"]) : false,
                                  minSamplingRange = p.Table.Columns.Contains("szSamplingThresholdMin") == true ? Convert.ToString(p["szSamplingThresholdMin"] == DBNull.Value ? string.Empty : p["szSamplingThresholdMin"]) : string.Empty,
                                  maxSamplingRange = p.Table.Columns.Contains("szSamplingThresholdMax") == true ? Convert.ToString(p["szSamplingThresholdMax"] == DBNull.Value ? string.Empty : p["szSamplingThresholdMax"]) : string.Empty,
                                  selectedDataElementTypeId = p.Table.Columns.Contains("iElementTypeId") == true ? Convert.ToInt32(p["iElementTypeId"] == DBNull.Value ? 0 : p["iElementTypeId"]) : 0,
                                  selectedDataElementTypeName = p.Table.Columns.Contains("szElementTypeName") == true ? Convert.ToString(p["szElementTypeName"] == DBNull.Value ? string.Empty : p["szElementTypeName"]) : string.Empty,
                                  ElementIsList = p.Table.Columns.Contains("bIsList") == true ? Convert.ToBoolean(p["bIsList"]) : false,
                                  selectedDataTypeId = p.Table.Columns.Contains("iDataTypeId") == true ? Convert.ToInt32(p["iDataTypeId"] == DBNull.Value ? 0 : p["iDataTypeId"]) : 0,
                                  selectedDataTypeName = p.Table.Columns.Contains("szDataTypeName") == true ? Convert.ToString(p["szDataTypeName"] == DBNull.Value ? string.Empty : p["szDataTypeName"]) : string.Empty,
                                  splChars = p.Table.Columns.Contains("szValidChars") == true ? Convert.ToString(p["szValidChars"] == DBNull.Value ? string.Empty : p["szValidChars"].ToString().Replace("|", "")) : string.Empty,
                                  IsDirectAuditLevel = p.Table.Columns.Contains("bDirectAuditReq") == true ? Convert.ToBoolean(p["bDirectAuditReq"] == DBNull.Value ? false : p["bDirectAuditReq"]) : false,
                                  DirectAuditLevel = p.Table.Columns.Contains("DirectAuditLevel") == true ? Convert.ToString(p["DirectAuditLevel"] == DBNull.Value ? string.Empty : p["DirectAuditLevel"]) : string.Empty,
                                  DirectAuditLevelId = p.Table.Columns.Contains("DirectAuditLevelId") == true ? Convert.ToInt32(p["DirectAuditLevelId"] == DBNull.Value ? 0 : p["DirectAuditLevelId"]) : 0,
                                  minAuditRange = p.Table.Columns.Contains("szAuditMin") == true ? Convert.ToString(p["szAuditMin"] == DBNull.Value ? string.Empty : p["szAuditMin"]) : string.Empty,
                                  maxAuditRange = p.Table.Columns.Contains("szAuditMax") == true ? Convert.ToString(p["szAuditMax"] == DBNull.Value ? string.Empty : p["szAuditMax"]) : string.Empty,
                                  selectedSubProcessName = p.Table.Columns.Contains("szSubProcessName") == true ? Convert.ToString(p["szSubProcessName"] == DBNull.Value ? string.Empty : p["szSubProcessName"]) : string.Empty,
                                  selectedProcessId = p.Table.Columns.Contains("iProcessId") == true ? Convert.ToInt32(p["iProcessId"] == DBNull.Value ? 0 : p["iProcessId"]) : 0,
                                  selectedProcessName = p.Table.Columns.Contains("szProcessName") == true ? Convert.ToString(p["szProcessName"] == DBNull.Value ? string.Empty : p["szProcessName"]) : string.Empty,
                                  selectedProgramId = p.Table.Columns.Contains("siProgramId") == true ? Convert.ToInt32(p["siProgramId"] == DBNull.Value ? 0 : p["siProgramId"]) : 0,
                                  selectedProgramName = p.Table.Columns.Contains("szProgramName") == true ? Convert.ToString(p["szProgramName"] == DBNull.Value ? string.Empty : p["szProgramName"]) : string.Empty,
                                  isActive = p.Table.Columns.Contains("bIsActive") == true ? Convert.ToBoolean(p["bIsActive"]) : false,

                                  createdBy = p.Table.Columns.Contains("iCreatedBy") == true ? Convert.ToString(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]) : string.Empty,
                                  createdDate = p.Table.Columns.Contains("dsCreatedDate") == true ? Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]) : DateTime.MinValue,
                                  modifiedBy = p.Table.Columns.Contains("iModifiedBy") == true ? Convert.ToString(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]) : string.Empty,
                                  modifiedDate = p.Table.Columns.Contains("dsModifiedDate") == true ? Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"]) : DateTime.MinValue,
                                  _TotalRows = p.Table.Columns.Contains("TotalRows") == true ? Convert.ToInt32(p["TotalRows"] == DBNull.Value ? 0 : p["TotalRows"]) : 0,
                              }).ToList();

            return baseEntityList;
        }

        internal List<DataElementEntity> MapToDropDownList(DataTable dt)
        {
            List<DataElementEntity> EntityList = new List<DataElementEntity>();
            if (dt.Columns.Count > 2)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddldataelmnt
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1]),
                                  ForeignKey = Convert.ToString(p[2] == DBNull.Value ? string.Empty : p[2])
                              }).Cast<DataElementEntity>().ToList();
            }
            else if (dt.Columns.Count == 1)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddldataelmnt
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0])
                              }).Cast<DataElementEntity>().ToList();
            }
            else
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddldataelmnt
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1])
                              }).Cast<DataElementEntity>().ToList();

            }

            return EntityList;
        }

        internal CodeGroupEntity MapToCodesList(DataSet ds)
        {
           // BaseTransportEntity baseEntityList = new BaseTransportEntity();
            CodeGroupEntity Obj = new CodeGroupEntity();
            Obj = (from p in ds.Tables[0].AsEnumerable()
                   select new CodeGroupEntity
                   {
                       CodeGrpId = p.Table.Columns.Contains("szCodeGroupId") == true ? Convert.ToString(p["szCodeGroupId"] == DBNull.Value ? string.Empty : p["szCodeGroupId"]) : string.Empty,
                       ElementName = p.Table.Columns.Contains("szElementName") == true ? Convert.ToString(p["szElementName"] == DBNull.Value ? string.Empty : p["szElementName"]) : string.Empty,
                       CodeGroupList = (from p1 in ds.Tables[1].AsEnumerable()
                                        select new CodesEntity
                                        {
                                            CodeId = p1.Table.Columns.Contains("iCodeId") == true ? Convert.ToInt32(p1["iCodeId"] == DBNull.Value ? 0 : p1["iCodeId"]) : 0,
                                            CodeDesc = p1.Table.Columns.Contains("szCodeDesc") == true ? Convert.ToString(p1["szCodeDesc"] == DBNull.Value ? string.Empty : p1["szCodeDesc"]) : string.Empty,
                                            DisplayName = p1.Table.Columns.Contains("szDisplayName") == true ? Convert.ToString(p1["szDisplayName"] == DBNull.Value ? string.Empty : p1["szDisplayName"]) : string.Empty,
                                            CodeValue = p1.Table.Columns.Contains("szCodeValue") == true ? Convert.ToString(p1["szCodeValue"] == DBNull.Value ? string.Empty : p1["szCodeValue"]) : string.Empty,
                                            SequenceNo = p1.Table.Columns.Contains("iSequenceNo") == true ? Convert.ToInt32(p1["iSequenceNo"] == DBNull.Value ? 0 : p1["iSequenceNo"]) : 0,
                                            CodeGroupId = p1.Table.Columns.Contains("szCodeGroupId") == true ? Convert.ToString(p1["szCodeGroupId"] == DBNull.Value ? string.Empty : p1["szCodeGroupId"]) : string.Empty,
                                            ParentGroupId = p1.Table.Columns.Contains("szParentGroupId") == true ? Convert.ToString(p1["szParentGroupId"] == DBNull.Value ? string.Empty : p1["szParentGroupId"]) : string.Empty,
                                            Level = p1.Table.Columns.Contains("iLevel") == true ? Convert.ToInt32(p1["iLevel"] == DBNull.Value ? 0 : p1["iLevel"]) : 0,
                                            isActive = p1.Table.Columns.Contains("bIsActive") == true ? Convert.ToBoolean(p1["bIsActive"]) : false,
                                            createdBy = p1.Table.Columns.Contains("iCreatedBy") == true ? Convert.ToString(p1["iCreatedBy"] == DBNull.Value ? string.Empty : p1["iCreatedBy"]) : string.Empty,
                                            createdDate = p1.Table.Columns.Contains("dsCreatedDate") == true ? Convert.ToDateTime(p1["dsCreatedDate"] == DBNull.Value ? string.Empty : p1["dsCreatedDate"]) : DateTime.MinValue,
                                            modifiedBy = p1.Table.Columns.Contains("iModifiedBy") == true ? Convert.ToString(p1["iModifiedBy"] == DBNull.Value ? string.Empty : p1["iModifiedBy"]) : string.Empty,
                                            modifiedDate = p1.Table.Columns.Contains("dsModifiedDate") == true ? Convert.ToDateTime(p1["dsModifiedDate"] == DBNull.Value ? string.Empty : p1["dsModifiedDate"]) : DateTime.MinValue
                                        }).ToList()
                   }).FirstOrDefault();
           // baseEntityList = (BaseTransportEntity)Obj;
            return Obj;
        }
    }
}
