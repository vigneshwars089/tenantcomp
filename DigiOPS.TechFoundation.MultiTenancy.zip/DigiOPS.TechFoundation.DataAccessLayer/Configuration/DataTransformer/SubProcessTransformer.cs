﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using System.Collections;
using System.Data;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    internal class SubProcessTransformer
    {
        internal List<SubProcessEntity> MapToSubProcessList(DataTable dt)
        {
            List<SubProcessEntity> baseEntityList = new List<SubProcessEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new SubProcessEntity
                              {
                                  SubProcessId = Convert.ToInt32(p["iSubProcessId"] == DBNull.Value ? 0 : p["iSubProcessId"]),
                                  SubProcessName = Convert.ToString(p["szSubProcessName"] == DBNull.Value ? string.Empty : p["szSubProcessName"]),
                                  ProcessId = Convert.ToInt32(p["iProcessId"] == DBNull.Value ? 0 : p["iProcessId"]),
                                  ProcessName = Convert.ToString(p["szProcessName"] == DBNull.Value ? string.Empty : p["szProcessName"]),
                                  EffectiveFrom = Convert.ToDateTime(p["dsEffectiveFrom"] == DBNull.Value ? 0 : p["dsEffectiveFrom"]),
                                  EffectiveTo = Convert.ToDateTime(p["dsEffectiveTo"] == DBNull.Value ? string.Empty : p["dsEffectiveTo"]),
                                  dSamplingPct = Convert.ToDecimal(p["dContractualSamplingPct"] == DBNull.Value ? 0 : p["dContractualSamplingPct"]),
                                  ProgramId = Convert.ToInt32(p["siProgramId"] == DBNull.Value ? 0 : p["siProgramId"]),
                                  ProgramName = Convert.ToString(p["szProgramName"] == DBNull.Value ? string.Empty : p["szProgramName"]),
                                  UserGroupId = Convert.ToInt32(p["iUserGroupId"] == DBNull.Value ? 0 : p["iUserGroupId"]),
                                  UserGroupName = Convert.ToString(p["szUserGroupName"] == DBNull.Value ? string.Empty : p["szUserGroupName"]),
                                  CreatedByName = Convert.ToString(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]),

                                  ModifiedByName = Convert.ToString(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]),
                                  IsActive = Convert.ToBoolean(p["bIsActive"] == DBNull.Value ? string.Empty : p["bIsActive"]),
                                  TotalRows = Convert.ToInt32(p["TotalRows"] == DBNull.Value ? 0 : p["TotalRows"]),
                                  CreatedDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]),
                                  ModifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"]),
                                  //Added for SLA Changes
                                  iSLALevelID = Convert.ToInt32(p["iSLALevelID"] == DBNull.Value ? 0 : p["iSLALevelID"]),
                                  ServiceLevelName = Convert.ToString(p["szServiceLevelName"] == DBNull.Value ? string.Empty : p["szServiceLevelName"])


                              }).ToList();

            return baseEntityList;
        }

        internal List<ProcessEntity> MapToProcessList(DataTable dt)
        {
            List<ProcessEntity> baseEntityList = new List<ProcessEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new ProcessEntity
                              {
                                  processId = Convert.ToInt16(p["iProcessId"] == DBNull.Value ? 0 : p["iProcessId"]),
                                  processName = Convert.ToString(p["szProcessName"] == DBNull.Value ? string.Empty : p["szProcessName"]),
                                  SelectedProgramId = Convert.ToInt16(p["siProgramId"] == DBNull.Value ? 0 : p["siProgramId"]),
                                  SelectedProgramName = Convert.ToString(p["szProgramName"] == DBNull.Value ? string.Empty : p["szProgramName"]),
                                  isActive = Convert.ToBoolean(p["bIsActive"]),
                                  effectiveFrom = Convert.ToDateTime(p["dsEffectiveFrom"] == DBNull.Value ? string.Empty : p["dsEffectiveFrom"]),
                                  effectiveTo = Convert.ToDateTime(p["dsEffectiveTo"] == DBNull.Value ? string.Empty : p["dsEffectiveTo"]),
                                  createdBy = Convert.ToString(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]),
                                  createdDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]),
                                  modifiedBy = Convert.ToString(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]),
                                  modifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"])
                              }).ToList();



            return baseEntityList;
        }

        internal List<ProcessEntity> MapToUserGroupList(DataTable dt)
        {
            List<ProcessEntity> baseEntityList = new List<ProcessEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new UserGroupEntity
                              {
                                  UserGroupId = Convert.ToInt32(p["iUserGroupId"] == DBNull.Value ? 0 : p["iUserGroupId"]),
                                  UserGroupName = Convert.ToString(p["szUserGroupName"] == DBNull.Value ? string.Empty : p["szUserGroupName"]),
                                  ProgramId = Convert.ToInt16(p["siProgramId"] == DBNull.Value ? 0 : p["siProgramId"]),
                                  CreatedBy = Convert.ToInt32(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]),
                                  CreatedDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? 0 : p["dsCreatedDate"]),
                                  ModifiedBy = Convert.ToInt32(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]),
                                  ModifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? 0 : p["dsModifiedDate"]),



                              }).Cast<ProcessEntity>().ToList();

            return baseEntityList;
        }

        internal List<ProcessEntity> MapToSLAList(DataTable dt)
        {
            List<ProcessEntity> baseEntityList = new List<ProcessEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new SLAEntity
                              {
                                  iSLALevelID = Convert.ToInt32(p["iSLALevelID"] == DBNull.Value ? 0 : p["iSLALevelID"]),
                                  ServiceLevelName = Convert.ToString(p["szServiceLevelName"] == DBNull.Value ? string.Empty : p["szServiceLevelName"])


                              }).Cast<ProcessEntity>().ToList();

            return baseEntityList;
        }

        internal List<SubProcessEntity> MapToDropDownList(DataTable dt)
        {
            List<SubProcessEntity> EntityList = new List<SubProcessEntity>();
            if (dt.Columns.Count > 2)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddlsubprocess
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1]),
                                  ForeignKey = Convert.ToString(p[2] == DBNull.Value ? string.Empty : p[2])
                              }).Cast<SubProcessEntity>().ToList();
            }
            else if (dt.Columns.Count == 1)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddlsubprocess
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0])
                              }).Cast<SubProcessEntity>().ToList();
            }
            else
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddlsubprocess
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1])
                              }).Cast<SubProcessEntity>().ToList();

            }

            return EntityList;
        }
    }
}
