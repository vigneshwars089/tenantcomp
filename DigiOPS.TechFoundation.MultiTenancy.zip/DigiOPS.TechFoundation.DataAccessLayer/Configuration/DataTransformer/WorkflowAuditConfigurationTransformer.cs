﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;
using System.Data;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    internal class WorkflowAuditConfigurationTransformer
    {
        internal List<WorkflowConfigurationEntity> MapToWorkflowAuditConfigList(DataTable dt)
        {
            List<WorkflowConfigurationEntity> baseEntityList = new List<WorkflowConfigurationEntity>();



            baseEntityList = (from p in dt.AsEnumerable()
                              select new WorkflowConfigurationEntity
                              {
                                  WorkflowConfigID = Convert.ToInt32(p["iWorkflowConfigId"] == DBNull.Value ? 0 : p["iWorkflowConfigId"]),
                                  TransactionTypeID = Convert.ToInt16(p["byTransactionTypeId"] == DBNull.Value ? 0 : p["byTransactionTypeId"]),
                                  iSubCategoryId = Convert.ToInt16(p["iSubcategoryId"] == DBNull.Value ? 0 : p["iSubcategoryId"]),
                                  IsCoreTransactionStatusRequired = Convert.ToBoolean(p["bIsCoreTransStatusApplicable"] == DBNull.Value ? 0 : p["bIsCoreTransStatusApplicable"]),
                                  IsCoreTransactionStatusReasonRequired = Convert.ToBoolean(p["bIsCoreTransStatusReasonApplicable"] == DBNull.Value ? 0 : p["bIsCoreTransStatusReasonApplicable"]),

                                  IsInternalExternalAuditRequired = Convert.ToBoolean(p["bIsInternalExternalAuditRequired"] == DBNull.Value ? 0 : p["bIsInternalExternalAuditRequired"]),
                                  IsCalibratorRequired = Convert.ToBoolean(p["bIsCalibratorRequired"] == DBNull.Value ? 0 : p["bIsCalibratorRequired"]),
                                  IsMCalibratorRequired = Convert.ToBoolean(p["bIsMCalibratorRequired"] == DBNull.Value ? 0 : p["bIsMCalibratorRequired"]),

                                  IsDirectBusinessAuditRequired = Convert.ToBoolean(p["bIsBusinessAuditRequired"] == DBNull.Value ? 0 : p["bIsBusinessAuditRequired"]),
                                  IsSuperVisorAuditRequired = Convert.ToBoolean(p["bIsSupervisorRequired"] == DBNull.Value ? 0 : p["bIsSupervisorRequired"]),
                                  IsExternalAuditRequired = Convert.ToBoolean(p["bIsExternalAuditRequired"] == DBNull.Value ? 0 : p["bIsExternalAuditRequired"]),

                                  IsTotalVolumeAuditRequired = Convert.ToBoolean(p["bIsTotalVolumeRequired"] == DBNull.Value ? 0 : p["bIsTotalVolumeRequired"]),
                                  IsAutoSamplingRequired = Convert.ToBoolean(p["bIsAutoSamplingNeeded"] == DBNull.Value ? 0 : p["bIsAutoSamplingNeeded"]),

                                  SubProcessID = Convert.ToInt32(p["iSubProcessId"] == DBNull.Value ? 0 : p["iSubProcessId"]),

                                  AuditConfigId = Convert.ToInt32(p["iAuditConfigId"] == DBNull.Value ? 0 : p["iAuditConfigId"]),
                                  AuditingLogicType = Convert.ToString(p["szAuditingLogicType"] == DBNull.Value ? 0 : p["szAuditingLogicType"]),
                                  ScoringLogicType = Convert.ToString(p["szScoringLogicType"] == DBNull.Value ? 0 : p["szScoringLogicType"]),
                                  IsEmpNeeded = Convert.ToBoolean(p["bIsEmpNeeded"] == DBNull.Value ? 0 : p["bIsEmpNeeded"]),
                                  bIsLineApplicable = Convert.ToBoolean(p["bIsLineNeeded"] == DBNull.Value ? 0 : p["bIsLineNeeded"]),
                                  bIsExternalAudit = Convert.ToBoolean(p["bIsExternalAudit"] == DBNull.Value ? 0 : p["bIsExternalAudit"]),
                                  bIsExternalAuditAuto = Convert.ToBoolean(p["bIsExternalAuditAuto"] == DBNull.Value ? 0 : p["bIsExternalAuditAuto"]),
                                  RootCauseLevel = Convert.ToInt16(p["bySubDefectLevel"] == DBNull.Value ? 0 : p["bySubDefectLevel"]),
                                  RootCauseLevelType = Convert.ToString(p["szSubDefectLevelType"] == DBNull.Value ? "" : p["szSubDefectLevelType"]),
                                  SamplingType = Convert.ToString(p["szSamplingType"] == DBNull.Value ? 0 : p["szSamplingType"]),
                                  ExternalSamplingType = Convert.ToString(p["szExternalSamplingType"] == DBNull.Value ? 0 : p["szExternalSamplingType"]),
                                  BusinessSamplingType = Convert.ToString(p["szBusinessSamplingType"] == DBNull.Value ? 0 : p["szBusinessSamplingType"]),
                                  isBusiAutoAllocationSamplingRequired = Convert.ToBoolean(p["bIsBusiAutoSamplingNeeded"] == DBNull.Value ? 0 : p["bIsBusiAutoSamplingNeeded"]),
                                  isExternalAutoAllocationSamplingRequired = Convert.ToBoolean(p["bIsExternalAutoSamplingNeeded"] == DBNull.Value ? 0 : p["bIsExternalAutoSamplingNeeded"]),
                                  ReworkRequiredFor = Convert.ToString(p["szRework_Update_NeededFor"] == DBNull.Value ? string.Empty : p["szRework_Update_NeededFor"]),
                                  ReworkupdateNeedFor = Convert.ToString(p["szRework_MandatoryFor"] == DBNull.Value ? string.Empty : p["szRework_MandatoryFor"]),
                                  ManualAllocationRequiredFor = Convert.ToString(p["szManualAllo_NeededFor"] == DBNull.Value ? string.Empty : p["szManualAllo_NeededFor"]),

                                  CreatedBy = Convert.ToString(p["iCreatedBy"] == DBNull.Value ? "0" : p["iCreatedBy"]).ToString(),
                                  CreatedDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? 0 : p["dsCreatedDate"]).ToString(),

                                  ModifiedBy = Convert.ToString(p["iModifiedBy"] == DBNull.Value ? "0" : p["iModifiedBy"]).ToString(),
                                  ModifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? 0 : p["dsModifiedDate"]).ToString(),

                                  IsEditAllowed = Convert.ToBoolean(p["bIsEditAllowed"] == DBNull.Value ? 0 : p["bIsEditAllowed"]),
                                  szSamplingMethodInternal = Convert.ToString(p["szSamplingMethodInternal"] == DBNull.Value ? string.Empty : p["szSamplingMethodInternal"]),
                                  szSamplingMethodBusiness = Convert.ToString(p["szSamplingMethodBusiness"] == DBNull.Value ? string.Empty : p["szSamplingMethodBusiness"]),
                                  iCopysubdefectLevel = Convert.ToInt32(p["iCopysubdefectLevel"] == DBNull.Value ? 0 : p["iCopysubdefectLevel"]),
                                  IsSamplingByVolume = Convert.ToBoolean(p["bSamplingByVolume"] == DBNull.Value ? 0 : p["bSamplingByVolume"]),
                                  IsCoverageScore = Convert.ToBoolean(p["bisCoverageScore"] == DBNull.Value ? 0 : p["bisCoverageScore"]),
                                  bIsAdditionalLanguageRequired = Convert.ToBoolean(p["bIsAdditionalLanguageRequired"] == DBNull.Value ? 0 : p["bIsAdditionalLanguageRequired"]),
                                  szLangId = Convert.ToString(p["szLangId"] == DBNull.Value ? string.Empty : p["szLangId"]),
                                  bIsAutoAudit = Convert.ToBoolean(p["bIsAutoAudit"] == DBNull.Value ? 0 : p["bIsAutoAudit"]),
                                  bIsNAWeightageRequired = Convert.ToBoolean(p["bIsNAWeightageRequired"] == DBNull.Value ? 0 : p["bIsNAWeightageRequired"])
                              }).ToList();


            return baseEntityList;

        }
    }
}
