﻿using System;
//using Quart.BusinessEntity;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Data;
//using Quart.Utility;
using System.Configuration;
using System.Collections;
using System.IO;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class ProcessDAO : ManualHierarchyConfigurationRepository
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        ConnectionString connectionstring = new ConnectionString();
       // BaseInfo objUserInfo = new BaseInfo();
        //private string dbConnectionString = string.Empty;
        //private Logger proxyLogger = new Logger();

        /// <summary>
        /// Database connestion string
        /// </summary>
        public ProcessDAO(string appId,int TenantId)
        {
            //dbConnectionString = Utility.Conversion.GetDecodedConnectionstring();
            dbConnectionString = connectionstring.GetConnectionString(appId, TenantId); 
           // dbConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnStr"];
        }
        public ProcessDAO(string TenantName, string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }

        /// <summary>
        /// to get Process List
        /// </summary>
        /// <param name="objProcessEntity"></param>
        /// <returns></returns>
        public override DataTable GetProcessEntityList(ManualHierarchyInfo objProcessEntity)
        {
            objloginfo.Message = ("ProcessDAO - GetProcessEntityList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            DataTable _dt = new DataTable();
            //proxyLogger.Log.Info("ProcessDAO - GetProcessEntityList - Called.");
                
                string spName = string.Empty;
                spName = "usp_Get_ProcessList";
            try
            {
            //    DataTable _dt = new DataTable();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("usp_Get_ProcessList", sqlConnection);
                    command.Parameters.Add("@siProgramId", SqlDbType.Int).Value = objProcessEntity.ProgramId;
                    command.Parameters.Add("@StartRowIndex", SqlDbType.Int).Value = objProcessEntity.StartRowIndex;
                    command.Parameters.Add("@MaximumRows", SqlDbType.Int).Value = objProcessEntity.MaximumRows;
                    command.Parameters.Add("@SortOrder", SqlDbType.VarChar).Value = objProcessEntity.SortOrder;
                    command.Parameters.Add("@SortColumn", SqlDbType.VarChar).Value = objProcessEntity.SortColumn;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_dt);
                }
                //Hashtable hs = new Hashtable();
                //hs.Add("@siProgramId", objProcessEntity.ProgramId);
                //hs.Add("@StartRowIndex", objProcessEntity.StartRowIndex);
                //hs.Add("@MaximumRows", objProcessEntity.MaximumRows);
                //hs.Add("@SortOrder", objProcessEntity.SortOrder);
                //hs.Add("@SortColumn", objProcessEntity.SortColumn);
                //DBHelper db = new DBHelper();
                //_dt = db.SelectDataTable(spName, hs);
               
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objProcessEntity.TenantName, objProcessEntity.AppID);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objProcessEntity.TenantName, objProcessEntity.AppID);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objProcessEntity.TenantName, objProcessEntity.AppID);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
            return _dt;
        }

        /// <summary>
        /// this method used for creating, updating and deleting the subprocess details 
        /// </summary>
        /// <param name="action"></param>
        /// <param name="objSubprocess"></param>
        /// <param name="Id"></param>
        /// <returns></returns>
        public override string SetProcessRecord(ProcessEntity _Process)
        {
            //dbConnectionString = connectionstring.GetConnectionString(_Process.AppID, _Process.TenantID); 

            objloginfo.Message = ("ProcessDAO - SetProcessRecord - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            string resultValue = "-1";
           // proxyLogger.Log.Info("ProcessDAO - SetProcessRecord - Called.");

            try
            {
                
                string spName = string.Empty;
                spName = "USP_SET_PROCESSMASTER";
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {

                   // ProcessEntity _Process = new ProcessEntity();
                    //_Process = (ProcessEntity)objprocess; 
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_SET_PROCESSMASTER, sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    //Hashtable hs = new Hashtable();
                    //hs.Add("@iProcessId", _Process.processId);
                    //hs.Add("@siProgramId", _Process.SelectedProgramId);
                    //hs.Add("@szProcessName", _Process.processName);
                    //hs.Add("@dsEffectiveFrom", _Process.effectiveFrom.ToShortDateString());
                    //hs.Add("@dsEffectiveTo", _Process.effectiveTo.ToShortDateString());
                    //hs.Add("@IsActive", _Process.isActive);
                    //hs.Add("@iDoneBy", _Process.createdBy);
                    //hs.Add("@sOpertaionName", _Process.eventAction);
                    //hs.Add("@iReturnValue", 0);
                    
                    command.Parameters.Add(Constants.PARAM_SET_PROCESSMASTER_PROCESSID, SqlDbType.VarChar).Value = _Process.processId;
                    command.Parameters.Add(Constants.PARAM_SET_PROCESSMASTER_PROGRAMID, SqlDbType.VarChar).Value = _Process.SelectedProgramId;
                    command.Parameters.Add(Constants.PARAM_SET_PROCESSMASTER_PROCESSNAME, SqlDbType.VarChar).Value = _Process.processName;
                    command.Parameters.Add(Constants.PARAM_SET_PROCESSMASTER_EFFECTIVEFROM, SqlDbType.DateTime).Value = (_Process.effectiveFrom == null) ? null : _Process.effectiveFrom.ToShortDateString();
                    command.Parameters.Add(Constants.PARAM_SET_PROCESSMASTER_EFFECTIVETO, SqlDbType.DateTime).Value = (_Process.effectiveTo == null) ? null : _Process.effectiveTo.ToShortDateString();
                    if (_Process.eventAction != "DELETE")
                    {
                        if (_Process.effectiveFrom.Date <= DateTime.Now)
                        {
                            _Process.isActive = true;
                        }
                        else
                        {
                            _Process.isActive = false;
                        }
                    }
                    command.Parameters.Add(Constants.PARAM_SET_PROCESSMASTER_ISACTIVE, SqlDbType.Bit).Value = _Process.isActive;
                    command.Parameters.Add(Constants.PARAM_SET_PROCESSMASTER_DONEBY, SqlDbType.VarChar).Value = _Process.createdBy;
                    command.Parameters.Add(Constants.PARAM_SET_PROCESSMASTER_OPERTAIONNAME, SqlDbType.VarChar).Value = _Process.eventAction;
                    command.Parameters.Add(Constants.PAR_iReturnValue, SqlDbType.Int, 100).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    //DBHelper db = new DBHelper();
                    //object message = db.ExecuteNonQuery(spName, hs);
                    //resultValue = message.ToString();
                    resultValue = command.Parameters[Constants.PAR_iReturnValue].Value.ToString();

                }

                
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, _Process.TenantName, _Process.AppID);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, _Process.TenantName, _Process.AppID);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidCastException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, _Process.TenantName, _Process.AppID);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, _Process.TenantName, _Process.AppID);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            //catch (QuartException ex)
            //{
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
            return resultValue;
        }

    }
}
