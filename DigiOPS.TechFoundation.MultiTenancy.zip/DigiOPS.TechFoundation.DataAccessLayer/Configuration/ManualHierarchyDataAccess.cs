﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.Collections;
using System.IO;
using System.Data;
using DigiOPS.TechFoundation.Logging;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class ManualHierarchyDataAccess
    {
        ProgramDAO prodao = null;
        ProcessDAO pdao = null;
        SubProcessDAO spdao = null;
        
        ProcessTransformer processtrans = new ProcessTransformer();
        SubProcessTransformer subprocesstrans = new SubProcessTransformer();
        ProgramTransformer prgmtrans = new ProgramTransformer();
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
          public ManualHierarchyDataAccess()
        {
            objloginfo.Message = ("ManualHierarchyDataAccess - Called." + "Tenant Name and AppId is not passed");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
         }
          public ManualHierarchyDataAccess(string TenantName, string AppId)
        {
            prodao = new ProgramDAO(TenantName, AppId);
            pdao = new ProcessDAO(TenantName, AppId);
            spdao = new SubProcessDAO(TenantName, AppId);  
        }
        public string AddUpdateDeleteProgram(ProgramEntity programEnt)
        {
            //prodao = new ProgramDAO(programEnt.AppID, programEnt.TenantID);
            string createRecVal = string.Empty;
            createRecVal = prodao.CUDProgramRecord(programEnt);
            return createRecVal;
        }
        public string AddUpdateDelProcess(ProcessEntity objprocess)
        {
           // pdao = new ProcessDAO(objprocess.AppID, objprocess.TenantID);
            string createRecVal = string.Empty;
            createRecVal = pdao.SetProcessRecord(objprocess);
            return createRecVal;
        }
        public List<ProcessEntity> GetProcessList(ManualHierarchyInfo objprocess)
        {
            //pdao = new ProcessDAO(objprocess.AppID, objprocess.TenantID);        
            List<ProcessEntity> listprocess = new List<ProcessEntity>();
            DataTable dt = new DataTable();
            dt = pdao.GetProcessEntityList(objprocess);
            if (dt.Rows.Count <= 0)
                return listprocess;
            if (objprocess.ViewName == "ProcessConfiguration")
            {
                listprocess = processtrans.MapToProcessList(dt);
                return listprocess;
            }
            else
            {
                listprocess = processtrans.MapToDropDownList(dt);
                return listprocess;
            }
        }
        public List<List<ProgramEntity>> GetProgramList(ManualHierarchyInfo objinfo)
        {
           // prodao = new ProgramDAO(objinfo.AppID, objinfo.TenantID);
            List<List<ProgramEntity>> listprogrm = new List<List<ProgramEntity>>();
            DataSet ds = new DataSet();
            ds = prodao.GetEntityListcollectionProgram(objinfo);
            if (ds.Tables.Count <= 0)
                return listprogrm;
            else
            {
                listprogrm.Add(prgmtrans.MapToProgramList(ds.Tables[0]));
                listprogrm.Add(prgmtrans.MapToDropDownList(ds.Tables[1]));
                listprogrm.Add(prgmtrans.MapToDropDownList(ds.Tables[2]));
            }
            return listprogrm;
        }
        public string AddUpdateDeleteSubProcess(SubProcessEntity objsubprocess)
        {
           // spdao = new SubProcessDAO(objsubprocess.AppID, objsubprocess.TenantID); 
            string createRecVal = string.Empty;
            createRecVal = spdao.SetSubProcessRecord(objsubprocess);
            return createRecVal;
        }
        public List<SubProcessEntity> GetSubProcessList(ManualHierarchyInfo objsubprocess)
        {
          //  spdao = new SubProcessDAO(objsubprocess.AppID, objsubprocess.TenantID); 
            List<SubProcessEntity> listsubprocess = new List<SubProcessEntity>();
            DataTable dt = new DataTable();
            dt = spdao.GetSubProcessList(objsubprocess);
            if (dt.Rows.Count <= 0)
                return listsubprocess;
            if (objsubprocess.ViewName == "SubProcessConfiguration")
                listsubprocess = subprocesstrans.MapToSubProcessList(dt);
            else
                listsubprocess = subprocesstrans.MapToDropDownList(dt);

            return listsubprocess;
        }
        public List<List<ProcessEntity>> GetProcessUsergrp(ManualHierarchyInfo objsubprocess)
        {
           // spdao = new SubProcessDAO(objsubprocess.AppID, objsubprocess.TenantID); 
            List<List<ProcessEntity>> listprocessuser = new List<List<ProcessEntity>>();
            DataSet ds = new DataSet();
            ds = spdao.GetEntityListcollection(objsubprocess);
            if (ds.Tables[0].Rows.Count <= 0)
                return listprocessuser;
            listprocessuser.Add(subprocesstrans.MapToProcessList(ds.Tables[0]));
            listprocessuser.Add(subprocesstrans.MapToUserGroupList(ds.Tables[1]));
            //Added to get SLA data to map in Subprocess
            if (ds.Tables.Count == 3)
            {
                listprocessuser.Add(subprocesstrans.MapToSLAList(ds.Tables[2]));
            }
            return listprocessuser;
        }
       
         
       
    }
}
