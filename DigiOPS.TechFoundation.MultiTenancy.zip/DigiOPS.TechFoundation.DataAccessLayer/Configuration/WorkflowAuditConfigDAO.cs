﻿using System;
//using Quart.BusinessEntity;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
//using Quart.Utility;
using System.Xml.Linq;
using System.Collections;
using System.IO;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    /// <summary>
    /// Workflow Audit Config DAO
    /// </summary>
    public class WorkflowAuditConfigDAO : IWorkFlowConfigurationRepository
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        ConnectionString connectionstring = new ConnectionString();

        /// <summary>
        /// Database connection
        /// </summary>

        public WorkflowAuditConfigDAO(string appId, int TenantId)
        {
            dbConnectionString = connectionstring.GetConnectionString(appId, TenantId);
            // dbConnectionString = Utility.Conversion.GetDecodedConnectionstring();
        }
        public WorkflowAuditConfigDAO(string TenantName, string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }

        /// <summary>
        /// Saves workflow configuration 
        /// </summary>
        /// <param name="action"></param>
        /// <param name="objConfigEntity"></param>
        /// <returns>Resultvalue</returns>
        public  string SetWorkflowAuditConfiguration(WorkflowConfigurationEntity objConfigEntity)
        {
            try
            {
                string resultValue = "-1";
                XElement Parent = new XElement("root");
                XElement root = new XElement("xmlArguments");

                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_SET_WORKFLOW_AUDIT_CONFIG", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.WorkflowConfigID)))
                        root.Add(new XAttribute("iWorkflowConfigurationID", Convert.ToString(objConfigEntity.WorkflowConfigID)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.AuditConfigId)))
                        root.Add(new XAttribute("iAuditConfigurationID", Convert.ToString(objConfigEntity.AuditConfigId)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.SubProcessID)))
                        root.Add(new XAttribute("iSubProcessID", Convert.ToString(objConfigEntity.SubProcessID)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.TransactionTypeID)))
                        root.Add(new XAttribute("byTransactionTypeID", Convert.ToString(objConfigEntity.TransactionTypeID)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.iSubCategoryId)))
                        root.Add(new XAttribute("iSubCategoryID", Convert.ToString(objConfigEntity.iSubCategoryId)));


                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsCoreTransactionStatusRequired)))
                        root.Add(new XAttribute("bIsCoreTransactionStatusRequired", Convert.ToString(objConfigEntity.IsCoreTransactionStatusRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsCoreTransactionStatusReasonRequired)))
                        root.Add(new XAttribute("bIsCoreTransactionStatusReasonRequired", Convert.ToString(objConfigEntity.IsCoreTransactionStatusReasonRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsSuperVisorAuditRequired)))
                        root.Add(new XAttribute("bIsSupervisorRequired", Convert.ToString(objConfigEntity.IsSuperVisorAuditRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsCalibratorRequired)))
                        root.Add(new XAttribute("bIsCalibratorRequired", Convert.ToString(objConfigEntity.IsCalibratorRequired)));


                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsMCalibratorRequired)))
                        root.Add(new XAttribute("bIsMCalibratorRequired", Convert.ToString(objConfigEntity.IsMCalibratorRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsInternalExternalAuditRequired)))
                        root.Add(new XAttribute("bIsInternalExternalAuditRequired", Convert.ToString(objConfigEntity.IsInternalExternalAuditRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsExternalAuditRequired)))
                        root.Add(new XAttribute("bIsExternalAuditRequired", Convert.ToString(objConfigEntity.IsExternalAuditRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.szSamplingMethodInternal)))
                        root.Add(new XAttribute("szSamplingMethodInternal", Convert.ToString(objConfigEntity.szSamplingMethodInternal)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.szSamplingMethodBusiness)))
                        root.Add(new XAttribute("szSamplingMethodBusiness", Convert.ToString(objConfigEntity.szSamplingMethodBusiness)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.isBusiAutoAllocationSamplingRequired)))
                        root.Add(new XAttribute("isBusiAutoAllocationSamplingRequired", Convert.ToString(objConfigEntity.isBusiAutoAllocationSamplingRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.isExternalAutoAllocationSamplingRequired)))
                        root.Add(new XAttribute("isExternalAutoAllocationSamplingRequired", Convert.ToString(objConfigEntity.isExternalAutoAllocationSamplingRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsDirectBusinessAuditRequired)))
                        root.Add(new XAttribute("bIsDirectBusinessAuditRequired", Convert.ToString(objConfigEntity.IsDirectBusinessAuditRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsTotalVolumeAuditRequired)))
                        root.Add(new XAttribute("bIsTotalAuditRequired", Convert.ToString(objConfigEntity.IsTotalVolumeAuditRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.AuditingLogicType)))
                        root.Add(new XAttribute("szAuditingLogicType", Convert.ToString(objConfigEntity.AuditingLogicType)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.ScoringLogicType)))
                        root.Add(new XAttribute("szScoringLogicType", Convert.ToString(objConfigEntity.ScoringLogicType)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsEmpNeeded)))
                        root.Add(new XAttribute("bIsEmpNeeded", Convert.ToString(objConfigEntity.IsEmpNeeded)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.bIsLineApplicable)))
                        root.Add(new XAttribute("bIsLineApplicable", Convert.ToString(objConfigEntity.bIsLineApplicable)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.bIsExternalAudit)))
                        root.Add(new XAttribute("bIsExternalAudit", Convert.ToString(objConfigEntity.bIsExternalAudit)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.bIsExternalAuditAuto)))
                        root.Add(new XAttribute("bIsExternalAuditAuto", Convert.ToString(objConfigEntity.bIsExternalAuditAuto)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.RootCauseLevel)))
                        root.Add(new XAttribute("bySubDefectLevel", Convert.ToString(objConfigEntity.RootCauseLevel)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.RootCauseLevelType)))
                        root.Add(new XAttribute("szSubDefectLevelType", Convert.ToString(objConfigEntity.RootCauseLevelType)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.SamplingType)))
                        root.Add(new XAttribute("szSamplingType", Convert.ToString(objConfigEntity.SamplingType)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.ExternalSamplingType)))
                        root.Add(new XAttribute("szExternalSamplingType", Convert.ToString(objConfigEntity.ExternalSamplingType)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.BusinessSamplingType)))
                        root.Add(new XAttribute("szBusinessSamplingType", Convert.ToString(objConfigEntity.BusinessSamplingType)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.ReworkRequiredFor)))
                        root.Add(new XAttribute("szRework_MandatoryFor", Convert.ToString(objConfigEntity.ReworkRequiredFor)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.ReworkupdateNeedFor)))
                        root.Add(new XAttribute("szRework_Update_NeededFor", Convert.ToString(objConfigEntity.ReworkupdateNeedFor)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.ManualAllocationRequiredFor)))
                        root.Add(new XAttribute("szManualAllo_NeededFor", Convert.ToString(objConfigEntity.ManualAllocationRequiredFor)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsAutoSamplingRequired)))
                        root.Add(new XAttribute("bIsAutoSamplingNeeded", Convert.ToString(objConfigEntity.IsAutoSamplingRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsActive)))
                        root.Add(new XAttribute("bIsActive", Convert.ToInt32(objConfigEntity.IsActive)));


                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.iCopysubdefectLevel)))
                        root.Add(new XAttribute("iCopysubdefectLevel", Convert.ToInt32(objConfigEntity.iCopysubdefectLevel)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsSamplingByVolume)))
                        root.Add(new XAttribute("bIsSamplingByVolume", Convert.ToString(objConfigEntity.IsSamplingByVolume)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsCoverageScore)))
                        root.Add(new XAttribute("IsCoverageScore", Convert.ToString(objConfigEntity.IsCoverageScore)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.bIsAutoAudit)))
                        root.Add(new XAttribute("bIsAutoAudit", Convert.ToString(objConfigEntity.bIsAutoAudit)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.bIsAdditionalLanguageRequired)))
                        root.Add(new XAttribute("bIsAdditionalLanguageRequired", Convert.ToString(objConfigEntity.bIsAdditionalLanguageRequired)));
                    if (!string.IsNullOrEmpty(objConfigEntity.szLangId))
                        root.Add(new XAttribute("szLangId", objConfigEntity.szLangId));
                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.bIsNAWeightageRequired)))
                        root.Add(new XAttribute("bIsNAWeightageRequired", Convert.ToString(objConfigEntity.bIsNAWeightageRequired)));
 
                    int AssociateID = 0;

                    if (objConfigEntity.Action == Constants.ACTION_Insert)
                    {
                        int.TryParse(objConfigEntity.CreatedBy.Trim(), out AssociateID);
                        root.Add(new XAttribute("iAssociateID", Convert.ToString(AssociateID)));
                    }
                    else if (objConfigEntity.Action == Constants.ACTION_Update)
                    {
                        int.TryParse(objConfigEntity.ModifiedBy.Trim(), out AssociateID);
                        root.Add(new XAttribute("iAssociateID", Convert.ToString(AssociateID)));
                    }
                    if (objConfigEntity.Action == "UpdateAudit")
                    {
                        int.TryParse(objConfigEntity.ModifiedBy.Trim(), out AssociateID);
                        root.Add(new XAttribute("iAssociateID", Convert.ToString(AssociateID)));
                    }

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.Action)))
                        root.Add(new XAttribute("szOpertaionName", Convert.ToString(objConfigEntity.Action)));

                    Parent.Add(root);

                    command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);
                    command.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters["@RETURN_VALUE"].Value.ToString();
                }

                return resultValue;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objConfigEntity.TenantName, objConfigEntity.AppID);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objConfigEntity.TenantName, objConfigEntity.AppID);
               // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objConfigEntity.TenantName, objConfigEntity.AppID);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            //catch (QuartException ex)
            //{
            //    proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
        }


        /// <summary>
        ///To get entity records by entity
        /// </summary>
        /// <param name="action"></param>
        /// <param name="objConfigEntity"></param>
        /// <returns>Dataset</returns>
        public  DataTable GetEntityRecordByEntity(WorkflowConfigInfo objBaseEntity)
        {
            DataTable dt = new DataTable();
            DataSet _ds = new DataSet();
            try
            {
                //DataTable _dt = new DataTable();
               
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("usp_Get_Workflow_Audit_Configuration_By_SubProcessID", SqlConnection);
                    command.Parameters.Add("@iSubProcessID", SqlDbType.Int).Value = objBaseEntity.SubProcessId;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
              
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objBaseEntity.TenantName, objBaseEntity.AppID);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
               // throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objBaseEntity.TenantName, objBaseEntity.AppID);
               // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
               // throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objBaseEntity.TenantName, objBaseEntity.AppID);
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw;
            }
            //catch (QuartException ex)
            //{
            //    proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            //    throw new QuartException(ex.Message, ex.InnerException);
            //}
            return (_ds.Tables[0]);
        }


        //public DataTable GetAuditTypeName(BaseTransportEntity objBaseEntity)
        //{
        //    DataTable dt = new DataTable();
        //    try
        //    {
        //        //DataTable _dt = new DataTable();
        //        DataSet _ds = new DataSet();
        //        using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
        //        {
        //            SqlConnection.Open();
        //            SqlCommand command = new SqlCommand("USP_GET_AUDIT_TYPE_NAME", SqlConnection);
        //            command.Parameters.Add("@ProgramID", SqlDbType.Int).Value = objBaseEntity._ProgramID;
        //            command.CommandType = CommandType.StoredProcedure;
        //            SqlDataAdapter adp = new SqlDataAdapter(command);
        //            adp.Fill(_ds);
        //        }
        //        return (_ds.Tables[0]);
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //}

        /// <summary>
        /// To get Entity list 
        /// </summary>
        /// <param name="action"></param>
        /// <param name="objConfigEntity"></param>
        /// <returns>Dataset</returns>
        //public DataTable GetEntityList(TransactionTypeEntity objTransactionType)
        //{
        //    DataTable dt = new DataTable();
        //    try
        //    {
        //        DataSet _ds = new DataSet();
        //        using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
        //        {
        //            sqlConnection.Open();
        //            SqlCommand command = new SqlCommand("usp_Get_TransactionTypes", sqlConnection);
        //            command.CommandType = CommandType.StoredProcedure;
        //            SqlDataAdapter adp = new SqlDataAdapter(command);
        //            adp.Fill(_ds);
        //        }
        //        return (_ds.Tables[0]);
        //    }
        //    catch (ArgumentException ex)
        //    {
        //        proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
        //        throw;
        //    }
        //    catch (SqlException ex)
        //    {
        //        proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
        //        throw;
        //    }
        //    catch (ApplicationException ex)
        //    {
        //        proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
        //        throw;
        //    }
        //    catch (QuartException ex)
        //    {
        //        proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
        //        throw new QuartException(ex.Message, ex.InnerException);
        //    }
        //}

        /// <summary>
        /// To get Category list 
        /// </summary>
        /// <param name="action"></param>
        /// <param name="objConfigEntity"></param>
        /// <returns>Dataset</returns>
        //public DataTable GetCategoryList(CategoryTypeEntity objCategoryType)
        //{
        //    DataTable dt = new DataTable();
        //    try
        //    {
        //        DataSet _ds = new DataSet();
        //        using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
        //        {
        //            sqlConnection.Open();
        //            SqlCommand command = new SqlCommand("USP_GET_CATEGORYTYPES", sqlConnection);
        //            command.CommandType = CommandType.StoredProcedure;
        //            SqlDataAdapter adp = new SqlDataAdapter(command);
        //            adp.Fill(_ds);
        //        }
        //        return (_ds.Tables[0]);
        //    }
        //    catch (ArgumentException ex)
        //    {
        //        proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
        //        throw;
        //    }
        //    catch (SqlException ex)
        //    {
        //        proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
        //        throw;
        //    }
        //    catch (ApplicationException ex)
        //    {
        //        proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
        //        throw;
        //    }
        //    catch (QuartException ex)
        //    {
        //        proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
        //        throw;
        //    }
        //}

    }
}
