﻿
using DigiOPS.TechFoundation.Logging;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class AUDITConfigurationRepository
    {
        LoggingFactory objloggingfactory = new LoggingFactory();
        public Database Db = DatabaseFactory.CreateDatabase("Conn");

        public DataTable GetDataElementRecordList(ConfigurationInfo DataElementEnt)//to read the list of elements from quart db
           { 
            const string SP_GET_TRANSELEMENTLIST = "USP_GET_TRANSELEMENTLIST";
               const string PAR_iSubProcessId = "@iSubProcessId";

               try
               {
                   DataTable _dt = new DataTable();
                   using (SqlConnection SqlConnection = new SqlConnection(Db.ConnectionString))
                   {
                       SqlConnection.Open();
                       SqlCommand command = new SqlCommand(SP_GET_TRANSELEMENTLIST, SqlConnection);
                       command.Parameters.Add(PAR_iSubProcessId, SqlDbType.Int).Value = (DataElementEnt._SubProcessID == 0) ? 0 : DataElementEnt._SubProcessID;
                       command.CommandType = CommandType.StoredProcedure;
                       SqlDataAdapter adp = new SqlDataAdapter(command);
                       adp.Fill(_dt);
                   }

                   int i = Convert.ToInt32(_dt.Rows.Count);

                   return _dt;
               }
               catch (Exception ex)
               {
                   objloggingfactory.GetLoggingHandler("Log4net").LogException(ex, DataElementEnt.TenantName, DataElementEnt.AppID); 
                   throw ex;
               }
           }

        public string CUDDataElementRecord(ConfigurationInfo DataElementEnt)
        {
            Log4NetLogger proxyLogger = new Log4NetLogger();

            string resultValue = "-1";
         
            proxyLogger.Log.Info("DataElementDAO - CUDDataElementRecord - Called.");
            try
            {
                const string SP_SET_TRANSELEMENTCONFIG = "USP_SET_TRANSELEMENTCONFIG";
                const string ACTION_Insert = "INSERT";
                const string PAR_iReturnValue = "iReturnValue";


                DataElementEntity _DataElement = new DataElementEntity();
                _DataElement = (DataElementEntity)DataElementEnt;
                using (SqlConnection SqlConnection = new SqlConnection(Db.ConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand(SP_SET_TRANSELEMENTCONFIG, SqlConnection);
                    command.CommandType = CommandType.StoredProcedure;


                    XElement Parent = AssignDataElementtoXML(DataElementEnt, ACTION_Insert, _DataElement);
                    command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);
                    SqlParameter outprm = new SqlParameter(PAR_iReturnValue, SqlDbType.Int, 100);
                    //     SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);

                    outprm.Direction = ParameterDirection.Output;
                    command.Parameters.Add(outprm);

                    command.ExecuteNonQuery();
                    resultValue = outprm.Value.ToString();
                }


            }
            catch (Exception ex)
            {
                objloggingfactory.GetLoggingHandler("Log4net").LogException(ex, DataElementEnt.TenantName, DataElementEnt.AppID); 
               
            }
            
            return resultValue;
        }

        private  XElement AssignDataElementtoXML(ConfigurationInfo DataElementEnt,  string ACTION_Insert, DataElementEntity _DataElement)
        {
            XElement Parent = new XElement("root");//Xattribute used to convert load this as xml document
            XElement root = new XElement("xmlArguments");
            root.Add(new XAttribute("iElementId", (DataElementEnt.eventAction == ACTION_Insert) ? 0 : _DataElement.ElementId));

            if (!string.IsNullOrEmpty(Convert.ToString(_DataElement.ElementName)))
                root.Add(new XAttribute("szElementName", Convert.ToString(_DataElement.ElementName)));

            if (!string.IsNullOrEmpty(Convert.ToString(_DataElement.FieldType)))
                root.Add(new XAttribute("FieldType", Convert.ToString(_DataElement.FieldType)));

            root.Add(new XAttribute("iElementTypeId", (_DataElement.ElementTypeId == 0) ? 0 : _DataElement.ElementTypeId));

            if (_DataElement.DataTypeId.Equals(0))
                root.Add(new XAttribute("iDataTypeId", 0));
            else
                root.Add(new XAttribute("iDataTypeId", Convert.ToString(_DataElement.DataTypeId)));

            if (!string.IsNullOrEmpty(_DataElement.splChars))
                root.Add(new XAttribute("szSplChars", Convert.ToString(_DataElement.splChars)));

            root.Add(new XAttribute("iElementLength", (_DataElement.ElementLength == 0) ? 0 : _DataElement.ElementLength));

            if (!string.IsNullOrEmpty(Convert.ToString(_DataElement.CodeGroupId)))
                root.Add(new XAttribute("szCodeGroupId", Convert.ToString(_DataElement.CodeGroupId)));

            root.Add(new XAttribute("iSequenceNo", (_DataElement.SequenceNo == 0) ? 0 : _DataElement.SequenceNo));
            root.Add(new XAttribute("bMandatoryElement", _DataElement.MandatoryElement));
            root.Add(new XAttribute("bAuditFormElement", _DataElement.AuditFormElement));
            root.Add(new XAttribute("bUniqueElement", _DataElement.UniqueElement));
            root.Add(new XAttribute("bGridViewElement", _DataElement.GridViewElement));
            root.Add(new XAttribute("bReportableField", _DataElement.IsReportField));
            root.Add(new XAttribute("bSearchableElement", _DataElement.SearchableElement));
            root.Add(new XAttribute("bSamplingThreshold", _DataElement.SamplingThreshold));
            root.Add(new XAttribute("bIsDirectAuditLevel", _DataElement.IsDirectAuditLevel));

            if (_DataElement.DirectAuditLevelId.Equals(0))
                root.Add(new XAttribute("iDirectAuditLevelId", "0"));
            else
                root.Add(new XAttribute("iDirectAuditLevelId", _DataElement.DirectAuditLevelId));

            if (!string.IsNullOrEmpty(_DataElement.minAuditRange))
                root.Add(new XAttribute("szMinAuditRange", Convert.ToString(_DataElement.minAuditRange)));
            if (!string.IsNullOrEmpty(_DataElement.maxAuditRange))
                root.Add(new XAttribute("szMaxAuditRange", Convert.ToString(_DataElement.maxAuditRange)));
            if (!string.IsNullOrEmpty(_DataElement.minSamplingRange))
                root.Add(new XAttribute("szMinSamplingRange", Convert.ToString(_DataElement.minSamplingRange)));
            if (!string.IsNullOrEmpty(_DataElement.maxSamplingRange))
                root.Add(new XAttribute("szMaxSamplingRange", Convert.ToString(_DataElement.maxSamplingRange)));
            if (!string.IsNullOrEmpty(_DataElement.DataEntryRoleId))
                root.Add(new XAttribute("szRoleIds", Convert.ToString(_DataElement.DataEntryRoleId)));
            else
                root.Add(new XAttribute("szRoleIds", string.Empty));

            root.Add(new XAttribute("iSubProcessId", (DataElementEnt._SubProcessID == 0) ? 0 : DataElementEnt._SubProcessID));

            root.Add(new XAttribute("bIsActive", true));

            if (!string.IsNullOrEmpty(_DataElement.createdBy))
                root.Add(new XAttribute("iCreatedBy", _DataElement.createdBy));

            if (!string.IsNullOrEmpty(_DataElement.modifiedBy))
                root.Add(new XAttribute("iModifiedBy", _DataElement.modifiedBy));

            root.Add(new XAttribute("szOpertaionName", Convert.ToString(DataElementEnt.eventAction)));
            root.Add(new XAttribute("iRectrictedElementCount", Convert.ToString(DataElementEnt._ElementCount)));
            Parent.Add(root);
            return Parent;
        }
    }
}
