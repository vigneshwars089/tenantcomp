﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class DataElementDataAccess
    {
        DataElementDAO dataelmntdao = null;
        DataElementTransformer dataelmnttrans = new DataElementTransformer();
        DataElementEntity dtent = new DataElementEntity();
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        public DataElementDataAccess()
        {
            objloginfo.Message = ("DataElementDataAccess - Called." + "Tenant Name and AppId is not passed");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
         }
        public DataElementDataAccess(string TenantName, string AppId)
        {
            dataelmntdao = new DataElementDAO(TenantName, AppId);           
        }
        public string AddUpdateDataElement(List<DataElementEntity> DataElements)
        {
            string createRecVal = string.Empty;
            dtent.ErrorMessage = new StringBuilder();
            foreach (var a in DataElements)
            {   
                createRecVal = dataelmntdao.CUDDataElementRecord(a);
               
                if(!(Convert.ToInt32(createRecVal)==1))
                {
                    dtent.ErrorMessage.Append(a.ElementName+" "+"Dataelement operation failed \n");
                }
                createRecVal = createRecVal + " "+dtent.ErrorMessage.ToString();
            }
            return createRecVal;
        }

        //public string DeleteDataElement(DataElementEntity datent)
        //{
        //    string createRecVal = string.Empty;
            
        //        dataelmntdao = new DataElementDAO(datent.AppID, datent.TenantID);

        //        createRecVal = dataelmntdao.CUDDataElementRecord(datent);

        //    return createRecVal;
        //}
        public List<DataElementEntity> GetDataElementRecordList(DataElementEntity _Obj)
        {
            DataTable dt = new DataTable();
            List<DataElementEntity> list = new List<DataElementEntity>();
            dataelmntdao = new DataElementDAO(_Obj.TenantName, _Obj.AppID);
            dt = dataelmntdao.GetDataElementRecordList(_Obj);
            if (dt.Rows.Count <= 0)
                return list;
            else
            {
                list = dataelmnttrans.MapToDataElementList(dt);
                return list;
            }
        }
        public List<List<DataElementEntity>> GetDataElements(DataElementInfo _obj)
        {
            dataelmntdao = new DataElementDAO(_obj.TenantName, _obj.AppID);
            List<List<DataElementEntity>> listdataelmnt = new List<List<DataElementEntity>>();
            DataSet ds = new DataSet();
            ds = dataelmntdao.GetEntityListcollection(_obj);
            if (ds.Tables.Count <= 0)
                return listdataelmnt;
            else
            {
                listdataelmnt.Add(dataelmnttrans.MapToDataElementList(ds.Tables[0]));
                listdataelmnt.Add(dataelmnttrans.MapToDropDownList(ds.Tables[1]));
                listdataelmnt.Add(dataelmnttrans.MapToDropDownList(ds.Tables[2]));
                return listdataelmnt;
            }
            
        }
        public DataSet BulkUploadDataElement(Hashtable hstbl, string AppID, string TenantName)
        {
            DataSet ds = new DataSet();
            dataelmntdao = new DataElementDAO(TenantName,AppID);
            ds = dataelmntdao.ExcelUploadToDB(hstbl, AppID, TenantName);
            return ds;
        }
        public List<DataElementStaticConditon> GetChildStaticConditions(int configid, string AppID, string TenantName)
        {
            dataelmntdao = new DataElementDAO(TenantName,AppID);
            List<DataElementStaticConditon> listdataelmnt = new List<DataElementStaticConditon>();
            listdataelmnt = dataelmntdao.GetChildStaticConditions(configid,AppID,TenantName);
            return listdataelmnt;
        }
        public List<DataElementStaticConditon> GetDataElementStaticCondition(int subprocessid, string AppID, string TenantName)
        {
            dataelmntdao = new DataElementDAO(TenantName,AppID);
            List<DataElementStaticConditon> listdataelmnt = new List<DataElementStaticConditon>();
            listdataelmnt = dataelmntdao.GetStaticConditions(subprocessid,AppID,TenantName);
            return listdataelmnt;
        }
        public string UpdateStaticConditions(List<DataElementStaticConditon> objConditions, string AppID, string TenantName)
        {
            dataelmntdao = new DataElementDAO(TenantName,AppID);
            string result = null;
            result = dataelmntdao.UpdateStaticConditions(objConditions, TenantName, AppID);
            return result;
        }
        public List<DataElementEntity> GetDirectAuditLevelList(int SubProcessID, string AppID, string TenantName)
        {
            dataelmntdao = new DataElementDAO(TenantName,AppID);
            List<DataElementEntity> baseList = new List<DataElementEntity>();
            DataTable dt = new DataTable();
            dt = dataelmntdao.GetDirectAuditLevelList(SubProcessID, TenantName, AppID);
            if (dt.Rows.Count <= 0)
                return baseList;
            baseList = dataelmnttrans.MapToDropDownList(dt);
                return baseList;
        }
        public string SetRanking(ElementSequence ElementSequence, string AppID, string TenantName)
        {
            dataelmntdao = new DataElementDAO(TenantName,AppID);
            string result = null;
            result = dataelmntdao.SetUpdateSequence(ElementSequence, TenantName, AppID);
            return result;
        }
        public string AddList(CodesEntity ListItem)
        {
            dataelmntdao = new DataElementDAO(ListItem.TenantName,ListItem.AppID);
            string result = null;
            result = dataelmntdao.SetCodesData(ListItem);
            return result;
        }
        public CodeGroupEntity GetCodesList(CodeGroupEntity _Codes)
        {
            dataelmntdao = new DataElementDAO(_Codes.TenantName,_Codes.AppID);
            CodeGroupEntity objcodes = new CodeGroupEntity();
            DataSet ds = new DataSet();
            ds = dataelmntdao.GetCodesList(_Codes);
            if (ds.Tables[0].Rows.Count <= 0)
                return objcodes;
            else
            {
                objcodes = dataelmnttrans.MapToCodesList(ds);
                return objcodes;
            }
        }

        public bool IsAutoAudit(DataElementInfo obj)
        {
            dataelmntdao = new DataElementDAO(obj.TenantName,obj.AppID);
            bool result = false;
            result = dataelmntdao.IsAutoAudit(obj);
            return result;
        }



        public string DeleteDataElement(List<DataElementEntity> DataElements, string ModifiedBy, string AppID, string TenantName)
        {
            string createRecVal = string.Empty;
            string Elementids = string.Empty;

            dataelmntdao = new DataElementDAO(TenantName,AppID);
            foreach (var a in DataElements)
            {
                if (Elementids != string.Empty)
                {
                    Elementids = Elementids+","+a.ElementId;
                }
                else
                {
                    Elementids = a.ElementId.ToString();
                }
              
            }
            createRecVal = dataelmntdao.DeleteDataelementRecords(Elementids,Convert.ToInt32(ModifiedBy));
            return createRecVal;
        } 

    }
}
