﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Configuration;

namespace DigiOPS.TechFoundation.DataAccessLayer
{ 
       
    public class CaseProcessingDAO
    {
         LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
            
        private string myConnection = string.Empty;
        //private DataSet dsStatus;
        public CaseProcessingDAO()
        {            
            //myConnection = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
            myConnection = System.Configuration.ConfigurationManager.AppSettings["ConnStr"];
        }
        public CaseProcessingDAO(string TenantName, string AppId)
        {

            myConnection = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }

        public  int GetMaxNoScreenshotCaseId(long CaseId)
        {
            int result = 0;
            DBHelper objDBHelper = new DBHelper();
            using (DbConnection connection = objDBHelper.Db.CreateConnection())
            {
                connection.Open();
                try
                {
                    using (DbTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            DbCommand attachcommand = objDBHelper.Db.GetStoredProcCommand("USP_GetNextScreenshotNumber");
                            attachcommand.Parameters.Add(new SqlParameter("CaseId", CaseId));
                            result = Convert.ToInt32(objDBHelper.Db.ExecuteScalar(attachcommand, transaction));
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            //ExceptionHelper.HandleException(ex);
                            objlog.GetLoggingHandler("Log4net").LogException(ex);
                            throw;
                        }
                    }
                }
                finally
                {
                    connection.Close();
                }
            }
            return result;
        }

        public  void LockEmail(int EmailBoxType, string EmailId)
        {
            try
            {
                DBHelper objDBHelper = new DBHelper();
                using (DbConnection connection = objDBHelper.Db.CreateConnection())
                {
                    connection.Open();
                    DbCommand attachcommand = objDBHelper.Db.GetStoredProcCommand("USP_LockEmail");
                    attachcommand.Parameters.Add(new SqlParameter("EmailBoxType", EmailBoxType));
                    attachcommand.Parameters.Add(new SqlParameter("EmailId", EmailId));
                    objDBHelper.Db.ExecuteNonQuery(attachcommand);
                }
            }
            catch (SqlException ex)
            {
                //ExceptionHelper.HandleException(ex);
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public  void InsertEMailDetails(long CaseId, string EMailTo, string EMailCc, string Subject, string EMailBody, int EMailTypeId, DateTime EMailSentDate, bool SentStatus, string plainbody, int ishighimp, bool isVIP)
        {
            try
            {
                DBHelper objDBHelper = new DBHelper();
                using (DbConnection connection = objDBHelper.Db.CreateConnection())
                {
                    connection.Open();
                    DbCommand attachcommand = objDBHelper.Db.GetStoredProcCommand("USP_Insert_EMailDetails");
                    attachcommand.Parameters.Add(new SqlParameter("CaseId", CaseId));
                    attachcommand.Parameters.Add(new SqlParameter("EMailTo", EMailTo));
                    attachcommand.Parameters.Add(new SqlParameter("EMailCc", EMailCc));
                    attachcommand.Parameters.Add(new SqlParameter("Subject", Subject));
                    attachcommand.Parameters.Add(new SqlParameter("EMailBody", EMailBody));
                    attachcommand.Parameters.Add(new SqlParameter("EMailTypeId", EMailTypeId));
                    attachcommand.Parameters.Add(new SqlParameter("EMailSentDate", EMailSentDate));
                    attachcommand.Parameters.Add(new SqlParameter("SentStatus", SentStatus));
                    attachcommand.Parameters.Add(new SqlParameter("plainbody", plainbody));
                    attachcommand.Parameters.Add(new SqlParameter("ishighimp", ishighimp));
                    //attachcommand.Parameters.Add(new SqlParameter("IsVip",isVIP));
                    objDBHelper.Db.ExecuteNonQuery(attachcommand);
                }
            }
            catch (SqlException ex)
            {
                //ExceptionHelper.HandleException(ex);
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
        }

        public DataSet LoadCase(string caseID)
        {
            DataSet dsStatus = new DataSet();
            try
            {

                string spname = string.Empty;
                Hashtable hs = new Hashtable();
                spname = "USP_GetCaseDetails";
                //spname = "USP_GetCaseDetailsForProcessing";
                hs.Add("@CaseId", caseID);
                DBHelper db = new DBHelper();
                dsStatus = db.SelectDataSet(spname, hs);

                //if (dsStatus.Tables.Count > 0)
                //{
                //    if (dsStatus.Tables[0].Rows.Count > 0)
                //    {
                //        currentStatus = db.ExecuteNonQuery(spname, hs);
                //    }
                //}
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;

            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;

            }
            return dsStatus;
        }
    }
}
