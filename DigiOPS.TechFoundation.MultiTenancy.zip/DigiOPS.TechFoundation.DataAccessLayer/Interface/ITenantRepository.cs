﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    interface ITenantRepository
    {
        string GetConnectionStringDetails(string TenantName, string AppId);
        int SaveTenantDetails(TenantInfo objMultiTenancyInfo);
        DataTable GetConnectionStringDetails(string AppId, int TenantId);
    }
}
