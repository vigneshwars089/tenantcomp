﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DigiOPS.TechFoundation.Entities;
namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public interface IProgramFeatureRepository
    {        
        string SetProgramFeatures(ProgramFeatureSetUp objBase);
        DataTable GetProgramFeatures(int ProgramID, string TenantName, string AppID);
    }
}
