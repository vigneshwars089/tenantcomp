﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public interface IEfficiencyCalculator
    {
        List<string> GetRoles(string ApplicationName);
        List<string> GetActivity(string ApplicationName);
    }
}
