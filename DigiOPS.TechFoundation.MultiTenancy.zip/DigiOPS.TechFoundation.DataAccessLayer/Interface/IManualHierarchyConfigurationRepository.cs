﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using System.Data;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public interface IManualHierarchyConfigurationRepository
    {
        string CUDProgramRecord(ProgramEntity _Program);
        string SetProcessRecord(ProcessEntity _Process);
        DataTable GetProcessEntityList(ManualHierarchyInfo objinfo);
        string SetSubProcessRecord(SubProcessEntity objSubprocess);
        DataTable GetSubProcessList(ManualHierarchyInfo objinfo);
        DataSet GetEntityListcollection(ManualHierarchyInfo objinfo);
        DataSet GetEntityListcollectionProgram(ManualHierarchyInfo _obj);
       
    }
}
