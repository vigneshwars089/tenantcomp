﻿using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class InterfacingDAO
    {
         private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();


        /// <summary>To get the database credentials from the configuration file</summary> 
        public InterfacingDAO()
        {
            dbConnectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
        }
        public InterfacingDAO(string TenantName, string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }
        public DataTable GetTeamSampling(int ProcessId)
        {
            objloginfo.Message = ("InterfacingDAO - GetTeamSampling - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);

            try
            {

                DataTable _dt = new DataTable();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                    if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                        QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"                

                    SqlCommand command = new SqlCommand("USP_SET_Interface", sqlConnection);
                    command.Parameters.Add("@iProcessId", ProcessId);
                    command.Parameters.Add("@sOpertaionName", "TeamSampling");
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    // da.Fill(ds);
                    adp.Fill(_dt);
                    sqlConnection.Close();

                }
                return _dt;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex); throw;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex); throw;
            }


        }

        public DataTable GetTransaction(int SubProcessId,DateTime ReceivedDate,DateTimeOffset ProcessedDate,string OperationName)
        {
            objloginfo.Message = ("InterfacingDAO - GetTransaction - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);

            try
            {

                DataTable _dt = new DataTable();
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

                    if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                        QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"                

                    SqlCommand command = new SqlCommand("USP_GET_Transaction", sqlConnection);
                    command.Parameters.Add("@iSubProcessId", SubProcessId);
                    command.Parameters.Add("@ddReceivedDate", ReceivedDate);
                    command.Parameters.Add("@dsProcessedDate", ProcessedDate);
                    command.Parameters.Add("@sOpertaionName", OperationName);
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    // da.Fill(ds);
                    adp.Fill(_dt);
                    sqlConnection.Close();

                }
                return _dt;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }

            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex); throw;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex); throw;
            }
        }

        //public DataTable GetReWorkTransaction(int SubProcessId, DateTime ReceivedDate, DateTimeOffset ProcessedDate)
        //{
        //    objloginfo.Message = ("InterfacingDAO - GetTransaction - Called.");
        //    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);

        //    try
        //    {

        //        DataTable _dt = new DataTable();
        //        using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
        //        {
        //            sqlConnection.Open();
        //            string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"];

        //            if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
        //                QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"                

        //            SqlCommand command = new SqlCommand("USP_GET_Transaction", sqlConnection);
        //            command.Parameters.Add("@iSubProcessId", SubProcessId);
        //            command.Parameters.Add("@ddReceivedDate", ReceivedDate);
        //            command.Parameters.Add("@dsProcessedDate", ProcessedDate);
        //            command.Parameters.Add("@sOpertaionName", "20/50k");
        //            command.CommandType = CommandType.StoredProcedure;
        //            command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
        //            SqlDataAdapter adp = new SqlDataAdapter(command);
        //            // da.Fill(ds);
        //            adp.Fill(_dt);
        //            sqlConnection.Close();

        //        }
        //        return _dt;
        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }

        //    catch (InvalidOperationException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex); throw;
        //    }
        //    catch (ArgumentException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex); throw;
        //    }
        //}

    }
}
