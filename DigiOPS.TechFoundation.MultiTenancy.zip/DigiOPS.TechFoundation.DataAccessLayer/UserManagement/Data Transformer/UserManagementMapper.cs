﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class UserManagementMapper
    {
        /// <summary>To get the User Mapping List</summary> 
        /// <param name="dt">Datatable</param> 
        /// <returns>Entity List</returns>
        internal List<UserInfo> MapToUserList(DataTable dt)
        {

            List<UserInfo> baseEntityList = new List<UserInfo>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new UserInfo
                              {
                                  SystemUserId = Convert.ToInt32(p["iSystemUserId"] == DBNull.Value ? 0 : p["iSystemUserId"]),
                                  CtsUserId = Convert.ToString(p["szCtsUserId"] == DBNull.Value ? string.Empty : p["szCtsUserId"]),
                                  ClientUserId = Convert.ToString(p["szClientUserId"] == DBNull.Value ? string.Empty : p["szClientUserId"]),
                                  FirstName = Convert.ToString(p["szFirstName"] == DBNull.Value ? string.Empty : p["szFirstName"]),
                                  EmailID = Convert.ToString(p["szEmail"] == DBNull.Value ? string.Empty : p["szEmail"]),
                                  EffectiveFrom = Convert.ToDateTime(p["dsEffectiveFrom"] == DBNull.Value ? null : p["dsEffectiveFrom"]),
                                  EffectiveTo = Convert.ToDateTime(p["dsEffectiveTo"] == DBNull.Value ? null : p["dsEffectiveTo"]),
                                  IsActive = Convert.ToBoolean(p["bIsActive"] == DBNull.Value ? string.Empty : p["bIsActive"]),
                                  CreatedBy = Convert.ToString(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]),
                                  CreatedOn = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? null : p["dsCreatedDate"]),
                                  ModifiedBy = Convert.ToString(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]),
                                  // ModifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? null : p["dsModifiedDate"])

                              }).Cast<UserInfo>().ToList();

            return baseEntityList;
        }

        /// <summary>To get the User Mapping List</summary> 
        /// <param name="dt">Datatable</param> 
        /// <returns>Entity List</returns>
        internal List<UserInfo> MapToUserGroupList(DataTable dt)
        {

            List<UserInfo> baseEntityList = new List<UserInfo>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new UserInfo
                              {
                                  UserGroupID = Convert.ToInt32(p["iUserGroupId"] == DBNull.Value ? 0 : p["iUserGroupId"]),
                                  UserGroupName = Convert.ToString(p["szUserGroupName"] == DBNull.Value ? string.Empty : p["szUserGroupName"]),
                                  EffectiveFrom = Convert.ToDateTime(p["dsEffectiveFrom"] == DBNull.Value ? null : p["dsEffectiveFrom"]),
                                  EffectiveTo = Convert.ToDateTime(p["dsEffectiveTo"] == DBNull.Value ? null : p["dsEffectiveTo"]),

                              }).Cast<UserInfo>().ToList();

            return baseEntityList;
        }
    }
}
