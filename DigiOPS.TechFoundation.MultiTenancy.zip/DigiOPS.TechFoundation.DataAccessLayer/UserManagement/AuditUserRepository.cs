﻿using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace DigiOPS.TechFoundation.DataAccessLayer
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :AuditUserRepository.cs
    // Namespace : DigiOps.TechFoundation.DataTransfer
    // Class Name(s) :AuditUserRepository
    // Author : Sadhesh
    // Creation Date : 6/14/2017
    // Purpose : insert the user and user group details 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //14-Jun-2017    Sadhesh     Create            Create user,usergroup, usergroup mapping, usergroup role mapping  
    //14-Jun-2017    Sadhesh     Read            Read user,usergroup content
    //14-Jun-2017    Sadhesh     Update            update user,usergroup, usergroup mapping, usergroup role mapping  
    //14-Jun-2017    Sadhesh     Delete            delete user, usergroup mapping

    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class AuditUserRepository : UserRepository
    {

        public struct S_UserManagement
        {

            public const string User = "User";
            public const string UserGroup = "UserGroup";
            public const string UserGroupMapping = "UserGroupMapping";
            public const string UserRoleMapping = "UserRoleMapping";
            public const string UserRolePermissionMapping = "UserRolePermissionMapping";

        }

        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        ConnectionString connectionstring = new ConnectionString();
        public string dbConnectionString = string.Empty;

        public override UserMgmtInfo Create(UserInfo objUserInfo)
        {


            //objUserInfo.eventAction = "Insert";
            UserMgmtInfo objResinfo = new UserMgmtInfo();

            string ResultStatus = string.Empty;
            try
            {
                if (objUserInfo.CreationType == S_UserManagement.User)
                {
                    ResultStatus = SetUserRecord(objUserInfo);
                }
                else if (objUserInfo.CreationType == S_UserManagement.UserGroup)
                {
                    ResultStatus = SetUserGroupMapping(objUserInfo);
                }
                else if (objUserInfo.CreationType == S_UserManagement.UserGroupMapping)
                {
                    ResultStatus = SetUserGroupUserMapping(objUserInfo);
                }
                else if (objUserInfo.CreationType == S_UserManagement.UserRoleMapping)
                {
                    ResultStatus = AddUserRoleMapping(objUserInfo);
                }
                else if (objUserInfo.CreationType == S_UserManagement.UserRolePermissionMapping)
                {
                    ResultStatus = SetRolePermissionMapping(objUserInfo);
                }

                objResinfo.ResultStatus = true;
                objResinfo.Message = ResultStatus;


            }
            catch (Exception ex)
            {

            }
            return objResinfo;
        }

        public override UserMgmtInfo Read(UserInfo objUserInfo)
        {


            UserMgmtInfo objResinfo = new UserMgmtInfo();
            DataTable dtDet = new DataTable();
            DataTable dtresult = new DataTable();
            try
            {
                if (objUserInfo.CreationType == S_UserManagement.User)
                {
                    dtDet = GetUserDetails(objUserInfo);
                    UserManagementMapper objmap = new UserManagementMapper();
                    objResinfo.UserList = objmap.MapToUserList(dtDet);

                }
                else if (objUserInfo.CreationType == S_UserManagement.UserGroup)
                {
                    dtDet = GetGroupNameDetails(objUserInfo);
                    UserManagementMapper objmap = new UserManagementMapper();
                    objResinfo.UserGroupList = objmap.MapToUserGroupList(dtDet);
                }

                else if (objUserInfo.CreationType == "GetGroupName")
                {
                    dtresult = GetGroupName(objUserInfo);
                }
                else if (objUserInfo.CreationType == "GetUsersNameBasedOnGroupSelection")
                {
                    dtresult = GetUsersNameBasedOnGroupSelection(objUserInfo);
                }
                else if (objUserInfo.CreationType == "GetRoles")
                {
                    dtresult = GetRoles(objUserInfo);
                }
                else if (objUserInfo.CreationType == "GetAllRoles")
                {
                    dtresult = GetAllRoles(objUserInfo);
                }
                else if (objUserInfo.CreationType == "GetRolePermissions")
                {
                    dtresult = GetRolePermissions(objUserInfo);
                }
                else if (objUserInfo.CreationType == "GetSelectedPermissionsByRoleID")
                {
                    dtresult = GetSelectedPermissionsByRoleID(objUserInfo);
                }
                else if (objUserInfo.CreationType == "GetRolePermissionMappingList")
                {
                    dtresult = GetRolePermissionMappingList(objUserInfo);
                }
                else if (objUserInfo.CreationType == "GetGroupUserRecordList")
                {
                    dtresult = GetGroupUserRecordList(objUserInfo);
                }
                else if (objUserInfo.CreationType == "GetSelectedUserForUserGroupMapping")
                {
                    dtresult = GetSelectedUserForUserGroupMapping(objUserInfo);
                }
                else if (objUserInfo.CreationType == "GetUserGroupUserMappingList")
                {
                    dtresult = GetUserGroupUserMappingList(objUserInfo);
                }
                else if (objUserInfo.CreationType == "GetUserMagmtRecordList")
                {
                    dtresult = GetUserMagmtRecordList(objUserInfo);
                }

                else if (objUserInfo.CreationType == "GetProgamList")
                {
                    dtresult = GetProgamList(objUserInfo);
                }

                else if (objUserInfo.CreationType == "GetUserList")
                {
                    dtresult = GetUserList(objUserInfo);
                }

                else if (objUserInfo.CreationType == "GetUserRoleMappings")
                {
                    dtresult = GetUserRoleMappings(objUserInfo);
                }

                else if (objUserInfo.CreationType == "GetProcessList")
                {
                    dtresult = GetProcessList(objUserInfo);
                }

                else if (objUserInfo.CreationType == "GetSubProcessList")
                {
                    dtresult = GetSubProcessList(objUserInfo);
                }

                else if (objUserInfo.CreationType == "GetUserList1")
                {
                    dtresult = GetUserList1(objUserInfo);
                }



                objResinfo.ResultStatus = true;
                objResinfo.dtlist = dtresult;
            }
            catch (Exception ex)
            {

            }
            return objResinfo;
        }

        public override UserMgmtInfo Update(UserInfo objUserInfo)
        {
            //return 0;
            objUserInfo.eventAction = "Update";
            UserMgmtInfo objResinfo = new UserMgmtInfo();
            string ResultStatus = string.Empty;
            try
            {
                if (objUserInfo.CreationType == S_UserManagement.User)
                {
                    ResultStatus = SetUserRecord(objUserInfo);
                }
                else if (objUserInfo.CreationType == S_UserManagement.UserGroup)
                {
                    ResultStatus = SetUserGroupMapping(objUserInfo);
                }
                else if (objUserInfo.CreationType == S_UserManagement.UserGroupMapping)
                {
                    ResultStatus = SetUserGroupUserMapping(objUserInfo);
                }
                else if (objUserInfo.CreationType == S_UserManagement.UserRoleMapping)
                {
                    ResultStatus = AddUserRoleMapping(objUserInfo);
                }
                else if (objUserInfo.CreationType == S_UserManagement.UserRolePermissionMapping)
                {
                    ResultStatus = SetRolePermissionMapping(objUserInfo);
                }
                objResinfo.ResultStatus = true;
                objResinfo.Message = ResultStatus;
            }
            catch (Exception ex)
            {

            }
            return objResinfo;
        }

        public override UserMgmtInfo Delete(UserInfo objUserInfo)
        {
            UserMgmtInfo objResinfo = new UserMgmtInfo();
            string ResultStatus = string.Empty;
            if (objUserInfo.CreationType == S_UserManagement.User)
            {
                ResultStatus = DeleteUser(objUserInfo);
            }
            if (objUserInfo.CreationType == "DeleteUserRoleMapping")
            {
                ResultStatus = DeleteUserRoleMapping(objUserInfo);
            }

            objResinfo.Message = ResultStatus;
            return objResinfo;
        }

        public string SetUserRecord(UserInfo user)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[user.TenantName].ConnectionString;
            objloginfo.Message = ("SetUserRecord -  Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            string resultValue = string.Empty;
            try
            {


                XElement Parent = new XElement("root");
                XElement root = new XElement("xmlArguments");
                Hashtable hs = new Hashtable();


                root.Add(new XAttribute("iSystemUserId", (user == null) ? 0 : user.SystemUserId));
                if (!string.IsNullOrEmpty(user.CtsUserId))
                    root.Add(new XAttribute("szCtsUserId", Convert.ToString(user.CtsUserId)));
                if (!string.IsNullOrEmpty(user.ClientUserId))
                    root.Add(new XAttribute("szClientUserId", Convert.ToString(user.ClientUserId)));
                if (!string.IsNullOrEmpty(user.FirstName))
                    root.Add(new XAttribute("szFirstName", Convert.ToString(user.FirstName)));
                if (!string.IsNullOrEmpty(user.EmailID))
                    root.Add(new XAttribute("szEmail", Convert.ToString(user.EmailID)));


                if (user.eventAction != "DELETE")
                {
                    if (user.EffectiveFrom.Date <= DateTime.Now)
                    {
                        user.IsActive = true;
                    }
                    else
                    {
                        user.IsActive = false;
                    }
                }

                root.Add(new XAttribute("iUserGroupId", (user == null) ? 0 : user.UserGroupID));
                root.Add(new XAttribute("bIsActive", (user == null) ? false : user.IsActive));
                root.Add(new XAttribute("iCreatedBy", (user == null) ? 0 : Convert.ToInt32(user.CreatedBy)));
                root.Add(new XAttribute("iModifiedBy", (user == null) ? 0 : Convert.ToInt32(user.ModifiedBy)));
                root.Add(new XAttribute("szOpertaionName", user.eventAction));

                Parent.Add(root);


                //hs.Add(Constants.PAR_dsEffectiveFrom, (user == null) ? null : user.EffectiveFrom.ToShortDateString());
                //hs.Add(Constants.PAR_dsEffectiveTo, (user == null) ? null : user.EffectiveTo.ToShortDateString());
                //hs.Add("@ExcelData", Convert.ToString(Parent));
                //hs.Add(Constants.PAR_RETURN_VALUE, 0);

                //DBHelper db = new DBHelper();
                //object message = db.ExecuteNonQuery(Constants.USP_SET_USERMASTER, hs);

                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_SET_USERMASTER", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(Constants.PAR_dsEffectiveFrom, (user == null) ? null : user.EffectiveFrom.ToShortDateString());
                    cmd.Parameters.AddWithValue(Constants.PAR_dsEffectiveTo, (user == null) ? null : user.EffectiveTo.ToShortDateString());
                    cmd.Parameters.AddWithValue("@ExcelData", Convert.ToString(Parent));
                    cmd.Parameters.Add(Constants.PAR_RETURN_VALUE, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;

                    cmd.ExecuteNonQuery();
                    resultValue = cmd.Parameters[Constants.PAR_RETURN_VALUE].Value.ToString();
                }

                return resultValue;
            }
            catch (InvalidOperationException Ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                resultValue = Ex.ToString();
                throw;
            }
            catch (SqlException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, user.TenantName, user.AppID);
                resultValue = ex.ToString();
                throw;
            }
            catch (ArgumentException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, user.TenantName, user.AppID);
                resultValue = ex.ToString();
                throw;
            }
            catch (FormatException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, user.TenantName, user.AppID);
                resultValue = ex.ToString();
                throw;
            }
            catch (OverflowException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, user.TenantName, user.AppID);
                resultValue = ex.ToString();
                throw;
            }

        }
        public string DeleteUser(UserInfo user)
        {
            dbConnectionString = ConfigurationManager.ConnectionStrings[user.TenantName].ConnectionString;
            objloginfo.Message = ("DeleteUser -  Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            string resultValue = string.Empty;
            try
            {



                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_Delete_USERMASTER", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@iSystemUserId", user.SystemUserId);
                   
                    cmd.Parameters.Add(Constants.PAR_RETURN_VALUE, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;

                    cmd.ExecuteNonQuery();
                    resultValue = cmd.Parameters[Constants.PAR_RETURN_VALUE].Value.ToString();
                }

                return resultValue;
            }
            catch (InvalidOperationException Ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }
            catch (SqlException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, user.TenantName, user.AppID);
                throw;
            }
            catch (ArgumentException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, user.TenantName, user.AppID);
                throw;
            }
            catch (FormatException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, user.TenantName, user.AppID);
                throw;
            }
            catch (OverflowException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, user.TenantName, user.AppID);
                throw;
            }

        }

        /// <summary>
        /// Method to Set User Group Mapping
        /// </summary>
        /// <param name="objBase">BaseTransportEntity</param>
        /// <returns>string</returns>
        public string SetUserGroupMapping(UserInfo groupUser)
        {
            dbConnectionString = ConfigurationManager.ConnectionStrings[groupUser.TenantName].ConnectionString;
            objloginfo.Message = ("SetUserGroupMapping  - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            string resultValue = string.Empty;
            try
            {


                Hashtable hs = new Hashtable();

                if (groupUser.eventAction != "DELETE")
                {
                    if (groupUser.EffectiveFrom.Date <= DateTime.Now)
                    {
                        groupUser.IsActive = true;
                    }
                    else
                    {
                        groupUser.IsActive = false;
                    }
                }


                //hs.Add("@szUserGroupName", (groupUser == null) ? string.Empty : groupUser.UserGroupName);
                //hs.Add("@siProgramId", (groupUser == null) ? 0 : groupUser.ProgramID);
                //hs.Add("@dsEffectiveFrom", (groupUser == null) ? string.Empty : groupUser.EffectiveFrom.ToShortDateString());
                //hs.Add("@dsEffectiveTo", (groupUser == null) ? string.Empty : groupUser.EffectiveTo.ToShortDateString());
                //hs.Add("@bIsActive", (groupUser == null) ? false : groupUser.IsActive);
                //hs.Add("@iCreatedBy", (groupUser == null) ? 0 : Convert.ToInt32(groupUser.CreatedBy));
                //hs.Add("@iUserGroupId", (groupUser == null) ? 0 : groupUser.UserGroupID);
                //hs.Add(Constants.PAR_szOpertaionName, groupUser.eventAction);
                //hs.Add(Constants.PAR_RETURN_VALUE, 0);

                //DBHelper db = new DBHelper();
                //object message = db.ExecuteNonQuery("USP_SET_USER_PROG_GROUP_MAPPING", hs);


                //return message.ToString();

                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_SET_USER_PROG_GROUP_MAPPING", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@szUserGroupName", (groupUser == null) ? string.Empty : groupUser.UserGroupName);
                    cmd.Parameters.AddWithValue("@siProgramId", (groupUser == null) ? 0 : groupUser.ProgramID);
                    cmd.Parameters.AddWithValue("@dsEffectiveFrom", (groupUser == null) ? string.Empty : groupUser.EffectiveFrom.ToShortDateString());
                    cmd.Parameters.AddWithValue("@dsEffectiveTo", (groupUser == null) ? string.Empty : groupUser.EffectiveTo.ToShortDateString());
                    cmd.Parameters.AddWithValue("@bIsActive", (groupUser == null) ? false : groupUser.IsActive);
                    cmd.Parameters.AddWithValue("@iCreatedBy", (groupUser == null) ? 0 : Convert.ToInt32(groupUser.CreatedBy));
                    cmd.Parameters.AddWithValue("@iUserGroupId", (groupUser == null) ? 0 : groupUser.UserGroupID);
                    cmd.Parameters.AddWithValue(Constants.PAR_szOpertaionName, groupUser.eventAction);
                    cmd.Parameters.Add(Constants.PAR_RETURN_VALUE, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;

                    cmd.ExecuteNonQuery();
                    resultValue = cmd.Parameters[Constants.PAR_RETURN_VALUE].Value.ToString();
                }

                return resultValue;
            }
            catch (InvalidOperationException Ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(Ex, groupUser.TenantName, groupUser.AppID);
                throw;
            }
            catch (SqlException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, groupUser.TenantName, groupUser.AppID);
                throw;
            }
            catch (ArgumentException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, groupUser.TenantName, groupUser.AppID);
                throw;
            }
            catch (FormatException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, groupUser.TenantName, groupUser.AppID);
                throw;
            }
            catch (OverflowException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, groupUser.TenantName, groupUser.AppID);
                throw;
            }

        }
        /// <summary>
        /// Method to Set UserGroup User Mapping
        /// </summary>
        /// <param name="objBase">BaseTransportEntity</param>
        /// <returns>string</returns>
        public string SetUserGroupUserMapping(UserInfo groupUserMapping)
        {
            dbConnectionString = ConfigurationManager.ConnectionStrings[groupUserMapping.TenantName].ConnectionString;
            objloginfo.Message = ("SetUserGroupUserMapping  - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            try
            {

                string resultValue = "-1";
                Hashtable hs = new Hashtable();


                //hs.Add("@siProgramId", (groupUserMapping == null) ? 0 : groupUserMapping.ProgramID);
                //hs.Add("@iUserGroupId", (groupUserMapping == null) ? 0 : groupUserMapping.UserGroupID);
                //hs.Add("@szUsers", (groupUserMapping == null) ? string.Empty : groupUserMapping.UserList);

                //hs.Add("@bIsActive", (groupUserMapping == null) ? false : groupUserMapping.IsActive);
                //hs.Add("@iCreatedBy", (groupUserMapping == null) ? 0 : Convert.ToInt32(groupUserMapping.CreatedBy));

                //hs.Add(Constants.PAR_szOpertaionName, groupUserMapping.eventAction);
                //hs.Add(Constants.PAR_RETURN_VALUE, 0);

                //DBHelper db = new DBHelper();
                //object message = null;

                //if (groupUserMapping.IsUserSearch == true)
                //{

                //    hs.Add("@siUserSearchText", (groupUserMapping == null) ? string.Empty : groupUserMapping.UsersSearchText);
                //    message = db.ExecuteNonQuery("USP_SET_USERGROUP_USER_MAPPINGBASEDONSEARCH", hs);
                //}
                //else
                //{

                //    message = db.ExecuteNonQuery("USP_SET_USERGROUP_USER_MAPPING", hs);
                //}


                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    string QueryExecutionTimeout = ConfigurationManager.AppSettings["QueryExecutionTimeout"].ToString();

                    if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                       QueryExecutionTimeout = Constants.QUERYEXECUTIONTIMEOUT; //"30"

                    SqlConnection.Open();
                    SqlCommand command = null;
                    if (groupUserMapping.IsUserSearch == true)
                    {
                        command = new SqlCommand("USP_SET_USERGROUP_USER_MAPPINGBASEDONSEARCH", SqlConnection);
                        command.Parameters.Add("@siUserSearchText", SqlDbType.VarChar).Value = (groupUserMapping == null) ? string.Empty : groupUserMapping.UsersSearchText;
                    }
                    else
                    {
                        command = new SqlCommand("USP_SET_USERGROUP_USER_MAPPING", SqlConnection);
                    }
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = Convert.ToInt32(QueryExecutionTimeout);
                    command.Parameters.Add("@siProgramId", SqlDbType.Int).Value = (groupUserMapping == null) ? 0 : groupUserMapping.ProgramID;
                    command.Parameters.Add("@iUserGroupId", SqlDbType.Int).Value = (groupUserMapping == null) ? 0 : groupUserMapping.UserGroupID;
                    command.Parameters.Add("@szUsers", SqlDbType.VarChar).Value = (groupUserMapping == null) ? string.Empty : groupUserMapping.UserList;
                    command.Parameters.Add("@bIsActive", SqlDbType.Bit).Value = (groupUserMapping == null) ? false : groupUserMapping.IsActive;
                    command.Parameters.Add("@iCreatedBy", SqlDbType.Int).Value = (groupUserMapping == null) ? 0 : Convert.ToInt32(groupUserMapping.CreatedBy);
                    command.Parameters.Add(Constants.PAR_szOpertaionName, SqlDbType.VarChar).Value = groupUserMapping.eventAction;
                    command.Parameters.Add(Constants.PAR_RETURN_VALUE, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters[Constants.PAR_RETURN_VALUE].Value.ToString();
                }


                return resultValue;
            }
            catch (InvalidOperationException Ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(Ex, groupUserMapping.TenantName, groupUserMapping.AppID);
                throw;
            }
            catch (SqlException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, groupUserMapping.TenantName, groupUserMapping.AppID);
                throw;
            }
            catch (ArgumentException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, groupUserMapping.TenantName, groupUserMapping.AppID);
                throw;
            }
            catch (ConfigurationErrorsException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, groupUserMapping.TenantName, groupUserMapping.AppID);
                throw;
            }
            catch (FormatException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, groupUserMapping.TenantName, groupUserMapping.AppID);
                throw;
            }
            catch (OverflowException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, groupUserMapping.TenantName, groupUserMapping.AppID);
                throw;
            }

        }

        /// <summary>
        /// Method to Add User RoleMapping 
        /// </summary>
        /// <param name="objAddUserRoleMapping">UserRoleMapping</param>
        /// <returns>string</returns>
        public string AddUserRoleMapping(UserInfo objAddUserRoleMapping)
        {
        dbConnectionString = ConfigurationManager.ConnectionStrings[objAddUserRoleMapping.TenantName].ConnectionString;
            objloginfo.Message = ("AddUserRoleMapping  - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            string resultValue = "-1";
            try
            {

                DataTable dt = new DataTable();
                //Hashtable hs = new Hashtable();


                //hs.Add("@siProgramId", (objAddUserRoleMapping == null) ? 0 : objAddUserRoleMapping.ProgramID);
                //hs.Add("@iUserGroupId", (objAddUserRoleMapping == null) ? 0 : objAddUserRoleMapping.UserGroupID);
                //hs.Add("@iSystemUserIDs", (objAddUserRoleMapping == null) ? string.Empty : objAddUserRoleMapping.UserList);
                //hs.Add("@szRoleID", (objAddUserRoleMapping == null) ? string.Empty : objAddUserRoleMapping.szRoles);
                //hs.Add("@bIsActive", (objAddUserRoleMapping == null) ? false : objAddUserRoleMapping.IsActive);
                //hs.Add("@iCreatedBy", (objAddUserRoleMapping == null) ? 0 : Convert.ToInt32(objAddUserRoleMapping.CreatedBy));

                //hs.Add(Constants.PAR_szOpertaionName, objAddUserRoleMapping.eventAction);
                //hs.Add(Constants.PAR_RETURN_VALUE, 0);
                //DBHelper db = new DBHelper();
                //object message = db.ExecuteNonQuery("USP_Add_UserRoleMapping", hs);

                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_Add_UserRoleMapping", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@siProgramId", objAddUserRoleMapping.ProgramID);
                    cmd.Parameters.AddWithValue("@iUserGroupId", objAddUserRoleMapping.UserGroupID);
                    cmd.Parameters.AddWithValue("@iSystemUserIDs", objAddUserRoleMapping.UserList);
                    cmd.Parameters.AddWithValue("@szRoleID", objAddUserRoleMapping.szRoles);
                    cmd.Parameters.AddWithValue("@iUserGroupRoleMapId", objAddUserRoleMapping.iUserGroupRoleMapId);
                    cmd.Parameters.AddWithValue("@iCreatedBy", objAddUserRoleMapping.CreatedBy);
                    cmd.Parameters.Add(Constants.PAR_RETURN_VALUE, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    cmd.ExecuteNonQuery();
                    resultValue = cmd.Parameters[Constants.PAR_RETURN_VALUE].Value.ToString();
                }
                return resultValue;


            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objAddUserRoleMapping.TenantName, objAddUserRoleMapping.AppID);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objAddUserRoleMapping.TenantName, objAddUserRoleMapping.AppID);
                throw;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objAddUserRoleMapping.TenantName, objAddUserRoleMapping.AppID);
                throw;
            }

        }

        /// <summary>
        /// Method to Set Role Permission Mapping
        /// </summary>
        /// <param name="objBase">BaseTransportEntity</param>
        /// <returns>string</returns>
        public string SetRolePermissionMapping(UserInfo rolePermissionMapping)
        {
            dbConnectionString = ConfigurationManager.ConnectionStrings[rolePermissionMapping.TenantName].ConnectionString;
            objloginfo.Message = ("SetRolePermissionMapping  - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            string resultValue = "-1";
            try
            {


                //Hashtable hs = new Hashtable();




                //hs.Add("@iSubProcessId", (rolePermissionMapping == null) ? 0 : rolePermissionMapping.SubProcessID);
                //hs.Add("@iRoleId", (rolePermissionMapping == null) ? 0 : rolePermissionMapping.RoleID);
                //hs.Add("@szPermissions", (rolePermissionMapping == null) ? string.Empty : rolePermissionMapping.PermissionIDs);

                //hs.Add("@bIsActive", (rolePermissionMapping == null) ? false : rolePermissionMapping.IsActive);
                //hs.Add("@iCreatedBy", (rolePermissionMapping == null) ? 0 : Convert.ToInt32(rolePermissionMapping.CreatedBy));

                //hs.Add(Constants.PAR_szOpertaionName, rolePermissionMapping.eventAction);
                //hs.Add(Constants.PAR_RETURN_VALUE, 0);
                //DBHelper db = new DBHelper();
                //object message = db.ExecuteNonQuery("USP_SET_ROLEPERMISSIONLIST", hs);



                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_SET_ROLEPERMISSIONLIST", SqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@iSubProcessId", SqlDbType.Int).Value = (rolePermissionMapping == null) ? 0 : rolePermissionMapping.SubProcessID;
                    command.Parameters.Add("@iRoleId", SqlDbType.Int).Value = (rolePermissionMapping == null) ? 0 : rolePermissionMapping.RoleID;
                    command.Parameters.Add("@szPermissions", SqlDbType.VarChar).Value = (rolePermissionMapping == null) ? string.Empty : rolePermissionMapping.PermissionIDs;
                    command.Parameters.Add("@bIsActive", SqlDbType.Bit).Value = (rolePermissionMapping == null) ? false : rolePermissionMapping.IsActive;
                    command.Parameters.Add("@iCreatedBy", SqlDbType.Int).Value = (rolePermissionMapping == null) ? 0 : Convert.ToInt32(rolePermissionMapping.CreatedBy);
                    command.Parameters.Add(Constants.PAR_szOpertaionName, SqlDbType.VarChar).Value = rolePermissionMapping.eventAction;
                    command.Parameters.Add(Constants.PAR_RETURN_VALUE, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters[Constants.PAR_RETURN_VALUE].Value.ToString();
                }

                return resultValue;
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, rolePermissionMapping.TenantName, rolePermissionMapping.AppID);

                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, rolePermissionMapping.TenantName, rolePermissionMapping.AppID);

                throw;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, rolePermissionMapping.TenantName, rolePermissionMapping.AppID);

                throw;
            }
            catch (FormatException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, rolePermissionMapping.TenantName, rolePermissionMapping.AppID);

                throw;
            }
            catch (OverflowException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, rolePermissionMapping.TenantName, rolePermissionMapping.AppID);

                throw;
            }

        }

        /// <summary>
        /// Method to Get Group Name by groupuserid
        /// </summary>
        /// <param name="objGroupEntity">GetGroupNameDetails</param>
        /// <returns>DataTable</returns>
        public DataTable GetGroupNameDetails(UserInfo objGroupEntity)
        {
            dbConnectionString = ConfigurationManager.ConnectionStrings[objGroupEntity.TenantName].ConnectionString;
            objloginfo.Message = ("GetGroupNameDetails  - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            try
            {
                //Hashtable hs = new Hashtable();
                DataTable dt = new DataTable();


                //hs.Add("@iUserGroupId", objGroupEntity.UserGroupID);
                //DBHelper db = new DBHelper();
                //dt = db.SelectDataTable("USP_GET_USERGROUPMASTER", hs);
                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_GET_USERGROUPMASTER", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@iUserGroupId", objGroupEntity.UserGroupID);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }


                return dt;
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objGroupEntity.TenantName, objGroupEntity.AppID);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objGroupEntity.TenantName, objGroupEntity.AppID);
                throw;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objGroupEntity.TenantName, objGroupEntity.AppID);
                throw;
            }

        }

        /// <summary>
        /// Method to Get User details by system user ID
        /// </summary>
        /// <param name="objGroupEntity">UserRoleMapping</param>
        /// <returns>DataTable</returns>
        public DataTable GetUserDetails(UserInfo objUserEntity)
        {
            dbConnectionString = ConfigurationManager.ConnectionStrings[objUserEntity.TenantName].ConnectionString;
            objloginfo.Message = ("GetUserDetails  - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            try
            {
                DataTable dt = new DataTable();
                //Hashtable hs = new Hashtable();

                //hs.Add("@SystemUserId", objUserEntity.SystemUserId);
                //DBHelper db = new DBHelper();
                //dt = db.SelectDataTable("USP_GET_USERMASTERByID", hs);
                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_GET_USERMASTERByID", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SystemUserId", objUserEntity.SystemUserId);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
                return dt;
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }

        }

        /// <summary>
        /// Method to Get Group Name
        /// </summary>
        /// <param name="objGroupEntity">UserRoleMapping</param>
        /// <returns>DataTable</returns>
        public DataTable GetGroupName(UserInfo objGroupEntity)
        {
            //  proxyLogger.Log.Info("GetGroupName - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[objGroupEntity.TenantName].ConnectionString;
            DataTable dt = new DataTable();
            try
            {

                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_GET_USERGROUPMASTERFORDDL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@LoggedInUserSystemID", objGroupEntity.UserID);
                    cmd.Parameters.AddWithValue("@siProgramId", objGroupEntity.ProgramID);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

            }
            catch (InvalidOperationException Ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(Ex, objGroupEntity.TenantName, objGroupEntity.AppID);
                throw;
            }
            catch (SqlException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objGroupEntity.TenantName, objGroupEntity.AppID);
                throw;
            }
            catch (ArgumentException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objGroupEntity.TenantName, objGroupEntity.AppID);
                throw;
            }
            catch (FormatException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objGroupEntity.TenantName, objGroupEntity.AppID);
                throw;
            }
            catch (OverflowException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objGroupEntity.TenantName, objGroupEntity.AppID);
                throw;
            }
            return dt;
        }
        /// <summary>
        /// Method to Get UserName Based on Group Selection
        /// </summary>
        /// <param name="objGroupEntity">UserRoleMapping</param>
        /// <returns>DataTable</returns>
        public DataTable GetUsersNameBasedOnGroupSelection(UserInfo objGroupEntity)
        {
            // proxyLogger.Log.Info("GetUsersNameBasedOnGroupSelection - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[objGroupEntity.TenantName].ConnectionString;
            DataTable dt = new DataTable();
            try
            {

                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = null;
                    if (objGroupEntity.IsUserSearch == false)
                    {
                        cmd = new SqlCommand("USP_GET_USERNAMESBASEDONGROUPSELECTION", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@iUserGroupId", objGroupEntity.UserGroupID);
                    }
                    else
                    {
                        cmd = new SqlCommand("USP_GET_USERSBYSEARCH", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@iUserGroupId", objGroupEntity.UserGroupID);
                        cmd.Parameters.AddWithValue("@siUserSearchText", objGroupEntity.UsersSearchText);
                        cmd.Parameters.Add(Constants.PAR_iReturnValue, SqlDbType.Int).Direction = ParameterDirection.Output;
                    }
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

            }
            catch (InvalidOperationException Ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(Ex, objGroupEntity.TenantName, objGroupEntity.AppID);
                throw;
            }
            catch (SqlException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objGroupEntity.TenantName, objGroupEntity.AppID);
                throw;
            }
            catch (ArgumentException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objGroupEntity.TenantName, objGroupEntity.AppID);
                throw;
            }
            catch (FormatException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objGroupEntity.TenantName, objGroupEntity.AppID);
                throw;
            }
            catch (OverflowException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objGroupEntity.TenantName, objGroupEntity.AppID);
                throw;
            }

            return dt;
        }

        /// <summary>To load the Roles</summary> 
        /// <returns>Datatable</returns>
        public DataTable GetRoles(UserInfo objUserEntity)
        {
            // proxyLogger.Log.Info("GetRoles - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[objUserEntity.TenantName].ConnectionString;
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_GET_ROLES", con);
                    cmd.Parameters.AddWithValue("@siProgramId", objUserEntity.ProgramID);
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
                return dt;
            }
            catch (InvalidOperationException Ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(Ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (SqlException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (ArgumentException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (FormatException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (OverflowException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }

        }

        /// <summary>To load all the Roles</summary> 
        /// <returns>Datatable</returns>
        public DataTable GetAllRoles(UserInfo objUserEntity)
        {
            //  proxyLogger.Log.Info("GetAllRoles - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[objUserEntity.TenantName].ConnectionString;
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_GET_ALL_ROLES", con);
                    cmd.Parameters.AddWithValue("@siProgramId", objUserEntity.ProgramID);
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
                return dt;
            }
            catch (InvalidOperationException Ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(Ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (SqlException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (ArgumentException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (FormatException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (OverflowException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }

        }

        /// <summary>To load the Role Permission Details</summary> 
        /// <returns>Datatable</returns>
        public DataTable GetRolePermissions(UserInfo objUserEntity)
        {
            // proxyLogger.Log.Info("GetRolePermissions - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[objUserEntity.TenantName].ConnectionString;
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_GET_USERSPERMISSION", con);
                    cmd.Parameters.AddWithValue("@szRoleIds", objUserEntity.RoleId.ToString());
                    cmd.Parameters.AddWithValue("@siProgramId", objUserEntity.ProgramID);
                    cmd.Parameters.AddWithValue("@iSubProcessID", objUserEntity.SubProcessID);
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
                return dt;
            }
            catch (InvalidOperationException Ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(Ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (SqlException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (ArgumentException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (FormatException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (OverflowException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }

        }

        /// <summary>To load Permissions based on Selected Role ID</summary> 
        /// <returns>Datatable</returns>
        public DataTable GetSelectedPermissionsByRoleID(UserInfo objUserEntity)
        {
            // proxyLogger.Log.Info("GetSelectedPermissionsByRoleID - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[objUserEntity.TenantName].ConnectionString;
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_GET_SELECTEDPERMISSIONS", con);
                    cmd.Parameters.AddWithValue("@iSubProcessId", objUserEntity.SubProcessID.ToString());
                    cmd.Parameters.AddWithValue("@iRoleId", objUserEntity.RoleId.ToString());
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
                return dt;
            }
            catch (InvalidOperationException Ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(Ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (SqlException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (ArgumentException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (FormatException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }
            catch (OverflowException ex)
            {

                objlog.GetLoggingHandler("Log4net").LogException(ex, objUserEntity.TenantName, objUserEntity.AppID);
                throw;
            }

        }

        /// <summary>To load the Role Permission Mapping List</summary> 
        /// <returns>Datatable</returns>
        public DataTable GetRolePermissionMappingList(UserInfo objRolePermissionList)
        {
            dbConnectionString = ConfigurationManager.ConnectionStrings[objRolePermissionList.TenantName].ConnectionString;
            // proxyLogger.Log.Info("GetRolePermissionMappingList - Called.");
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_GET_ROLEPERMISSIONLIST", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@StartRowIndex", SqlDbType.Int).Value = objRolePermissionList.StartRowIndex;
                    cmd.Parameters.Add("@MaximumRows", SqlDbType.Int).Value = objRolePermissionList.MaximumRows;
                    cmd.Parameters.Add("@SortOrder", SqlDbType.VarChar).Value = objRolePermissionList.SortOrder;
                    cmd.Parameters.Add("@SortColumn", SqlDbType.VarChar).Value = objRolePermissionList.SortColumn;
                    cmd.Parameters.Add("@iSubProcessId", SqlDbType.Int).Value = objRolePermissionList.SubProcessID;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
                return dt;
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objRolePermissionList.TenantName, objRolePermissionList.AppID);
                throw;
            }
            catch (SqlException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objRolePermissionList.TenantName, objRolePermissionList.AppID);
                throw;
            }
            catch (ArgumentException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objRolePermissionList.TenantName, objRolePermissionList.AppID);
                throw;
            }

        }

        /// <summary>To load the User Group Record Details </summary> 
        /// <returns>Datatable</returns>
        public DataTable GetGroupUserRecordList(UserInfo groupUser)
        {
            //  proxyLogger.Log.Info("GetGroupUserRecordList - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[groupUser.TenantName].ConnectionString;
            DataTable dt = new DataTable();
            try
            {
                //GroupUser groupUser = new GroupUser();
                //groupUser = (GroupUser)objBase;

                DataSet _ds = new DataSet();
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_PROGRAM_USERGROUP_MAPPINGLIST", SqlConnection);
                    command.Parameters.Add("@siProgramId", SqlDbType.Int).Value = (groupUser == null) ? 0 : groupUser.ProgramID;
                    command.Parameters.Add("@StartRowIndex", SqlDbType.Int).Value = groupUser.StartRowIndex;
                    command.Parameters.Add("@MaximumRows", SqlDbType.Int).Value = groupUser.MaximumRows;
                    command.Parameters.Add("@SortOrder", SqlDbType.VarChar).Value = groupUser.SortOrder;
                    command.Parameters.Add("@SortColumn", SqlDbType.VarChar).Value = groupUser.SortColumn;
                    command.Parameters.Add(Constants.PAR_iReturnValue, SqlDbType.Int).Direction = ParameterDirection.Output;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
                return (_ds.Tables[0]);
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, groupUser.TenantName, groupUser.AppID);
                throw;
            }
            catch (SqlException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, groupUser.TenantName, groupUser.AppID);
                throw;
            }
            catch (ArgumentException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, groupUser.TenantName, groupUser.AppID);
                throw;
            }

        }

        /// <summary>
        /// Method to Get Selected User For User Grouping
        /// </summary>
        /// <param name="objBase">BaseTransportEntity</param>
        /// <returns>DataTable</returns>
        public DataTable GetSelectedUserForUserGroupMapping(UserInfo objGroupUserMapping)
        {
            //  proxyLogger.Log.Info("GetSelectedUserForUserGroupMapping - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[objGroupUserMapping.TenantName].ConnectionString;
            try
            {
                //GroupUserMapping objGroupUserMapping = new GroupUserMapping();
                //objGroupUserMapping = (GroupUserMapping)objBase;

                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = null;
                    if (objGroupUserMapping.IsUserSearch == false)
                    {
                        cmd = new SqlCommand("USP_GET_SELECTEDUSERS_USERGROUP_MAPPING", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@siProgramId", objGroupUserMapping.ProgramID);
                        cmd.Parameters.AddWithValue("@iUserGroupId", objGroupUserMapping.UserGroupID);
                    }
                    else
                    {
                        if (objGroupUserMapping.ProgramID != 0)
                        {
                            cmd = new SqlCommand("USP_GET_SELECTEDUSERS_USERGROUP_SEARCH", con);
                        }
                        else
                        {
                            cmd = new SqlCommand("USP_GET_SELECTEDUSERS_MAPPEDUNMAPPEDUSERGROUP_SEARCH", con);

                        }
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@siProgramId", objGroupUserMapping.ProgramID);
                        cmd.Parameters.AddWithValue("@iUserGroupId", objGroupUserMapping.UserGroupID);
                        cmd.Parameters.AddWithValue("@siUserSearchText", objGroupUserMapping.UsersSearchText);
                    }

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
                return dt;
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objGroupUserMapping.TenantName, objGroupUserMapping.AppID);
                throw;
            }
            catch (SqlException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objGroupUserMapping.TenantName, objGroupUserMapping.AppID);
                throw;
            }
            catch (ArgumentException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objGroupUserMapping.TenantName, objGroupUserMapping.AppID);
                throw;
            }

        }

        /// <summary>To load the User UserGroup Mapping List</summary> 
        /// <returns>Datatable</returns>
        public DataTable GetUserGroupUserMappingList(UserInfo groupUserMapping)
        {
            // proxyLogger.Log.Info("GetUserGroupUserMappingList - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[groupUserMapping.TenantName].ConnectionString;
            DataTable dt = new DataTable();
            try
            {
                //GroupUserMapping groupUserMapping = new GroupUserMapping();
                //groupUserMapping = (GroupUserMapping)objBase;

                DataSet _ds = new DataSet();
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_USER_USERGROUP_MAPPINGLIST", SqlConnection);
                    command.Parameters.Add("@siProgramId", SqlDbType.Int).Value = (groupUserMapping == null) ? 0 : groupUserMapping.ProgramID;
                    command.Parameters.Add("@siUserGroupId", SqlDbType.Int).Value = (groupUserMapping == null) ? 0 : groupUserMapping.UserGroupID;
                    command.Parameters.Add("@StartRowIndex", SqlDbType.Int).Value = groupUserMapping.StartRowIndex;
                    command.Parameters.Add("@MaximumRows", SqlDbType.Int).Value = groupUserMapping.MaximumRows;
                    command.Parameters.Add("@SortOrder", SqlDbType.VarChar).Value = groupUserMapping.SortOrder;
                    command.Parameters.Add("@SortColumn", SqlDbType.VarChar).Value = groupUserMapping.SortColumn;
                    command.Parameters.Add("@siUserSearchText", SqlDbType.VarChar).Value = (groupUserMapping.UsersSearchText != "") ? groupUserMapping.UsersSearchText : null;
                    command.Parameters.Add(Constants.PAR_iReturnValue, SqlDbType.Int).Direction = ParameterDirection.Output;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
                return (_ds.Tables[0]);
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, groupUserMapping.TenantName, groupUserMapping.AppID);
                throw;
            }
            catch (SqlException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, groupUserMapping.TenantName, groupUserMapping.AppID);
                throw;
            }
            catch (ArgumentException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, groupUserMapping.TenantName, groupUserMapping.AppID);
                throw;
            }

        }

        /// <summary>To load the User Management Details List 
        /// <para>Exceptions:</para>
        ///<list type="Generic">
        ///<para>InvalidOperationException</para>
        /// <para>SqlException</para>
        /// </list>      
        /// </summary> 
        /// <param name="objBase"></param> 
        /// <returns>Datatable</returns>
        public DataTable GetUserMagmtRecordList(UserInfo user)
        {
            //  proxyLogger.Log.Info("GetUserMagmtRecordList - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[user.TenantName].ConnectionString;
            try
            {
                //AddUser user = new AddUser();
                //user = (AddUser)objBase;
                DataTable resultdt = new DataTable();
                XElement Parent = new XElement("root");
                XElement root = new XElement("xmlArguments");
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_USERMASTER", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    root.Add(new XAttribute("StartRowIndex", Convert.ToString(user.StartRowIndex)));
                    root.Add(new XAttribute("MaximumRows", Convert.ToString(user.MaximumRows)));
                    root.Add(new XAttribute("SortOrder", Convert.ToString(user.SortOrder)));
                    root.Add(new XAttribute("SortColumn", Convert.ToString(user.SortColumn)));
                    if (!string.IsNullOrEmpty(Convert.ToString(user.CtsUserId)))
                        root.Add(new XAttribute("CTSUserId", (user.CtsUserId != "") ? user.CtsUserId : null));
                    if (!string.IsNullOrEmpty(Convert.ToString(user.ClientUserId)))
                        root.Add(new XAttribute("ClientUserId", Convert.ToString(user.ClientUserId)));
                    if (!string.IsNullOrEmpty(Convert.ToString(user.FirstName)))
                        root.Add(new XAttribute("UserName", Convert.ToString(user.FirstName)));
                    if (!string.IsNullOrEmpty(Convert.ToString(user.EmailID)))
                        root.Add(new XAttribute("Email", Convert.ToString(user.EmailID)));
                    if (!string.IsNullOrEmpty(Convert.ToString(user.eventAction)))
                        root.Add(new XAttribute("szOperationName", Convert.ToString(user.eventAction)));

                    command.Parameters.Add(Constants.PAR_dsEffectiveFrom, SqlDbType.VarChar).Value = (user == null) ? null : user.EffectiveFrom.ToShortDateString();
                    command.Parameters.Add(Constants.PAR_dsEffectiveTo, SqlDbType.VarChar).Value = (user == null) ? null : user.EffectiveTo.ToShortDateString();
                    Parent.Add(root);
                    command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(resultdt);
                }
                return resultdt;
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }
            catch (SqlException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }
            catch (ArgumentException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }
            catch (FormatException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }
            catch (OverflowException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }

        }

        /// <summary>
        /// Method to Get Program List
        /// </summary>
        /// <param name="programEntity">ProgramEntity</param>
        /// <returns>DataTable</returns>
        public DataTable GetProgamList(UserInfo user)
        {
            // proxyLogger.Log.Info("GetProgamList - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[user.TenantName].ConnectionString;
            DataTable dt = new DataTable();
            try
            {
                DataSet _ds = new DataSet();
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_PROGRAMS_MAPPED_TO_ADMIN", SqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@iAdminUserID", SqlDbType.Int).Value = user.UserID;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
                return (_ds.Tables[0]);
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }
            catch (SqlException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }
            catch (ArgumentException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }

        }

        /// <summary>
        /// 
        ///Method to Get User List
        /// </summary>
        /// <param name="userEntity">AddUser</param>
        /// <returns>DataTable</returns>
        public DataTable GetUserList(UserInfo userEntity)
        {
            //  proxyLogger.Log.Info("GetUserList - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[userEntity.TenantName].ConnectionString;
            DataTable dt = new DataTable();
            try
            {
                DataSet _ds = new DataSet();
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_USERS_Config", SqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@siProgramId", SqlDbType.SmallInt).Value = userEntity.ProgramID;
                    command.Parameters.Add(Constants.PAR_iReturnValue, SqlDbType.Int).Direction = ParameterDirection.Output;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
                return (_ds.Tables[0]);
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, userEntity.TenantName, userEntity.AppID);
                throw;
            }
            catch (SqlException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, userEntity.TenantName, userEntity.AppID);
                throw;
            }
            catch (ArgumentException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, userEntity.TenantName, userEntity.AppID);
                throw;
            }

        }

        /// <summary>To load the User Role Mapping Details</summary> 
        /// <returns>Datatable</returns>
        public DataTable GetUserRoleMappings(UserInfo objUserRoleMappingEntity)
        {
            //  proxyLogger.Log.Info("GetUserRoleMappings - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[objUserRoleMappingEntity.TenantName].ConnectionString;
            try
            {
                DataTable dt = new DataTable();
                XElement Parent = new XElement("root");
                XElement root = new XElement("xmlArguments");
                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_GET_USERROLEMAPPINGS", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (!string.IsNullOrEmpty(Convert.ToString(objUserRoleMappingEntity.StartRowIndex)))
                        root.Add(new XAttribute("StartRowIndex", Convert.ToString(objUserRoleMappingEntity.StartRowIndex)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objUserRoleMappingEntity.MaximumRows)))
                        root.Add(new XAttribute("MaximumRows", Convert.ToString(objUserRoleMappingEntity.MaximumRows)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objUserRoleMappingEntity.SortOrder)))
                        root.Add(new XAttribute("SortOrder", Convert.ToString(objUserRoleMappingEntity.SortOrder)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objUserRoleMappingEntity.SortColumn)))
                        root.Add(new XAttribute("SortColumn", Convert.ToString(objUserRoleMappingEntity.SortColumn)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objUserRoleMappingEntity.UserID)))
                        root.Add(new XAttribute("LoggedInUserId", Convert.ToString(objUserRoleMappingEntity.UserID)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objUserRoleMappingEntity.UserGroupID)))
                        root.Add(new XAttribute("GroupID", Convert.ToString(objUserRoleMappingEntity.UserGroupID)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objUserRoleMappingEntity.ProgramID)))
                        root.Add(new XAttribute("siProgramId", Convert.ToString(objUserRoleMappingEntity.ProgramID)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objUserRoleMappingEntity.SelectedUserID)))
                        root.Add(new XAttribute("iSelectedUserID", Convert.ToString(objUserRoleMappingEntity.SelectedUserID)));
                    if (!string.IsNullOrEmpty(Convert.ToString(objUserRoleMappingEntity.UsersSearchText)))
                        root.Add(new XAttribute("siUserSearchText", (objUserRoleMappingEntity.UsersSearchText != "") ? objUserRoleMappingEntity.UsersSearchText : null));
                    Parent.Add(root);

                    cmd.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);
                    cmd.Parameters.Add(Constants.PAR_iReturnValue, SqlDbType.Int).Direction = ParameterDirection.Output;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
                return dt;
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objUserRoleMappingEntity.TenantName, objUserRoleMappingEntity.AppID);
                throw;
            }
            catch (SqlException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objUserRoleMappingEntity.TenantName, objUserRoleMappingEntity.AppID);
                throw;
            }
            catch (ArgumentException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objUserRoleMappingEntity.TenantName, objUserRoleMappingEntity.AppID);
                throw;
            }

        }

        /// <summary>
        /// Method to Get ProcessList
        /// </summary>
        /// <param name="processEntity">ProcessEntity</param>
        /// <returns>DataTable</returns>
        public DataTable GetProcessList(UserInfo user)
        {
            // proxyLogger.Log.Info("GetProcessList - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[user.TenantName].ConnectionString;
            DataTable dt = new DataTable();
            try
            {
                DataSet _ds = new DataSet();
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_PROCESSMASTER", SqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@siProgramId", SqlDbType.SmallInt).Value = user.ProgramID;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
                return (_ds.Tables[0]);
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }
            catch (SqlException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }
            catch (ArgumentException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }

        }

        /// <summary>
        /// Method to Get Sub Process List
        /// </summary>
        /// <param name="subprocessEntity">SubProcessEntity</param>
        /// <returns>DataTable</returns>
        public DataTable GetSubProcessList(UserInfo user)
        {
            //  proxyLogger.Log.Info("GetProcessList - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[user.TenantName].ConnectionString;
            DataTable dt = new DataTable();
            try
            {
                DataSet _ds = new DataSet();
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_SUBPROCESSMASTER", SqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@iProcessId", SqlDbType.Int).Value = user.ProcessId;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
                return (_ds.Tables[0]);
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }
            catch (SqlException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }
            catch (ArgumentException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }

        }

        /// <summary>
        /// Method to Delete User Role Mapping
        /// </summary>
        /// <param name="objAddUserRoleMapping">UserRoleMapping</param>
        /// <returns>string</returns>
        public string DeleteUserRoleMapping(UserInfo objAddUserRoleMapping)
        {
            //  proxyLogger.Log.Info("DeleteUserRoleMapping - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[objAddUserRoleMapping.TenantName].ConnectionString;
            try
            {
                string resultValue = "-1";
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(dbConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("USP_DELETE_USERROLEMAPPING", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@iUserGroupRoleMapId", objAddUserRoleMapping.iUserGroupRoleMapId);
                    cmd.Parameters.AddWithValue("@iModifiedBy", objAddUserRoleMapping.ModifiedBy);
                    cmd.Parameters.Add(Constants.PAR_RETURN_VALUE, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;

                    cmd.ExecuteNonQuery();
                    resultValue = cmd.Parameters[Constants.PAR_RETURN_VALUE].Value.ToString();
                }
                return resultValue;
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objAddUserRoleMapping.TenantName, objAddUserRoleMapping.AppID);
                throw;
            }
            catch (SqlException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objAddUserRoleMapping.TenantName, objAddUserRoleMapping.AppID);
                throw;
            }
            catch (ArgumentException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, objAddUserRoleMapping.TenantName, objAddUserRoleMapping.AppID);
                throw;
            }

        }

        /// <summary>
        /// Method to Get User List 1
        /// </summary>  No Reference Found will be deleted once got confirmation from the owner
        /// <param name="userEntity">AddUser</param>
        /// <returns>DataTable</returns>
        public DataTable GetUserList1(UserInfo user)
        {
            //  proxyLogger.Log.Info("GetUserList - Called.");
            dbConnectionString = ConfigurationManager.ConnectionStrings[user.TenantName].ConnectionString;
            DataTable dt = new DataTable();
            try
            {
                DataSet _ds = new DataSet();
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_USERS", SqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
                return (_ds.Tables[0]);
            }
            catch (InvalidOperationException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }
            catch (SqlException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }
            catch (ArgumentException Ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(Ex, user.TenantName, user.AppID);
                throw;
            }

        }
    }
}
