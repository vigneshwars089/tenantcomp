﻿using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.DataAccessLayer
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :EMTUserRepository.cs
    // Namespace : DigiOps.TechFoundation.DataTransfer
    // Class Name(s) :EMTUserRepository
    // Author : Sadhesh
    // Creation Date : 6/14/2017
    // Purpose : insert the user
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //14-Jun-2017    Sadhesh     Create            Create user 
    //14-Jun-2017    Sadhesh     Read              Read user
    //14-Jun-2017    Sadhesh     Update            update user
    //14-Jun-2017    Sadhesh     Delete            delete user

    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public class EMTUserRepository : UserRepository
    {
        LoggingFactory objloggingfactory = new LoggingFactory();

        public override UserMgmtInfo Create(UserInfo objUserInfo)
        {
            UserMgmtInfo objinfo = new UserMgmtInfo();
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@USERID", objUserInfo.UserID);
                hs.Add("@FIRSTNAME", objUserInfo.FirstName);
                hs.Add("@LASTNAME", objUserInfo.LastName);
                hs.Add("@EMAIL", objUserInfo.EmailID);
                hs.Add("@Password", objUserInfo.EncryptPassword);
                hs.Add("@ISACTIVE", objUserInfo.IsActive);
                hs.Add("@LoggedinUserId", objUserInfo.RoleId);
                hs.Add("@TIMEZONE", objUserInfo.TimeZone);
                hs.Add("@OFFSET", objUserInfo.UTCTime);
            }
            catch (Exception ex)
            {
                objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
                // logger.HandleError(ex, UserData.UserId, " | UserManagementDataService.cs | AddUser()");
            }
            //return Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_UserDBScripts.CREATE_USERS, hs));
            objinfo.Message = Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_UserDBScripts.CREATE_USERS, hs)).ToString();
            return objinfo;

        }

        public override UserMgmtInfo Read(UserInfo objUserInfo)
        {
            UserMgmtInfo objinfo = new UserMgmtInfo();
            return objinfo;
        }

        public override UserMgmtInfo Update(UserInfo objUserInfo)
        {
            UserMgmtInfo objinfo = new UserMgmtInfo();
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@USERID", objUserInfo.UserID);
                hs.Add("@FIRSTNAME", objUserInfo.FirstName);
                hs.Add("@LASTNAME", objUserInfo.LastName);
                hs.Add("@EMAIL", objUserInfo.EmailID);
                hs.Add("@Password", objUserInfo.EncryptPassword);
                hs.Add("@ISACTIVE", objUserInfo.IsActive);
                hs.Add("@LoggedinUserId", objUserInfo.RoleId);
                hs.Add("@TIMEZONE", objUserInfo.TimeZone);
                hs.Add("@OFFSET", objUserInfo.UTCTime);
            }
            catch (Exception ex)
            {
                objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
                //errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UpdateUser()");
            }
            // return Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_UserDBScripts.UPDATE_USERS, hs));
            objinfo.Message = Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_UserDBScripts.UPDATE_USERS, hs)).ToString();
            return objinfo;
        }

        public override UserMgmtInfo Delete(UserInfo objUserInfo)
        {
            UserMgmtInfo objResinfo = new UserMgmtInfo();
            return objResinfo;
        }

        public override int AssignRole(UserRoleInfo objRoleInfo)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserID", objRoleInfo.User.UserID);
                hs.Add("@RoleId", objRoleInfo.UserRoles);
                hs.Add("@LoggedinUserId", objRoleInfo.User.UserID);
                hs.Add("@CountryIdsToMap", objRoleInfo.User.CountryId);
            }
            catch (Exception ex)
            {
                objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
                // errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | MapUserRole()");

            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_RoleDBScripts.CreateRoleMap, hs));
        }

        public override int UpdateUserRole(UserRoleInfo objRoleInfo)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserRoleMappingId", objRoleInfo.UserRoleMapId);
                //hs.Add("@UserID", UserId);
                //hs.Add("@RoleId", RoleId);
                hs.Add("@CountryIdsToMap", objRoleInfo.User.CountryId);
            }
            catch (Exception ex)
            {
                objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
                //errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | UpdateRoleMap()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_RoleDBScripts.UpdateRoleMap, hs));
        }

        public override int DeleteUserRole(UserRoleInfo objRoleInfo)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserRoleMappingId", objRoleInfo.UserRoleMapId);
            }
            catch (Exception ex)
            {
                objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
                // errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | DeleteRoleMap()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_RoleDBScripts.DeleteRoleMap, hs));
        }

        public override bool ValidateCredentials(UserInfo objUserInfo)
        {
            return false;
        }

        public override int LockAccount(string UserId, bool IsAccountLocked, string Token, DateTime TokenExpirationTime)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserId", UserId);
                hs.Add("@IsLocked", IsAccountLocked);
                hs.Add("@Token", Token);
                hs.Add("@TokenExpirationTime", TokenExpirationTime);
                //hs.Add("", PasswordEnteredTime);
            }
            catch (Exception ex)
            {
                objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
                //errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | AccountLock()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_AccountUnLockScripts.TokenLock, hs));
        }
        public override int ValidateAccountLock(string UserId, bool IsAccountLocked, string Token)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserId", UserId);
                hs.Add("@IsLocked", IsAccountLocked);
                hs.Add("@Token", Token);
            }
            catch (Exception ex)
            {
                objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
                // errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | ValidateAccountLock()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_AccountUnLockScripts.TokenValidation, hs));
        }
        public override int IsAccountLocked(string UserId)
        {
            Hashtable hs = new Hashtable();
            try
            {
                hs.Add("@UserId", UserId);
            }
            catch (Exception ex)
            {
                objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
                //errorlog.HandleError(ex, UserData.UserId, " | UserManagementDataService | IsAccountLocked()");
            }
            return Convert.ToInt32(new DBHelper().SelectSingleValue(EMTConstant.S_AccountUnLockScripts.IsAccountLocked, hs));
        }
    }
}
