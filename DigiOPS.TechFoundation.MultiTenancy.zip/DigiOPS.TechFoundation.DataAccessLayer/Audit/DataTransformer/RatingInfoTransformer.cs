﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    internal class RatingInfoTransformer
    {


        internal List<RatingEntity> MapToRatingList(DataTable dt)
        {

            List<RatingEntity> baseEntityList = new List<RatingEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new RatingEntity
                              {
                                  RatingId = Convert.ToInt16(p["iRatingId"] == DBNull.Value ? 0 : p["iRatingId"]),
                                  RatingDesc = Convert.ToString(p["szRatingDesc"] == DBNull.Value ? string.Empty : p["szRatingDesc"]),
                                  RatingDisplayName = Convert.ToString(p["szDisplayName"] == DBNull.Value ? string.Empty : p["szDisplayName"]),
                                  //CanRatingEnable = Convert.ToInt32(p["CanRatingEnable"] == DBNull.Value ? 0 : p["CanRatingEnable"]),
                                  //selectedProgramName = Convert.ToString(p["szProgramName"] == DBNull.Value ? string.Empty : p["szProgramName"]),
                                  //selectedProcessName = Convert.ToString(p["szProcessName"] == DBNull.Value ? string.Empty : p["szProcessName"]),
                                  //selectedSubProcessName = Convert.ToString(p["szSubProcessName"] == DBNull.Value ? string.Empty : p["szSubProcessName"]),
                                  //selectedProgramId = Convert.ToInt32(p["siProgramId"] == DBNull.Value ? 0 : p["siProgramId"]),
                                  //selectedProcessId = Convert.ToInt32(p["iProcessId"] == DBNull.Value ? 0 : p["iProcessId"]),
                                  //selectedSubProcessId = Convert.ToInt32(p["iSubProcessId"] == DBNull.Value ? 0 : p["iSubProcessId"]),
                                  blnNotApplicable = Convert.ToBoolean(p["bIsNotApplicable"]),
                                  //CreatedBy = Convert.ToString(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]),
                                  //CreatedDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]),
                                  //ModifiedBy = Convert.ToString(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]),
                                  //dsModifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"]),
                                  //TotalRows = Convert.ToInt32(p["TotalRows"] == DBNull.Value ? 0 : p["TotalRows"]),
                                  //ValidNA = Convert.ToInt32(p["ValidNA"] == DBNull.Value ? 0 : p["ValidNA"])

                              }).ToList();


            return baseEntityList;
        }
        internal List<RatingGroupEntity> MapToRatingGroupList(DataTable dt)
        {
            List<RatingGroupEntity> baseEntityList = new List<RatingGroupEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new RatingGroupEntity
                              {
                                  RatingId = Convert.ToInt16(p["iRatingGroupId"] == DBNull.Value ? 0 : p["iRatingGroupId"]),
                                  RatingDisplayName = Convert.ToString(p["GroupName"] == DBNull.Value ? string.Empty : p["GroupName"]),
                                  selectedProgramName = Convert.ToString(p["szProgramName"] == DBNull.Value ? string.Empty : p["szProgramName"]),
                                  selectedProcessName = Convert.ToString(p["szProcessName"] == DBNull.Value ? string.Empty : p["szProcessName"]),
                                  selectedSubProcessName = Convert.ToString(p["szSubProcessName"] == DBNull.Value ? string.Empty : p["szSubProcessName"]),
                                  selectedProgramId = Convert.ToInt32(p["siProgramId"] == DBNull.Value ? 0 : p["siProgramId"]),
                                  selectedProcessId = Convert.ToInt32(p["iProcessId"] == DBNull.Value ? 0 : p["iProcessId"]),
                                  selectedSubProcessId = Convert.ToInt32(p["iSubProcessId"] == DBNull.Value ? 0 : p["iSubProcessId"]),
                                  CreatedBy = Convert.ToString(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]),
                                  CreatedDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]),
                                  strRatingGrpIds = Convert.ToString(p["RatingIds"] == DBNull.Value ? string.Empty : p["RatingIds"]),
                                  strRatingGrpIdValues = Convert.ToString(p["RatingValues"] == DBNull.Value ? string.Empty : p["RatingValues"]),
                                  action = Convert.ToString(p["RatingNALists"] == DBNull.Value ? string.Empty : p["RatingNALists"]),
                                  ModifiedBy = Convert.ToString(p["iModifiedBy"] == DBNull.Value ? string.Empty : p["iModifiedBy"]),
                                  dsModifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"]),
                                  TotalRows = Convert.ToInt32(p["TotalRows"] == DBNull.Value ? 0 : p["TotalRows"]),
                                  ValidNA = Convert.ToInt32(p["ValidNA"] == DBNull.Value ? 0 : p["ValidNA"])
                              }).ToList();




            return baseEntityList;
        }

        internal List<RatingEntity> MapToRatingListForGroup(DataTable dt)
        {
            List<RatingEntity> baseEntityList = new List<RatingEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new RatingEntity
                              {
                                  RatingId = Convert.ToInt16(p["iRatingId"] == DBNull.Value ? 0 : p["iRatingId"]),
                                  RatingDesc = Convert.ToString(p["szDisplayName"] == DBNull.Value ? string.Empty : p["szDisplayName"]),
                                  blnNotApplicable = Convert.ToBoolean(p["bIsNotApplicable"])

                              }).ToList();



            return baseEntityList;
        }
        internal List<RatingGroupEntity> MapToDropDownList(DataTable dt)
        {
            List<RatingGroupEntity> EntityList = new List<RatingGroupEntity>();
            if (dt.Columns.Count > 2)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddrat
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1]),
                                  ForeignKey = Convert.ToString(p[2] == DBNull.Value ? string.Empty : p[2])
                              }).Cast<RatingGroupEntity>().ToList();
            }
            else if (dt.Columns.Count == 1)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddrat
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0])
                              }).Cast<RatingGroupEntity>().ToList();
            }
            else
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddrat
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1])
                              }).Cast<RatingGroupEntity>().ToList();

            }

            return EntityList;
        }
    }
}
