﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Data;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    internal class CombinedAccuracyTransformer
    {
        internal List<CombinedAccuracyEntity> MapToDropDownList(DataTable dt)
        {
            List<CombinedAccuracyEntity> EntityList = new List<CombinedAccuracyEntity>();
            if (dt.Columns.Count > 2)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddl
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1]),
                                  ForeignKey = Convert.ToString(p[2] == DBNull.Value ? string.Empty : p[2])
                              }).Cast<CombinedAccuracyEntity>().ToList();
            }
            else if (dt.Columns.Count == 1)
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddl
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0])
                              }).Cast<CombinedAccuracyEntity>().ToList();
            }
            else
            {
                EntityList = (from p in dt.AsEnumerable()
                              select new Transddl
                              {
                                  Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                                  Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1])
                              }).Cast<CombinedAccuracyEntity>().ToList();

            }

            return EntityList;
        }


        internal List<List<CombinedAccuracyEntity>> GetEntityListCollection(CombinedAccuracyEntity caEntity)
        {
            List<List<CombinedAccuracyEntity>> listcoll = new List<List<CombinedAccuracyEntity>>();

            DataSet ds = null;
            //DataTable dt = null;

            // CombinedAccuracyEntity caEntity = null;
            CombinedAuditDAO caDAO = new CombinedAuditDAO();
            // CombinedAccuracyMapper camap = new CombinedAccuracyMapper();
            try
            {
                //caEntity = (CombinedAccuracyEntity)_obj;
                ds = caDAO.GetAuditRatingList(caEntity);
                if (ds.Tables.Count <= 0)
                    return listcoll;
                listcoll.Add(MapToDropDownList(ds.Tables[0]));
                listcoll.Add(MapToRatingTableViewModel(ds.Tables[1]));
                return listcoll;
            }
            catch (InvalidCastException Ex)
            {
                throw;
                //proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
            }
        }


        internal List<CombinedAccuracyEntity> MapToRatingTableViewModel(DataTable dt)
        {
            List<CombinedAccuracyEntity> baseEntityList = new List<CombinedAccuracyEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new RatingTableViewModel
                              {
                                  InternalId = Convert.ToInt32(p["iInternalRatingId"] == DBNull.Value ? string.Empty : p["iInternalRatingId"]),
                                  ExternalId = Convert.ToInt32(p["iExternalRatingId"] == DBNull.Value ? string.Empty : p["iExternalRatingId"]),
                                  CombinedId = Convert.ToInt32(p["iCombinedRatingId"] == DBNull.Value ? string.Empty : p["iCombinedRatingId"]),
                                  ModifiedBy = Convert.ToString(p["ModifiedBy"] == DBNull.Value ? string.Empty : p["ModifiedBy"]),
                                  ModifiedDate = Convert.ToString(p["ModifiedDate"] == DBNull.Value ? string.Empty : p["ModifiedDate"])

                              }).Cast<CombinedAccuracyEntity>().ToList();

            return baseEntityList;
        }
    }
}
