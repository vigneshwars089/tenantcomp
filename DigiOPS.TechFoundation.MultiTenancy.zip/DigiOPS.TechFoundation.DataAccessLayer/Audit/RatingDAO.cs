﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Xml.Linq;
using System.IO;
using System.Collections;
//using System.Configuration;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Collections.Generic;
using System.Linq;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    /// <summary>
    /// RATING DAO Class
    /// </summary>
    public class RatingDAO
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        ConnectionString connectionstring = new ConnectionString();
        //  protected Logger // proxyLogger = new Logger();

        /// <summary>
        /// Rating DAO Constructor 
        /// </summary>
        public RatingDAO()
        {
            dbConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnStr"];

        }
        public RatingDAO(string TenantName, string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }

        public DataTable GetRatingEntityList(RatingEntity objRatingEntity)
        {
            try
            {
                //dbConnectionString = connectionstring.GetConnectionString(objRatingEntity.AppID, objRatingEntity.TenantID);
                DataTable _dt = new DataTable();
                //DataSet _ds = new DataSet();
                string spName = string.Empty;
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_RATINGLIST", SqlConnection);

                    command.Parameters.Add("@SubProcessId", SqlDbType.Int).Value = objRatingEntity.SubProcessId;
                    if (objRatingEntity.RatingId != 0)
                    {
                        command.Parameters.Add("@RatingID", SqlDbType.Int).Value = objRatingEntity.RatingId;
                    }
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_dt);
                }

                return _dt;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// load rating and rating group list
        /// </summary>
        /// <param name="objRatingEntity"></param>
        /// <returns></returns>
        public DataTable GetRatingGroupEntityList(RatingGroupEntity objRatingEntity)
        {
            //dbConnectionString = connectionstring.GetConnectionString(objRatingEntity.AppID, objRatingEntity.TenantID);
            objloginfo.Message = ("RatingDAO - GetRatingGroupEntityList - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            // proxyLogger.Log.Info("RatingDAO - GetRatingGroupEntityList - Called.");
            SqlCommand command = null;
            DataTable _dt = new DataTable();
            try
            {
                string spName = string.Empty;
                DataSet _ds = new DataSet();
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    command = new SqlCommand("USP_GET_RATINGGROUPLIST", SqlConnection);
                    command.Parameters.Add("@StartRowIndex", SqlDbType.Int).Value = objRatingEntity.StartRowIndex;
                    command.Parameters.Add("@MaximumRows", SqlDbType.Int).Value = objRatingEntity.MaximumRows;
                    command.Parameters.Add("@SortOrder", SqlDbType.VarChar).Value = objRatingEntity.SortOrder;
                    command.Parameters.Add("@SortColumn", SqlDbType.VarChar).Value = objRatingEntity.SortColumn;
                    command.Parameters.Add(Constants.PARAM_SET_RATINGMASTER_SUBPROCESSID, SqlDbType.Int).Value = objRatingEntity.SubProcessId;
                    //command.Parameters.Add("@OrderByCol", SqlDbType.VarChar).Value = orderBy;
                    //command.Parameters.Add("@bOrder", SqlDbType.VarChar).Value = desc;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_dt);
                }
                //spName = "USP_GET_RATINGGROUPLIST";
                //Hashtable hs = new Hashtable();
                //hs.Add("@StartRowIndex", objRatingEntity.StartRowIndex);
                //hs.Add("@MaximumRows", objRatingEntity.MaximumRows);
                //hs.Add("@SortOrder", objRatingEntity.SortOrder);
                //hs.Add("@SortColumn", objRatingEntity.SortColumn);
                //hs.Add("@iSubProcessId", objRatingEntity.SubProcessId);
                //DBHelper db = new DBHelper();
                // _dt = db.SelectDataTable(spName, hs);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRatingEntity.TenantName, objRatingEntity.AppID);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }

            catch (InvalidCastException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRatingEntity.TenantName, objRatingEntity.AppID);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRatingEntity.TenantName, objRatingEntity.AppID);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRatingEntity.TenantName, objRatingEntity.AppID);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            /*
        catch (QuartException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
             */
            finally
            {
                //command = null;               
                objRatingEntity = null;
            }

            return _dt;
        }





        /// <summary>
        /// load rating list for group
        /// </summary>
        /// <param name="objRatingEntity"></param>
        /// <returns></returns>
        public DataTable GetRatingListForGroup(RatingEntity objRatingEntity)
        {
            objloginfo.Message = ("RatingDAO - GetRatingListForGroup - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            //dbConnectionString = connectionstring.GetConnectionString(objRatingEntity.AppID, objRatingEntity.TenantID);
            // proxyLogger.Log.Info("RatingDAO - GetRatingListForGroup - Called.");
            try
            {
                DataTable _dt = new DataTable();
                string spName = string.Empty;
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_GET_RATINGLIST_GROUP", sqlConnection);
                    command.Parameters.Add("@EntityName", SqlDbType.VarChar).Value = objRatingEntity.EntityName;
                    command.Parameters.Add("@iSubProcessId", SqlDbType.VarChar).Value = objRatingEntity.SubProcessId;

                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_dt);
                }
                //spName = "USP_GET_RATINGLIST_GROUP";
                //Hashtable hs = new Hashtable();
                //hs.Add("@EntityName", objRatingEntity.EntityName);
                //hs.Add("@iSubProcessId", objRatingEntity.SubProcessId);
                //DBHelper db = new DBHelper();
                //_dt = db.SelectDataTable(spName, hs);
                return _dt;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRatingEntity.TenantName, objRatingEntity.AppID);
                throw;
                //new QuartException(ex.Message, ex.InnerException);
            }

            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRatingEntity.TenantName, objRatingEntity.AppID);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRatingEntity.TenantName, objRatingEntity.AppID);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            /*
        catch (QuartException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
        */
        }

        /// <summary>
        /// this method used for creating, updating and deleting the Rating details 
        /// </summary>
        /// <param name="action"></param>
        /// <param name="objSubprocess"></param>
        /// <param name="Id"></param>
        /// <returns></returns>
        public string SetRatings(AuditRatingInfo objRating)
        {
            objloginfo.Message = ("RatingDAO - SetRatingRecord - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           // dbConnectionString = connectionstring.GetConnectionString(objRating.AppID, objRating.TenantID);
            // proxyLogger.Log.Info("RatingDAO - SetRatingRecord - Called.");
            try
            {
                string resultValue = "-1";
                string spName = string.Empty;
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    string spname = "";
                    if (objRating.Action == "Rating")
                    {
                        spname = "USP_SET_AUDITRATINGMASTER";


                    }
                    else
                    {
                        spname = "USP_SET_AUDITRATINGGRPMASTER";
                    }

                    SqlCommand command = new SqlCommand(spname, sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    if (objRating.Action == "Rating")
                    {
                        //      objRating.xmlRatingCheckItem = new XElement("AuditRatingData",
                        //objRating.RatingInfoList.Select(i => new XElement("Rating",
                        //      new XAttribute("iRatingId", i.RatingId),
                        //     new XAttribute("szDisplayName", i.RatingDisplayName),
                        //      new XAttribute("bIsNotApplicable", i.blnNotApplicable)

                        //)));
                        command.Parameters.Add("@iRatingId", SqlDbType.Int).Value = objRating.RatingId.ToString();
                        command.Parameters.Add("@szRatingDesc", SqlDbType.VarChar).Value = objRating.RatingDisplayName.ToString();
                        command.Parameters.Add("@szDisplayName", SqlDbType.VarChar).Value = objRating.RatingDisplayName.ToString();
                        command.Parameters.Add("@bIsNotApplicable", SqlDbType.Bit).Value = objRating.blnNotApplicable.ToString();

                    }
                    else
                    {
                        command.Parameters.Add("@szRatingIds", SqlDbType.VarChar).Value = objRating.Ratingids;
                        command.Parameters.Add(Constants.PARAM_SET_RATINGGROUPMASTER_ID, SqlDbType.VarChar).Value = (objRating.RatingGroupID == null) ? 0 : objRating.RatingGroupID;
                        command.Parameters.Add(Constants.PARAM_SET_RATINGGROUPMASTER_DESC, SqlDbType.VarChar).Value = (objRating.RatingGroupName == null) ? string.Empty : objRating.RatingGroupName;

                    }




                    command.Parameters.Add("@Isactive", SqlDbType.Bit).Value = objRating.IsActive;
                    command.Parameters.Add(Constants.PARAM_SET_RATINGMASTER_SUBPROCESSID, SqlDbType.Int).Value = objRating.SubProcessId;
                    command.Parameters.Add(Constants.PARAM_SET_RATINGMASTER_DONEBY, SqlDbType.Int).Value = objRating.CreatedBy;
                    // command.Parameters.Add(Constants.PARAM_SET_RATINGMASTER_OPERTAIONNAME, SqlDbType.VarChar).Value = objRating.eventAction;
                    command.Parameters.Add(Constants.PAR_iReturnValue, SqlDbType.Int, 100).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters[Constants.PAR_iReturnValue].Value.ToString();
                    //SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                    //outprm.Direction = ParameterDirection.Output;
                    //command.Parameters.Add(outprm);

                    //command.ExecuteNonQuery();
                    //resultValue = outprm.Value.ToString();   
                }
                //spName = "USP_SET_AUDITRATINGMASTER";
                //Hashtable hs = new Hashtable();
                //hs.Add("@iRatingId", objRating.RatingId);
                //hs.Add("@szRatingDesc", objRating.RatingDisplayName);
                //hs.Add("@szDisplayName", objRating.RatingDisplayName);
                //hs.Add("@iSubProcessId", objRating.selectedSubProcessId);
                //hs.Add("@bIsNotApplicable", objRating.blnNotApplicable);
                //hs.Add("@iDoneBy", objRating.CreatedBy);
                //hs.Add("@sOpertaionName", objRating.eventAction);
                //// hs.Add("@iReturnValue", 0);
                //DBHelper db = new DBHelper();
                //object message = new DBHelper().SelectSingleValue(spName, hs);


                return resultValue;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRating.TenantName, objRating.AppID);
                throw;
                //new QuartException(ex.Message, ex.InnerException);
            }

            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRating.TenantName, objRating.AppID);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRating.TenantName, objRating.AppID);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            /*
        catch (QuartException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
             * */
        }

        /// <summary>
        /// this method used for creating, updating and deleting the Rating details 
        /// </summary>
        /// <param name="action"></param>
        /// <param name="objSubprocess"></param>
        /// <param name="Id"></param>
        /// <returns></returns>
        public string SetRatingRecord(RatingEntity objRating)
        {
            objloginfo.Message = ("RatingDAO - SetRatingRecord - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           // dbConnectionString = connectionstring.GetConnectionString(objRating.AppID, objRating.TenantID);
            // proxyLogger.Log.Info("RatingDAO - SetRatingRecord - Called.");
            try
            {
                string resultValue = "-1";
                string spName = string.Empty;
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_SET_RATINGMASTER, sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(Constants.PARAM_SET_RATINGMASTER_ID, SqlDbType.VarChar).Value = objRating.RatingId;

                    command.Parameters.Add(Constants.PARAM_SET_RATINGMASTER_DESC, SqlDbType.VarChar).Value = (objRating.RatingDisplayName == null) ? string.Empty : objRating.RatingDisplayName;
                    command.Parameters.Add(Constants.PARAM_SET_RATINGMASTER_DSPYNAME, SqlDbType.VarChar).Value = (objRating.RatingDisplayName == null) ? string.Empty : objRating.RatingDisplayName;
                    command.Parameters.Add(Constants.PARAM_SET_RATINGMASTER_SUBPROCESSID, SqlDbType.Int).Value = objRating.selectedSubProcessId;
                    command.Parameters.Add(Constants.PARAM_SET_RATINGMASTER_NOTAPP, SqlDbType.Bit).Value = objRating.blnNotApplicable;
                    command.Parameters.Add(Constants.PARAM_SET_RATINGMASTER_DONEBY, SqlDbType.Int).Value = objRating.CreatedBy;
                    command.Parameters.Add(Constants.PARAM_SET_RATINGMASTER_OPERTAIONNAME, SqlDbType.VarChar).Value = objRating.eventAction;
                    command.Parameters.Add(Constants.PAR_iReturnValue, SqlDbType.Int, 100).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters[Constants.PAR_iReturnValue].Value.ToString();
                    //SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                    //outprm.Direction = ParameterDirection.Output;
                    //command.Parameters.Add(outprm);

                    //command.ExecuteNonQuery();
                    //resultValue = outprm.Value.ToString();   
                }
                //spName = "USP_SET_AUDITRATINGMASTER";
                //Hashtable hs = new Hashtable();
                //hs.Add("@iRatingId", objRating.RatingId);
                //hs.Add("@szRatingDesc", objRating.RatingDisplayName);
                //hs.Add("@szDisplayName", objRating.RatingDisplayName);
                //hs.Add("@iSubProcessId", objRating.selectedSubProcessId);
                //hs.Add("@bIsNotApplicable", objRating.blnNotApplicable);
                //hs.Add("@iDoneBy", objRating.CreatedBy);
                //hs.Add("@sOpertaionName", objRating.eventAction);
                //// hs.Add("@iReturnValue", 0);
                //DBHelper db = new DBHelper();
                //object message = new DBHelper().SelectSingleValue(spName, hs);


                return resultValue.ToString();
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRating.TenantName, objRating.AppID);
                throw;
                //new QuartException(ex.Message, ex.InnerException);
            }

            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRating.TenantName, objRating.AppID);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRating.TenantName, objRating.AppID);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            /*
        catch (QuartException ex)
        {
            throw new QuartException(ex.Message, ex.InnerException);
        }
             * */
        }


        /// <summary>
        /// this method used for creating, updating and deleting the Rating details 
        /// </summary>
        /// <param name="action"></param>
        /// <param name="objSubprocess"></param>
        /// <param name="Id"></param>
        /// <returns></returns>
        public string SetRatingGroupRecord(RatingGroupEntity objRatingGrp)
        {
            objloginfo.Message = ("RatingDAO - SetRatingGroupRecord - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           // dbConnectionString = connectionstring.GetConnectionString(objRatingGrp.AppID, objRatingGrp.TenantID);
            // // proxyLogger.Log.Info("RatingDAO - SetRatingGroupRecord - Called.");
            try
            {
                string spName = string.Empty;
                string resultValue = "-1";
                using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
                {

                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand(Constants.SP_SET_RATINGGROUPMASTER, sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(Constants.PARAM_SET_RATINGGROUPMASTER_ID, SqlDbType.VarChar).Value = objRatingGrp.RatingId;
                    command.Parameters.Add(Constants.PARAM_SET_RATINGGROUPMASTER_DESC, SqlDbType.VarChar).Value = objRatingGrp.RatingDisplayName;
                    command.Parameters.Add(Constants.PARAM_SET_RATINGGROUPMASTER_SUBPROCESSID, SqlDbType.Int).Value = objRatingGrp.selectedSubProcessId;
                    command.Parameters.Add(Constants.PARAM_SET_RATINGGROUPMASTER_RATINGID, SqlDbType.VarChar).Value = (objRatingGrp.strRatingGrpIds == null) ? string.Empty : objRatingGrp.strRatingGrpIds;
                    command.Parameters.Add(Constants.PARAM_SET_RATINGGROUPMASTER_DONEBY, SqlDbType.Int).Value = objRatingGrp.CreatedBy;
                    command.Parameters.Add(Constants.PARAM_SET_RATINGGROUPMASTER_OPERTAIONNAME, SqlDbType.VarChar).Value = objRatingGrp.eventAction;
                    command.Parameters.Add("@Isactive", SqlDbType.Bit).Value = objRatingGrp.IsActive;
                    command.Parameters.Add(Constants.PAR_iReturnValue, SqlDbType.Int, 100).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters[Constants.PAR_iReturnValue].Value.ToString();
                }
                //spName = "USP_SET_AUDITRATINGGRPMASTER";

                //Hashtable hs = new Hashtable();
                //hs.Add("@iRatingGroupId", objRatingGrp.RatingId);
                //hs.Add("@szRatingGroupName", objRatingGrp.RatingDisplayName);
                //hs.Add("@iSubProcessId", objRatingGrp.selectedSubProcessId);
                //hs.Add("@szRatingIds", objRatingGrp.strRatingGrpIds);
                //hs.Add("@iDoneBy", objRatingGrp.CreatedBy);
                //hs.Add("@sOpertaionName", objRatingGrp.eventAction);
                //// hs.Add("@iReturnValue", 0);
                //DBHelper db = new DBHelper();
                //object message = db.SelectSingleValue(spName, hs);

                //return message.ToString();
                return resultValue;
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRatingGrp.TenantName, objRatingGrp.AppID);
                throw;
                //new QuartException(ex.Message, ex.InnerException);
            }

            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRatingGrp.TenantName, objRatingGrp.AppID);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRatingGrp.TenantName, objRatingGrp.AppID);
                throw;// new QuartException(ex.Message, ex.InnerException);
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objRatingGrp.TenantName, objRatingGrp.AppID);
                throw;//new QuartException(ex.Message, ex.InnerException);
            }
            /*
        catch (QuartException ex)
        {

            throw new QuartException(ex.Message, ex.InnerException);
        } */
        }



    }
}
