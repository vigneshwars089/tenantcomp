﻿using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class AudotmatedAuditDataAccess
    {
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        AudotmatedAuditDAO objautomateddao = null;        
        public AudotmatedAuditDataAccess()
        {
            objloginfo.Message = ("AudotmatedAuditDataAccess - Called." + "Tenant Name and AppId is not passed");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
         }
        public AudotmatedAuditDataAccess(string TenantName, string AppId)
        {
            objautomateddao = new AudotmatedAuditDAO(TenantName, AppId);           
        }

        public List<List<DataelementAutomatedAuditEntity>> GetDataElement(int recordid)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAuditQCStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            DataTable dt = new DataTable();
            DataTable dt1 = new DataTable();
            DataTable dt2 = new DataTable();
            DataSet ds = new DataSet();
            List<DataelementAutomatedAuditEntity> objoutputOCR = new List<DataelementAutomatedAuditEntity>();
            List<DataelementAutomatedAuditEntity> objoutputLOS = new List<DataelementAutomatedAuditEntity>();
            List<DataelementAutomatedAuditEntity> objoutputLoanNo = new List<DataelementAutomatedAuditEntity>();
            List<List<DataelementAutomatedAuditEntity>> objoutput = new List<List<DataelementAutomatedAuditEntity>>();
            try
            {
                ds = objautomateddao.GetDataElement(recordid);
                if (ds != null)
                {
                    dt = ds.Tables[0];
                    dt1 = ds.Tables[1];
                    dt2 = ds.Tables[2];
                    if (dt.Rows.Count <= 0)
                        return null;
                    objoutputOCR = MapDataElemntEntity(dt1);
                    objoutputLOS = MapDataElemntEntity(dt);
                    objoutputLoanNo = MapDataElemntEntity(dt2);
                    objoutput.Add(objoutputOCR);
                    objoutput.Add(objoutputLOS);
                    objoutput.Add(objoutputLoanNo);
                }
                return objoutput;

            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw ex;
            }
        }

        //public List<DataelementAutomatedAuditEntity> GetAutoAuditFindingData(int recordid)
        //{
        //    objloginfo.Message = ("AuditDetailsDAO - GetAuditQCStatus - Called.");
        //    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        //    DataTable dt = new DataTable();
        //    List<DataelementAutomatedAuditEntity> objoutput = new List<DataelementAutomatedAuditEntity>();
        //    try
        //    {
        //        dt = objautomateddao.GetAutoAuditFindingData(recordid);
        //        if (dt.Rows.Count <= 0)
        //            return null;
        //        objoutput = MapDataElemntEntity(dt);
        //        return objoutput;

        //    }
        //    catch (Exception ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw ex;
        //    }
        //}

        public int SetAutoAuditedElement(List<ServiceOutput> objservoutlist)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAuditQCStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            int result = 0;
            string output = null;
            try
            {
                foreach (var a in objservoutlist)
                {
                    output = objautomateddao.SetAutoAuditedElement(a.RecordID, a.ElementId, a.ExpectedValue, a.ActualValue, a.ResultStatus, a.CreatedBy, a.ModifiedBy, a.AuditStatusId, a.SubDefects, a.Comments);
                    if (output != null)
                        result = Convert.ToInt32(output);

                }
                //  output = objautomateddao.SetAutoAuditedElementtotblARD(recordid, elementid, elementocr, elementlos, matchstatus, createdby, modifiedby, statusid);
            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objservoutlist[0].TenantName, objservoutlist[0].AppID);
                throw ex;
            }
            return result;
        }
        public int SetAutoAuditedElementStatus(ServiceOutput objservoutlist)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAuditQCStatus - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            int output = 0;
            //int recordid = 0, elementid = 0, createdby = 0, modifiedby = 0, statusid = 0;
            //string elementocr = null, elementlos = null;
            //bool matchstatus = false;
            try
            {
                output = objautomateddao.SetAutoAuditedElementtotblARD(objservoutlist.RecordID, objservoutlist.ElementId, objservoutlist.ActualValue, objservoutlist.ExpectedValue, objservoutlist.ResultStatus, objservoutlist.CreatedBy, objservoutlist.ModifiedBy, objservoutlist.AuditStatusId, objservoutlist.QCNotes);
            }

            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex, objservoutlist.TenantName, objservoutlist.AppID);
                throw ex;
            }
            return output;
        }

        public List<DataelementAutomatedAuditEntity> GetToAutomateAuditLOSData(int subprocessid)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAutoAuditFindingData - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            DataTable dt = new DataTable();
            List<DataelementAutomatedAuditEntity> objoutput = new List<DataelementAutomatedAuditEntity>();
            try
            {
                dt = objautomateddao.GetToAutomateAuditLOSData(subprocessid);
                if (dt.Rows.Count <= 0)
                    return null;
                objoutput = MapDataElemntEntity(dt);
                return objoutput;

            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw ex;
            }
        }

        public List<ServiceOutput> GetToAutomateAuditImageData(int RecordId)
        {
            objloginfo.Message = ("AuditDetailsDAO - GetAutoAuditFindingData - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            DataSet dt = new DataSet();
            List<ServiceOutput> objoutput = new List<ServiceOutput>();
            try
            {
                dt = objautomateddao.GetAutoAuditFindingData(RecordId);
                if (dt.Tables.Count <= 0)
                    return null;
                objoutput = MapDataElemntEntityToGetAuditedList(dt.Tables[0]);
                return objoutput;

            }
            catch (Exception ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw ex;
            }
        }
        internal List<DataelementAutomatedAuditEntity> MapDataElemntEntity(DataTable dt)
        {
            List<DataelementAutomatedAuditEntity> baseEntityList = new List<DataelementAutomatedAuditEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new DataelementAutomatedAuditEntity
                              {
                                  ElementId = p.Table.Columns.Contains("iElementId") == true ? Convert.ToInt32(p["iElementId"] == DBNull.Value ? 0 : p["iElementId"]) : 0,
                                  ElementData = p.Table.Columns.Contains("sznElementData") == true ? Convert.ToString(p["sznElementData"] == DBNull.Value ? string.Empty : p["sznElementData"]) : string.Empty,
                                  TransactionSource = p.Table.Columns.Contains("szSource") == true ? Convert.ToString(p["szSource"] == DBNull.Value ? string.Empty : p["szSource"]) : string.Empty,
                                  RecordId = p.Table.Columns.Contains("iRecordId") == true ? Convert.ToInt32(p["iRecordId"] == DBNull.Value ? 0 : p["iRecordId"]) : 0,
                                  ValueOfLoanNumber = p.Table.Columns.Contains("szLoanNumber") == true ? Convert.ToString(p["szLoanNumber"] == DBNull.Value ? string.Empty : p["szLoanNumber"]) : string.Empty,

                              }).ToList();

            return baseEntityList;
        }

        internal List<ServiceOutput> MapDataElemntEntityToGetAuditedList(DataTable dt)
        {
            List<ServiceOutput> baseEntityList = new List<ServiceOutput>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new ServiceOutput
                              {
                                  ElementId = p.Table.Columns.Contains("iElementId") == true ? Convert.ToInt32(p["iElementId"] == DBNull.Value ? 0 : p["iElementId"]) : 0,
                                  CreatedBy = p.Table.Columns.Contains("iCreatedBy") == true ? Convert.ToInt32(p["iCreatedBy"] == DBNull.Value ? 0 : p["iCreatedBy"]) : 0,
                                  ExpectedValue = p.Table.Columns.Contains("szElementLOSData") == true ? Convert.ToString(p["szElementLOSData"] == DBNull.Value ? string.Empty : p["szElementLOSData"]) : string.Empty,
                                  ActualValue = p.Table.Columns.Contains("szElementOCRData") == true ? Convert.ToString(p["szElementOCRData"] == DBNull.Value ? string.Empty : p["szElementOCRData"]) : string.Empty,
                                  RecordID = p.Table.Columns.Contains("iRecordId") == true ? Convert.ToInt32(p["iRecordId"] == DBNull.Value ? 0 : p["iRecordId"]) : 0,
                                  ResultStatus = p.Table.Columns.Contains("MatchStatus") == true ? Convert.ToBoolean(p["MatchStatus"] == DBNull.Value ? false : p["MatchStatus"]) : false,
                                  OCRConfidencetiality = p.Table.Columns.Contains("szElementName") == true ? Convert.ToString(p["szElementName"] == DBNull.Value ? string.Empty : p["szElementName"]) : string.Empty,
                                  Description = p.Table.Columns.Contains("szDescription") == true ? Convert.ToString(p["szDescription"] == DBNull.Value ? string.Empty : p["szDescription"]) : string.Empty,
                                  Comments = p.Table.Columns.Contains("szComments") == true ? Convert.ToString(p["szComments"] == DBNull.Value ? string.Empty : p["szComments"]) : string.Empty,
                                  // SubDefects = p.Table.Columns.Contains("iSubDefectId") == true ? Convert.ToString(p["iSubDefectId"] == DBNull.Value ? string.Empty : p["iSubDefectId"]) : string.Empty,
                                  SubDefects = p.Table.Columns.Contains("coOrdinates ") == true ? Convert.ToString(p["coOrdinates "] == DBNull.Value ? string.Empty : p["coOrdinates "]) : string.Empty,
                                  PageNo = p.Table.Columns.Contains("PageNo") == true ? Convert.ToInt32(p["PageNo"] == DBNull.Value ? 0 : p["PageNo"]) : 0,
                                  PagePath = p.Table.Columns.Contains("PagePath ") == true ? Convert.ToString(p["PagePath "] == DBNull.Value ? string.Empty : p["PagePath "]) : string.Empty,
                                 
                                 
                              }).ToList();

            return baseEntityList;
        }

        internal List<ServiceOutput> MapServiceOutputImageEntity(DataTable dt)
        {
            List<ServiceOutput> baseEntityList = new List<ServiceOutput>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new ServiceOutput
                              {
                                  RecordID = p.Table.Columns.Contains("RecordId") == true ? Convert.ToInt32(p["RecordId"] == DBNull.Value ? 0 : p["RecordId"]) : 0,
                                  ImageAttributes = p.Table.Columns.Contains("ImageAttributes") == true ? Convert.ToString(p["ImageAttributes"] == DBNull.Value ? string.Empty : p["sznElementData"]) : string.Empty,
                                   TotalPages = p.Table.Columns.Contains("TotalPage") == true ? Convert.ToInt32(p["TotalPage"] == DBNull.Value ? 0 : p["TotalPage"]) : 0,
                                  FileName = p.Table.Columns.Contains("FileName") == true ? Convert.ToString(p["FileName"] == DBNull.Value ? string.Empty : p["FileName"]) : string.Empty,

                              }).ToList();

            return baseEntityList;
        }

    }
}
