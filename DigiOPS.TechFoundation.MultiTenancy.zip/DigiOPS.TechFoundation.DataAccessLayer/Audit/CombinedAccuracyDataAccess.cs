﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using System.Data;
using DigiOPS.TechFoundation.Logging;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class CombinedAccuracyDataAccess
    {
        CombinedAuditDAO caDAOCA = null;
        CombinedAccuracyTransformer catrans = new CombinedAccuracyTransformer();
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
     public CombinedAccuracyDataAccess()
        {
            objloginfo.Message = ("CombinedAccuracyDataAccess - Called." + "Tenant Name and AppId is not passed");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
         }
     public CombinedAccuracyDataAccess(string TenantName, string AppId)
        {
            caDAOCA = new CombinedAuditDAO(TenantName, AppId);           
        }
        public List<CombinedAccuracyEntity> GetAuditDetailList(CombinedAccuracyEntity caEntity)
        {
            //DefectOpportunityDAO doDAOAuditconfig = new DefectOpportunityDAO();
            DataTable dt = new DataTable();
            List<CombinedAccuracyEntity> baseList = null;
            try
            {
                //  CombinedAccuracyEntity caEntity = (CombinedAccuracyEntity)objBase;
                dt = caDAOCA.GetAuditDetailList(caEntity);
                if (dt.Rows.Count <= 0)
                    return baseList;
                baseList = catrans.MapToDropDownList(dt);
                return baseList;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public List<List<CombinedAccuracyEntity>> GetAuditRatingList(CombinedAccuracyEntity caEntity)
        {
            List<List<CombinedAccuracyEntity>> listcoll = new List<List<CombinedAccuracyEntity>>();
            DataSet ds = new DataSet();
            ds = caDAOCA.GetAuditRatingList(caEntity);
            if (ds.Tables.Count <= 0)
                return listcoll;
            else
            {
                listcoll.Add(catrans.MapToDropDownList(ds.Tables[0]));
                listcoll.Add(catrans.MapToRatingTableViewModel(ds.Tables[1]));
            }
            return listcoll;
        }

        public string SetCombinedAccuracy(CombinedAccuracyEntity caEntity)
        {
            string createRecVal = string.Empty;
            createRecVal = caDAOCA.SetCombinedAccuracy(caEntity);
            return createRecVal;
        }
    }
}
