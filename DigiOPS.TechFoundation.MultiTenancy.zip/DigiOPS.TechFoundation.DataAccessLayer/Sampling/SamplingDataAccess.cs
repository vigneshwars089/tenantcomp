﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using DigiOPS.TechFoundation.Entities;
using System.Data.SqlClient;
using System.Data;
using DigiOPS.TechFoundation.Logging;
using System.IO;
using System.Xml;
using System.Xml.Serialization;


namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class SamplingDataAccess : SamplingRepository
    {
        private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();
        SamplingDAO samplingDao = null;
        public SamplingDataAccess()
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
            objloginfo.Message = ("SamplingDataAccess - Called." + "Tenant Name and AppId is not passed");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        }
        public SamplingDataAccess(string TenantName, string AppId)
        {
            samplingDao = new SamplingDAO(TenantName, AppId);            
        }

        public string InsertSampledTrans(List<TransactionLists> SamplingTransactionLists)
        {
            string createRecVal = string.Empty;
            string str = string.Empty;
            str = SerializeToString(SamplingTransactionLists);
            try
            {
                createRecVal = samplingDao.InsertSamplingDetails(str);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return createRecVal;
        }
        public string SerializeToString(object value)
        {
            var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
            var serializer = new XmlSerializer(value.GetType());
            var settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.OmitXmlDeclaration = true;

            using (var stream = new StringWriter())
            using (var writer = XmlWriter.Create(stream, settings))
            {
                serializer.Serialize(writer, value, emptyNamepsaces);
                string str = stream.ToString().Replace("<TransactionListResponse>\r\n ", "");
                str = str.Replace("\r\n</TransactionListResponse>", "");

                return str;

            }
        }

        public override string InsertSamplingDetails(string str)
        {
            string result = string.Empty;
            try
            {
                result = samplingDao.InsertSamplingDetails(str);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return result;

        }
        //public DataTable GetSamplingPctDetails(SamplingEntity objSamplingEntity)
        //{
        //    objloginfo.Message = ("SamplingDAO - GetSamplingPctDetails - Called.");
        //    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        //    DataTable dt = new DataTable();
        //    try
        //    {
        //        DBHelper DBH = new DBHelper();  
        //        Hashtable hs = new Hashtable();

        //        hs.Add("@iSubProcessId", objSamplingEntity.SubProcessId);
        //        hs.Add("@StartRowIndex", objSamplingEntity.StartRowIndex);
        //        hs.Add("@MaximumRows", objSamplingEntity.MaximumRows);
        //        hs.Add("@SortOrder", objSamplingEntity.SortOrder);
        //        hs.Add("@SortColumn", objSamplingEntity.SortColumn);
        //        hs.Add("@SamplingMethod", objSamplingEntity.samplingMethod);


        //        dt =  DBH.SelectDataTable("USP_Get_SamplingPctDetails", hs);


        //    }
        //    catch (ArgumentException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (ApplicationException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }

        //    return dt;
        //}
        //public DataTable GetUsersNameBasedOnSubprocessSelection(SamplingEntity objSamplingEntity)
        //{
        //    DataTable dt = new DataTable();
        //    try
        //    {

        //        using (SqlConnection con = new SqlConnection(dbConnectionString))
        //        {
        //            con.Open();
        //            SqlCommand cmd = new SqlCommand("USP_Get_UsersBasedOnSubprocessID", con);
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.Parameters.AddWithValue("@iSubProcessId", objSamplingEntity.SubProcessId);
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            da.Fill(dt);
        //        }

        //    }
        //    catch (ArgumentException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (ApplicationException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }

        //    return dt;
        //}
        //public string AddSamplingPercentage(SamplingEntity objAddSampling)
        //{
        //    objloginfo.Message = ("SamplingDAO - AddSamplingPercentage - Called.");
        //    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        //    string strResult = string.Empty;
        //    try
        //    {
        //        DBHelper DBHSetSmpPct = new DBHelper();
        //        Hashtable hsSetSmpPct = new Hashtable();

        //        hsSetSmpPct.Add("@szSystemUserID", objAddSampling.SystemUserId);
        //        hsSetSmpPct.Add("@dSamplingPct", objAddSampling.SamplingPct);
        //        hsSetSmpPct.Add("@iSubProcessId", objAddSampling.SubProcessId);
        //        hsSetSmpPct.Add("@iCreatedBy", objAddSampling.CreatedBy);
        //        hsSetSmpPct.Add("@SamplingMethod", objAddSampling.SamplingType);

        //        strResult = (DBHSetSmpPct.SelectSingleValue("USP_Add_SamplingPctDetails", hsSetSmpPct)).ToString();


        //    }
        //    catch (ArgumentException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (ApplicationException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }

        //    return strResult;
        //}

        //public string GetTransListForAutoAlloc(TransactionListDetails objBase, string str)
        //{
        //    string result = string.Empty;
        //    objloginfo.Message = ("SamplingDAO - GetTransListForAutoAlloc - Called.");
        //    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);

        //    try
        //    {
        //        DBHelper DBHSetSmpPct = new DBHelper();
        //        Hashtable hsSetSmpPct = new Hashtable();
        //        hsSetSmpPct.Add("@xmlData", str);

        //        result = (DBHSetSmpPct.SelectSingleValue("USP_AuditSampled", hsSetSmpPct)).ToString();

        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (InvalidOperationException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    return result;
        //}

    }
}

