﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using DigiOPS.TechFoundation.Entities;
using System.Data.SqlClient;
using System.Data;
using DigiOPS.TechFoundation.Logging;


namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class SamplingDAO
    {
         private string dbConnectionString = string.Empty;
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();

        public SamplingDAO()
        {
            
            dbConnectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
        }
        public SamplingDAO(string TenantName, string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }
        //public DataTable GetSamplingPctDetails(SamplingEntity objSamplingEntity)
        //{
        //    objloginfo.Message = ("SamplingDAO - GetSamplingPctDetails - Called.");
        //    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        //    DataTable dt = new DataTable();
        //    try
        //    {
        //        DBHelper DBH = new DBHelper();  
        //        Hashtable hs = new Hashtable();
                
        //        hs.Add("@iSubProcessId", objSamplingEntity.SubProcessId);
        //        hs.Add("@StartRowIndex", objSamplingEntity.StartRowIndex);
        //        hs.Add("@MaximumRows", objSamplingEntity.MaximumRows);
        //        hs.Add("@SortOrder", objSamplingEntity.SortOrder);
        //        hs.Add("@SortColumn", objSamplingEntity.SortColumn);
        //        hs.Add("@SamplingMethod", objSamplingEntity.samplingMethod);
                

        //        dt =  DBH.SelectDataTable("USP_Get_SamplingPctDetails", hs);
                
               
        //    }
        //    catch (ArgumentException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (ApplicationException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
          
        //    return dt;
        //}
        //public DataTable GetUsersNameBasedOnSubprocessSelection(SamplingEntity objSamplingEntity)
        //{
        //    DataTable dt = new DataTable();
        //    try
        //    {
               
        //        using (SqlConnection con = new SqlConnection(dbConnectionString))
        //        {
        //            con.Open();
        //            SqlCommand cmd = new SqlCommand("USP_Get_UsersBasedOnSubprocessID", con);
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.Parameters.AddWithValue("@iSubProcessId", objSamplingEntity.SubProcessId);
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            da.Fill(dt);
        //        }
               
        //    }
        //    catch (ArgumentException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (ApplicationException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
           
        //    return dt;
        //}
        //public string AddSamplingPercentage(SamplingEntity objAddSampling)
        //{
        //    objloginfo.Message = ("SamplingDAO - AddSamplingPercentage - Called.");
        //    objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        //    string strResult = string.Empty;
        //    try
        //    {
        //        DBHelper DBHSetSmpPct = new DBHelper();
        //        Hashtable hsSetSmpPct = new Hashtable();

        //        hsSetSmpPct.Add("@szSystemUserID", objAddSampling.SystemUserId);
        //        hsSetSmpPct.Add("@dSamplingPct", objAddSampling.SamplingPct);
        //        hsSetSmpPct.Add("@iSubProcessId", objAddSampling.SubProcessId);
        //        hsSetSmpPct.Add("@iCreatedBy", objAddSampling.CreatedBy);
        //        hsSetSmpPct.Add("@SamplingMethod", objAddSampling.SamplingType);
                    
        //        strResult = (DBHSetSmpPct.SelectSingleValue("USP_Add_SamplingPctDetails", hsSetSmpPct)).ToString();
                   
                
        //    }
        //    catch (ArgumentException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (SqlException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
        //    catch (ApplicationException ex)
        //    {
        //        objlog.GetLoggingHandler("Log4net").LogException(ex);
        //        throw;
        //    }
            
        //    return strResult;
        //}

        public string InsertSamplingDetails(string str)
        {
            string result = string.Empty;
            objloginfo.Message = ("SamplingDAO - GetTransListForAutoAlloc - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            
            try
            {
                DBHelper DBHSetSmpPct = new DBHelper();
                Hashtable hsSetSmpPct = new Hashtable();
                hsSetSmpPct.Add("@xmlData", str);
               result = (DBHSetSmpPct.SelectSingleValue("USP_AuditSampled", hsSetSmpPct)).ToString();

            }
             
            catch (SqlException ex)
            {
                result = "Duplication Transactions Entered";
               
                //result = result + "  " + ex.ToString();
                
            }
            catch (InvalidOperationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                result = ex.ToString();
                throw;
            }
            return result;
        }

    }
   }

