﻿using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public class SupportTicketDataAccess : SupportTicketRepository
    {
        SupportTicketDAO objsupportdao = null;
        LoggingFactory objlog = new LoggingFactory();
         LogInfo objloginfo = new LogInfo();
        public SupportTicketDataAccess()
        {
            objloginfo.Message = ("SupportTicketDataAccess - Called." + "Tenant Name and AppId is not passed");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
        }
        public SupportTicketDataAccess(string TenantName, string AppId)
        {
            objsupportdao = new SupportTicketDAO(TenantName, AppId);            
        }

        public override string SetSupportTicket(Entities.SupportTicketEntity Ticket)
        {
            string SupportTicket = string.Empty;

            try
            {
                SupportTicket = objsupportdao.SetSupportTicket(Ticket);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return SupportTicket;
        }

        public override string SetSupportTicketTrail(Entities.SupportTicketEntity Ticket)
        {
            string SupportTicket = string.Empty;

            try
            {
                SupportTicket = objsupportdao.SetSupportTicketTrail(Ticket);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return SupportTicket;
        }

        public override System.Data.DataTable GetSupportTicketEntityList(Entities.SupportTicketEntity objProgramIssuesEntity)
        {
            DataTable SupportTicket = new DataTable();

            try
            {
                SupportTicket = objsupportdao.GetSupportTicketEntityList(objProgramIssuesEntity);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return SupportTicket;
        }

        public override string SetSupportTicketMailingDetails(Entities.BaseTransportEntity _Obj)
        {
            string SupportTicket = string.Empty;

            try
            {
                SupportTicket = objsupportdao.SetSupportTicketMailingDetails(_Obj);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return SupportTicket;
        }

        public override System.Data.DataTable GetSupportTicketEntityTrailList(Entities.SupportTicketTrailEntity objTicketTrailEntity)
        {
            DataTable SupportTicket = new DataTable();

            try
            {
                SupportTicket = objsupportdao.GetSupportTicketEntityTrailList(objTicketTrailEntity);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return SupportTicket;
        }

        public override System.Data.DataTable GetSupportTicketStatus(Entities.SupportTicketEntity objTicket)
        {
            DataTable SupportTicket = new DataTable();

            try
            {
                SupportTicket = objsupportdao.GetSupportTicketStatus(objTicket);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return SupportTicket;
        }

        public override System.Data.DataTable GetSupportTicketById(Entities.SupportTicketEntity objTicket)
        {
            DataTable SupportTicket = new DataTable();

            try
            {
                SupportTicket = objsupportdao.GetSupportTicketById(objTicket);
            }
            catch (ArgumentException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (SqlException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            catch (ApplicationException ex)
            {
                objlog.GetLoggingHandler("Log4net").LogException(ex);
                throw;
            }
            return SupportTicket;
        }
    }
}
