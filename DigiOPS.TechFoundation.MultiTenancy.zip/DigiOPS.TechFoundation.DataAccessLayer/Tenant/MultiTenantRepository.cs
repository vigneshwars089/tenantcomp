﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace DigiOPS.TechFoundation.DataAccessLayer
//{
//    public abstract class MultiTenantRepository : IMultiTenantRepository
//    {

//        public virtual System.Data.DataTable GetConnectionStringDetails(int AppId)
//        {
//            throw new NotImplementedException();
//        }

//        public virtual int SaveTenantDetails(Entities.TenantInfo objMultiTenancyInfo)
//        {
//            throw new NotImplementedException();
//        }
//    }
//}
