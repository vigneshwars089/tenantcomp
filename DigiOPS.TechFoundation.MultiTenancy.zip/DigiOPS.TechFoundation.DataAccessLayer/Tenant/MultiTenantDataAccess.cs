﻿//using DigiOPS.TechFoundation.Logging;
//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Data.SqlClient;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace DigiOPS.TechFoundation.DataAccessLayer
//{
//    public class MultiTenantDataAccess : MultiTenantRepository
//    {
//        MultiTenantDAL objmultitenatdao = new MultiTenantDAL();
//        LoggingFactory objlog = new LoggingFactory();
//        public override System.Data.DataTable GetConnectionStringDetails(int AppId)
//        {
//            DataTable dtTenantDetails = new DataTable();

//            try
//            {
//                dtTenantDetails = objmultitenatdao.GetConnectionStringDetails(AppId);
//            }
//            catch (ArgumentException ex)
//            {
//                objlog.GetLoggingHandler("Log4net").LogException(ex);
//                throw;
//            }
//            catch (SqlException ex)
//            {
//                objlog.GetLoggingHandler("Log4net").LogException(ex);
//                throw;
//            }
//            catch (ApplicationException ex)
//            {
//                objlog.GetLoggingHandler("Log4net").LogException(ex);
//                throw;
//            }
//            return dtTenantDetails;
//        }

//        public override int SaveTenantDetails(Entities.TenantInfo objMultiTenancyInfo)
//        {
//            int TenantDetails;

//            try
//            {
//                TenantDetails = objmultitenatdao.SaveTenantDetails(objMultiTenancyInfo);
//            }
//            catch (ArgumentException ex)
//            {
//                objlog.GetLoggingHandler("Log4net").LogException(ex);
//                throw;
//            }
//            catch (SqlException ex)
//            {
//                objlog.GetLoggingHandler("Log4net").LogException(ex);
//                throw;
//            }
//            catch (ApplicationException ex)
//            {
//                objlog.GetLoggingHandler("Log4net").LogException(ex);
//                throw;
//            }
//            return TenantDetails;
//        }
//    }
//}
