﻿////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :BaseScoringAlgorithm.cs
// Namespace : DigiOps.TechFoundation.DataAccessLayer
// Class Name(s) :CaseHandler
// Author : Sujitha
// Creation Date : 9/5/2017
// Purpose : Data Access Method for CaseHandling
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////

using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataTransfer;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Collections;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
   public class CaseHandler
    {
       LoggingFactory objloggingfactory = new LoggingFactory();
       LogInfo objlog = new LogInfo();
       string dbConnectionString = ConfigurationManager.ConnectionStrings["ConnStr"].ConnectionString;
       public CaseHandler(string TenantName, string AppId)
        {

            dbConnectionString = ConfigurationManager.ConnectionStrings[TenantName].ConnectionString;
        }
       public string SetTransRecordData(string action, string sb, int recordid, string viewname)
        {
            //objlog.Message=("SetTransRecordData - Called.");
            //objloggingfactory.GetLoggingHandler("Log4net").LogInfo(objlog);
           // _proxyLogger.Log.Info("SetTransRecordData - Called.");
            try
            {
                string resultValue = "-1";
                using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
                {
                    SqlConnection.Open();
                    string spName = string.Empty;
                    if (action == "INSERT")
                    {
                        spName = "USP_SET_TRANSRECORDDETAILS_INSERT";
                    }
                    else if (action == "UPDATE")
                    {
                        spName = "USP_SET_TRANSRECORDDETAILS_UPDATE";
                    }
                    SqlCommand command = new SqlCommand(spName, SqlConnection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@RecordXML", SqlDbType.Xml).Value = sb;
                    command.Parameters.Add("@szAction", SqlDbType.VarChar).Value = action;
                    command.Parameters.Add("@Id", SqlDbType.Int).Value = recordid;
                    if (action == "UPDATE")
                    {
                        if (viewname == "SearchCall")
                        {
                            command.Parameters.Add("@SearchCall", SqlDbType.Bit).Value = true;
                        }
                        else
                        {
                            command.Parameters.Add("@SearchCall", SqlDbType.Bit).Value = false;
                        }
                    }
                    command.Parameters.Add("@iReturnValue", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                    outprm.Direction = ParameterDirection.Output;
                    command.Parameters.Add(outprm);

                    command.ExecuteNonQuery();
                    resultValue = outprm.Value.ToString();
                }

                return resultValue;
            }
            catch (SqlException ex)
            {
               // _proxyLogger.Log.Error(ex.Message); _proxyLogger.Log.Error(ex.StackTrace);
                objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
                throw ex;
            }
            catch (ApplicationException ex)
            {
                //_proxyLogger.Log.Error(ex.Message); _proxyLogger.Log.Error(ex.StackTrace);
                objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
                throw ex;
            }
        }
     
       /// <summary>
       /// Delete Transaction record using TransRecordData object
       /// </summary>
       /// <param name="objRecord">TransRecordData object</param>
       /// <returns>string</returns>
       public string DeleteTransaction(TransRecordData objRecord)
       {
           //_proxyLogger.Log.Info("DeleteTransaction - Called.");
           objlog.Message = ("DeleteTransaction - Called.");
           objloggingfactory.GetLoggingHandler("Log4net").LogInfo(objlog);
           try
           {
               string resultValue = "-1";
               using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
               {
                   SqlConnection.Open();
                   SqlCommand command = new SqlCommand("USP_SET_TRANSRECORDDETAILS_DELETE", SqlConnection);
                   command.CommandType = CommandType.StoredProcedure;
                   command.Parameters.Add("@Id", SqlDbType.Int).Value = objRecord.RecordId;
                   command.Parameters.Add("@szAction", SqlDbType.VarChar).Value = objRecord.eventAction;
                   command.Parameters.Add("@iReturnValue", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                   SqlParameter outprm = new SqlParameter(Constants.PAR_iReturnValue, SqlDbType.Int, 100);
                   outprm.Direction = ParameterDirection.Output;
                   command.Parameters.Add(outprm);

                   command.ExecuteNonQuery();
                   resultValue = outprm.Value.ToString();
               }

               return resultValue;
           }
           catch (SqlException ex)
           {
               objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
               //_proxyLogger.Log.Error(ex.Message); _proxyLogger.Log.Error(ex.StackTrace);
               throw ex;
           }
           catch (ApplicationException ex)
           {
               objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
               //_proxyLogger.Log.Error(ex.Message); _proxyLogger.Log.Error(ex.StackTrace);
               throw ex;
           }
       }

       /// <summary>
       /// Get Transaction List using TransactionListViewModal object
       /// </summary>
       /// <param name="objBase">TransactionListViewModal object</param>
       /// <returns>DataSet object</returns>
       public DataSet GetTransactionList(TransactionListView objBase)
       {
           objlog.Message=("GetTransactionList - Called.");
           objloggingfactory.GetLoggingHandler("Log4net").LogInfo(objlog);
           //_proxyLogger.Log.Info("GetTransactionList - Called.");
           try
           {
               DataSet ds = new DataSet();
               DataTable resultdt = new DataTable();
               using (SqlConnection SqlConnection = new SqlConnection(dbConnectionString))
               {
                   SqlConnection.Open();
                   SqlCommand command = new SqlCommand("USP_GET_TRANSACTIONLIST", SqlConnection);
                   command.CommandType = CommandType.StoredProcedure;
                   command.Parameters.Add("@iSubProcessId", SqlDbType.VarChar).Value = objBase.SubProcessId.ToString();
                   command.Parameters.Add("@StartRowIndex", SqlDbType.Int).Value = objBase.StartRowIndex;
                   command.Parameters.Add("@MaximumRows", SqlDbType.Int).Value = objBase.MaximumRows;
                   command.Parameters.Add("@SortOrder", SqlDbType.VarChar).Value = objBase.SortOrder;
                   command.Parameters.Add("@SortColumn", SqlDbType.VarChar).Value = objBase.SortColumn;
                   command.Parameters.Add("@CurrentUserID", SqlDbType.Int).Value = objBase.CurrentUserID;
                   SqlDataAdapter adp = new SqlDataAdapter(command);
                   adp.Fill(ds);
               }
               return ds;
           }
           catch (SqlException ex)
           {
               objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
               throw ex;
           }
           catch (ApplicationException ex)
           {
               objloggingfactory.GetLoggingHandler("Log4net").LogException(ex);
               throw ex;
           }
       }

       /// <summary>
       /// Method to Upload Excel to DataBase 
       /// </summary>
       /// <param name="Path">string</param>
       /// <param name="fileExtn">string</param>
       /// <param name="SubProcess">int</param>
       /// <param name="UploadedBy">string</param>
       /// <param name="Errorpath">string</param>
       /// <param name="ExcelColumn">string</param>
       /// <param name="Column">string</param>
       /// <param name="ExcelDataxml">string</param>
       /// <param name="ActionType">string</param>
       /// <param name="dateformatcon">string</param>
       /// <returns>DataSet</returns>
       public DataSet ExcelUploadToDB(Hashtable hstbl)
       {
           DataSet dsRecords = new DataSet();

           try
           {




               using (SqlConnection sqlConnection = new SqlConnection(dbConnectionString))
               {
                   var BulkUdCount = "300";
                   string QueryExecutionTimeout = "0";
                   if (string.IsNullOrWhiteSpace(QueryExecutionTimeout))
                       QueryExecutionTimeout = Constants.BULKUPLOADQUERYEXECTIMEOUT;
                   sqlConnection.Open();


                   SqlCommand command = new SqlCommand(Constants.SP_SET_BULKUPLOADDATA, sqlConnection);
                   command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_FILEPATH, SqlDbType.VarChar).Value = (hstbl.ContainsKey("FilePath") ? Convert.ToString(hstbl["FilePath"]) : string.Empty);
                   command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_FILEEXTN, SqlDbType.VarChar).Value = (hstbl.ContainsKey("FileExtention") ? Convert.ToString(hstbl["FileExtention"]) : string.Empty);
                   command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_SUBPROCESS, SqlDbType.VarChar).Value = (hstbl.ContainsKey("SubProcessID") ? Convert.ToString(hstbl["SubProcessID"]) : string.Empty);
                   command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_UPLOADBY, SqlDbType.VarChar).Value = (hstbl.ContainsKey("CurrentUserID") ? Convert.ToString(hstbl["CurrentUserID"]) : string.Empty);
                   command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_ERRORPATH, SqlDbType.VarChar).Value = (hstbl.ContainsKey("ErrorPath") ? Convert.ToString(hstbl["ErrorPath"]) : string.Empty);
                   command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_EXCELCOLUMN, SqlDbType.VarChar).Value = (hstbl.ContainsKey("StrExcelColumn") ? Convert.ToString(hstbl["StrExcelColumn"]) : string.Empty);
                   command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_COLUMN, SqlDbType.VarChar).Value = (hstbl.ContainsKey("StrColumn") ? Convert.ToString(hstbl["StrColumn"]) : string.Empty);
                   command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_EXCELDATA, SqlDbType.Xml).Value = (hstbl.ContainsKey("StrExcelDataxml") ? Convert.ToString(hstbl["StrExcelDataxml"]) : string.Empty);
                   command.Parameters.Add(Constants.PARAM_SET_BULKUPLOADDATA_DATEFORMATCON, SqlDbType.VarChar).Value = (hstbl.ContainsKey("DateFormatCon") ? Convert.ToString(hstbl["DateFormatCon"]) : string.Empty);
                   command.Parameters.Add("@UploadType", SqlDbType.VarChar).Value = (hstbl.ContainsKey("UploadType") ? Convert.ToString(hstbl["UploadType"]) : string.Empty);
                   command.Parameters.Add("@iBulkUploadId", SqlDbType.VarChar).Value = (hstbl.ContainsKey("BulkUploadId") ? Convert.ToString(hstbl["BulkUploadId"]) : string.Empty);
                   command.Parameters.Add("@maxBulkUploadCount", SqlDbType.VarChar).Value = BulkUdCount;
                   command.CommandType = CommandType.StoredProcedure;
                   command.CommandTimeout = 0;
                   SqlDataAdapter adp = new SqlDataAdapter(command);
                   adp.Fill(dsRecords);

               }

               return dsRecords;

           }
           catch (Exception ex)
           {

           }


           return dsRecords;
       }
    }
}
