﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public abstract class CaseHandlerRepository : ICaseHandlerRepository
    {

        public virtual string SetTransRecordData(string action, string sb, int recordid, string viewname)
        {
            throw new NotImplementedException();
        }

        public virtual string DeleteTransaction(Entities.TransRecordData objRecord)
        {
            throw new NotImplementedException();
        }

        public virtual System.Data.DataSet GetTransactionList(Entities.TransactionListView objBase)
        {
            throw new NotImplementedException();
        }
    }
}
