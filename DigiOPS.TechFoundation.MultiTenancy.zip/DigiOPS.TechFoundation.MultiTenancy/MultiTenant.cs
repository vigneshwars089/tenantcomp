﻿////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :BaseScoringAlgorithm.cs
// Namespace : DigiOps.TechFoundation.MultiTenancy
// Class Name(s) :MultiTenant
// Author : Sujitha
// Creation Date : 9/5/2017
// Purpose : MultiTenant Insertion and Retrieval Methods 
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////


using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;


using System.Collections.ObjectModel;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;


namespace DigiOPS.TechFoundation.MultiTenancy
{
   public class MultiTenant
    {
       MultiTenantDAL objMultiTenantDAL = new MultiTenantDAL();
       DataTable db = new DataTable();
       LoggingFactory objlog = new LoggingFactory();
       LogInfo objloginfo = new LogInfo();
       
       /// <summary>
       /// Method to Get Connection String
       /// </summary>
       /// <param name="MultiTenancyInfo"></param>
       /// <returns>MultiTenantOutput</returns>
       public MultiTenantOutput GetConnectionString(MultiTenancyInfo MultiTenancyInfo) 
       {
           MultiTenantOutput objMultiTenantOutput = new MultiTenantOutput();
           objloginfo.Message = ("MultiTenancy - GetTenantDataBaseDetails - Called.");
           objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           if (MultiTenancyInfo == null)
           {
               MultiTenantOutput objMultiTenancyInfo = new MultiTenantOutput();
               objMultiTenancyInfo.ErrorMessage = new StringBuilder();
               objMultiTenancyInfo.ErrorMessage.Append("MultiTenancy Info can't be null");
               objMultiTenancyInfo.ResultStatus = false;
               return objMultiTenancyInfo;
           }
          int AppId = Convert.ToInt32(MultiTenancyInfo.AppID);
          if (AppId > 0)
           {
               db = objMultiTenantDAL.GetConnectionStringDetails(AppId);              
               try
               {
                   if (db.Rows.Count >= 0)
                       foreach (DataRow dtrow in db.Rows)
                       {
                           //MultiTenancyInfo ctry = new MultiTenancyInfo();
                           objMultiTenantOutput.ServerName = dtrow["szServerName"].ToString();
                           objMultiTenantOutput.DataBaseName = dtrow["szDataBaseName"].ToString();
                           objMultiTenantOutput.UserName = dtrow["szUserId"].ToString();
                           objMultiTenantOutput.Password = dtrow["szPassword"].ToString();
                        
                       }
                   else
                   {
                       objMultiTenantOutput.ErrorMessage = new StringBuilder();
                       objMultiTenantOutput.ErrorMessage.Append("DataTable is null");
                       return null;
                   }

               }
               catch (Exception ex)
               {
                   objlog.GetLoggingHandler("Log4net").LogException(ex); 
               }
           }
           else
           {
               objMultiTenantOutput.ErrorMessage = new StringBuilder();
               objMultiTenantOutput.ResultStatus = false;
               objMultiTenantOutput.ErrorMessage.Append("Input's can't be null");
           }
          return objMultiTenantOutput;
       }

       /// <summary>
       /// Saves Tenant Details
       /// </summary>
       /// <param name="MultiTenancyInfo"></param>
       /// <returns>MultiTenantOutput</returns>
       public MultiTenantOutput SaveTenantDetails(MultiTenancyInfo MultiTenancyInfo)
       {
           MultiTenantOutput objMultiTenantOutput = new MultiTenantOutput();
           objloginfo.Message = ("MultiTenancy - SaveTenantDetails - Called.");
           objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           if (MultiTenancyInfo == null)
           {
               MultiTenantOutput objMultiTenancyInfo = new MultiTenantOutput();
               objMultiTenancyInfo.ErrorMessage = new StringBuilder();
               objMultiTenancyInfo.ErrorMessage.Append("MultiTenancy Info can't be null");
               objMultiTenancyInfo.ResultStatus = false;
               return objMultiTenancyInfo;
           }
           if ((!(MultiTenancyInfo.AccountId < 0)) && (!(MultiTenancyInfo.Vertical < 0)) && (!(MultiTenancyInfo.TenantUserID < 0)) && MultiTenancyInfo.EffectiveFrom != null && MultiTenancyInfo.EffectiveTo != null && (!String.IsNullOrEmpty(MultiTenancyInfo.InstanceName)) && (!String.IsNullOrEmpty(MultiTenancyInfo.LicenseKey)) && (!String.IsNullOrEmpty(MultiTenancyInfo.TenantName)) && (!String.IsNullOrEmpty(MultiTenancyInfo.URL)) && (!String.IsNullOrEmpty(MultiTenancyInfo.ServerName)) && (!String.IsNullOrEmpty(MultiTenancyInfo.DataBaseName)) && (!String.IsNullOrEmpty(MultiTenancyInfo.UserName)) && (!String.IsNullOrEmpty(MultiTenancyInfo.Password)))
            {
               MultiTenancyInfo.OperationName = "INSERT";
               try
               {
                   int output = objMultiTenantDAL.SaveTenantDetails(MultiTenancyInfo);
                   if (output < 1)
                   {
                       objMultiTenantOutput.ErrorMessage = new StringBuilder();
                       objMultiTenantOutput.ResultStatus = false;
                       objMultiTenantOutput.ErrorMessage.Append("Insertion of Tenant Details failed");
                   }
                   else
                   {
                       objMultiTenantOutput.ResultStatus = true;
                       objMultiTenantOutput.Output = output.ToString();
                   }
                }
               
               catch (Exception ex)
               {
                   objlog.GetLoggingHandler("Log4net").LogException(ex);
               }
           }
           else
           {
               objMultiTenantOutput.ErrorMessage = new StringBuilder();
               objMultiTenantOutput.ResultStatus = false;
               objMultiTenantOutput.ErrorMessage.Append("Input's can't be null");
           }
           return objMultiTenantOutput;
       }
       /// <summary>
       /// Generates Database through PowerShell Script
       /// </summary>
       /// <param name="MultiTenancyInfo"></param>
       /// <returns>MultiTenantOutput</returns>
       public MultiTenantOutput GenerateDataBase(DatabaseInfo MultiTenancyInfo)
       {
           StringBuilder sb = new StringBuilder();
           MultiTenantOutput objMultiTenantOutput = new MultiTenantOutput();
           objloginfo.Message = ("MultiTenancy - GenerateDataBase - Called.");
           objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           if (MultiTenancyInfo == null)
           {
               MultiTenantOutput objMultiTenancyInfo = new MultiTenantOutput();
               objMultiTenancyInfo.ErrorMessage = new StringBuilder();
               objMultiTenancyInfo.ErrorMessage.Append("MultiTenancy Info can't be null");
               objMultiTenancyInfo.ResultStatus = false;
               return objMultiTenancyInfo;
           }
           if (MultiTenancyInfo.DataBaseName != null || String.IsNullOrEmpty(MultiTenancyInfo.DataBaseName) && MultiTenancyInfo.UserName != null || String.IsNullOrEmpty(MultiTenancyInfo.UserName) && String.IsNullOrEmpty(MultiTenancyInfo.Password) || MultiTenancyInfo.Password != null)
           {
               try
               {
                   PowerShell psExec = PowerShell.Create();                
                   psExec.AddCommand(MultiTenancyInfo.PSScriptPath);
                   psExec.AddArgument(MultiTenancyInfo.ServerName);
                   psExec.AddArgument(MultiTenancyInfo.DataBaseName);
                   psExec.AddArgument(MultiTenancyInfo.UserName);
                   psExec.AddArgument(MultiTenancyInfo.Password);               
                   psExec.AddArgument(MultiTenancyInfo.SQLScriptPath);               
                   Collection<PSObject> results;
                   Collection<ErrorRecord> errors;
                   results = psExec.Invoke();
                   errors = psExec.Streams.Error.ReadAll();

                   if (errors.Count > 0)
                   {
                       foreach (ErrorRecord error in errors)
                       {  
                           sb.AppendLine(error.ToString());
                           objloginfo.Message = (sb.ToString());
                           objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
                       }
                   }
                   else
                   {
                       foreach (PSObject result in results)
                       {                          
                           sb.AppendLine(result.ToString());
                           objloginfo.Message = (sb.ToString());
                           objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
                       }
                   }
                  
                   objMultiTenantOutput.Output = sb.ToString();
               }


               catch (Exception ex)
               {
                   objlog.GetLoggingHandler("Log4net").LogException(ex);
               }
           }
           else
           {
               objMultiTenantOutput.ErrorMessage = new StringBuilder();
               objMultiTenantOutput.ResultStatus = false;
               objMultiTenantOutput.ErrorMessage.Append("Script Generation failed");
               objloginfo.Message = ("Script Generation failed");
               objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
           }
           return objMultiTenantOutput;
       }
    }
}
