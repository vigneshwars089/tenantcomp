﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;



namespace DigiOPS.TechFoundation.AuditSampling
{
   public class RandomAuditorSampling:IAuditSampling
    {
        SamplingDAO SDAORandomAuditor = new SamplingDAO();
        public TransactionListDetails SamplingLogic(TransactionListDetails objTransactionListDetails)
        {
            string Message = objTransactionListDetails.SamplingTechnique + " Auditor Sampling";
            // Message = (SDAORandomAuditor.GetTransListForAutoAlloc(objTransactionListDetails)).ToString();
            return objTransactionListDetails;
        }
    }
}
