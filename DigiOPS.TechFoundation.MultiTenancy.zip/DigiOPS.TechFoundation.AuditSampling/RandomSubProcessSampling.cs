﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace DigiOPS.TechFoundation.AuditSampling
{
    public class RandomSubProcessSampling : BaseAuditSampling
    {
        SamplingDAO SDAORandomSubProcess = new SamplingDAO();
        public override TransactionListDetails SamplingLogic(TransactionListDetails objTransactionListDetails)
        {
            
            string Message = objTransactionListDetails.SamplingTechnique + " Sub-Process Sampling";

            //Getting the sampling Period
            string SamplingPeriod = objTransactionListDetails.SamplingPeriod;

            //Getting the SamplingPercentage
            double SampPercentage = objTransactionListDetails.Percentage;

            //Getting the Transaction Total count
            // int Total = objTransactionListDetails.Total;
            var ProcesedFromDate = objTransactionListDetails.ProcessedFromDate.ToString();
            var ProcesedToDate = objTransactionListDetails.ProcessingToDate.ToString();
           
            //Getting the Transaction Lists
            List<TransactionLists> objTransactionLists = objTransactionListDetails.TransactionLists;

            //Getting the Processor Transaction Details
            var ProcessorAllocatedLists = objTransactionListDetails.TransactionAllocatedLists;


            if (SamplingPeriod == Constants.DAILY)
            {
                /*Grouping the Date */
                var objGrpProcessor = from c in objTransactionLists
                                      where (DateTime.Compare(c.ProcessedDate, Convert.ToDateTime(ProcesedFromDate)) >= 0 && DateTime.Compare(c.ProcessedDate, Convert.ToDateTime(ProcesedToDate)) <= 0)
                                      group c by new { c.ProcessedDate } into Procgrp
                                      select new
                                      {

                                          NoofTransaction = Procgrp.Count(),
                                          ProcessedDate = Procgrp.Key.ProcessedDate

                                      };

                /*Finding the Pending Details for Each Date */
                var GetPendinglist = (from c in objGrpProcessor
                                      join d in ProcessorAllocatedLists on new { c.ProcessedDate } equals new { d.ProcessedDate }

                                      select new
                                      {
                                          TotalRecords = c.NoofTransaction,
                                         
                                          ProcessedDate = d.ProcessedDate,
                                          Allocated = d.Allocated,
                                          Pending = Math.Ceiling((c.NoofTransaction * SampPercentage) / 100)

                                      }).ToList();

                GetPendinglist = (from c in GetPendinglist
                                  select new
                                  {
                                      TotalRecords = c.TotalRecords,
                                    
                                      ProcessedDate = c.ProcessedDate,
                                      Allocated = c.Allocated,
                                      Pending = ((c.Pending <= c.Allocated) ? 0 : c.Pending - c.Allocated)

                                  }).ToList();

                /*Getting the transactions from each Date based on the pending */
                List<TransactionLists> objGetFinalTransactionLists1 = objTransactionLists.GroupBy(a => new {  a.ProcessedDate })
                                        .SelectMany(g => g.Take((int)GetPendinglist.Where(b =>  (b.ProcessedDate == g.Key.ProcessedDate))
                                            .Select(b => b.Pending).DefaultIfEmpty(0).Single())).ToList();

                objTransactionListDetails.TransactionLists = objGetFinalTransactionLists1;
            }
            else if (SamplingPeriod == Constants.Monthly)
            {
              
                /*Getting the Month First Date and Last to Calculate MTD */
                var firstDayOfMonth = new DateTime(objTransactionListDetails.ProcessedFromDate.Year, objTransactionListDetails.ProcessedFromDate.Month, 1);
                var lastDayOfMonth = firstDayOfMonth.AddMonths(1).AddDays(-1);

                /* GEt Total Transactions for the given Month*/
                int Total = (from p in objTransactionListDetails.TransactionLists
                          where (DateTime.Compare(p.ProcessedDate, Convert.ToDateTime(firstDayOfMonth)) >= 0 && DateTime.Compare(p.ProcessedDate, Convert.ToDateTime(lastDayOfMonth)) <= 0)
                          select p
                               ).Count();
                
                /* Calculating the Percentage*/
                double Percntage = Math.Ceiling((Total * SampPercentage) / 100);
               
                /* Calculating the pending transactions*/
                int pen = Convert.ToInt16(Percntage);
                pen = ((pen <= objTransactionListDetails.Allocated) ? 0 : pen - objTransactionListDetails.Allocated);

                TransactionLists objGetFinalTransactionLists = new TransactionLists();
                List<TransactionLists> baseEntityList = new List<TransactionLists>();
                
                /* Getting Random sampled transactions from the transactions list */
                baseEntityList = (from p in objTransactionListDetails.TransactionLists
                                  
                                  where (DateTime.Compare(p.ProcessedDate, Convert.ToDateTime(objTransactionListDetails.ProcessedFromDate)) >= 0 && DateTime.Compare(p.ProcessedDate, Convert.ToDateTime(objTransactionListDetails.ProcessingToDate)) <= 0)
                                  select p
                               )
                               .OrderBy(q => Guid.NewGuid())
                               .Take(pen).ToList();

                objTransactionListDetails.TransactionLists = baseEntityList;

            }

            return objTransactionListDetails;

           

        }
        public string SerializeToString(object value)
        {
            var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
            var serializer = new XmlSerializer(value.GetType());
            var settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.OmitXmlDeclaration = true;

            using (var stream = new StringWriter())
            using (var writer = XmlWriter.Create(stream, settings))
            {
                serializer.Serialize(writer, value, emptyNamepsaces);
                string str = stream.ToString().Replace("ArrayOfTransactionLists", "TransactionList");
                return stream.ToString().Replace("ArrayOfTransactionLists", "TransactionList");

            }
        }
    }

}
