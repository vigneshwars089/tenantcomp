﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;

using System.Data.SqlClient;
using System.Data;

namespace DigiOPS.TechFoundation.AuditSampling
{
    public class AuditSamplingFactory : IAuditSamplingFactory
    {
        public IAuditSampling AuditSamplingHandler(TransactionListDetails objTranDet)
        {
            IAuditSampling objSamplingType = null;

            switch (objTranDet.SamplingTechnique)
            {
                case Constants.RANDOM:

                    switch (objTranDet.SamplingLevel)
                    {
                        case Constants.SUBPROCESS:
                            objSamplingType = new RandomSubProcessSampling();

                            break;
                        case Constants.PROCESSOR:
                            objSamplingType = new RandomProcessorSampling();

                            break;

                        default:
                            objSamplingType = new RandomSubProcessSampling();
                            break;
                    }

                    break;
                case Constants.STATISTICAL:
                    switch (objTranDet.SamplingLevel)
                    {
                        case Constants.SUBPROCESS:
                            objSamplingType = new StatisticalSubProcessSampling();
                            break;

                        default:
                            objSamplingType = new StatisticalSubProcessSampling();
                            break;
                    }
                    break;
                case Constants.STRATIFIED:
                    switch (objTranDet.SamplingLevel)
                    {
                        case Constants.SUBPROCESS:
                            objSamplingType = new StratifiedSubProcessSampling();

                            break;
                        case Constants.PROCESSOR:
                            objSamplingType = new StratifiedProcessorSampling();

                            break;
                        default:
                            objSamplingType = new StratifiedSubProcessSampling();
                            break;
                    }
                    break;
                //case "PropensityScore":
                //    switch (objTranDet.SamplingLevel)
                //    {
                //        case "Sub-Process":
                //            objSamplingType = new PropensityScoreSubProcessSampling();
                //            break;
                //        case "Processor":
                //            objSamplingType = new PropensityScoreProcessorSampling();
                //            break;
                //        case "Auditor":
                //            objSamplingType = new PropensityScoreAuditorSampling();
                //            break;
                //        default:
                //            objSamplingType = new PropensityScoreSubProcessSampling();
                //            break;
                //    }
                //    break;
                default:
                    objSamplingType = new RandomSubProcessSampling();
                    break;
            }
            return objSamplingType;
        }
        public string SetSamplingPercentage(SamplingEntity SE)
        {
            SamplingDAO SDAO = new SamplingDAO();

            string result = (SDAO.AddSamplingPercentage(SE)).ToString();
            return result;
        }
        public List<SamplingEntity> GetSamplingPctDetails(SamplingEntity objSampling)
        {
            SamplingDAO SDAOGet = new SamplingDAO();

            string result = string.Empty;
            result = "GetSampling  ";
            DataTable dt = new DataTable();
            List<SamplingEntity> baseList = new List<SamplingEntity>();
            
            string sSamplingMethodint = objSampling.SamplingType;

            dt = SDAOGet.GetSamplingPctDetails(objSampling);
            if (dt.Rows.Count <= 0)
                return baseList;
            //if (objSampling.samplingMethod == "Associate")
            //{
            //    baseList = GetSamplingPctDetailsForMapper(dt, objSampling.samplingMethod);
            //}
            //else if (objSampling.samplingMethod == "Sub-process")
            //{
            baseList = GetSamplingPctDetailsForMapper(dt, objSampling.samplingMethod);
            //}


            return baseList;

        }


        static internal List<SamplingEntity> GetSamplingPctDetailsForMapper(DataTable dt, string sMapperType)
        {
            List<SamplingEntity> baseEntityList = new List<SamplingEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new SamplingEntity
                              {
                                  szAssociate = sMapperType == "Associate" ? Convert.ToString(p["szAssociate"] == DBNull.Value ? string.Empty : p["szAssociate"]) : string.Empty,
                                  szAuditTypid = Convert.ToInt16(p["iAuditTypeId"] == DBNull.Value ? string.Empty : p["iAuditTypeId"]),
                                  szAuditTypeName = Convert.ToString(p["szAuditTypeName"] == DBNull.Value ? string.Empty : p["szAuditTypeName"]),
                                  dSamplingPct = Convert.ToDecimal(p["dSamplingPct"] == DBNull.Value ? string.Empty : p["dSamplingPct"]),
                                  szModifiedBy = Convert.ToString(p["szModifiedBy"] == DBNull.Value ? string.Empty : p["szModifiedBy"]),
                                  dsModifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"]),
                                  TotalRows = Convert.ToInt32(p["TotalRows"] == DBNull.Value ? 0 : p["TotalRows"]),
                                  RowNumber = Convert.ToInt32(p["RowNumber"] == DBNull.Value ? 0 : p["RowNumber"])
                              }).ToList();

            return baseEntityList;
        }

    }
}
