﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.AuditSampling
{
    class Constants
    {
        #region SAMPLING_TECHNIQUES
        public const string RANDOM = "Random";
        public const string STATISTICAL = "Statistical";
        public const string STRATIFIED = "Stratified";
        public const string PROPENSITYSCORE = "PropensityScore";
        #endregion

        #region SAMPLING_LEVEL
        public const string SUBPROCESS = "Sub-process";
        public const string PROCESSOR = "Processor";
        public const string AUDITOR = "Auditor";
        #endregion

        #region SAMPLING_PERIOD
        public const string DAILY = "Daily";
        public const string Monthly = "Monthly";
        public const string WEEKLY = "Weekly";
        #endregion
    }
}
