﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.MetricManagement
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :BaseScoringAlgorithm.cs
    // Namespace : DigiOps.TechFoundation.MetricManagement
    // Class Name(s) :BaseScoringAlgorithm
    // Author : Sujitha
    // Creation Date : 17/4/2017
    // Purpose : Base Method 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
    //////////////////////////////////////////////////////////////////////////////////////////////////////

    public class BaseScoringAlgorithm : IScoringAlgorithm
    {

        public ScoringOutput CalculateQualityScore(ScoringInfo objAuditDataEntity)
        {
            ScoringOutput scoringout = new ScoringOutput();


            scoringout = Validation(objAuditDataEntity);

            if (scoringout.ResultStatus)
            {
                if (objAuditDataEntity._IsCriticalApp == "True")
                {
                    scoringout = GenerateCriticalityQualityScore(objAuditDataEntity);
                }
                else
                {
                    scoringout = GenerateQualityScore(objAuditDataEntity);
                }
            }
            return scoringout;
        }

        public ScoringOutput CalculateQualityScore(List<ScoringInfo> objAuditDataEntity)
        {
            ScoringOutput scoringout = new ScoringOutput();

            scoringout = GenerateQualityScore(objAuditDataEntity);


            return scoringout;
        }

        public virtual ScoringOutput GenerateCriticalityQualityScore(ScoringInfo objAuditDataEntity)
        {

            return null;
        }

        public virtual ScoringOutput GenerateQualityScore(ScoringInfo objAuditDataEntity)
        {

            return null;
        }
        public virtual ScoringOutput GenerateQualityScore(List<ScoringInfo> objAuditDataEntity)
        {

            return null;
        }

        public ScoringOutput Validation(ScoringInfo objAuditDataEntity)
        {
            ScoringOutput objResponseInfo = new ScoringOutput();
            objResponseInfo.ErrorMessage = new StringBuilder();
            if (objAuditDataEntity == null)
            {
                objResponseInfo.ErrorMessage.Append("Scoring Info can't be null");
                objResponseInfo.ResultStatus = false;
                return objResponseInfo;
            }

            DetailsEntity objDetailsEntity = new DetailsEntity();
            List<DetailsEntity> objdetailslist = new List<DetailsEntity>(objAuditDataEntity.AuditedList);
            int flag = 0;

            objResponseInfo.ResultStatus = false;

            if ((objAuditDataEntity._strScoringLogic == "" || String.IsNullOrEmpty(objAuditDataEntity._strScoringLogic)) || (objAuditDataEntity._strAuditlogic == "" || String.IsNullOrEmpty(objAuditDataEntity._strAuditlogic)))
            {
                objResponseInfo.ErrorMessage.Append("Scoring Handler Input's can't be null");
                objResponseInfo.ResultStatus = false;
                return objResponseInfo;

            }

            else if ((objAuditDataEntity._strScoringLogic.ToUpper().Trim() == "HEADING BASED" || objAuditDataEntity._strScoringLogic.ToUpper().Trim() == "CHECKPOINT BASED" || objAuditDataEntity._strScoringLogic.ToUpper().Trim() == "GROUP BASED") && (objAuditDataEntity._strAuditlogic.ToUpper().Trim() == "DPO" || objAuditDataEntity._strAuditlogic.ToUpper().Trim() == "WDPO" || objAuditDataEntity._strAuditlogic.ToUpper().Trim() == "DPU" || objAuditDataEntity._strAuditlogic.ToUpper().Trim() == "DEDUCTIVEWDPO"))
            {
                switch (objAuditDataEntity._strScoringLogic.ToUpper().Trim())
                {

                    case "HEADING BASED":
                        foreach (var a in objdetailslist)
                        {
                            objDetailsEntity.MaxWeightage = a.MaxWeightage;
                            objDetailsEntity.GivenWeightage = a.GivenWeightage;
                            objDetailsEntity.ParentDOId = a.ParentDOId;
                            objDetailsEntity.DOGroupID = a.DOGroupID;
                            objDetailsEntity.GroupWeightage = a.GroupWeightage;
                            if (objDetailsEntity.MaxWeightage < 0.0 || objDetailsEntity.GivenWeightage < -1 || objDetailsEntity.MaxWeightage > 100.0 || objDetailsEntity.GivenWeightage > 100.0)
                                flag = 2;
                            else if (objDetailsEntity.DOGroupID < 1 || objDetailsEntity.ParentDOId < 1)
                                flag = 0;
                            else if ((objAuditDataEntity._strAuditlogic.ToUpper().Trim() == "COMBINED") && (objDetailsEntity.GroupWeightage < 0.0))
                            {
                                flag = 4;
                            }
                            else
                                flag = 1;
                        }
                        break;
                    case "CHECKPOINT BASED":
                        foreach (var a in objdetailslist)
                        {
                            objDetailsEntity.MaxWeightage = a.MaxWeightage;
                            objDetailsEntity.GivenWeightage = a.GivenWeightage;
                            objDetailsEntity.ParentDOId = a.ParentDOId;
                            objDetailsEntity.DOGroupID = a.DOGroupID;
                            objDetailsEntity.GroupWeightage = a.GroupWeightage;
                            if (objDetailsEntity.MaxWeightage < 0.0 || objDetailsEntity.GivenWeightage < -1 || objDetailsEntity.MaxWeightage > 100.0 || objDetailsEntity.GivenWeightage > 100.0)
                                flag = 2;
                            else if ((objAuditDataEntity._strAuditlogic.ToUpper().Trim() == "COMBINED") && (objDetailsEntity.GroupWeightage < 0.0))
                            {
                                flag = 4;
                            }

                            else
                                flag = 1;
                        }
                        break;
                    case "GROUP BASED":
                        foreach (var a in objdetailslist)
                        {
                            objDetailsEntity.MaxWeightage = a.MaxWeightage;
                            objDetailsEntity.GivenWeightage = a.GivenWeightage;
                            objDetailsEntity.ParentDOId = a.ParentDOId;
                            objDetailsEntity.DOGroupID = a.DOGroupID;
                            objDetailsEntity.GroupWeightage = a.GroupWeightage;

                            if (objDetailsEntity.GivenWeightage < -1 || objDetailsEntity.GroupWeightage < 0.0 || objDetailsEntity.GivenWeightage > 100.0 || objDetailsEntity.GroupWeightage > 100.0)
                                flag = 2;
                            else if (objDetailsEntity.DOGroupID == 0)
                                flag = 0;
                            else if (objAuditDataEntity._strAuditlogic.ToUpper().Trim() == "DeductiveWDPO")
                                flag = 3;
                            else
                                flag = 1;

                        }
                        break;

                }
                if (flag == 1)
                {
                    // objResponseInfo = CalculateQualityScore(objAuditDataEntity);
                    objResponseInfo.ResultStatus = true;
                }
                else if (flag == 0)
                {
                    objResponseInfo.ResultStatus = false;
                    objResponseInfo.ErrorMessage.Append("MaxWeightage,GivenWeightage,DOGroupID,GroupWeightage and ParentDOId can't be null");
                    return objResponseInfo;
                }
                else if (flag == 2)
                {
                    objResponseInfo.ResultStatus = false;
                    objResponseInfo.ErrorMessage.Append("Weightage values have to be within -1 to 100");
                    return objResponseInfo;
                }
                else if (flag == 3)
                {
                    objResponseInfo.ResultStatus = false;
                    objResponseInfo.ErrorMessage.Append("Deductive WDPO not applicable for Group Based");
                    return objResponseInfo;
                }
                else if (flag == 3)
                {
                    objResponseInfo.ResultStatus = false;
                    objResponseInfo.ErrorMessage.Append("Group Weightage is needed for Combined Scoring");
                    return objResponseInfo;
                }
            }
            else
            {
                objResponseInfo.ErrorMessage.Append("Input's are not in the standard format");
                objResponseInfo.ResultStatus = false;
            }

            return objResponseInfo;
        }

    }
}
