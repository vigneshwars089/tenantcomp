﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.MetricManagement
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :DPUScoreAlgorithm.cs
    // Namespace : DigiOps.TechFoundation.MetricManagement
    // Class Name(s) :DPUScoreAlgorithm
    // Author : Sujitha
    // Creation Date : 17/4/2017
    // Purpose : Base Method 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX     
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    public class DPUScoreAlgorithm: BaseScoringAlgorithm
    {
        
    }
}
