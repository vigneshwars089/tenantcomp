﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.MetricManagement
{
    ////////////////////////////////////////////////////////////////////////////////////
    // Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
    ////////////////////////////////////////////////////////////////////////////////////
    // File Name :DeductiveWDPOHeading.cs
    // Namespace : DigiOps.TechFoundation.MetricManagement
    // Class Name(s) :DeductiveWDPOHeading
    // Author : 
    // Creation Date : 17/4/2017
    // Purpose : Base Method 
    //////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
    // Date           Name         Method Name               Description
    // ----------   --------    -------------------------- --------------------------------------------------
    //16-Apr-2017    XXXXX     GenerateQualityScore            Generate QualityScore  
    //////////////////////////////////////////////////////////////////////////////////////////////////////
  public  class DeductiveWDPOHeading : WDPOScoreAlgorithm
    {
        public override ScoringOutput GenerateQualityScore(ScoringInfo objAuditDataEntity)
        {
            ScoringOutput objScoringOutput = new ScoringOutput();
            ScoringAlgorithmInfo scoringAlgorithmInfo = new ScoringAlgorithmInfo();

            scoringAlgorithmInfo._QualityScore = 0.0;
            scoringAlgorithmInfo._CriticalityChecked = 0;
            scoringAlgorithmInfo._totAppDefects = 0;
            scoringAlgorithmInfo._totHeadings = 0;
            scoringAlgorithmInfo._totAppHeadings = 0;
            scoringAlgorithmInfo._totAppHeadingsDefects = 0;
            scoringAlgorithmInfo._totHeadings_W = 0.0;
            scoringAlgorithmInfo._totAppHeadings_W = 0.0;
            scoringAlgorithmInfo._totAppHeadingsWDPO_W = 0.0;
            scoringAlgorithmInfo._totHeadingsWDPO_W = 0.0;
            scoringAlgorithmInfo._totErrorField = 0;
            scoringAlgorithmInfo._ErrorFieldScore = 0.0;
            scoringAlgorithmInfo._ErrorFieldQualityScore = 0.0;

            scoringAlgorithmInfo._CriticalityChecked = objAuditDataEntity.AuditedList
                                   .Where(m => m.MaxWeightage > m.GivenWeightage && m.GivenWeightage != -1 && m.CriticalityType == "Fatal").Count();


            var _Headings = objAuditDataEntity.AuditedList.GroupBy(m => m.ParentDOId).ToArray();

            foreach (var _Heading in _Headings)
            {
                double _Heading_W = _Heading
                                    .Select(m => m.MaxWeightage)
                                    .FirstOrDefault();

                double HeadingsDefects_W = _Heading
                                        .Where(x => x.GivenWeightage < _Heading_W && x.GivenWeightage != -1)
                                        .Select(x => x.GivenWeightage)
                                         .FirstOrDefault();

                int _AppHeading = _Heading
                                    .Where(x => x.GivenWeightage != -1)
                                    .GroupBy(x => x.DOGroupID)
                                    .Count();

                int _AppHeadingDefects = _Heading
                                           .Where(x => x.GivenWeightage < _Heading_W && x.GivenWeightage != -1)
                                           .GroupBy(x => x.DOGroupID)
                                           .Count();

                int _AppHeadingsNoDefects = 0;



                _AppHeadingsNoDefects = (_AppHeading == 0) ? 0 : 1;
                if (_AppHeading < 1)
                {
                    _Heading_W = 0;
                }
                if (_AppHeadingDefects == 1)
                {
                    HeadingsDefects_W = _Heading
                                            .Where(x => x.GivenWeightage < _Heading_W && x.GivenWeightage != -1)
                                            .Select(x => x.GivenWeightage)
                                            .Min();
                }



                scoringAlgorithmInfo._totHeadings_W = scoringAlgorithmInfo._totHeadings_W + _Heading_W;

                scoringAlgorithmInfo._totAppHeadings = scoringAlgorithmInfo._totAppHeadings + _AppHeading;
                scoringAlgorithmInfo._totAppHeadings_W = scoringAlgorithmInfo._totAppHeadings_W + (_AppHeading * _Heading_W);

                scoringAlgorithmInfo._totAppHeadingsDefects = scoringAlgorithmInfo._totAppHeadingsDefects + _AppHeadingDefects;


                if (_AppHeadingDefects == 1)
                {
                    scoringAlgorithmInfo._totHeadingsWDPO_W = scoringAlgorithmInfo._totHeadingsWDPO_W + _Heading_W;
                    scoringAlgorithmInfo._totAppHeadingsWDPO_W = scoringAlgorithmInfo._totAppHeadingsWDPO_W + HeadingsDefects_W;
                }
                else
                {
                    scoringAlgorithmInfo._totHeadingsWDPO_W = scoringAlgorithmInfo._totHeadingsWDPO_W + _Heading_W;
                    scoringAlgorithmInfo._totAppHeadingsWDPO_W = scoringAlgorithmInfo._totAppHeadingsWDPO_W + _Heading_W;

                }

            }


            if (scoringAlgorithmInfo._CriticalityChecked > 0)
            {
                scoringAlgorithmInfo._QualityScore = 0.0;
                scoringAlgorithmInfo._auditedData.FieldQualityScore = 0;
                objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
            }
            else
            {
                double QualityScore = (scoringAlgorithmInfo._totAppHeadingsWDPO_W > 100) ? 0 : (100 - scoringAlgorithmInfo._totAppHeadingsWDPO_W);

               // scoringAlgorithmInfo._QualityScore = scoringAlgorithmInfo._totAppHeadingsDefects == 0 ? 1 : (scoringAlgorithmInfo._totAppHeadingsWDPO_W) / (scoringAlgorithmInfo._totHeadingsWDPO_W);
                scoringAlgorithmInfo._QualityScore = QualityScore;
                //scoringAlgorithmInfo._QualityScore = Math.Round(scoringAlgorithmInfo._QualityScore, 4) * 100;
                objScoringOutput.QualityScore = scoringAlgorithmInfo._QualityScore;
            }
            objScoringOutput.ResultStatus = true;
            return objScoringOutput;

        }

    }
}
