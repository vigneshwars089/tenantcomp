﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Notification
{
    public class CollaborationInfo : BaseCollaboration
    {
    }
    public struct S_CollaborationType
    {
        public const string EMail = "EMail";

    }
    public struct S_TemplateType
    {
        public const string EMail = "EMail";

    }
}
