﻿using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Security;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI.WebControls;
using System.Xml;

namespace DigiOPS.TechFoundation.Notification
{
   public class SupportTicket 
    {
       static bool mailSent = false;
       LogInfo objLogInfo = new LogInfo();
       ILoggingFactory objLogging = new LoggingFactory();
        SupportTicketDAO supportDAOSupportTkt = new SupportTicketDAO();
        DataTable dt = new DataTable();
        public  void GetTicket()
       {
           LogInfo objLogInfo = new LogInfo();
           ILoggingFactory objLogging = new LoggingFactory();
           objLogInfo.Message = "SubProcessConfigurationController - SupportTicket - Called.";
           objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
         //  ProxyLogger.Log.Info("SubProcessConfigurationController - SupportTicket - Called.");

           try
           {
               string Msg = string.Empty;
               //if (TempData["SupportTicketMsg"] != null)
               //{
               //    Msg = Convert.ToString(TempData["SupportTicketMsg"]);
               //}
               //TempData["SupportTicketMsg"] = null;

               SupportTicketEntity obj = new SupportTicketEntity();

               obj.CustomMessage = Msg;
              // return View("Queries", obj);

           }
           catch (ApplicationException ex)
           {
              // ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);

               throw ex;
           }
           catch (Exception ex)
           {
               //ProxyLogger.Log.Error(ex.Message); ProxyLogger.Log.Error(ex.StackTrace);

               throw ex;
           }
       }

        public  void SaveTicket(SupportTicketEntity objTicket, HttpPostedFileBase file)
       { 
          
           objLogInfo.Message = "SubProcessConfigurationController - SetSupportTicket - Called.";
           objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
          // ProxyLogger.Log.Info("SubProcessConfigurationController - SetSupportTicket - Called.");
            string message = string.Empty;
            var fileName = string.Empty;
            string createRecVal = string.Empty;
            string result = string.Empty;
           
            
            BaseTransportEntity objBase = new BaseTransportEntity();
            try
            {       
                {
                    createRecVal = supportDAOSupportTkt.SetSupportTicket(objTicket);
                }
                int _result;
                SupportTicketSendMailEntity _SMEObj = new SupportTicketSendMailEntity();
                _SMEObj = SendingMail(_SMEObj);
                _result = _SMEObj.bMailSent == true ? 1 : -1;
                try
                {

                    if (_SMEObj != null)
                    {
                        _SMEObj.EntityName = "MailInsertion";
                        _SMEObj.IssueId = int.Parse(result);
                        if (fileName != string.Empty)
                            _SMEObj.FileName = fileName;

                        _SMEObj.Sender = System.Configuration.ConfigurationManager.AppSettings["SupportMail"].ToString();
                        //objBase = (BaseTransportEntity)_SMEObj;
                        //objBAL.SetEntity(objBase);
                    }
                }

                catch (ArgumentException Ex)
                {
                    objLogging.GetLoggingHandler("Log4net").LogException(Ex);
                    // ProxyLogger.Log.Error(Ex.Message + "Mail Sent Tracker Issue"); ProxyLogger.Log.Error(Ex.StackTrace);
                }
                catch (NotImplementedException Ex)
                {
                    objLogging.GetLoggingHandler("Log4net").LogException(Ex);
                    //ProxyLogger.Log.Error(Ex.Message + "Mail Sent Tracker Issue"); ProxyLogger.Log.Error(Ex.StackTrace);
                }
                catch (FormatException Ex)
                {
                    objLogging.GetLoggingHandler("Log4net").LogException(Ex);
                    // ProxyLogger.Log.Error(Ex.Message + "Mail Sent Tracker Issue"); ProxyLogger.Log.Error(Ex.StackTrace);
                }
                catch (OverflowException Ex)
                {
                    objLogging.GetLoggingHandler("Log4net").LogException(Ex);
                    //ProxyLogger.Log.Error(Ex.Message + "Mail Sent Tracker Issue"); ProxyLogger.Log.Error(Ex.StackTrace);
                }
                catch (ApplicationException Ex)
                {
                    objLogging.GetLoggingHandler("Log4net").LogException(Ex);
                    // ProxyLogger.Log.Error(Ex.Message + "Mail Sent Tracker Issue"); ProxyLogger.Log.Error(Ex.StackTrace);
                }
                catch (Exception Ex)
                {
                    objLogging.GetLoggingHandler("Log4net").LogException(Ex);
                    // ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
                }
            }
            catch (InvalidCastException Ex)
            {
                // proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
            }
        }      

        public  SupportTicketViewModel GetSupportTicketByList(string sortOrder = null, string sortColumn = null, int? startRowIndex = null, string strMsg = null)
       {
           //ProxyLogger.Log.Info("ProgramSupportTicketController - GetSupportTicketByList - Called.");
           objLogInfo.Message = "ProgramSupportTicketController - GetSupportTicketByList - Called.";
           objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);

           SupportTicketViewModel model = new SupportTicketViewModel();

           try
           {
               int maximumRows = 0;

               maximumRows = Convert.ToInt16(ConfigurationManager.AppSettings["PageSize"]);

               string FileName = System.Web.HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["SupportTicket_UPLD_PATH"]);


               SupportTicketEntity objIssueEntity = new SupportTicketEntity();


               int CurrentRoleId = 0;
               if (HttpContext.Current.Session[Constants.ROLEID] != null)
               {
                   CurrentRoleId = Convert.ToInt32(HttpContext.Current.Session[Constants.ROLEID]);
               }

               model.CurrentUserRoleID = CurrentRoleId;

               // objIssueEntity.EntityName = Constants.ENTITY_SupportTicket;

               objIssueEntity.FileName = FileName;

               objIssueEntity.StartRowIndex = startRowIndex.HasValue ? startRowIndex.Value : 1;
               objIssueEntity.SortColumn = !(string.IsNullOrEmpty(sortColumn)) ? sortColumn : "iIssueId";
               objIssueEntity.SortOrder = !(string.IsNullOrEmpty(sortOrder)) ? sortOrder : "DESC";
               objIssueEntity.MaximumRows = (int)maximumRows;


               objIssueEntity.ViewName = "ProgramIssueConfig";

            
              // model.SupportTicketList = _objBAL.GetEntityList(objIssueEntity).Cast<SupportTicketEntity>().ToList();
                dt = supportDAOSupportTkt.GetSupportTicketEntityList(objIssueEntity);
                if (dt.Rows.Count <= 0)
                    return null;                    
                model.SupportTicketList = MapToSupportTicketList(dt).Cast<SupportTicketEntity>().ToList(); ;
               

                if (model.SupportTicketList.Any())
               {

                   model.SupportTicket.SortColumn = !(string.IsNullOrEmpty(sortColumn)) ? sortColumn : "iIssueId";
                   model.SupportTicket.StartRowIndex = startRowIndex.HasValue ? startRowIndex.Value : 1;
                   model.SupportTicket.SortOrder = !(string.IsNullOrEmpty(sortOrder)) ? sortOrder : "DESC";
                   model.SupportTicket.TotalRows = model.SupportTicketList.FirstOrDefault().TotalRows;
                   model.SupportTicket.MaximumRows = maximumRows;
               }

               model.CustomMessage = strMsg;

               return model;

           }
           catch (ConfigurationErrorsException Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
               // ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           catch (InvalidCastException Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
               // ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           catch (InvalidOperationException Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
               // ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           catch (ArgumentException Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
               // ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           catch (ApplicationException Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
               //  ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           catch (Exception Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
               //ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           return model;
       }

        /// <summary>
        /// Methos to Get Supprot Ticket Trial By List 
        /// </summary>
        /// <param name="IssueId">int</param>
        /// <returns>SupportTicketTrailModel</returns>
        public  SupportTicketTrailModel GetSupportTicketTrailByList(int IssueId)
       {
           //ProxyLogger.Log.Info("ProgramSupportTicketController - GetSupportTicketTrailByList - Called.");
           objLogInfo.Message = "ProgramSupportTicketController -  GetSupportTicketTrailByList - Called.";
           objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);

           SupportTicketTrailModel modelTicketTrail = new SupportTicketTrailModel();

           SupportTicketTrailEntity objTicketTrailEntity = new SupportTicketTrailEntity();

           try
           {
               objTicketTrailEntity.IssueId = IssueId;
            
             //  modelTicketTrail.SupportTicketTrailList = _objBAL.GetEntityList(objTicketTrailEntity).Cast<SupportTicketTrailEntity>().ToList();
                dt = supportDAOSupportTkt.GetSupportTicketEntityTrailList(objTicketTrailEntity);
                if (dt.Rows.Count <= 0)
                    return null;
                modelTicketTrail.SupportTicketTrailList = MapToSupportTicketTrailList(dt).Cast<SupportTicketTrailEntity>().ToList();

            }
           catch (ApplicationException Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
               //ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           catch (Exception Ex)
           {
              // ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }

           return modelTicketTrail;

       }

        /// <summary>
        /// Method to Get Support Ticket By Give Issue ID
        /// </summary>
        /// <param name="IssueId">int</param>
        /// <returns>SupportTicketViewModel</returns>
        public  SupportTicketViewModel GetSupportTicketById(int IssueId)
       {
          // ProxyLogger.Log.Info("ProgramSupportTicketController - GetSupportTicketById - Called.");
           objLogInfo.Message = "ProgramSupportTicketController -  GetSupportTicketById - Called.";
           objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);

           SupportTicketEntity objTicketEntity = new SupportTicketEntity();
           SupportTicketEntity objSupportTicketEntity = new SupportTicketEntity();
           SupportTicketViewModel objSupportTicketViewmodel = new SupportTicketViewModel();
           DataTable dt = new DataTable();
           try
           {
               objTicketEntity.IssueId = IssueId;

               string XmlSupportTicketPath = ConfigurationManager.AppSettings["SupportConfig"];

                // BaseTransportEntity objbase = _objBAL.GetEntity((BaseTransportEntity)objTicketEntity);
                dt = supportDAOSupportTkt.GetSupportTicketById(objTicketEntity);
                objSupportTicketEntity = MapSupportTicketById(dt);
               
               SupportTicketDAO supportdao = new SupportTicketDAO();           

              

               XmlDocument xmlDoc = new XmlDocument();
               xmlDoc.Load(HttpContext.Current.Server.MapPath(XmlSupportTicketPath));

               XmlNodeList itemModules = xmlDoc.SelectNodes("//Issue/IssueModule");

               DropDownEntity ddlModule = new DropDownEntity();
               TransDropDown transddl = null;

               if (itemModules != null)
               {

                   for (int i = 0; i < itemModules.Count; i++)
                   {

                       transddl = new TransDropDown();

                       transddl.Text = itemModules[i].Attributes["Text"].Value;

                       transddl.Value = itemModules[i].Attributes["Value"].Value;

                       ddlModule.SupportIssueModuleList.Add(transddl);
                   }
               }
               objSupportTicketEntity.ddlIssueModule = ddlModule;

               string strIssueMod = objSupportTicketEntity.SelectedIssueModule;

               XmlNode itemTypes = xmlDoc.SelectSingleNode("//Issue//IssueModule[@Value='" + strIssueMod + "']");

               DropDownEntity ddlType = new DropDownEntity();
               if (itemTypes != null)
               {
                   foreach (XmlNode itemType in itemTypes)
                   {

                       transddl = new TransDropDown();



                       transddl.Text = itemType.Attributes["Text"].Value;

                       transddl.Value = itemType.Attributes["Value"].Value;

                       ddlType.SupportIssueTypeList.Add(transddl);


                   }
               }
               objSupportTicketEntity.ddlIssueType = ddlType;

               XmlNode itemPriorities = xmlDoc.SelectSingleNode("//Issue/IssuePriority");

               DropDownEntity ddlPriority = new DropDownEntity();
               if (itemPriorities != null)
               {
                   foreach (XmlNode itemPriority in itemPriorities)
                   {

                       transddl = new TransDropDown();

                       transddl.Text = itemPriority.Attributes["Text"].Value;

                       transddl.Value = itemPriority.Attributes["Value"].Value;

                       ddlPriority.SupportIssuePriporityList.Add(transddl);
                   }
               }

               objSupportTicketEntity.ddlIssuePriority = ddlPriority;

               objSupportTicketEntity.IssueId = IssueId;

               List<TransDropDown> StatusList = GetStatusList();

               objSupportTicketViewmodel.ddlSupportStatus.SupportIssueStatusList = StatusList;

               objSupportTicketViewmodel.SupportTicket = objSupportTicketEntity;

               objSupportTicketViewmodel.SupportTicket.Comments = "";



           }
           catch (NotImplementedException Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
              // ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           catch (ArgumentException Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
              // ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           catch (XmlException Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
             //  ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           catch (ApplicationException Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
              // ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           catch (Exception Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
             //  ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }

           return objSupportTicketViewmodel;

       }


        /// <summary>
        /// Method to Upload Support Ticket by List 
        /// </summary>
        /// <param name="IssueId">string</param>
        /// <param name="strModule">string</param>
        /// <param name="strType">string</param>
        /// <param name="strPriority">string</param>
        /// <param name="strStatus">string</param>
        /// <param name="strEffort">string</param>
        /// <param name="strComments">string</param>
        /// <returns></returns>

        public  string UpdateSupportTicketById(string IssueId, string strModule, string strType, string strPriority, string strStatus, string strEffort, string strComments)
       {
          // ProxyLogger.Log.Info("ProgramSupportTicketController - UpdateSupportTicketById - Called.");
           objLogInfo.Message = "ProgramSupportTicketController -  UpdateSupportTicketById - Called.";
           objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);

           string strMessage = ""; 

            SupportTicketEntity objTicketEntity = new SupportTicketEntity();

           try
           {
               string result = "";



               objTicketEntity.IssueId = Convert.ToInt32(IssueId);
               objTicketEntity.SelectedIssueModule = strModule;
               objTicketEntity.SelectedIssueType = strType;
               objTicketEntity.SelectedPriorityType = strPriority;
               objTicketEntity.SelectedStatus = strStatus;
               objTicketEntity.WorkEffort = Convert.ToSingle(strEffort.ToString());
               objTicketEntity.Comments = strComments;
               objTicketEntity.Action = Constants.ACTION_Update;
               objTicketEntity.ViewName = Constants.ACTION_Update;
               objTicketEntity.ModifiedBy = HttpContext.Current.Session["SYSUSERID"].ToString();

               result =  supportDAOSupportTkt.SetSupportTicketTrail(objTicketEntity);
                //_objBAL.SetEntity((BaseTransportEntity)objTicketEntity);

                if (result == Constants.SUCCESS)
               {
                   strMessage = "Ticket details updated sucessfully!";
               }
               else if (result == Constants.ALREADYEXISTS)
               {
                   strMessage = "Overall work effort should not exceed 100!";
               }
               else if (result == Constants.FAILURE)
               {
                   strMessage = "Ticket details updation failed!";
               }

           }
           catch (FormatException Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
              // ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           catch (OverflowException Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
              // ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           catch (ApplicationException Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
              // ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }
           catch (Exception Ex)
           {
               objLogging.GetLoggingHandler("Log4net").LogException(Ex);
             //  ProxyLogger.Log.Error(Ex.Message); ProxyLogger.Log.Error(Ex.StackTrace);
           }

           return strMessage;

       }


        /// <summary>
        /// Method to Get Status List
        /// </summary>
        /// <returns>List of DropDown values</returns>
        public  List<TransDropDown> GetStatusList()
       {
           List<TransDropDown> lstStatus = new List<TransDropDown>();
           SupportTicketEntity objEntity = new SupportTicketEntity();
           if (HttpContext.Current.Session[Constants.SYSUSERID] != null)
           {
               objEntity.CurrentUserID = int.Parse(HttpContext.Current.Session[Constants.SYSUSERID].ToString());
               objEntity.CurrentUserRoleID = int.Parse(HttpContext.Current.Session[Constants.ROLEID].ToString());
               objEntity.ViewName = Constants.ENTITY_SupportTicketStatus;
                // lstStatus = _objBAL.GetEntityList(objEntity).Cast<TransDropDown>().ToList();
                dt = supportDAOSupportTkt.GetSupportTicketStatus(objEntity);
            }
            if (dt.Rows.Count <= 0)
                return null;
            lstStatus = MapToDropDownList(dt).Cast<TransDropDown>().ToList(); 
            return lstStatus;
            
       }

        /// <summary>
        /// Method to send mail for Support Ticket
        /// </summary>
        /// <param name="_Sendmail">SupportTicketSendMailEntity</param>
        /// <returns>SupportTicketSendMailEntity</returns>
        private SupportTicketSendMailEntity SendingMail(SupportTicketSendMailEntity _Sendmail)
        {
            SupportTicketSendMailEntity __SentData = new SupportTicketSendMailEntity();

            try
            {
                System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage();
                string strSubj = string.Empty;
                string strFrom = string.Empty;
                string strTo = string.Empty;
                string strCC = string.Empty;
                string MailName = GetDecodedConfigValue("SupportMailName"); //Utility.Conversion.GetDecodedConfigValue("SupportMailName");
                string Port = System.Configuration.ConfigurationManager.AppSettings["Port"].ToString();
                string Host = System.Configuration.ConfigurationManager.AppSettings["Host"].ToString();
                string PATH = System.Configuration.ConfigurationManager.AppSettings["MailImgPath"].ToString();
                strTo = System.Configuration.ConfigurationManager.AppSettings["SupportTicketToEmailID"].ToString();
                strCC = System.Configuration.ConfigurationManager.AppSettings["SupportTicketCCEmailID"].ToString();
                var Attachmentpath = System.Configuration.ConfigurationManager.AppSettings["SupportTicket_UPLD_PATH"].ToString();

                StringBuilder objTransactionDetails = new StringBuilder();
                StringBuilder objBindAuditDetails = new StringBuilder();
                StringBuilder objBindAuditFeedBackDetails = new StringBuilder();

                string FPath = HttpContext.Current.Server.MapPath(PATH);

                //now create the HTML version
                strFrom = _Sendmail.Sender;
                MailDefinition message = new MailDefinition();
                message.From = strFrom;

                /*Mailer body - Attaching Html to Mail body*/
                message.BodyFileName = FPath + "\\" + "SupportTicketMail.html";
                message.IsBodyHtml = true;
                /*start->attach the images using in the template*/
                EmbeddedMailObject emo = new EmbeddedMailObject();
                emo.Path = FPath + "\\" + "greenarrow.png";
                emo.Name = "cogicon";
                EmbeddedMailObject emo1 = new EmbeddedMailObject();
                emo1.Path = FPath + "\\" + "CognizantLOGrey.png";
                emo1.Name = "cogfooterr";
                EmbeddedMailObject emo2 = new EmbeddedMailObject();
                emo2.Path = FPath + "\\" + "HeaderImg.png";
                emo2.Name = "cogheader";
                message.EmbeddedObjects.Add(emo);
                message.EmbeddedObjects.Add(emo1);
                message.EmbeddedObjects.Add(emo2);


                objTransactionDetails.Append(" <table width='100%' border='1' style='border: solid 1px #848484;border-collapse: collapse; border-spacing: 0;border-radius: 0 0 10px 0;table-layout:fixed;'>");
                objTransactionDetails.Append("<tr style='vertical-align:middle;'><td style='width: 25%;background:#DDEFEF;'> <b>Ticket ID</b> </td><td style='width: 75%;word-wrap:break-word;'>" + _Sendmail.IssueId + "</td></tr>");
                objTransactionDetails.Append("<tr style='vertical-align:middle;'><td style='width: 25%;background:#DDEFEF;'> <b>User Name</b> </td><td style='width: 75%;word-wrap:break-word;'>" + _Sendmail.UserName + "</td></tr><tr style='vertical-align:middle;'><td style='width: 25%;background:#DDEFEF;'> <b>User ID</b> </td><td style='width: 75%;word-wrap:break-word;'>" + _Sendmail.UserID + "</td></tr>");
                objTransactionDetails.Append("<tr style='vertical-align:middle;'><td style='width: 25%;background:#DDEFEF;'> <b>Email ID</b> </td><td style='width: 75%;word-wrap:break-word;'>" + _Sendmail.EmailId + "</td></tr><tr style='vertical-align:middle;'><td style='width: 25%;background:#DDEFEF;'> <b>Issue Summary</b> </td><td style='width: 75%;word-wrap:break-word;'>" + _Sendmail.IssueSummary + "</td></tr>");
                objTransactionDetails.Append("<tr style='vertical-align:middle;'><td style='width: 25%;background:#DDEFEF;'> <b>Issue Description</b> </td><td style='width: 75%;word-wrap:break-word;'>" + _Sendmail.IssueDescription + "</td></tr>");
                objTransactionDetails.Append(" </tr></table>");

                strSubj = "New Support Ticket Raised - ID: " + _Sendmail.IssueId;

                ListDictionary replacements = new ListDictionary();
                if (!string.IsNullOrWhiteSpace(Convert.ToString(objTransactionDetails)))
                    replacements.Add("<% BindSupportTicketDetails %>", objTransactionDetails.ToString());

                msg = message.CreateMailMessage(strTo, replacements, new Label());
                AlternateView htmlView = AlternateView.CreateAlternateViewFromString(msg.Body, null, "text/html");
                msg.AlternateViews.Add(htmlView);

                msg.From = new MailAddress(strFrom, MailName, System.Text.Encoding.UTF8);
                msg.Subject = strSubj;
                msg.SubjectEncoding = System.Text.Encoding.UTF8;
                msg.IsBodyHtml = true;
                msg.Priority = MailPriority.High;

                if (_Sendmail.FileName != string.Empty && _Sendmail.FileName != null)
                {
                    Attachment objattach = null;
                    objattach = new Attachment(HttpContext.Current.Server.MapPath(Attachmentpath) + _Sendmail.IssueId + "\\" + _Sendmail.FileName);
                    objattach.Name = _Sendmail.FileName.ToString();
                    msg.Attachments.Add(objattach);
                }

                __SentData.szSentTo = strTo;
                __SentData.szSentFrom = strFrom;
                __SentData.szSentSubj = strSubj;
                __SentData.UserID = _Sendmail.UserID;

                MailCollaboration objMailCollaboration = new MailCollaboration();
                SmtpClient client = new SmtpClient();
                object userstate1 = new object();
                client.Port = Convert.ToInt32(Port);
                client.Host = Host;
                client.EnableSsl = false;
                client.SendCompleted += objMailCollaboration.client_SendCompleted;
                object userState = msg;

                client.Send(msg);
                mailSent = true;
            }
            catch (InvalidOperationException ex)
            {
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            }
            catch (ConfigurationErrorsException ex)
            {
                //  proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            }
            catch (HttpException ex)
            {
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            }
            catch (ArgumentException ex)
            {
                //  proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            }
            catch (SmtpException ex)
            {
                //  proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            }
            catch (ApplicationException ex)
            {
                // proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            }

            __SentData.bMailSent = mailSent;
            return __SentData;
        }

        private static string GetDecodedConfigValue(string strkey)
        {
            CryptInfo cryptInfo = new CryptInfo();
            SecurityFactory securityFactory = new SecurityFactory();
            string result = "";
            try
            {
                if (strkey != "" & strkey != null)
                {
                    if (System.Configuration.ConfigurationManager.AppSettings[strkey] != null)
                    {
                        string isEncrypt = ConfigurationManager.AppSettings["EnableEncryption"];
                        if (isEncrypt == "Y")
                        {
                            string ciphertext = System.Configuration.ConfigurationManager.AppSettings["CIPHERPASSWORD"];
                            cryptInfo.ValueToCrypt = System.Configuration.ConfigurationManager.AppSettings[strkey];
                            cryptInfo.CryptKey = ciphertext;
                            result = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);
                            // result = EncodeDecode.StringDecode(System.Configuration.ConfigurationManager.AppSettings[strkey], ciphertext);
                        }
                        else
                        {
                            result = System.Configuration.ConfigurationManager.AppSettings[strkey];
                        }
                    }
                    else
                    {
                        throw new Exception("The Specified Key not found.");
                    }
                }
            }
            catch (System.Configuration.ConfigurationErrorsException ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }

            return result;
        }
        internal List<BaseTransportEntity> MapToSupportTicketList(DataTable dt)
        {
            List<BaseTransportEntity> baseEntityList = new List<BaseTransportEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new SupportTicketEntity
                              {
                                  IssueId = Convert.ToInt32(p["iIssueId"] == DBNull.Value ? 0 : p["iIssueId"]),
                                  UserName = Convert.ToString(p["szUserName"] == DBNull.Value ? string.Empty : p["szUserName"]),
                                  EmailId = Convert.ToString(p["szEmailId"] == DBNull.Value ? string.Empty : p["szEmailId"]),
                                  QuartLoginId = Convert.ToString(p["szQuartLoginId"] == DBNull.Value ? string.Empty : p["szQuartLoginId"]),
                                  IssueSummary = Convert.ToString(p["szIssueSummary"] == DBNull.Value ? string.Empty : p["szIssueSummary"]),
                                  IssueDesc = Convert.ToString(p["szIssueDesc"] == DBNull.Value ? string.Empty : p["szIssueDesc"]),
                                  IssueModule = Convert.ToString(p["szIssueModule"] == DBNull.Value ? string.Empty : p["szIssueModule"]),
                                  IssueType = Convert.ToString(p["szIssueType"] == DBNull.Value ? string.Empty : p["szIssueType"]),
                                  PriorityType = Convert.ToString(p["szPriorityType"] == DBNull.Value ? string.Empty : p["szPriorityType"]),
                                  SelectedStatus = Convert.ToString(p["szStatus"] == DBNull.Value ? string.Empty : p["szStatus"]),
                                  WorkEffort = Convert.ToSingle(p["WorkEffort"] == DBNull.Value ? 0 : p["WorkEffort"]),
                                  CreatedUserName = Convert.ToString(p["iCreatedBy"] == DBNull.Value ? string.Empty : p["iCreatedBy"]),
                                  CreatedDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]),
                                  FileName = Convert.ToString(p["FileName"] == DBNull.Value ? string.Empty : p["FileName"]),
                                  FilePath = Convert.ToString(p["FilePath"] == DBNull.Value ? string.Empty : p["FilePath"]),
                                  TotalRows = Convert.ToInt32(p["TotalRows"] == DBNull.Value ? 0 : p["TotalRows"])

                              }).Cast<BaseTransportEntity>().ToList();



            return baseEntityList;
        }

        /// <summary>
        /// TO MAP DROPDOWN LIST
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<BaseTransportEntity> MapToDropDownList(DataTable dt)
        {
            List<BaseTransportEntity> EntityList = new List<BaseTransportEntity>();

            EntityList = (from p in dt.AsEnumerable()
                          select new TransDropDown
                          {
                              Value = Convert.ToString(p[0] == DBNull.Value ? string.Empty : p[0]),
                              Text = Convert.ToString(p[1] == DBNull.Value ? string.Empty : p[1])
                          }).Cast<BaseTransportEntity>().ToList();



            return EntityList;
        }

        internal List<BaseTransportEntity> MapToSupportTicketTrailList(DataTable dt)
        {
            List<BaseTransportEntity> baseEntityList = new List<BaseTransportEntity>();
            baseEntityList = (from p in dt.AsEnumerable()
                              select new SupportTicketTrailEntity
                              {
                                  IssueTrailId = Convert.ToInt32(p["iIssueTrailId"] == DBNull.Value ? 0 : p["iIssueTrailId"]),
                                  IssueId = Convert.ToInt32(p["iIssueId"] == DBNull.Value ? 0 : p["iIssueId"]),
                                  Status = Convert.ToString(p["szStatus"] == DBNull.Value ? string.Empty : p["szStatus"]),
                                  WorkEffort = Convert.ToSingle(p["fWorkEffort"] == DBNull.Value ? 0 : p["fWorkEffort"]),
                                  Comments = Convert.ToString(p["szComments"] == DBNull.Value ? string.Empty : p["szComments"]),
                                  CreatedUserName = Convert.ToString(p["UserName"] == DBNull.Value ? string.Empty : p["UserName"]),
                                  ModifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? string.Empty : p["dsModifiedDate"]),


                              }).Cast<BaseTransportEntity>().ToList();


            return baseEntityList;
        }

        internal SupportTicketEntity MapSupportTicketById(DataTable dt)
        {
            SupportTicketEntity obj = new SupportTicketEntity();
            obj = (from p in dt.AsEnumerable()
                   select new SupportTicketEntity
                   {

                       UserName = Convert.ToString(p["szUserName"] == DBNull.Value ? string.Empty : p["szUserName"]),
                       EmailId = Convert.ToString(p["szEmailId"] == DBNull.Value ? string.Empty : p["szEmailId"]),
                       QuartLoginId = Convert.ToString(p["szQuartLoginId"] == DBNull.Value ? string.Empty : p["szQuartLoginId"]),
                       IssueSummary = Convert.ToString(p["szIssueSummary"] == DBNull.Value ? string.Empty : p["szIssueSummary"]),
                       IssueDesc = Convert.ToString(p["szIssueDesc"] == DBNull.Value ? string.Empty : p["szIssueDesc"]),
                       SelectedIssueModule = Convert.ToString(p["szIssueModule"] == DBNull.Value ? string.Empty : p["szIssueModule"]),
                       SelectedIssueType = Convert.ToString(p["szIssueType"] == DBNull.Value ? string.Empty : p["szIssueType"]),
                       SelectedPriorityType = Convert.ToString(p["szPriorityType"] == DBNull.Value ? string.Empty : p["szPriorityType"]),
                       SelectedStatus = Convert.ToString(p["iStatusId"] == DBNull.Value ? string.Empty : p["iStatusId"]),
                       Comments = Convert.ToString(p["szComments"] == DBNull.Value ? string.Empty : p["szComments"]),
                       CreatedUserName = Convert.ToString(p["UserName"] == DBNull.Value ? string.Empty : p["UserName"]),
                       CreatedDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? string.Empty : p["dsCreatedDate"]),

                   }).FirstOrDefault();
            return obj;
        }
    }
}

