﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Notification
{
    public class CollaborationFactory: ICollaborationFactory
    {
        public ICollaboration GetCollaborationHandler(string collaborationType)
        {
            switch (collaborationType)
            {
                case S_CollaborationType.EMail:
                    return new MailCollaboration();

                default:
                    return null;
            }
        }

        public IContentTemplate GetTemplateHandler(string templateType)
        {
            switch (templateType)
            {
                case S_TemplateType.EMail:
                    return new MailContentTemplate();

                default:
                    return null;
            }
        }
      
    }
}
