﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Notification
{
    public interface ICollaboration
    {
        void send(EMailInfo objCollaborationInfo);
        ResponseInfo ValidateMailObject(EMailInfo objEMailInfo);
    }
}
