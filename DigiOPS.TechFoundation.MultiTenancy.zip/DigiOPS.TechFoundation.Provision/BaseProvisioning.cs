﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DigiOPS.TechFoundation.ProvisioningManagement
{
    public class BaseProvisioning : IProvisioning
    {

         public virtual string AddUpdateProgramFeatures(ProgramFeatureSetUp programEnt)
        {
            return null;
        }
         public virtual List<ProgramFeatureSetUp> GetProgramFeatures(int programId, string AppID, string TenantName)
        {
            return null;
        }

    }
}
