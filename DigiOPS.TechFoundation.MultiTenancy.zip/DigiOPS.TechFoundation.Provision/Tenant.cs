﻿////////////////////////////////////////////////////////////////////////////////////
// Copyright: <<2017>> << DigiOps TechFoundation >> ALL RIGHTS RESERVED 
////////////////////////////////////////////////////////////////////////////////////
// File Name :BaseScoringAlgorithm.cs
// Namespace : DigiOps.TechFoundation.MultiTenancy
// Class Name(s) :MultiTenant
// Author : Sujitha
// Creation Date : 9/5/2017
// Purpose : MultiTenant Insertion and Retrieval Methods 
//////////////////////// REVISIONS /////////////////////////////////////////////////////////////////
// Date           Name         Method Name               Description
// ----------   --------    -------------------------- --------------------------------------------------
//16-Apr-2017    XXXXX     SXXXXX            Added XXX method  
//////////////////////////////////////////////////////////////////////////////////////////////////////


using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Collections.ObjectModel;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Logging;
using DigiOPS.TechFoundation.Entities;
using System.Security;
using System.Runtime.InteropServices;


namespace DigiOPS.TechFoundation.ProvisioningManagement
{
    public class Tenant : ITenant
    {
        TenantDAL objMultiTenantDAL = new TenantDAL();
        DataTable db = new DataTable();
        LoggingFactory objlog = new LoggingFactory();
        LogInfo objloginfo = new LogInfo();


        /// <summary>
        /// Saves Tenant Details
        /// </summary>
        /// <param name="MultiTenancyInfo"></param>
        /// <returns>MultiTenantOutput</returns>
        public TenantInfo SaveTenantDetails(TenantInfo MultiTenancyInfo)
        {
            TenantInfo objMultiTenantOutput = new TenantInfo();
            objloginfo.Message = ("MultiTenancy - SaveTenantDetails - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            bool a = NullCheck(MultiTenancyInfo);
            if (a == false)
            {
                objMultiTenantOutput.ResultStatus = false;
                return objMultiTenantOutput;
            }

            bool valid = Validation(MultiTenancyInfo, "SaveTenantDetails");
            if (valid == true)
            {
                // MultiTenancyInfo.OperationName = "INSERT";
                try
                {
                    int output = objMultiTenantDAL.SaveTenantDetails(MultiTenancyInfo);

                    if (output < 1)
                    {
                        objMultiTenantOutput.ErrorMessage = new StringBuilder();
                        objMultiTenantOutput.ResultStatus = false;
                        objMultiTenantOutput.ErrorMessage.Append("Insertion of Tenant Details failed");
                    }
                    else
                    {
                        objMultiTenantOutput.ResultStatus = true;
                        objMultiTenantOutput.Output = output.ToString();
                    }
                }

                catch (Exception ex)
                {
                    objlog.GetLoggingHandler("Log4net").LogException(ex);
                }
            }
            else
            {
                objMultiTenantOutput.ResultStatus = false;
                return objMultiTenantOutput;
            }
            return objMultiTenantOutput;
        }

        /// <summary>
        /// Generates Database through PowerShell Script
        /// </summary>
        /// <param name="MultiTenancyInfo"></param>
        /// <returns>MultiTenantOutput</returns>
        public TenantInfo GenerateDataBase(TenantInfo MultiTenancyInfo)
        {
            StringBuilder sb = new StringBuilder();
            TenantInfo objMultiTenantOutput = new TenantInfo();
            objloginfo.Message = ("MultiTenancy - GenerateDataBase - Called.");
            objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
            int flag = 0;          
            bool a = NullCheck(MultiTenancyInfo);
            if (a == false)
            {
                objMultiTenantOutput.ResultStatus = false;
                return objMultiTenantOutput;
            }           
            bool valid = Validation(MultiTenancyInfo, "SaveTenantDetails");
            if (valid == true)
            {
                try
                {
                   
                    SecureString securepwd = convertToSecureString(MultiTenancyInfo.DatabaseDetails.Password);                   
                    PowerShell psExec = PowerShell.Create();
                    psExec.AddCommand(MultiTenancyInfo.DatabaseDetails.PSScriptPath);
                    psExec.AddArgument(MultiTenancyInfo.DatabaseDetails.ServerName);
                    psExec.AddArgument(MultiTenancyInfo.DatabaseDetails.DataBaseName);
                    psExec.AddArgument(MultiTenancyInfo.DatabaseDetails.UserName);
                    psExec.AddArgument(convertToUNSecureString(securepwd));//MultiTenancyInfo.DatabaseDetails.Password);
                    psExec.AddArgument(MultiTenancyInfo.DatabaseDetails.SQLScriptPath);
                    Collection<PSObject> results;
                    Collection<ErrorRecord> errors;
                    objloginfo.Message = (MultiTenancyInfo.DatabaseDetails.PSScriptPath + MultiTenancyInfo.DatabaseDetails.SQLScriptPath);
                    results = psExec.Invoke();                   
                    errors = psExec.Streams.Error.ReadAll();

                    if (errors.Count > 0)
                    {
                        foreach (ErrorRecord error in errors)
                        {
                            sb.AppendLine(error.ToString());
                            flag++;
                            //objloginfo.Message = (sb.ToString());
                            //objlog.GetLoggingHandler("Log4net").LogInfo(objloginfo);
                        }
                    }
                    else
                    {
                        foreach (PSObject result in results)
                        {
                            sb.AppendLine(result.ToString());
                        }
                    }
                    if (flag > 0 && results != null)
                    {
                        objMultiTenantOutput.ResultStatus = true;
                        objMultiTenantOutput.Output = "Database Created Successfully";
                    }
                    else //if (flag == 0)
                    {
                        objMultiTenantOutput.ResultStatus = false;
                        objMultiTenantOutput.Output = "Database creation failed";
                    }


                }


                catch (Exception ex)
                {
                    objlog.GetLoggingHandler("Log4net").LogException(ex);
                }
            }
            else
            {
                objMultiTenantOutput.ResultStatus = false;
                return objMultiTenantOutput;
            }
            return objMultiTenantOutput;
        }

        public string GetTenantConnectionString(string AppId, int TenantId)
        {
            TenantDAL tenant = new TenantDAL();
            DataTable dt = new DataTable();
            string ConnectionString = string.Empty;
            try
            {
                dt = tenant.GetConnectionStringDetails(AppId, TenantId);
                //string ConnectionString = "<add name=" + '"' + "ConnStr" + '"' + " connectionString=" + '"' + "Data Source=" + dt.Rows[0]["szServerName"] + "; Initial Catalog=" + dt.Rows[0]["szDatabaseName"] + ";  User Id=" + dt.Rows[0]["szUserId"] + "; Password=" + dt.Rows[0]["szPassword"] + "; Min Pool Size=10; Max Pool Size=100;Trusted_Connection=No;MultipleActiveResultSets=True;" + '"' + " providerName=" + '"' + "System.Data.SqlClient" + '"' + "/>";
                ConnectionString = "Data Source=" + dt.Rows[0]["szServerName"] + "; Initial Catalog=" + dt.Rows[0]["szDatabaseName"] + ";  User Id=" + dt.Rows[0]["szUserId"] + "; Password=" + dt.Rows[0]["szPassword"] + "; Min Pool Size=10; Max Pool Size=100;Trusted_Connection=No;MultipleActiveResultSets=True;";
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex); }
            return ConnectionString;
        }

        public string GetTenantConnectionString(string AppId, string TenantName)
        {
            TenantDAL tenant = new TenantDAL();
            string ConnectionString = string.Empty;
            try
            {
                ConnectionString = tenant.GetConnectionStringDetails(TenantName, AppId);
            }
            catch (Exception ex)
            { objlog.GetLoggingHandler("Log4net").LogException(ex); }
            return ConnectionString;
        }

        public SecureString convertToSecureString(string strPassword)
        {
            var secureStr = new SecureString();
            if (strPassword.Length > 0)
            {
                foreach (var c in strPassword.ToCharArray()) secureStr.AppendChar(c);
            }
            return secureStr;
        }


        public string convertToUNSecureString(SecureString secstrPassword)
        {
            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(secstrPassword);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }

        private bool Validation(TenantInfo MultiTenancyInfo, string method)
        {
            switch (method)
            {
                case "SaveTenantDetails":
                    foreach (var a in MultiTenancyInfo.TenantDetails)
                    {
                        if ((!(a.AccountId < 0)) && (!(a.Vertical < 0)) && (!(MultiTenancyInfo.TenantID < 0)) && a.EffectiveFrom != null && a.EffectiveTo != null
                            && (!String.IsNullOrEmpty(a.InstanceName)) && (!String.IsNullOrEmpty(a.LicenseKey))
                            && (!String.IsNullOrEmpty(MultiTenancyInfo.TenantName)) &&
                            (!String.IsNullOrEmpty(MultiTenancyInfo.DatabaseDetails.ServerName)) &&
                            (!String.IsNullOrEmpty(MultiTenancyInfo.DatabaseDetails.DataBaseName)) &&
                            (!String.IsNullOrEmpty(MultiTenancyInfo.DatabaseDetails.UserName)) &&
                            (!String.IsNullOrEmpty(MultiTenancyInfo.DatabaseDetails.Password)) &&
                            (!String.IsNullOrEmpty(MultiTenancyInfo.AppID)))
                        {
                            return MultiTenancyInfo.ResultStatus = true;
                        }
                        else
                        {
                            MultiTenancyInfo.ErrorMessage = new StringBuilder();
                            MultiTenancyInfo.ResultStatus = false;
                            MultiTenancyInfo.ErrorMessage.Append("Input's can't be null");
                            return MultiTenancyInfo.ResultStatus;
                        }
                    }
                    return MultiTenancyInfo.ResultStatus;
                    //break;
                case "GenerateDataBase":
                    if (MultiTenancyInfo.DatabaseDetails.DataBaseName != null || String.IsNullOrEmpty(MultiTenancyInfo.DatabaseDetails.DataBaseName) && MultiTenancyInfo.DatabaseDetails.UserName != null || String.IsNullOrEmpty(MultiTenancyInfo.DatabaseDetails.UserName) && String.IsNullOrEmpty(MultiTenancyInfo.DatabaseDetails.Password) || MultiTenancyInfo.DatabaseDetails.Password != null)
                    { return MultiTenancyInfo.ResultStatus = true; }
                    else
                    {
                        MultiTenancyInfo.ErrorMessage = new StringBuilder();
                        MultiTenancyInfo.ResultStatus = false;
                        MultiTenancyInfo.ErrorMessage.Append("Script Generation failed");
                        return MultiTenancyInfo.ResultStatus;
                    }
                   // break;
                case "GetTenantDBInfo":
                    int AppId = Convert.ToInt32(MultiTenancyInfo.AppID);
                    if (AppId > 0)
                    { return MultiTenancyInfo.ResultStatus = true; }
                    else
                    {
                        MultiTenancyInfo.ErrorMessage = new StringBuilder();
                        MultiTenancyInfo.ResultStatus = false;
                        MultiTenancyInfo.ErrorMessage.Append("Input's can't be null");
                        return MultiTenancyInfo.ResultStatus;
                    }
                   // break;
                default: return false;
            }

        }

        private bool NullCheck(TenantInfo MultiTenancyInfo)
        {
            if (MultiTenancyInfo == null)
            {
                TenantInfo objMultiTenancyInfo = new TenantInfo();
                objMultiTenancyInfo.ErrorMessage = new StringBuilder();
                objMultiTenancyInfo.ErrorMessage.Append("TenantInfo can't be null");
                objMultiTenancyInfo.ResultStatus = false;
                return objMultiTenancyInfo.ResultStatus;
            }
            else return MultiTenancyInfo.ResultStatus = true;
        }
    }
}

