﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.DataAccessLayer;
namespace DigiOPS.TechFoundation.ProvisioningManagement
{
    public class ProgramFeaturesProvision : BaseProvisioning
    {
        ProgramFeaturesDataAccess progda = null;
        public override string AddUpdateProgramFeatures(ProgramFeatureSetUp programEnt)
        {
            progda = new ProgramFeaturesDataAccess(programEnt.TenantName, programEnt.AppID);
            return progda.AddUpdateProgramFeatures(programEnt);
        }
        public override List<ProgramFeatureSetUp> GetProgramFeatures(int programId, string AppID,string TenantName)
        { progda = new ProgramFeaturesDataAccess(TenantName, AppID);
        return progda.GetProgramFeatures(programId, AppID, TenantName);
        }

    }
}
